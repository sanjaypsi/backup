/* ──────────────────────────────────────────────────────────────────────────
  Module Name:
    api.ts

  Module Description:
    Type definitions and API functions for asset data management.

  Details:
    - Defines interfaces and types for assets, table props, sorting, filtering, and related data structures.
        
  * Update and Modification History:
    * - 29-10-2025 - SanjayK PSI - Initial creation sorting pagination implementation.
    * - 20-11-2025 - SanjayK PSI - Fixed typo in filter property names handling.

  Functions:
    * fetchAssets: Fetches a paginated list of assets for a given project.
    * fetchAssetReviewInfos: Fetches review information for a specific asset and relation.
    * fetchAssetThumbnail: Fetches the thumbnail image for a specific asset and relation.
    * fetchPipelineSettingAssetComponents: Fetches asset component values from pipeline settings.
    * fetchLatestAssetComponents: Fetches the latest documents for specified asset components.
    * fetchGenerateAssetCsv: Initiates CSV generation for assets in a project.
    * fetchAssetsPivot: Fetches pivoted assets with filtering and sorting options. 
  * ───────────────────────────────────────────────────────────────────────── */




import { AuthorizationError } from '../../auth/types';
import { getAuthHeader, setNewToken } from '../../auth/util';
import { Value } from "../../new-pipeline-setting/types";
import { Asset, LatestAssetComponentDocumentsResponse, ReviewInfo, AssetsPivotResponse } from './types';

type ReviewInfoListResponse = {
  reviews: ReviewInfo[],
  next: string | null,
  total: number,
};

export type AssetsResponse = {
  assets: Asset[],
  total: number,
};



export const fetchAssets = async (
  project: string,
  page: number,
  rowsPerPage: number,
  signal?: AbortSignal | null,
): Promise<AssetsResponse> => {
  const headers = getAuthHeader();

  // keep your route; encode project parameter to ensure URL safety - Add by PSI
  let url: string = `/api/projects/${encodeURIComponent(project)}/reviews/assets`; // 

  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  url += `?${params.toString()}`; // Fix: convert params to string here - Add by PSI

  const res = await fetch(url, {
      method: 'GET',
      headers,
      mode: 'cors',
    signal: signal || undefined, // Fix: added missing comma here - Add by PSI
  });

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch parameters.');

  setNewToken(res);
  const json: AssetsResponse = await res.json();
  return json;
};

export const fetchAssetReviewInfos = async (
  project: string,
  asset: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<ReviewInfoListResponse> => {
  // keep your route names; just encode parameters to ensure URL safety - Add by PSI
  const url =
    `/api/projects/${(project)}` +
    `/assets/${(asset)}` +
    `/relations/${(relation)}/reviewInfos`;

  const headers = getAuthHeader();
  const res = await fetch(url, {
      method: 'GET',
      headers,
      mode: 'cors',
    signal: signal || undefined,
  });

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch review infos.');

  setNewToken(res);

  const json = await res.json();  // Fix: added missing comment end - Add by PSI
  // Basic validation to ensure expected structure
  if (!json || !Array.isArray(json.reviews) || typeof json.total !== 'number') {
    throw new Error('Invalid response format for review infos.');
  }
  return json as ReviewInfoListResponse; // Type assertion after validation - Add by PSI
};

export const fetchAssetThumbnail = async (
  project: string,
  asset: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  // keep your route name; just encode
  const url =
    `/api/projects/${(project)}` +
    `/assets/${(asset)}` +
    `/relations/${(relation)}/reviewthumbnail`;
  
  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 204) {
    return null; // 204 is allowed, it means the thumbnail does not exist.
  }
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch thumbnail.');
  }
  setNewToken(res);
  return res;
};

type ValueListResponse = Readonly<{
  values: Value[],
  next: string | null,
  total: number,
}>;

export const fetchPipelineSettingAssetComponents = async (
  project: string,
  signal?: AbortSignal | null,
): Promise<ValueListResponse> => {
  let url = `/api/pipelineSetting/preference/projects/${(project)}/values`;
  const params = new URLSearchParams();
  params.set('search_key', '/ppiTracker/assets/components/');
  url += `?${params}`;
  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch values.');
  }
  const json: ValueListResponse = await res.json();
  setNewToken(res);

  return json;
};

export const fetchLatestAssetComponents = async (
  project: string,
  asset: string,
  relation: string,
  components: string[],
  signal?: AbortSignal | null,
): Promise<LatestAssetComponentDocumentsResponse[]> => {
  let url = `/api/projects/${project}/latestAssetsOperationInfos`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('asset', asset);
  params.set('relation', relation);
  components.forEach(component => params.append('component', component));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch latest asset components.');
  }
  setNewToken(res);
  const json: LatestAssetComponentDocumentsResponse[] = await res.json();
  return json;
};

export const fetchGenerateAssetCsv = async (
  project: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  let url = `/api/projects/${project}/assets/generateCsv`;
  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to generate CSV.');
  }
  setNewToken(res);
  return res;
};

/* ========================================================================
   Fetch Assets Pivoted API
   - New function to fetch pivoted assets with filtering and sorting
   - Replaces previous fetchAssets implementation with enhanced functionality
   - Retains original fetchAssets and fetchAssetReviewInfos for backward compatibility
   - Uses URLSearchParams for cleaner query parameter handling
   - Encodes project, asset, and relation parameters to ensure URL safety
   - Improved error handling and response validation
   - Maintains consistent coding style with async/await and fetch API
   - Added comments for clarity and maintainability
   - Add by PSI
  ====================================================================== */
export const fetchAssetsPivot = async (
  project: string,
  page: number,
  rowsPerPage: number,
  sortKey: string,
  sortDir: string, // 'asc' | 'desc'
  phase: string,   // 'mdl' | 'rig' | 'bld' | 'dsn' | 'ldv' | 'none' | ''
  assetNameKey: string,       // Name filter (prefix, case-insensitive)
  approvalStatuses: string[], // Approval filter (OR within set)
  workStatuses: string[],     // Work filter (OR within set)
  view: 'list' | 'grouped', // View mode: list or grouped
  signal?: AbortSignal | null,
): Promise<AssetsPivotResponse> => {
  const headers = getAuthHeader();
  let url = `/api/projects/${(project)}/reviews/assets/pivot`;

  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  if (sortKey) params.set('sort', sortKey);
  if (sortDir) params.set('dir', sortDir.toUpperCase());
  if (phase)   params.set('phase', phase);

  // View mode parameter
  if (view) params.set('view', view);

  // ✅ Server expects these keys:
  // name (with name_mode=prefix), work (CSV), appr (CSV)
  const trimmed = (typeof assetNameKey === 'string' ? assetNameKey : '').trim();
  if (trimmed) {
    params.set('name', trimmed);
    params.set('name_mode', 'prefix'); // keep prefix per your spec
  }
  if (Array.isArray(workStatuses) && workStatuses.length > 0) {
    params.set('work', workStatuses.join(',')); // CSV
  }
  if (Array.isArray(approvalStatuses) && approvalStatuses.length > 0) {
    params.set('appr', approvalStatuses.join(',')); // CSV
  }

  url += `?${params.toString()}`;

  const res = await fetch(url, {
    method: 'GET',
    headers,
    mode: 'cors',
    signal: signal || undefined,
  });

  console.log('Fetching Assets Pivot with URL:', url); // Debug log

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch pivoted assets.');

  setNewToken(res);
  const json = (await res.json()) as AssetsPivotResponse;
  return json;
};

/* ──────────────────────────────────────────────────────────────────────────
  End of Module
  ───────────────────────────────────────────────────────────────────────── */  
import { AssetsGroupedPivotResponse } from './types';

export const fetchAssetsPivotGrouped = async (
  project: string,
  page: number,
  rowsPerPage: number,
  phase: string,
  assetNameKey: string,
  approvalStatuses: string[],
  workStatuses: string[],
  signal?: AbortSignal | null,
): Promise<AssetsGroupedPivotResponse> => {
  const headers = getAuthHeader();
  let url = `/api/projects/${project}/reviews/assets/pivot`;

  const params = new URLSearchParams();
  params.set('view', 'grouped');                 // IMPORTANT
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  if (phase) params.set('phase', phase);

  const trimmed = (typeof assetNameKey === 'string' ? assetNameKey : '').trim();
  if (trimmed) {
    params.set('name', trimmed);
    params.set('name_mode', 'prefix');
  }

  if (workStatuses.length) {
    params.set('work_status', workStatuses.join(','));
  }
  if (approvalStatuses.length) {
    params.set('approval_status', approvalStatuses.join(','));
  }

  url += `?${params.toString()}`;

  const res = await fetch(url, {
    method: 'GET',
    headers,
    mode: 'cors',
    signal: signal || undefined,
  });

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch grouped pivoted assets.');

  setNewToken(res);
  return (await res.json()) as AssetsGroupedPivotResponse;
};
