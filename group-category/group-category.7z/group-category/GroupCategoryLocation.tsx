import React, { useEffect, useState } from 'react';
import { queryPreference } from '../../pipeline-setting/api';
import { Project } from '../types';
import {
  Button,
  createStyles,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemSecondaryAction,
  ListItemText,
  makeStyles,
  Paper,
  Theme,
} from '@material-ui/core';
import { Category } from './types';
import AddIcon from '@material-ui/icons/Add';
import { createGroupCategory, deleteGroupCategory, updateGroupCategory } from './api';
import DeleteIcon from '@material-ui/icons/Delete';
import AddDialog from './GroupCategoryAddDialog';
import DeleteDialog from './GroupCategoryDeleteDialog';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    },
    container: {
      witdh: '100%',
      backgroundColor: theme.palette.background.paper,
      display: 'flex',
      overflow: 'auto hidden',
      '& > nav': {
        overflow: 'auto',
        marginRight: theme.spacing(.5),
        flexShrink: 0,
        '&:first-child': {
          marginLeft: theme.spacing(.5),
        },
      },
    },
  }),
);

type RootListProps = {
  project: Project,
  selected: string,
  setSelected: React.Dispatch<React.SetStateAction<string>>,
};

const RootList: React.FC<RootListProps> = ({
  project,
  selected,
  setSelected,
}) => {
  const [roots, setRoots] = useState<string[]>([]);

  useEffect(() => {
    if (roots.length !== 0) {
      setRoots([]);
      setSelected('');
    }

    const controller = new AbortController();

    (async () => {
      // The studio of the logged-in user cannot be determined because the authentication
      // feature has not been implemented yet.
      const studio = project.key_name == 'potoodev' ? 'ppidev' : 'ppi'

      const res: string[] | null = await queryPreference(
        'default',
        studio,
        project.key_name,
        '/ppip/roots',
        controller.signal,
      ).catch(err => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setRoots(res);
      }
    })();

    return () => {
      controller.abort();
    };
  }, [project]);

  const handlelistItemClick = (root: string) => {
    setSelected(root);
  };

  return (
    <List component="nav">
      {roots.map((root, index) => (
        <ListItem
          button
          selected={selected === root}
          key={index}
          onClick={() => handlelistItemClick(root)}
        >
          {root}
        </ListItem>
      ))}
    </List>
  );
};

type GroupCategoryListProps = {
  project: Project,
  root: string,
  selected: Category | null,
  setSelected: React.Dispatch<React.SetStateAction<Category | null>>,
  categories: Category[],
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>,
};

const GroupCategoryList: React.FC<GroupCategoryListProps> = ({
  project,
  root,
  selected,
  setSelected,
  categories,
  setCategories,
}) => {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [categoryTitles, setCategoryTitles] = useState<string[]>([]);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);

  useEffect(() => {
    if (categoryTitles.length !== 0) {
      setCategoryTitles([]);
    }

    const controller = new AbortController();

    (async () => {
      // The studio of the logged-in user cannot be determined because the authentication
      // feature has not been implemented yet.
      const studio = project.key_name == 'potoodev' ? 'ppidev' : 'ppi'

      const res: string[] | null = await queryPreference(
        'default',
        studio,
        project.key_name,
        `/ppip/roots/${root}/categories`,
        controller.signal,
      ).catch(err => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setCategoryTitles(res);
      }
    })();

    return () => {
      controller.abort();
    };

  }, [root])

  const handleListItemClick = (
    category: Category | null,
  ) => {
    setSelected(category);
  };

  const handleClickOpen = () => {
    setAddDialogOpen(true);
  };

  const handleAddDialogClose = () => {
    setAddDialogOpen(false);
  };

  const handleAddDialogAccept = (path: string) => {
    createGroupCategory(
      project.key_name,
      root,
      path,
    ).catch(err => {
      console.error(err);
    }).then(res => {
      if (res == null) {
        return;
      }
      setCategories([...categories, res]);
    });

    setAddDialogOpen(false);
  };

  const handleDeleteClick = (category: Category) => {
    setCategoryToDelete(category);
    setDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setCategoryToDelete(null);
  };

  const handleAcceptDeleteDialog = () => {
    if (categoryToDelete == null) {
      return;
    }
    deleteGroupCategory(
      project.key_name,
      categoryToDelete.id,
    ).catch(err => {
      console.error(err);
    }).then(() => {
      setCategories(categories.filter(c => c.id !== categoryToDelete.id));
    });
    setDeleteDialogOpen(false);
    setCategoryToDelete(null);
  };

  return (
    <>
      <List component="nav">
        {categories.map(category => (
          <ListItem
            key={category.id}
            button
            selected={selected != null ? category == selected : false}
            onClick={() => handleListItemClick(category)}
          >
            <ListItemText primary={category.path} />
            {category.groups.length === 0 && (
              <ListItemSecondaryAction>
                <IconButton
                  edge="end"
                  aria-label="delete"
                  onClick={() => handleDeleteClick(category)}
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </ListItemSecondaryAction>
            )}
          </ListItem>
        ))}
        {categoryTitles.length !== 0 && (
          <ListItem button onClick={handleClickOpen}>
            <ListItemIcon><AddIcon fontSize="small" /></ListItemIcon>
          </ListItem>
        )}
      </List>

      <AddDialog
        root={root}
        categoryTitles={categoryTitles}
        open={addDialogOpen}
        onClose={handleAddDialogClose}
        onAccept={handleAddDialogAccept}
      />

      {categoryToDelete != null && (
        <DeleteDialog
          category={categoryToDelete}
          open={deleteDialogOpen}
          onClose={handleCloseDeleteDialog}
          onAccept={handleAcceptDeleteDialog}
        />
      )}
    </>
  );
};

type GroupListProps = {
  project: Project,
  category: Category,
  onDelete: (category: Category) => void,
};

const GroupList: React.FC<GroupListProps> = ({ project, category, onDelete }) => {
  const [groupToDelete, setGroupToDelete] = useState<string | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const handleDeleteClick = (group: string) => {
    setGroupToDelete(group);
    setDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setGroupToDelete(null);
  };

  const handleAcceptDeleteDialog = () => {
    if (groupToDelete == null) {
      return;
    }
    updateGroupCategory(
      project.key_name,
      category.id,
      'remove',
      [groupToDelete],
    ).then(res => {
      if (res == null) {
        return;
      }
      onDelete(res);
    });
    setDeleteDialogOpen(false);
    setGroupToDelete(null);
  };

  return (
    <>
      <List component="nav">
        {category.groups.map(group =>
          <ListItem key={group} button >
            {group}
            <ListItemSecondaryAction>
              <IconButton
                edge="end"
                aria-label="delete"
                onClick={() => handleDeleteClick(group)}
              >
                <DeleteIcon fontSize="small" />
              </IconButton>
            </ListItemSecondaryAction>
          </ListItem>
        )}
      </List>
      {groupToDelete != null && (
        <Dialog open={deleteDialogOpen} aria-labelledby="delete-dialog-title">
          <DialogTitle id="delete-dialog-title">Delete Group</DialogTitle>
          <DialogContent>
            <DialogContentText>Group: {groupToDelete}</DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDeleteDialog}>Cancel</Button>
            <Button onClick={handleAcceptDeleteDialog} color="secondary">Accept</Button>
          </DialogActions>
        </Dialog>
      )}
    </>
  );
};

type GroupCategoryLocationProps = {
  project?: Project | null,
  root: string,
  setRoot: React.Dispatch<React.SetStateAction<string>>,
  categories: Category[],
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>,
};

const GroupCategoryLocation: React.FC<GroupCategoryLocationProps> = ({
  project,
  root,
  setRoot,
  categories,
  setCategories,
}) => {
  const classes = useStyles();
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const handleDeleteGroup = (target: Category) => {
    setCategories(
      categories.map(c => c.id === target.id ? target : c),
    );
  };
  useEffect(() => {
    if (selectedCategory == null) {
      return;
    }
    for (const category of categories) {
      if (category.id === selectedCategory.id) {
        setSelectedCategory(category);
        return;
      }
    }
    setSelectedCategory(null);
  }, [categories]);

  return (
    <Paper className={classes.root}>
      <div className={classes.container}>
        {project != null && (
          <>
            <RootList project={project} selected={root} setSelected={setRoot} />
            {root !== '' && (
              <GroupCategoryList
                project={project}
                root={root}
                selected={selectedCategory}
                setSelected={setSelectedCategory}
                categories={categories}
                setCategories={setCategories}
              />
            )}
            {selectedCategory != null &&
              <GroupList
                project={project}
                category={selectedCategory}
                onDelete={handleDeleteGroup}
              />
            }
          </>
        )}
      </div>
    </Paper>
  );
};

export default GroupCategoryLocation;
