import React, { useCallback, useEffect, useState } from 'react';
import { useCurrentProject } from '../hooks';
import { Container, createStyles, makeStyles, Theme } from '@material-ui/core';
import GroupCategoryLocation from './GroupCategoryLocation';
import GroupCategoryTable, { FilterForm, FilterState } from './GroupCategoryTable';
import { Category } from './types';
import { queryGroupCategories } from './api';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      padding: 0,
      '& > *': {
        display: 'flex',
        overflow: 'hidden',
        padding: theme.spacing(1),
        paddingBottom: 0,
      },
      '& > *:last-child': {
        paddingBottom: theme.spacing(1),
      },
    },
    locationContainer: {
      overflow: 'hidden',
      minHeight: 250,
    },
    filterContainer: {
      minHeight: 108,
    },
    tableContainer: {
      minHeight: 250,
    },
  }),
);

type Root = string;

type GlobalFilterState = Readonly<{
  [k: Root]: FilterState,
}>;

const initialFilter: FilterState = {
  group: '',
}

type GroupCategoryPanelProps = {};

const GroupCategoryPanel: React.FC<GroupCategoryPanelProps> = () => {
  const classes = useStyles();
  const { currentProject } = useCurrentProject();
  const [root, setRoot] = useState<Root>('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [filter, setFilter] = useState<GlobalFilterState>({});

  useEffect(() => {
    if (categories.length !== 0) {
      setCategories([]);
    }
    if (currentProject == null || root === '') {
      return;
    }

    const controller = new AbortController();

    (async () => {
      const res = await queryGroupCategories(
        currentProject.key_name,
        root,
        controller.signal,
      ).catch(err => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setCategories(res);
      }
    })();

    return () => {
      controller.abort();
    };
  }, [currentProject, root]);

  const setRootFilter = useCallback((rootFilter: FilterState) => {
    setFilter({ ...filter, [root]: rootFilter });
  }, [root]);

  return (
    <Container maxWidth="xl" className={classes.root}>
      <div className={classes.locationContainer}>
        <GroupCategoryLocation
          project={currentProject}
          root={root}
          setRoot={setRoot}
          categories={categories}
          setCategories={setCategories}
        />
      </div>
      {root !== '' && (
        <>
          <div className={classes.filterContainer}>
            <FilterForm
              filter={filter[root] || initialFilter}
              setFilter={setRootFilter}
            />
          </div>
          <div className={classes.tableContainer}>
            <GroupCategoryTable
              project={currentProject}
              root={root}
              categories={categories}
              setCategories={setCategories}
              filter={filter[root] || initialFilter}
            />
          </div>
        </>
      )}
    </Container>
  );
};

export default GroupCategoryPanel;
