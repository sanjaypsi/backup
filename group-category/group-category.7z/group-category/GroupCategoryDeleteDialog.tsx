import React from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@material-ui/core';
import { Category } from './types';

export type DeleteDialogProps = {
  category: Category,
  open: boolean,
  onClose: () => void,
  onAccept: () => void,
};

export const DeleteDialog: React.FC<DeleteDialogProps> = ({
  category,
  open,
  onClose,
  onAccept,
}) => {
  return (
    <Dialog open={open} aria-labelledby="delete-dialog-title">
      <DialogTitle id="delete-dialog-title">Delete Group Category</DialogTitle>
      <DialogContent>
        <DialogContentText>
          Root: {category.root}<br />
          Category: {category.path}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={onAccept} color="secondary">Accept</Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteDialog;
