import { getAuthHeader, setNewToken } from '../../auth/util';
import { Category } from './types';

type Response = Readonly<{
  categories: Category[],
  next: string | null,
}>;

export async function queryGroupCategories(
  project: string,
  root: string,
  signal?: AbortSignal | null,
): Promise<Category[] | null> {
  const headers = getAuthHeader();
  const categories: Category[] = [];

  const params = new URLSearchParams();
  params.append('root', root);
  params.append('order_by', 'path');
  let url: string | null = `/api/projects/${project}/groupCategories?${params}`;

  while (url != null) {
    const res = await fetch(
      url,
      {
        method: 'GET',
        headers,
        mode: 'cors',
        signal
      }
    );
    if (res.status == 401) {
      return null;
    }
    if (!res.ok) {
      throw new Error('Failed to fetch group categories.');
    }
    setNewToken(res);
    const json: Response = await res.json();
    categories.push(...json.categories);
    url = json.next;
  }

  return categories;
}

export async function createGroupCategory(
  project: string,
  root: string,
  path: string,
  signal?: AbortSignal | null,
): Promise<Category | null> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/projects/${project}/groupCategories`,
    {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ root, path }),
      signal,
    },
  ).catch(err => {
    throw err;
  });
  if (res.status == 401) {
    return null;
  }
  if (!res.ok) {
    throw new Error('Failed to create group category.');
  }
  setNewToken(res);
  return await res.json();
}

export async function updateGroupCategory(
  project: string,
  id: number,
  operation: 'add' | 'remove',
  groups: string[],
  signal?: AbortSignal | null,
): Promise<Category | null> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/projects/${project}/groupCategories/${id}`,
    {
      method: 'PATCH',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ operation, groups }),
      signal,
    },
  ).catch(err => {
    throw err;
  });
  if (res.status == 401) {
    return null;
  }
  if (!res.ok) {
    throw new Error('Failed to update group category.');
  }
  setNewToken(res);
  return await res.json();
}

export async function deleteGroupCategory(
  project: string,
  id: number,
  signal?: AbortSignal | null,
): Promise<void> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/projects/${project}/groupCategories/${id}`,
    {
      method: 'DELETE',
      headers,
      mode: 'cors',
      signal,
    },
  ).catch(err => {
    throw err;
  });
  if (res.status == 401) {
    return;
  }
  if (!res.ok) {
    throw new Error('Failed to delete group category.');
  }
  setNewToken(res);
}
