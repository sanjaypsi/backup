import React from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  TextField,
  Theme,
  createStyles,
  makeStyles,
} from '@material-ui/core';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    formControll: {
      flexDirection: 'row',
    },
    textField: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
    },
  }),
);

type FieldProps = {
  title: string,
  inputRef: React.Ref<any>,
  onChange: (text: string) => void,
};

const Field: React.FC<FieldProps> = ({ title, inputRef, onChange }) => {
  const classes = useStyles();
  const [errorMessage, setErrorMessage] = React.useState<string>('');

  const handleTextChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const text = event.target.value;
    if (text.includes(' ')) {
      setErrorMessage('Cannot contain spaces.');
    } else {
      setErrorMessage('');
    }
    onChange(text);
  };

  return (
    <TextField
      margin="dense"
      title={title}
      inputRef={inputRef}
      className={classes.textField}
      error={errorMessage !== ''}
      helperText={errorMessage}
      onChange={handleTextChange}
    />
  );
};

export type AddDialogProps = {
  root: string,
  categoryTitles: string[],
  open: boolean,
  onClose: () => void,
  onAccept: (path: string) => void,
};

export const AddDialog: React.FC<AddDialogProps> = ({
  root,
  categoryTitles,
  open,
  onClose,
  onAccept,
}) => {
  const classes = useStyles();
  const itemEls = React.useRef<HTMLInputElement[]>([]);
  const [canAccept, setCanAccept] = React.useState<boolean>(false);

  const handleTextChange = () => {
    for (const elm of itemEls.current) {
      const text = elm.value;
      if (text === '' || text.includes(' ')) {
        setCanAccept(false);
        return;
      }
    }
    setCanAccept(true);
  };

  const handleAccept = () => {
    const values: string[] = [];
    for (const el of itemEls.current) {
      const text = el.value;
      if (text === '' || text.includes(' ')) {
        return;
      }
      values.push(text);
    }
    if (values.length === 0) {
      return;
    }
    onAccept(values.join('/'));
  };

  return (
    <Dialog open={open} aria-labelledby="add-dialog-title">
      <DialogTitle id="add-dialog-title">Add Group Category</DialogTitle>
      <DialogContent>
        <DialogContentText>
          Root: {root}
        </DialogContentText>
        <FormControl fullWidth className={classes.formControll}>
          {categoryTitles.map((title, index) => (
            <Field
              key={title}
              title={title}
              inputRef={elm => itemEls.current[index] = elm}
              onChange={handleTextChange}
            />
          ))}
        </FormControl>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button disabled={!canAccept} onClick={handleAccept}>Accept</Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddDialog;
