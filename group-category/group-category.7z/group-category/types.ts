export type Category = Readonly<{
  id: number,
  project: string,
  root: string,
  path: string,
  depth: number,
  groups: string[],
}>;

export type Group = Readonly<{
  path: string,
}>;
