/* ──────────────────────────────────────────────────────────────────────────
  Module Name:
    AssetsDataTableFooter.tsx

  Module Description:
    Footer component for the Assets Data Table, providing pagination controls.
  Details:
    - Utilizes Material-UI components for styling and functionality.
    - Custom pagination actions for navigating through asset data pages.

  Author:
    - 
  
  Function:
    AssetsDataTableFooter: React.FC<Props>
      - Renders the footer of the assets data table with pagination controls.
    ────────────────────────────────────────────────────────────────────────── */

import React from 'react';
import { TableFooter, TablePagination, TableRow, IconButton } from '@material-ui/core';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import { styled } from '@material-ui/core';
import {
  FirstPage as FirstPageIcon,
  KeyboardArrowLeft as KeyboardArrowLeftIcon,
  KeyboardArrowRight as KeyboardArrowRightIcon,
  LastPage as LastPageIcon,
} from '@material-ui/icons';
import { IconButtonProps } from '@material-ui/core/IconButton';


const StyledDiv = styled('div')(({ theme }) => ({
  flexShrink: 0,
  color: theme.palette.text.secondary,
  marginLeft: theme.spacing(2.5),
}));

const StyledTableFooter = styled(TableFooter)(({ theme }) => ({
  position: 'sticky',
  bottom: 0,
  backgroundColor: theme.palette.background.paper,
}));

const StyledTablePagination = styled(TablePagination)({
  width: '100%',
  '&:last-child': {
    paddingRight: '10%',
  },

  // ✅ keep pagination controls on the right even when only a few columns are visible (group view)
  '& .MuiTablePagination-toolbar': {
    width: '100%',
    justifyContent: 'flex-end',
  },
  '& .MuiTablePagination-spacer': {
    flex: '1 1 auto',
  },
});

type TablePaginationActionsProps = {
  count: number,
  page: number,
  rowsPerPage: number,
  onChangePage: TablePaginationProps['onChangePage'],
};

export const TablePaginationActions: React.FC<TablePaginationActionsProps> = ({
  count,
  page,
  rowsPerPage,
  onChangePage,
}) => {
  const handleFirstButtonClick: IconButtonProps['onClick'] = event => {
    onChangePage(event, 0);
  };

  const handlePrevButtonClick: IconButtonProps['onClick'] = event => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick: IconButtonProps['onClick'] = event => {
    onChangePage(event, page + 1);
  };

  const handleLastButtonClick: IconButtonProps['onClick'] = event => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <StyledDiv>
      <IconButton
        onClick={handleFirstButtonClick}
        disabled={page === 0}
        aria-label="First Page"
      >
        <FirstPageIcon />
      </IconButton>
      <IconButton
        onClick={handlePrevButtonClick}
        disabled={page === 0}
        aria-label="Previous Page"
      >
        <KeyboardArrowLeftIcon />
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="Next Page"
      >
        <KeyboardArrowRightIcon />
      </IconButton>
      <IconButton
        onClick={handleLastButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="Last Page"
      >
        <LastPageIcon />
      </IconButton>
    </StyledDiv>
  );
};

type Props = {
  count: number,
  page: number,
  rowsPerPage: number,
  onChangePage: TablePaginationProps['onChangePage'],
  onChangeRowsPerPage: TablePaginationProps['onChangeRowsPerPage'],
};

const AssetsDataTableFooter: React.FC<Props> = ({
  count,
  page,
  rowsPerPage,
  onChangePage,
  onChangeRowsPerPage,
}) => {
  return (
    <StyledTableFooter>
      <TableRow>
        <StyledTablePagination
          rowsPerPageOptions={[15, 30, 60, 120, 240]}
          count={count}
          rowsPerPage={rowsPerPage}
          // ✅ Clamp page index so we never render an out-of-range page
          page={Math.max(0, Math.min(page, Math.max(0, Math.ceil(count / rowsPerPage) - 1)))}
          onChangePage={onChangePage}
          onChangeRowsPerPage={onChangeRowsPerPage}
          ActionsComponent={TablePaginationActions}
        />
      </TableRow>
    </StyledTableFooter>
  );
};

export default AssetsDataTableFooter;