from typing import Any

from ppui.PySide.QtCore import Qt, QEvent, QObject, QTimer, QPoint
from ppui.PySide.QtGui import (
    QColor,
    QMouseEvent,
    QPainter,
    QPaintEvent,
    QPen,
    QStandardItem,
    QStandardItemModel,
)
from ppui.PySide.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QListView,
    QMessageBox, # added import for QMessageBox
    QPushButton,
    QScrollArea,
    QSpinBox,
    QWidget,
    QVBoxLayout,
    QTextEdit,
    QSizePolicy,
)

from .apiClient import ApiClient
from .tableData import Column


MIXED_TEXT = 'MULTI'  # Text to display for mixed values in multi-edit mode
MIXED_DATA = '__ppi_tracker_mixed__' # Data to represent mixed values in multi-edit mode


class ResizableTextEdit(QTextEdit):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setMinimumHeight(60)
        self.setMaximumHeight(300)
        self._resizing = False
        self._dragStartPos = QPoint()
        self._startHeight = 0
        self._isMixed = False # Flag to indicate if the text edit is in mixed state
        self.setMouseTracking(True)
        self.textChanged.connect(self._clearMixed) # Connect textChanged signal to clear mixed state when user edits the text

    # Set the text edit to mixed state
    def setMixed(self):
        self._isMixed = True
        self.setPlaceholderText(MIXED_TEXT)

    # Check if the text edit is in mixed state
    def isMixed(self) -> bool:
        return self._isMixed

    # Clear the mixed state when the user edits the text
    def _clearMixed(self):
        self._isMixed = False

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            vpGeo = self.viewport().geometry()
            bottomRight = vpGeo.bottomRight()
            pos = event.position()
            isXBottomRight = pos.x() <= bottomRight.x()
            isYBottomRight = pos.y() <= bottomRight.y()

            isWidthArea = bottomRight.x() - pos.x() < 15
            isHeightArea = bottomRight.y() - pos.y() < 15
            if isWidthArea and isHeightArea and isXBottomRight and isYBottomRight:
                self._resizing = True
                self._dragStartPos = event.globalPosition().toPoint()
                self._startHeight = self.height()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._resizing:
            delta = event.globalPosition().toPoint().y() - self._dragStartPos.y()
            newHeight = max(60, min(300, self._startHeight + delta))
            self.setFixedHeight(newHeight)
            return

        super().mouseMoveEvent(event)

        vpGeo = self.viewport().geometry()
        bottomRight = vpGeo.bottomRight()
        pos = event.position()
        isXBottomRight = pos.x() <= bottomRight.x()
        isYBottomRight = pos.y() <= bottomRight.y()
        isWidthArea = bottomRight.x() - pos.x() < 15
        isHeightArea = bottomRight.y() - pos.y() < 15
        if isWidthArea and isHeightArea and isXBottomRight and isYBottomRight:
            self.viewport().setCursor(Qt.CursorShape.SizeVerCursor)
        else:
            self.viewport().setCursor(Qt.CursorShape.IBeamCursor)

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        if self._resizing:
            self._resizing = False
            return
        super().mouseReleaseEvent(event)

    def paintEvent(self, event: QPaintEvent):
        super().paintEvent(event)
        # Draw resize grip indicator (three lines)
        painter = QPainter(self.viewport())
        painter.setPen(QPen(QColor(150, 150, 150), 1))
        w = self.viewport().width()
        h = self.viewport().height()

        for i in range(1, 4):
            offset = i * 4
            painter.drawLine(w - offset, h, w, h - offset)


class EntityEditorDialog(QDialog):
    # This dialog allows editing of one or multiple entities. It dynamically creates input widgets based on the provided columns and their data types. It also handles mixed values for multi-edit scenarios.
    @staticmethod
    def _getColumnValueState(
        entityData: list[dict[str, Any]],
        columnKey: str,
    ) -> tuple[Any, bool]:
        values = [
            '' if data.get(columnKey) is None else data.get(columnKey)
            for data in entityData
        ]
        commonValue = values[0] if values else None
        hasMixedValues = any(value != commonValue for value in values[1:])
        return commonValue, hasMixedValues

    def __init__(
        self,
        api: ApiClient,
        root: str,
        groups: list[str], # List of entity groups to edit
        columns: list[Column],
        entities: list[dict[str, Any] | None], # List of entity data dictionaries corresponding to the groups. If an entity is None, it indicates a new entity will be created for that group.
        parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self._api = api
        self._root = root
        self._groups = groups # List of entity groups to edit
        self._columns = columns
        self._entities = entities # List of entity data dictionaries corresponding to the groups. If an entity is None, it indicates a new entity will be created for that group.
        
        # Determine if this is a multi-edit scenario based on the number of groups
        self._isMultiEdit = len(groups) > 1
        if self._isMultiEdit:
            self.setWindowTitle(f'[{root.title()}] Edit {len(groups)} Entities')
        else:
            self.setWindowTitle(f'[{root.title()}:{groups[0]}] Edit Entity')
        self.resize(500, 600)

        self._mainLayout = QVBoxLayout(self)
        self._scrollArea = QScrollArea()
        self._scrollArea.setWidgetResizable(True)
        self._contentWidget = QWidget()

        self._layout = QFormLayout(self._contentWidget)
        self._widgets: dict[str, tuple[QWidget, str]] = {}
        self._columnDisplayNames: dict[str, str] = {} # Mapping of column keys to their display names
        self._initialData: dict[str, Any] = {} # Initial values of the columns before any edits
        self._existingValueKeys: set[str] = set() # Set of column keys that have existing values in the entities
        self._mixedKeys: set[str] = set() # Set of column keys that have mixed values across the entities
        entityData = [entity.get('data', {}) if entity else {} for entity in self._entities] # List of entity data dictionaries corresponding to the groups. If an entity is None, it indicates a new entity will be created for that group.

        self._savedRoot = root
        self._savedGroups = list(groups) # List of groups for which the entities were saved
        self._savedData: dict[str, Any] = {} # Data that was saved for the entities

        for col in self._columns:
            if not col.visibled():
                continue

            key = col.key()
            dtype = col.dataType()
            display = col.displayName()
            isSys = col.isSystem()
            scope = 'project' if not col.scope() else col.scope()
            oldValues = [data.get(key) for data in entityData] # List of old values for the current column across all entities
            if any(value is not None and str(value) != '' for value in oldValues): # Check if any entity has an existing value for this column
                self._existingValueKeys.add(key) # Mark this column as having existing values in the entities

            # Show scope in label
            labelText = f'{display}'
            if isSys:
                labelText += ' [System]'
            labelText += ' (Global)' if scope == 'global' else ' (Project)'

            currentVal, isMixed = self._getColumnValueState(entityData, key) # Get the common value and mixed state for the current column across all entities
            if self._isMultiEdit and key in self._existingValueKeys: # If this is a multi-edit scenario and the column has existing values, mark it as mixed
                isMixed = True # Mark the column as having mixed values
            if isMixed: # If the column has mixed values, add it to the mixed keys set
                self._mixedKeys.add(key) # Mark the column as having mixed values
            else:
                self._initialData[key] = currentVal # Store the initial value for the column if it's not mixed

            widget = None
            if dtype == 'array':
                # select ComboBox
                isMulti = col.config().get('multi_select', False)
                if isMulti:
                    widget = CheckableComboBox()
                else:
                    widget = QComboBox()
                    widget.addItem('')

                # Add options
                opts = col.config().get('options', [])
                widget.addItems(opts)

                # Set the current value or mixed state for the widget
                if isMixed:
                    if isinstance(widget, CheckableComboBox):
                        widget.setMixed()
                    else:
                        widget.insertItem(0, MIXED_TEXT, MIXED_DATA)
                        widget.setCurrentIndex(0)
                elif currentVal is not None:
                    if isMulti:
                        vals = [val.strip() for val in str(currentVal).split(',')] # Split the current value into a list of values for multi-select
                        for v in vals:
                            index = widget.findText(v)
                            if index != -1:
                                widget.model().item(index).setCheckState(Qt.CheckState.Checked)
                    else:
                        widget.setCurrentText(str(currentVal))
            elif dtype == 'int':
                widget = QSpinBox()
                # Set the range and special value text for mixed state
                if isMixed:
                    widget.setRange(-1000000, 999999)
                    widget.setSpecialValueText(MIXED_TEXT)
                    widget.setValue(widget.minimum())
                else:
                    widget.setRange(-999999, 999999)
                if currentVal is not None and not isMixed:
                    try:
                        widget.setValue(int(currentVal))
                    except (ValueError, TypeError):
                        # Align initial data with the widget's fallback value to avoid
                        # overwriting existing values when parsing fails.
                        self._initialData[key] = widget.value()
            elif dtype == 'float':
                widget = QDoubleSpinBox()
                widget.setRange(-999999.99, 999999.99)
                widget.setDecimals(2)
                # Set the range and special value text for mixed state
                if isMixed:
                    widget.setRange(-1000000.99, 999999.99)
                    widget.setSpecialValueText(MIXED_TEXT)
                    widget.setValue(widget.minimum())
                else:
                    widget.setRange(-999999.99, 999999.99)
                if currentVal is not None and not isMixed:
                    try:
                        widget.setValue(float(currentVal))
                    except (ValueError, TypeError):
                        # Align initial data with the widget's fallback value to avoid
                        # overwriting existing values when parsing fails.
                        self._initialData[key] = widget.value()
            elif dtype == 'bool':
                widget = QCheckBox()
                # Set the check state for mixed values
                if isMixed:
                    widget.setTristate(True)
                    widget.setCheckState(Qt.CheckState.PartiallyChecked)
                else:
                    widget.setChecked(bool(currentVal))
            elif dtype == 'string':
                widget = ResizableTextEdit()
                # Set the mixed state or current value for the text edit
                if isMixed:
                    widget.setMixed()
                elif currentVal:
                    widget.setText(str(currentVal))

            if widget is None:
                continue
            # Store the display name for the column key
            # This is used later to show user-friendly names in confirmation dialogs.
            self._columnDisplayNames[key] = display
            if not isMixed:
                if dtype == 'array':
                    if isinstance(widget, CheckableComboBox):
                        self._initialData[key] = ', '.join(widget.getCheckedItems())
                    else:
                        self._initialData[key] = widget.currentText()
                elif dtype in ('int', 'float'):
                    self._initialData[key] = widget.value()
                elif dtype == 'bool':
                    self._initialData[key] = widget.isChecked()
                elif dtype == 'string':
                    self._initialData[key] = widget.toPlainText()
            self._layout.addRow(f'{labelText}:', widget)
            self._widgets[key] = (widget, dtype)

        self._scrollArea.setWidget(self._contentWidget)
        self._mainLayout.addWidget(self._scrollArea)

        btnSave = QPushButton('Save')
        btnSave.clicked.connect(self.save)
        self._mainLayout.addWidget(btnSave)

    # Collects the changes made in the dialog and returns a dictionary of the changed values. It compares the current values of the widgets with the initial values and only includes those that have changed or are marked as mixed.
    # Returns:
    #     dict[str, Any]: A dictionary containing the changed values for each column key.
    def _collectChanges(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        for key, (widget, dtype) in self._widgets.items():
            isMixed = key in self._mixedKeys
            if dtype == 'array':
                if isinstance(widget, CheckableComboBox):
                    if isMixed and widget.isMixed():
                        continue
                    data[key] = ', '.join(widget.getCheckedItems())
                else:
                    if isMixed and widget.currentData() == MIXED_DATA:
                        continue
                    data[key] = widget.currentText()
            elif dtype == 'int':
                if isMixed and widget.value() == widget.minimum():
                    continue
                data[key] = widget.value()
            elif dtype == 'float':
                if isMixed and widget.value() == widget.minimum():
                    continue
                data[key] = widget.value()
            elif dtype == 'bool':
                if isMixed and widget.checkState() == Qt.CheckState.PartiallyChecked:
                    continue
                data[key] = widget.isChecked()
            elif dtype == 'string':
                if isMixed and widget.isMixed():
                    continue
                data[key] = widget.toPlainText()

        sendData: dict[str, Any] = {}
        for key, value in data.items():
            if key in self._mixedKeys or value != self._initialData.get(key):
                sendData[key] = value
        return sendData

    # Prompts the user to confirm overwriting existing values if any of the changed keys already have old values. It displays a message box with the list of columns that will be overwritten and asks for confirmation.
    # Args:
    #     sendData (dict[str, Any]): A dictionary containing the changed values for each column key.
    # Returns:
    #     bool: True if the user confirms overwriting the existing values, False otherwise.
    def _confirmOverwrite(self, sendData: dict[str, Any]) -> bool:
        changedExistingKeys = [
            key for key in sendData
            if key in self._existingValueKeys or key in self._mixedKeys
        ]
        if not changedExistingKeys:
            return True

        columnNames = [
            self._columnDisplayNames.get(key, key)
            for key in changedExistingKeys
        ]
        if len(columnNames) == 1:
            message = (
                f'"{columnNames[0]}" already has an old value.\n\n'
                'Click Ok to replace the old values with the new value, '
                'or Cancel to keep the old values.'
            )
        else:
            message = (
                'These columns already have old values:\n'
                f'{", ".join(columnNames)}\n\n'
                'Click Ok to replace the old values with the new values, '
                'or Cancel to keep the old values.'
            )

        confirm = QMessageBox.question(
            self,
            'Confirm Replace Values',
            message,
            QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        return confirm == QMessageBox.StandardButton.Ok

    # Saves the changes made in the dialog. It collects the changed values, checks for confirmation if any existing values will be overwritten, and then updates or creates entities using the API client. If no changes were made, it rejects the dialog.
    def save(self):
        sendData = self._collectChanges() # Collect the changes made in the dialog
        if not sendData:
            self.reject()
            return
        # Check if any of the changed keys already have old values and prompt for confirmation
        if not self._confirmOverwrite(sendData):
            return

        # Update or create entities for each group based on the collected changes
        for group, entity in zip(self._groups, self._entities):
            if entity:
                self._api.updateEntity(entity['id'], self._root, group, sendData)
            else:
                self._api.createEntity(self._root, group, sendData)

        self._savedRoot = self._root
        self._savedGroups = list(self._groups) # List of groups for which the entities were saved
        self._savedData = sendData # Data that was saved for the entities
        self.accept()

    def getSavedInfo(self) -> tuple[str, list[str], dict[str, Any]]: # Returns the saved information after the dialog is accepted. It includes the root, list of groups, and the data that was saved for the entities.
        return self._savedRoot, self._savedGroups, self._savedData # Returns a tuple containing the root, list of groups, and the data that was saved for the entities after the dialog is accepted.


class CheckableComboBox(QComboBox):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self._model = QStandardItemModel(self)
        self._isMixed = False # Flag to indicate if the combo box is in mixed state
        self.setModel(self._model)
        self.setView(QListView())
        self._model.itemChanged.connect(self.updateDisplayText)
        self.currentIndexChanged.connect(self.updateDisplayText)
        self.view().viewport().installEventFilter(self)

    def model(self) -> QStandardItemModel:
        return self._model

    def addItem(self, text: str, userData: Any = None):
        item = QStandardItem(text)
        item.setData(userData)
        item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        item.setCheckState(Qt.CheckState.Unchecked)
        self._model.appendRow(item)

    def addItems(self, texts: list[str], userData: list[Any] | None = None):
        if userData is None:
            userData = [None] * len(texts)
        for text, userData in zip(texts, userData):
            self.addItem(text, userData)

    # Set the combo box to mixed state
    def setMixed(self):
        self._isMixed = True
        self.lineEdit().setText(MIXED_TEXT)

    def isMixed(self) -> bool:
        return self._isMixed

    def updateDisplayText(self, _: QStandardItem | None = None):
        def _update():
            if self._isMixed: # If the combo box is in mixed state, display the mixed text and return
                self.lineEdit().setText(MIXED_TEXT) # Set the line edit text to indicate mixed values
                return # If the combo box is in mixed state, display the mixed text and return
            checkedItems: list[str] = []
            for index in range(self._model.rowCount()):
                _item = self._model.item(index)
                if _item.checkState() == Qt.CheckState.Checked:
                    checkedItems.append(_item.text())
            text = ', '.join(checkedItems) if checkedItems else ''
            self.lineEdit().setText(text)
        QTimer.singleShot(0, _update)

    def getCheckedItems(self) -> list[str]:
        checkedData: list[str] = []
        for index in range(self._model.rowCount()):
            item = self._model.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                checkedData.append(item.text())
        return checkedData

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if watched == self.view().viewport():
            if event.type() == QEvent.Type.MouseButtonRelease:
                index = self.view().indexAt(event.position().toPoint())
                item = self._model.itemFromIndex(index)
                if item is None: # If the click is outside any item, ignore it
                    return False # If the click is outside any item, ignore it
                self._isMixed = False # Clear the mixed state when the user interacts with the combo box
                if item.checkState() == Qt.CheckState.Checked:
                    item.setCheckState(Qt.CheckState.Unchecked)
                else:
                    item.setCheckState(Qt.CheckState.Checked)
                return True
        return False