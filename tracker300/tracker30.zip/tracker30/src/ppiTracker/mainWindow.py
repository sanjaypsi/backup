import csv
from logging import getLogger
from typing import Any, Iterator

from ppilib.core.launcher import AppInfo
from ppilib.core.phase.structure2 import Group
from ppilib.desktop.setting import DesktopPipelineSetting # noqa: F401
from ppui.PySide.QtCore import (
    QEvent, # noqa: F401
    QItemSelectionModel,
    QModelIndex,
    QPersistentModelIndex,
    QPoint,
    QSize,
    QSortFilterProxyModel,
    Qt,
)
from ppui.PySide.QtGui import (
    QAction,
    QColor,
    QIcon,
    QImage,
    QPalette,
    QPixmap,
    QStandardItem,
    QStandardItemModel,
)
from ppui.PySide.QtWidgets import (
    QAbstractItemView,
    QButtonGroup,
    QDialog,
    QFileDialog,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMenuBar,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QTableView,
    QTreeView,
    QWidget,
    QVBoxLayout,
)

from .apiClient import ApiClient
from .centralClient import Sections
from .columnManagerDialog import ColumnListDialog
from .config import CsvEntityData
from .confirmImportDialog import ConfirmImportDialog
from .entityEditorDialog import EntityEditorDialog
from .roleManagerDialog import RoleManagerDialog
from .service import LoadThumbnailPathsTask, LoadThumbnailTask, Service, ThreadPool, ThumbnailPaths
from .state import State
from .tableData import Column, Entity, DataRepository
from .userRole import RoleManager # noqa: F401
from .ui.mainWindow import Ui_MainWindow
from .userRole import Permission

_logger = getLogger(__name__)

READ_ONLY_COLUMN_KEYS = ('name', 'thumbnail', 'cut_number') # noqa: E501
GENERATED_COLUMN_KEYS = ('cut_number',) # noqa: E501


class KeywordFilterProxyModel(QSortFilterProxyModel):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._pattern = ''
        self._keywords: list[str] = []

    def setKeywordFilterPattern(self, text: str):
        self._pattern = text.lower()
        self._keywords = [k for k in self._pattern.split() if k]
        self.invalidateFilter()

    def filterAcceptsRow(
        self,
        source_row: int,
        source_parent: QModelIndex | QPersistentModelIndex,
    ) -> bool:
        if not self._keywords:
            return True

        model = self.sourceModel()
        cols = model.columnCount(source_parent)

        for kw in self._keywords:
            kwFound = False
            for col in range(cols):
                index = model.index(source_row, col, source_parent)
                data = model.data(index, Qt.ItemDataRole.UserRole + 3)
                if data is not None and kw in str(data).lower():
                    kwFound = True
                    break
            if not kwFound:
                return False
        return True


class CornerWidget(QWidget):
    def __init__(self, text: str, menuBar: QMenuBar) -> None:
        super(CornerWidget, self).__init__(parent=menuBar)
        self._layout = QVBoxLayout()
        self._layout.setContentsMargins(9, 3, 9, 3)
        self._label = QLabel(text, parent=self)
        self._layout.addWidget(self._label)
        self.setLayout(self._layout)


class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(
        self,
        appInfo: AppInfo,
        pipelineSetting: DesktopPipelineSetting, 
        roleManager: RoleManager,
        isDev: bool,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._appInfo = appInfo
        self._pipelineSetting = pipelineSetting
        self._service = Service(self._pipelineSetting)
        self._isDev = isDev
        _project = self._pipelineSetting.project()
        assert _project is not None, 'No project selected in pipeline setting.'
        self._project = _project
        _studio = self._pipelineSetting.studio()
        assert _studio is not None, 'No studio selected in pipeline setting.'
        self._studio = _studio

        self._api = ApiClient(self._pipelineSetting, isDev=self._isDev)
        self._dataRepo = DataRepository(self._isDev)
        self._roleManager = roleManager
        self._threadPool = ThreadPool()

        self._columns: list[Column] = []
        self._assetsEntities: dict[str, Entity | None] = {}
        self._assetsHeaderMap: list[str] = []
        self._shotsEntities: dict[str, Entity | None] = {}
        self._shotsHeaderMap: list[str] = []
        self._thumbnailPathsTasks: dict[str, LoadThumbnailPathsTask] = {}
        self._thumbnailTasks: dict[str, LoadThumbnailTask] = {}
        self._thumbnailCache: dict[str, dict[str, QIcon]] = {
            'assets': {},
            'shots': {},
        }

        self.setupUi(self)

        self._rootsButtonGroup = QButtonGroup(self)
        self._assetsButton = CheckableButton(' Assets', QIcon(':/child_w.png'), self)
        self._shotsButton = CheckableButton(' Shots', QIcon(':/film_w.png'), self)
        self._rootsButtonGroup.addButton(self._assetsButton)
        self._rootsButtonGroup.addButton(self._shotsButton)
        self._spacer = QSpacerItem(1, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.rootButtonHLayout.insertWidget(0, self._assetsButton)
        self.rootButtonHLayout.insertWidget(1, self._shotsButton)
        self.rootButtonHLayout.addItem(self._spacer)

        self._exportCsvButton = QPushButton(' Export CSV')
        self._exportCsvButton.setIcon(QIcon(':/export.png'))
        self._exportCsvButton.setMinimumWidth(120)
        self._importCsvButton = QPushButton(' Import CSV')
        self._importCsvButton.setIcon(QIcon(':/import.png'))
        self._importCsvButton.setMinimumWidth(120)
        self.rootButtonHLayout.addWidget(self._importCsvButton)
        self.rootButtonHLayout.addWidget(self._exportCsvButton)

        self._assetsTableWidget = TableWidget(
            self._service,
            self._api,
            self._state,
            self._columns,
            self._thumbnailCache['assets'],
            'assets',
            self,
        )
        self._shotsTreeWidget = TreeWidget(
            self._service,
            self._api,
            self._state,
            self._columns,
            self._thumbnailCache['shots'],
            'shots',
            self,
        )
        self.verticalLayout.addWidget(self._assetsTableWidget)
        self.verticalLayout.addWidget(self._shotsTreeWidget)

        self._currentSortKey = 'name'
        self._currentSortDirection = 1
        self._currentRoot = 'assets'
        self._dataWidgets: dict[str, 'DataWidget'] = {
            'assets': self._assetsTableWidget,
            'shots': self._shotsTreeWidget,
        }

        self._aboutDialog = None
        self._cornerWidget = None

        self.refreshButton.clicked.connect(self._onRefreshClicked)
        self._rootsButtonGroup.buttonToggled.connect(self.changeRootButtonToggled)
        self.columnManagerButton.clicked.connect(self._manageColumns)
        self.roleManagerButton.clicked.connect(self._manageRoles)

        self._exportCsvButton.clicked.connect(self._onExportCsvClicked)
        self._importCsvButton.clicked.connect(self._onImportCsvClicked)

        self._genaratedMenu()

        self._assetsTableWidget.setVisible(self._currentRoot == 'assets')
        self._shotsTreeWidget.setVisible(self._currentRoot == 'shots')
        self._setRootButton(self._currentRoot)
        self.roleManagerButton.setVisible(self._state.isAdmin())

        self._rebuildColumns()
        self._refresh(True)

    def _genaratedMenu(self):
        # Help Menu
        self._actionAboutPpiBreakdown = QAction('About PPI Breakdown...', self)
        self.menuHelp.addAction(self._actionAboutPpiBreakdown)
        self._actionAboutPpiBreakdown.triggered.connect(self._showAboutDialog)
        self._ppiBreakdownHelp = QAction('PPI Breakdown Help', self)
        self.menuHelp.addAction(self._ppiBreakdownHelp)
        self._ppiBreakdownHelp.triggered.connect(self._showHelpDocument)

        # Corner Widget
        text = (
            f'{self._studio.displayName()}'
            f' / {self._roleManager.userName()}'
            f' / {self._roleManager.currentRoleName()}'
        )
        self._cornerWidget = CornerWidget(text, self.menuBar())
        self.menuBar().setCornerWidget(self._cornerWidget)

    def _showAboutDialog(self):
        if self._aboutDialog is None:
            from ppui.desktop.widget.aboutDialog import AboutDialog

            self._aboutDialog = AboutDialog(self._appInfo, self)
        self._aboutDialog.show()

    def _showHelpDocument(self):
        import webbrowser

        url = self._pipelineSetting.preference().get('/ppiToolsDocument/url')
        if url:
            webbrowser.open(url + '/toolList/ppiBreakdown/')

    def _onRefreshClicked(self) -> None:
        for cache in self._thumbnailCache.values():
            cache.clear()
        self._refresh()

    def _onExportCsvClicked(self) -> None:
        widget = self._dataWidgets.get(self._currentRoot)
        if widget:
            widget.exportCsv()

    def _onImportCsvClicked(self) -> None:
        widget = self._dataWidgets.get(self._currentRoot)
        if widget:
            widget.importCsv()

    def _refresh(self, force: bool = False) -> None:
        if force or self._currentRoot == 'assets':
            _columns = list(self._collectColumns('assets'))
            self._assetsTableWidget.refresh(_columns)
        if force or self._currentRoot == 'shots':
            _columns = list(self._collectColumns('shots'))
            self._shotsTreeWidget.refresh(_columns)
        root = None if force else self._currentRoot
        self._resetTasks(root)
        self._loadThumbnail(root)

    def _setRootButton(self, root: str) -> None:
        isBlocked = self._rootsButtonGroup.blockSignals(True)
        try:
            if root == 'assets':
                self._assetsButton.setChecked(True)
            elif root == 'shots':
                self._shotsButton.setChecked(True)
        finally:
            self._rootsButtonGroup.blockSignals(isBlocked)

    def _rebuildColumns(self) -> None:
        project = self._project.keyName()
        tempColumns = list(self._dataRepo.loadTemplateColumns(project))
        dbColumns = self._api.getColumns()
        tempExistKeys = {col.key() for col in tempColumns}
        for dbCol in dbColumns:
            column = Column.fromDict(dbCol)
            if dbCol['key'] not in tempExistKeys:
                tempColumns.append(column)
            else:
                for i, tempCol in enumerate(tempColumns):
                    if tempCol.key() == dbCol['key']:
                        tempColumns[i] = column
                        break
        self._columns = sorted(tempColumns, key=lambda c: c.createdAtUtc() or '0')

    def _collectColumns(self, root: str) -> Iterator[Column]:
        for col in self._columns:
            if not col.visibled() or col.root() not in ('common', root):
                continue
            yield col

    def _manageColumns(self):
        cols = [
            col
            for col in self._columns
            if col.root() in ('common', self._currentRoot)
            and col.key() not in READ_ONLY_COLUMN_KEYS # noqa: E501
        ]  # noqa: E501
        dlg = ColumnListDialog(
            self._api,
            self._project.keyName(),
            self._studio.keyName(),
            self._currentRoot,
            cols,
            currentWidget.getColumnOrder() if currentWidget else [],
            self._dataRepo,
            self._roleManager,
            self,
        )
        dlg.exec()
        if dlg.isChanged():
            self._rebuildColumns()
            self._refresh()

    def _manageRoles(self):
        dlg = RoleManagerDialog(self._state, self)
        dlg.exec()

    def _resetTasks(self, root: str | None = None) -> None:
        for path, task in self._thumbnailPathsTasks.items():
            if root is not None and not path.startswith(root + '/'):
                continue
            task.thumbnailPathsLoaded.disconnect(self._loadThumbnailTask)
        self._thumbnailPathsTasks.clear()
        for path, task in self._thumbnailTasks.items():
            if root is not None and not path.startswith(root + '/'):
                continue
            task.thumbnailLoaded.disconnect(self._updateThumbnailLabel)
        self._thumbnailTasks.clear()

    def _updateThumbnailLabel(self, path: str, image: QImage) -> None:
        pathParts = path.split('/')
        if len(pathParts) < 2:
            return
        root = pathParts[0]
        scaledImage = image.scaled(
            90,
            90,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        icon = QIcon(QPixmap.fromImage(scaledImage))

        if root in self._thumbnailCache:
            self._thumbnailCache[root][path] = icon

        if path in self._thumbnailTasks:
            self._thumbnailTasks.pop(path)

        widget = self._dataWidgets.get(root)
        if widget is None:
            return

        groupPath = '/'.join(pathParts[1:])
        widget.onThumbnailUpdated(groupPath, icon)

    def _loadThumbnailTask(self, path: str, thumbPaths: ThumbnailPaths) -> None:
        if path not in self._thumbnailPathsTasks:
            return
        self._thumbnailPathsTasks.pop(path)

        pathParts = path.split('/')
        root = pathParts[0]
        if root in self._thumbnailCache and path in self._thumbnailCache[root]:
            widget = self._dataWidgets.get(root)
            if widget is not None:
                groupPath = '/'.join(pathParts[1:])
                widget.onThumbnailUpdated(groupPath, self._thumbnailCache[root][path])
            return

        task = LoadThumbnailTask(
            path,
            thumbPaths,
        )
        task.thumbnailLoaded.connect(self._updateThumbnailLabel)
        self._thumbnailTasks[path] = task
        self._service.threadStart(task)

    def _loadThumbnail(self, root: str | None = None) -> None:
        for value in self._service.iterLatestThumbnailValues():
            if root is not None and not value.location().startswith(root + '/'):
                continue
            groupPath = self._service.valueLocationToGroupPath(value)
            if groupPath is None:
                continue
            _logger.debug('Loading thumbnail for %s', groupPath)
            pathRoot = groupPath.split('/')[0]
            if pathRoot in self._thumbnailCache and groupPath in self._thumbnailCache[pathRoot]:
                widget = self._dataWidgets.get(pathRoot)
                if widget is not None:
                    widgetGroupPath = '/'.join(groupPath.split('/')[1:])
                    widget.onThumbnailUpdated(
                        widgetGroupPath, self._thumbnailCache[pathRoot][groupPath]
                    )  # noqa: E501
                continue

            task = LoadThumbnailPathsTask(
                self._service,
                value,
            )
            task.thumbnailPathsLoaded.connect(self._loadThumbnailTask)
            self._thumbnailPathsTasks[groupPath] = task
            self._service.threadStart(task)

    def changeRootButtonToggled(self, button: QPushButton, checked: bool) -> None:
        if checked:
            root = 'assets' if button == self._assetsButton else 'shots'
            _logger.debug('Root changed to %s', root)
            if root != self._currentRoot:
                self._currentRoot = root
                self._assetsTableWidget.setVisible(root == 'assets')
                self._shotsTreeWidget.setVisible(root == 'shots')


class CheckableButton(QPushButton):
    def __init__(self, text: str, icon: QIcon | None = None, parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.setCheckable(True)
        self.setMinimumWidth(120)

        if icon is not None:
            self.setIcon(icon)


class DataWidget(QWidget):
    GROUPPATH_ROLE = Qt.ItemDataRole.UserRole + 1
    SORT_ROLE = Qt.ItemDataRole.UserRole + 2
    FILTER_ROLE = Qt.ItemDataRole.UserRole + 3

    def __init__(
        self,
        service: Service,
        api: ApiClient,
        state: State,
        columns: list[Column],
        thumbnailCache: dict[str, QIcon],
        root: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._service = service
        self._api = api
        self._state = state
        self._columns = columns
        self._thumbnailCache = thumbnailCache
        self._root = root

        self._vLayout = QVBoxLayout(self)
        self._vLayout.setContentsMargins(0, 0, 0, 0)

        self._model = QStandardItemModel(self)
        self._proxyModel = KeywordFilterProxyModel(self)
        self._proxyModel.setSourceModel(self._model)
        self._proxyModel.setRecursiveFilteringEnabled(True)
        self._proxyModel.setSortRole(self.SORT_ROLE)
        self._proxyModel.setFilterRole(self.FILTER_ROLE)

        self._currentSortKey = 'name'
        self._currentSortDirection = 1
        self._headerMap: list[str] = []
        self._entities: dict[str, Entity | None] = {}

        self._thumbnailItems: dict[str, QStandardItem] = {}

        defaultImg = self._service.defaultThumbnail()
        scaledDefault = defaultImg.scaled(
            90,
            90,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self._defaultThumbnailIcon = QIcon(QPixmap.fromImage(scaledDefault))

    def _getView(self) -> QAbstractItemView:
        raise NotImplementedError

    def _getHorizontalHeader(self) -> QHeaderView:
        raise NotImplementedError

    def _getVisibleColumns(self) -> list[Column]:
        raise NotImplementedError

    def _getTypedValue(self, val: Any, dtype: str) -> Any:
        if val == '' or val is None:
            if dtype == 'int':
                return -999999999
            elif dtype == 'float':
                return -999999999.0
            return ''

        try:
            if dtype == 'int':
                return int(val)
            elif dtype == 'float':
                return float(val)
            elif dtype == 'bool':
                return str(val).lower() in ('true', '1')
        except (ValueError, TypeError):
            if dtype == 'int':
                return -999999999
            elif dtype == 'float':
                return -999999999.0

        return str(val).lower()

    def enableCustomSorting(self):
        header = self._getHorizontalHeader()
        header.setSectionsClickable(True)
        header.setSortIndicatorShown(True)
        header.sectionClicked.connect(self.onHeaderSectionClicked)

    def enableColumnReordering(self):
        header = self._getHorizontalHeader()
        header.setSectionsMovable(True)

        header.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        header.customContextMenuRequested.connect(self.showHeaderContextMenu)

    def showHeaderContextMenu(self, pos: QPoint) -> None:
        menu = QMenu(self)
        saveUserAction = menu.addAction('Save Column Order for User')
        saveProjectAction = menu.addAction('Save Column Order for Project')
        _canSaveProjectOrder = self._state.hasPermission(Permission.CanSaveProjectColumnOrder)
        saveProjectAction.setVisible(_canSaveProjectOrder)
        resetAction = menu.addAction('Reset User Column Order')

        action = menu.exec(self._getHorizontalHeader().mapToGlobal(pos))
        if action == saveUserAction:
            self._onSaveUserColumnOrder()
        elif action == saveProjectAction:
            self._onSaveProjectColumnOrder()
        elif action == resetAction:
            self._onResetColumnOrder()

    def getColumnOrder(self) -> list[str]:
        header = self._getHorizontalHeader()
        orderKeys: list[str] = []
        for visualIdx in range(header.count()):
            logicalIdx = header.logicalIndex(visualIdx)
            if 0 <= logicalIdx < len(self._headerMap):
                orderKeys.append(self._headerMap[logicalIdx])
        return orderKeys

    def _onResetColumnOrder(self) -> None:
        reply = QMessageBox.question(
            self,
            'Confirm Reset',
            'Are you sure you want to reset the data?\nThis action cannot be undone.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.saveColumnOrder([], str(Sections.USER), self._root)
            self.refresh()

    def _onSaveUserColumnOrder(self) -> None:
        self.saveColumnOrder(self.getColumnOrder(), str(Sections.USER), self._root)

    def _onSaveProjectColumnOrder(self) -> None:
        self.saveColumnOrder(self.getColumnOrder(), str(Sections.PROJECT), self._root)

    def saveColumnOrder(
        self,
        columnKeys: list[str],
        section: str,
        root: str,
    ) -> None:
        self._state.setColumnOrder(columnKeys, section, root)

    def applyColumnOrder(self, columnKeys: list[str]) -> None:
        if not columnKeys:
            return

        header = self._getHorizontalHeader()
        keyToLogical = {key: i for i, key in enumerate(self._headerMap)}

        header.blockSignals(True)
        try:
            currentVisualIdx = 0
            for key in columnKeys:
                if key in keyToLogical:
                    logicalIdx = keyToLogical[key]
                    oldVisualIdx = header.visualIndex(logicalIdx)
                    if oldVisualIdx != currentVisualIdx:
                        header.moveSection(oldVisualIdx, currentVisualIdx)
                    currentVisualIdx += 1
        finally:
            header.blockSignals(False)

    def getSavedColumnOrder(self, root: str) -> list[str]:
        return self._state.columnOrder(root)

    def onHeaderSectionClicked(self, logicalIndex: int):
        if logicalIndex < 0 or logicalIndex >= len(self._headerMap):
            return

        desc = Qt.SortOrder.DescendingOrder
        asc = Qt.SortOrder.AscendingOrder
        colKey = self._headerMap[logicalIndex]

        if colKey == 'thumbnail':
            if self._currentSortKey in self._headerMap:
                prevIdx = self._headerMap.index(self._currentSortKey)
                prevOrder = asc if self._currentSortDirection == 1 else desc
                self._getHorizontalHeader().setSortIndicator(prevIdx, prevOrder)
                _logger.debug(
                    'Set sort indicator: index=%d, order=%s',
                    prevIdx,
                    'asc' if prevOrder == asc else 'desc',
                )
            return

        header = self._getHorizontalHeader()

        if self._currentSortKey == colKey:
            new_order = desc if self._currentSortDirection == 1 else asc
        else:
            new_order = asc

        self._currentSortKey = colKey
        self._currentSortDirection = 1 if new_order == asc else -1

        header.setSortIndicator(logicalIndex, new_order)
        self._proxyModel.sort(logicalIndex, new_order)
        _logger.debug(
            'Header clicked: index=%d, key=%s, new_order=%s',
            logicalIndex,
            colKey,
            'asc' if new_order == asc else 'desc',
        )

    def setupFilterWidget(self):
        self._filterWidget = QWidget(self)
        self._filterLayout = QHBoxLayout(self._filterWidget)
        self._filterLayout.setContentsMargins(0, 0, 0, 0)
        self._filterSpacer = QSpacerItem(
            1,
            0,
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Minimum,
        )
        self._filterLabel = QLabel('Filter keyword: ', self)
        self._filterLineEdit = QLineEdit(self)
        self._filterLineEdit.setPlaceholderText('Space separated for AND search')
        palette = self._filterLineEdit.palette()
        placeholderColor = QColor('gray')
        palette.setColor(QPalette.ColorRole.PlaceholderText, placeholderColor)
        self._filterLineEdit.setPalette(palette)
        if hasattr(self._filterLineEdit, 'setClearButtonEnabled'):
            self._filterLineEdit.setClearButtonEnabled(True)
        self._filterLineEdit.textChanged.connect(self._proxyModel.setKeywordFilterPattern)
        self._filterLayout.addItem(self._filterSpacer)
        self._filterLayout.insertWidget(1, self._filterLabel)
        self._filterLayout.insertWidget(2, self._filterLineEdit)
        self._vLayout.insertWidget(0, self._filterWidget)

    def _getGroups(self) -> Iterator[Group]:
        for group in self._service.iterGroups(self._root):
            yield group

    def onThumbnailUpdated(self, group: str, icon: QIcon):
        item = self._thumbnailItems.get(group)
        if item is not None:
            item.setIcon(icon)

    def onDoubleClick(self, index: QModelIndex):
        if not self._state.hasPermission(Permission.CanEditParameters):
            return
        group = index.data(self.GROUPPATH_ROLE)
        if group is None:
            return
        
        # Get the selected groups, ensuring that the double-clicked group is included
        # If the double-clicked group is not in the current selection, we add it to the list of groups to edit.
        # This allows the user to edit multiple selected groups at once, or just the double-clicked group if it wasn't already selected.
        groups = self._getSelection()
        if group not in groups:
            groups = [group]
        else:
            groups = list(dict.fromkeys(groups))
        entities = [
            entity.asDict() if entity is not None else None
            for entity in (self._entities.get(selectedGroup) for selectedGroup in groups)
        ]
        _columns = [col for col in self._columns if col.key() not in READ_ONLY_COLUMN_KEYS]
        dlg = EntityEditorDialog(
            self._api,
            self._root,
            groups,
            _columns,
            entities,
            self,
        )
        if dlg.exec() == QDialog.DialogCode.Accepted:
            newRoot, savedGroups, newData = dlg.getSavedInfo() #  Get the new root, saved groups, and new data from the dialog
            if newRoot != self._root:
                self.refresh()
            else:
                for savedGroup in savedGroups: # Iterate through the saved groups and update each one with the new data
                    self.updateSingleEntity(savedGroup, newData)

    def _getSelection(self) -> list[str]:
        selectedPaths: list[str] = []
        for index in self._getView().selectionModel().selectedRows():
            path = index.data(self.GROUPPATH_ROLE)
            if path:
                selectedPaths.append(path)
        return selectedPaths

    def _setSelection(self, paths: list[str]) -> None:
        def _searchProxyIndex(parentIdx: QModelIndex):
            for row in range(self._proxyModel.rowCount(parentIdx)):
                idx = self._proxyModel.index(row, 0, parentIdx)
                path = idx.data(self.GROUPPATH_ROLE)
                if path in targetPaths:
                    selectionModel.select(
                        idx,
                        QItemSelectionModel.SelectionFlag.Select
                        | QItemSelectionModel.SelectionFlag.Rows,  # noqa: E501
                    )
                    self._getView().scrollTo(idx)

                if self._proxyModel.hasChildren(idx):
                    _searchProxyIndex(idx)

        if not paths:
            return

        targetPaths = set(paths)
        selectionModel = self._getView().selectionModel()
        selectionModel.clearSelection()

        _searchProxyIndex(QModelIndex())

    def refresh(self, columns: list[Column] | None = None) -> None:
        selectedPaths = self._getSelection()
        self.refreshColumns(columns)
        self.refreshData()
        self._setSelection(selectedPaths)

    def refreshColumns(self, columns: list[Column] | None = None) -> None:
        if columns is not None:
            self._columns = columns

        visible_cols = self._getVisibleColumns()
        displayColumns = [col.displayName() for col in visible_cols]

        self._model.setColumnCount(len(displayColumns))
        self._model.setHorizontalHeaderLabels(displayColumns)
        self._headerMap = [col.key() for col in visible_cols]

    def exportCsv(self) -> None:
        filePath, _ = QFileDialog.getSaveFileName(
            self,
            'Export CSV',
            '',
            'CSV Files (*.csv)',
        )
        if not filePath:
            return

        try:
            _logger.debug('Exporting CSV to %s', filePath)
            with open(filePath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)

                # Header
                headers = [
                    col.key()
                    for col in self._columns
                    if col.visibled() and col.key() != 'thumbnail'
                ]  # noqa: E501
                writer.writerow(headers)

                # Data
                allGroups = [grp.keyName() for grp in self._getGroups()]
                sortedKeys = sorted(allGroups)

                for key in sortedKeys:
                    entity = self._entities.get(key)

                    row: list[str] = []
                    for col in self._columns:
                        if not col.visibled() or col.key() == 'thumbnail':
                            continue

                        colKey = col.key()
                        # Check if the column key is in the list of generated column keys
                        # If it is, we call the _getGeneratedValue method to get the generated value for that column and append it to the row.
                        # If not, we check if the column key is 'name', in which case we append the key itself to the row. Otherwise, we retrieve the value from the entity's data and append it to the row.
                        # This ensures that the exported CSV contains the correct values for each column, including any generated values.
                        if colKey in GENERATED_COLUMN_KEYS:
                            row.append(self._getGeneratedValue(colKey, key))
                        elif colKey == 'name':
                            row.append(key)
                        else:
                            val = ''
                            if entity:
                                val = entity.data().get(colKey, '')
                            row.append(str(val))
                    writer.writerow(row)

            _logger.debug('CSV export completed: %s', filePath)
            QMessageBox.information(self, 'Success', f'Exported to {filePath}')

        except Exception as e:
            _logger.exception('Error exporting CSV')
            QMessageBox.critical(self, 'Error', str(e))

    def _validateImportValue(self, value: str | Any, column: Column) -> str | None:
        dtype = column.dataType()

        if not value:
            return None

        if dtype == 'int':
            try:
                int(value)
                return 'valid'
            except ValueError:
                return 'error'
        elif dtype == 'float':
            try:
                float(value)
                return 'valid'
            except ValueError:
                return 'error'
        elif dtype == 'bool':
            if str(value).lower() in ('true', 'false', '0', '1'):
                return 'valid'
            return 'error'
        elif dtype == 'array':
            options = column.config().get('options', [])
            isMulti = column.config().get('multi_select', False)
            if isMulti:
                vals = [v.strip() for v in str(value).split(',')]
                for v in vals:
                    if v and v not in options:
                        return 'warning'
            else:
                if str(value) not in options:
                    return 'warning'
        return 'valid'

    def importCsv(self) -> None:
        filePath, _ = QFileDialog.getOpenFileName(
            self,
            'Import CSV',
            '',
            'CSV Files (*.csv)',
        )
        if not filePath:
            return

        try:
            _logger.debug('Importing CSV from %s', filePath)
            changes: list[CsvEntityData] = []
            validGroups = {grp.keyName() for grp in self._getGroups()}
            columnMap = {c.key(): c for c in self._columns}
            with open(filePath, 'r', newline='', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)

                if reader.fieldnames is not None and 'name' not in reader.fieldnames:
                    raise ValueError('CSV must have a "name" column to identify entities.')

                csvHeaders = reader.fieldnames
                if csvHeaders is None:
                    raise ValueError('CSV file is empty or invalid.')
                validKeys = {col.key() for col in self._columns}
                # Filter out read-only columns from the display columns
                # This ensures that only editable columns are considered for import
                displayColumns = [
                    h for h in csvHeaders if h in validKeys and h not in READ_ONLY_COLUMN_KEYS
                ] # 

                for row in reader:
                    name = row.get('name')
                    if not name or name not in validGroups:
                        continue

                    dataEntity = self._entities.get(name)
                    isNew = False
                    if dataEntity is None:
                        isNew = True
                        _logger.debug('Creating new entity for %s', name)
                        # Add an entity without updating the UI
                        dataEntity = Entity('', '', self._root, name, {}, '', '', '', '', '0')

                    entityChanges: dict[str, dict[str, str | Any]] = {}

                    for colKey in displayColumns:
                        column = columnMap.get(colKey)
                        if column is None:
                            continue

                        newVal = row.get(colKey)
                        if newVal is None:
                            continue
                        currentVal = dataEntity.data().get(colKey, '')
                        if str(currentVal) != str(newVal):
                            status = self._validateImportValue(newVal, column)
                            if status is None:
                                continue
                            entityChanges[colKey] = {
                                'value': newVal,
                                'status': status,
                            }

                    if entityChanges:
                        _logger.debug('Changes detected for entity %s: %s', name, entityChanges)
                        changes.append(
                            CsvEntityData(
                                entity=dataEntity,
                                changes=entityChanges,
                                isNew=isNew,
                            )
                        )

            if not changes:
                _logger.debug('No changes detected in CSV import.')
                QMessageBox.information(self, 'Info', 'No changes detected.')
                return

            dlg = ConfirmImportDialog(changes, displayColumns, self)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                updateCount = 0
                for item in changes:
                    entity: Entity = item['entity']
                    rawChanges: dict[str, dict[str, str | Any]] = item['changes']
                    isNew: bool = item.get('isNew', False)

                    changeData: dict[str, str | Any] = {}
                    for key, val in rawChanges.items():
                        rawVal = val.get('value')
                        if val.get('status') == 'valid' and rawVal:
                            changeData[key] = rawVal
                    if not changeData:
                        continue

                    if isNew:
                        self._api.createEntity(
                            entity.root(),
                            entity.group(),
                            changeData,
                        )
                    else:
                        self._api.updateEntity(
                            entity.id(),
                            entity.root(),
                            entity.group(),
                            changeData,
                        )
                    self.updateSingleEntity(entity.group(), changeData)
                    updateCount += 1

                if updateCount > 0:
                    _logger.debug('%d entities updated/created.', updateCount)
                    QMessageBox.information(
                        self,
                        'Success',
                        f'{updateCount} entities updated/created.',
                    )
                else:
                    _logger.debug('No valid data to update.')
                    QMessageBox.warning(self, 'Warning', 'No valid data to update.')

        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))

    def updateSingleEntity(self, group: str, data: dict[str, Any]) -> None:
        raise NotImplementedError

    def refreshData(self) -> None:
        raise NotImplementedError

    # This method generates a value for specific columns based on the group path. For example, if the root is 'shots' and the column key is 'cut_number', it will generate a value by joining parts of the group path with underscores. If the conditions are not met, it returns an empty string.
    # This allows for dynamic generation of values for certain columns based on the structure of the group path, which can be useful for organizing and displaying data in a meaningful way.
    def _getGeneratedValue(self, colKey: str, group: str) -> str:
        if self._root == 'shots' and colKey == 'cut_number':
            parts = [part for part in group.split('/') if part]
            if len(parts) >= 3:
                return '_'.join(parts)
        return ''


class TableWidget(DataWidget):
    def __init__(
        self,
        service: Service,
        api: ApiClient,
        state: State,
        columns: list[Column],
        thumbnailCache: dict[str, QIcon],
        root: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(service, api, columns, thumbnailCache, root, parent) #

        self._tableWidget = QTableView(self)
        self._tableWidget.setAlternatingRowColors(True)
        self._tableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._tableWidget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection) # 
        self._tableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._tableWidget.verticalHeader().setDefaultSectionSize(70)
        self._tableWidget.setIconSize(QSize(90, 90))
        self._tableWidget.setModel(self._proxyModel)
        self._vLayout.addWidget(self._tableWidget)

        # Separate synced view used to keep Thumbnail and Name visible while scrolling horizontally.
        # This is a common technique to create "frozen" columns in a table view, where certain columns remain visible while the user scrolls through the rest of the data. In this case, the first two columns (likely "Thumbnail" and "Name") are kept visible for better usability.
        self._frozenColumnsTableWidget = QTableView(self._tableWidget)
        self._frozenColumnsTableWidget.setModel(self._proxyModel)
        self._frozenColumnsTableWidget.setSelectionModel(self._tableWidget.selectionModel())
        self._frozenColumnsTableWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._frozenColumnsTableWidget.setAlternatingRowColors(True)
        self._frozenColumnsTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._frozenColumnsTableWidget.setIconSize(QSize(90, 90))
        self._frozenColumnsTableWidget.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self._frozenColumnsTableWidget.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self._frozenColumnsTableWidget.verticalHeader().setDefaultSectionSize(70)
        self._frozenColumnsTableWidget.verticalHeader().hide()
        self._frozenColumnsTableWidget.horizontalHeader().setSectionsClickable(False)
        self._frozenColumnsTableWidget.horizontalHeader().setSortIndicatorShown(False)
        self._frozenColumnsTableWidget.horizontalScrollBar().hide()
        self._frozenColumnsTableWidget.verticalScrollBar().hide()
        self._frozenColumnsTableWidget.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._frozenColumnsTableWidget.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._tableWidget.viewport().installEventFilter(self)
        self._tableWidget.horizontalHeader().sectionResized.connect(
            self._updateFrozenColumns
        )
        self._tableWidget.verticalScrollBar().valueChanged.connect(
            self._frozenColumnsTableWidget.verticalScrollBar().setValue
        )
        self._frozenColumnsTableWidget.verticalScrollBar().valueChanged.connect(
            self._tableWidget.verticalScrollBar().setValue
        )

        self.setupFilterWidget()
        self.enableCustomSorting()
        self.enableColumnReordering()
        self._tableWidget.doubleClicked.connect(self.onDoubleClick)
        self._frozenColumnsTableWidget.doubleClicked.connect(self.onDoubleClick) # Connect double-click signal for frozen columns
    
    # The eventFilter method is used to intercept events for the table widget's viewport. Specifically, it listens for resize events and calls the _updateFrozenColumns method to adjust the frozen columns accordingly. This ensures that the frozen columns remain properly aligned and sized when the table is resized.
    # The method returns the result of the base class's eventFilter method to allow normal event processing to continue.
    def eventFilter(self, watched: QWidget, event: QEvent) -> bool:
        if watched == self._tableWidget.viewport() and event.type() == QEvent.Type.Resize:
            self._updateFrozenColumns()
        return super().eventFilter(watched, event)

    def _getView(self) -> QTableView:
        return self._tableWidget

    def _getHorizontalHeader(self) -> QHeaderView:
        return self._tableWidget.horizontalHeader()

    def _getVisibleColumns(self) -> list[Column]:
        return [col for col in self._columns if col.visibled()]

    def refreshColumns(self, columns: list[Column] | None = None) -> None:
        super().refreshColumns(columns)

        header = self._getHorizontalHeader()
        if header.count() > 1:
            header.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
            self._tableWidget.setColumnWidth(1, 150)
        self._updateFrozenColumns() # Update frozen columns after refreshing
    
    # The _updateFrozenColumns method is responsible for managing the visibility and size of the frozen columns in the table view. It determines how many columns should be frozen (up to a maximum of two), hides any additional columns in the frozen view, and adjusts the width and height of the frozen columns table to match the main table's viewport. It also ensures that the frozen columns are positioned correctly and made visible, allowing users to see important information (like thumbnails and names) while scrolling through other data.
    # This method is called whenever the table is resized or when the columns are refreshed, ensuring that the frozen columns remain properly aligned and functional.
    def _updateFrozenColumns(self) -> None:
        # Mirror only the first two columns and place them over the scrolling table viewport.
        frozenColumnCount = min(2, self._proxyModel.columnCount())
        if frozenColumnCount == 0:
            self._frozenColumnsTableWidget.hide()
            return

        for col in range(self._proxyModel.columnCount()):
            self._frozenColumnsTableWidget.setColumnHidden(col, col >= frozenColumnCount)

        frozenWidth = 0
        for col in range(frozenColumnCount):
            columnWidth = self._tableWidget.columnWidth(col)
            self._frozenColumnsTableWidget.setColumnWidth(col, columnWidth)
            frozenWidth += columnWidth

        self._frozenColumnsTableWidget.setFixedWidth(frozenWidth)
        self._frozenColumnsTableWidget.setFixedHeight(
            self._tableWidget.viewport().height()
            + self._tableWidget.horizontalHeader().height()
        )
        self._frozenColumnsTableWidget.move(
            self._tableWidget.verticalHeader().width() + self._tableWidget.frameWidth(),
            self._tableWidget.frameWidth(),
        )
        self._frozenColumnsTableWidget.show()
        self._frozenColumnsTableWidget.raise_()

    def updateSingleEntity(self, group: str, data: dict[str, Any]) -> None:
        entity = self._entities.get(group)
        if entity is not None:
            entity.data().update(data)
        else:
            # Create local cache if not exists (for new entities)
            # We don't have full server info (ID etc) but enough for display
            self._entities[group] = Entity('', '', self._root, group, data, '', '', '', '', '0')

        for row in range(self._model.rowCount()):
            index = self._model.index(row, 0)
            if index.data(self.GROUPPATH_ROLE) == group:
                for colIdx, column in enumerate(self._getVisibleColumns()):
                    key = column.key()
                    if key in READ_ONLY_COLUMN_KEYS: # Skip read-only columns
                        continue
                    if key in data:
                        item = self._model.itemFromIndex(self._model.index(row, colIdx))
                        if item:
                            val = data.get(key, '')
                            item.setText(str(val))
                            item.setToolTip(str(val))
                            item.setData(
                                self._getTypedValue(val, column.dataType()),
                                self.SORT_ROLE,
                            )
                break

    def refreshData(self) -> None:
        _entities = self._api.searchEntities(
            '',
            self._root,
            self._currentSortKey,
            self._currentSortDirection,
        )
        self._entities = {
            ent.get('group'): Entity.fromDict(ent) for ent in _entities if ent.get('group')
        }  # noqa: E501
        groupKeyNames = [grp.keyName() for grp in self._getGroups()]

        self._model.removeRows(0, self._model.rowCount())
        self._thumbnailItems.clear()
        visible_cols = self._getVisibleColumns()

        for ent in groupKeyNames:
            _entity = self._entities.get(ent)
            items: list[QStandardItem] = []
            for column in visible_cols:
                item = QStandardItem()
                item.setSizeHint(QSize(0, 70))
                item.setData(ent, self.GROUPPATH_ROLE)
                item.setData(ent, self.FILTER_ROLE)

                if column.key() == 'thumbnail':
                    cacheKey = f'{self._root}/{ent}'
                    icon = self._thumbnailCache.get(cacheKey, self._defaultThumbnailIcon)
                    item.setIcon(icon)
                    # 高速アクセスのために辞書に登録
                    self._thumbnailItems[ent] = item
                    item.setData('', self.SORT_ROLE)
                elif column.key() == 'name':
                    item.setText(str(ent))
                    item.setData(str(ent).lower(), self.SORT_ROLE)
                else:
                    val = _entity.data().get(column.key(), '') if _entity is not None else ''
                    item.setText(str(val))
                    item.setToolTip(str(val))
                    item.setData(self._getTypedValue(val, column.dataType()), self.SORT_ROLE)
                items.append(item)
            if items:
                self._model.appendRow(items)

        if self._currentSortKey in self._headerMap:
            colIdx = self._headerMap.index(self._currentSortKey)
            order = (
                Qt.SortOrder.AscendingOrder
                if self._currentSortDirection == 1
                else Qt.SortOrder.DescendingOrder
            )  # noqa: E501
            self._getHorizontalHeader().setSortIndicator(colIdx, order)
            self._proxyModel.sort(colIdx, order)


class TreeWidget(DataWidget):
    def __init__(
        self,
        service: Service,
        api: ApiClient,
        state: State,
        columns: list[Column],
        thumbnailCache: dict[str, QIcon],
        root: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(service, api, columns, thumbnailCache, root, parent) # 

        self._treeWidget = QTreeView(self)
        self._treeWidget.setAlternatingRowColors(True)
        # Set a custom stylesheet for the tree view to customize the appearance of branches and expand/collapse indicators. This is done to remove default branch lines and use custom icons for expanded and collapsed states, enhancing the visual presentation of the tree structure.
        # The stylesheet defines how the branches of the tree view should look based on their state (e.g., whether they have children, are expanded, or are collapsed). It also specifies custom images for the expand/collapse indicators using URLs to image resources.
        treeStyleSheet = (
            'QTreeView::branch:has-siblings:!adjoins-item {\n'
            '    border-image: none;\n'
            '}\n'
            'QTreeView::branch:has-siblings:adjoins-item {\n'
            '    border-image: none;\n'
            '}\n'
            'QTreeView::branch:!has-children:!has-siblings:adjoins-item {\n'
            '    border-image: none;\n'
            '}\n'
            'QTreeView::branch:has-children:!has-siblings:closed,\n'
            'QTreeView::branch:closed:has-children:has-siblings {\n'
            '    border-image: none;\n'
            '    image: url(:/angle-right.png);\n'
            '}\n'
            'QTreeView::branch:open:has-children:!has-siblings,\n'
            'QTreeView::branch:open:has-children:has-siblings {\n'
            '    border-image: none;\n'
            '    image: url(:/angle-down.png);\n'
            '}'
        )
        self._treeWidget.setStyleSheet(treeStyleSheet) # Apply the custom stylesheet to the tree view
        self._treeWidget.setIconSize(QSize(90, 90))
        self._treeWidget.setModel(self._proxyModel)
        self._treeWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._treeWidget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection) # Allow multiple items to be selected
        self._treeWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._vLayout.addWidget(self._treeWidget)

        # Separate synced tree used to keep Thumbnail and Name visible while scrolling horizontally.
        # This is a common technique to create "frozen" columns in a tree view, where certain columns remain visible while the user scrolls through the rest of the data. In this case, the first two columns (likely "Thumbnail" and "Name") are kept visible for better usability.
        # The frozen tree view is set up to mirror the main tree view's model and selection, but it has its own appearance settings to ensure that it does not interfere with user interactions (e.g., it does not accept focus). It also hides its scroll bars and disables sorting indicators to maintain a consistent look with the main tree view.
        # The frozen tree view is positioned over the main tree view's viewport and is updated whenever the main tree view is resized or scrolled, ensuring that the frozen columns remain aligned with the rest of the data.
        # This technique enhances the user experience by keeping important columns visible while navigating through large datasets.
        self._frozenColumnsTreeWidget = QTreeView(self._treeWidget)
        self._frozenColumnsTreeWidget.setModel(self._proxyModel)
        self._frozenColumnsTreeWidget.setSelectionModel(self._treeWidget.selectionModel())
        self._frozenColumnsTreeWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._frozenColumnsTreeWidget.setAlternatingRowColors(True)
        self._frozenColumnsTreeWidget.setStyleSheet(treeStyleSheet)
        self._frozenColumnsTreeWidget.setIconSize(QSize(90, 90))
        self._frozenColumnsTreeWidget.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self._frozenColumnsTreeWidget.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self._frozenColumnsTreeWidget.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self._frozenColumnsTreeWidget.header().setSectionsClickable(False)
        self._frozenColumnsTreeWidget.header().setSortIndicatorShown(False)
        self._frozenColumnsTreeWidget.horizontalScrollBar().hide()
        self._frozenColumnsTreeWidget.verticalScrollBar().hide()
        self._frozenColumnsTreeWidget.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._frozenColumnsTreeWidget.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._treeWidget.viewport().installEventFilter(self)
        self._treeWidget.header().sectionResized.connect(self._updateFrozenColumns)
        self._treeWidget.verticalScrollBar().valueChanged.connect(
            self._frozenColumnsTreeWidget.verticalScrollBar().setValue
        )
        self._frozenColumnsTreeWidget.verticalScrollBar().valueChanged.connect(
            self._treeWidget.verticalScrollBar().setValue
        )
        self._treeWidget.expanded.connect(self._frozenColumnsTreeWidget.expand)
        self._treeWidget.collapsed.connect(self._frozenColumnsTreeWidget.collapse)
        self._frozenColumnsTreeWidget.expanded.connect(self._treeWidget.expand)
        self._frozenColumnsTreeWidget.collapsed.connect(self._treeWidget.collapse)

        self.setupFilterWidget()
        self.enableCustomSorting()
        self.enableColumnReordering()
        self._treeWidget.doubleClicked.connect(self.onDoubleClick)

    def _getView(self) -> QTreeView:
        return self._treeWidget

    def _getHorizontalHeader(self) -> QHeaderView:
        return self._treeWidget.header()

    def _buildColumns(self) -> list[Column]:
        _columns: list[Column] = []
        nameColumn = None
        thumbnailColumn = None
        cutNumberColumn = None # Column for displaying cut numbers
        for col in self._columns:
            if not col.visibled():
                continue
            if col.key() == 'name':
                nameColumn = col
                continue
            if col.key() == 'thumbnail':
                thumbnailColumn = col
                continue
            if col.key() == 'cut_number': # Column for displaying cut numbers
                cutNumberColumn = col #     
                continue
            _columns.append(col)
        if nameColumn is not None:
            _columns.insert(0, nameColumn)
        if thumbnailColumn is not None:
            _columns.insert(1, thumbnailColumn)
        if cutNumberColumn is not None: # Column for displaying cut numbers
            _columns.insert(2, cutNumberColumn) # Column for displaying cut numbers
        return _columns

    def _getVisibleColumns(self) -> list[Column]:
        return self._buildColumns()

    def refreshColumns(self, columns: list[Column] | None = None) -> None:
        super().refreshColumns(columns)

        header = self._getHorizontalHeader()
        if header.count() > 0:
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
            self._treeWidget.setColumnWidth(0, 150)

        _columns = self._getVisibleColumns()
        if len(_columns) >= 2 and _columns[0].key() == 'name' and _columns[1].key() == 'thumbnail':
            # Ensure the 'thumbnail' column is visually before the 'name' column,
            # using current visual indices to avoid flip-flopping on repeated calls.
            nameLogical = 0
            thumbnailLogical = 1
            nameVisual = header.visualIndex(nameLogical)
            thumbnailVisual = header.visualIndex(thumbnailLogical)
            if nameVisual != -1 and thumbnailVisual != -1 and nameVisual < thumbnailVisual:
                header.moveSection(nameVisual, thumbnailVisual)
            self._syncFrozenColumnVisualOrder() # Synchronize the visual order of frozen columns

        self._updateFrozenColumns() # Update frozen columns after refreshing

    # The _syncFrozenColumnVisualOrder method ensures that the visual order of the frozen columns in the frozen tree widget matches the order of the corresponding columns in the main tree widget. It checks the visual indices of the 'name' and 'thumbnail' columns and moves them if necessary to maintain the correct order. This is important for keeping the user interface consistent and intuitive, especially when users interact with the frozen columns while scrolling through the rest of the data.
    # This method is called after refreshing the columns to ensure that any changes in column visibility or order are reflected in the frozen view.
    # It helps maintain a seamless user experience by preventing confusion that could arise from mismatched column orders between the main and frozen views.
    # 
    def _syncFrozenColumnVisualOrder(self) -> None:
        header = self._frozenColumnsTreeWidget.header()
        nameLogical = 0
        thumbnailLogical = 1
        nameVisual = header.visualIndex(nameLogical)
        thumbnailVisual = header.visualIndex(thumbnailLogical)
        if nameVisual != -1 and thumbnailVisual != -1 and nameVisual < thumbnailVisual:
            header.moveSection(nameVisual, thumbnailVisual)

    # The _updateFrozenColumns method is responsible for managing the visibility and size of the frozen columns in the tree view. It determines how many columns should be frozen (up to a maximum of two), hides any additional columns in the frozen view, and adjusts the width and height of the frozen columns tree to match the main tree's viewport. It also ensures that the frozen columns are positioned correctly and made visible, allowing users to see important information (like thumbnails and names) while scrolling through other data.
    # This method is called whenever the tree is resized or when the columns are refreshed, ensuring that the frozen columns remain properly aligned and functional.
    # 
    def _updateFrozenColumns(self) -> None:
        # Mirror only the first two logical columns and place them over the scrolling tree viewport.
        frozenColumnCount = min(2, self._proxyModel.columnCount())
        if frozenColumnCount == 0:
            self._frozenColumnsTreeWidget.hide()
            return

        for col in range(self._proxyModel.columnCount()):
            self._frozenColumnsTreeWidget.setColumnHidden(col, col >= frozenColumnCount)

        frozenWidth = 0
        for col in range(frozenColumnCount):
            columnWidth = self._treeWidget.columnWidth(col)
            self._frozenColumnsTreeWidget.setColumnWidth(col, columnWidth)
            frozenWidth += columnWidth

        self._frozenColumnsTreeWidget.setFixedWidth(frozenWidth)
        self._frozenColumnsTreeWidget.setFixedHeight(
            self._treeWidget.viewport().height() + self._treeWidget.header().height()
        )
        self._frozenColumnsTreeWidget.move(
            self._treeWidget.frameWidth(),
            self._treeWidget.frameWidth(),
        )
        self._frozenColumnsTreeWidget.show()
        self._frozenColumnsTreeWidget.raise_()

    def updateSingleEntity(self, group: str, data: dict[str, Any]) -> None:
        def _updateRecursively(parentItem: QStandardItem):
            for row in range(parentItem.rowCount()):
                child = parentItem.child(row, 0)
                if child and child.data(self.GROUPPATH_ROLE) == group:
                    for colIdx, column in enumerate(self._getVisibleColumns()):
                        key = column.key()
                        if key in READ_ONLY_COLUMN_KEYS: # Skip read-only columns
                            continue
                        if key in data:
                            sibling = parentItem.child(row, colIdx)
                            if sibling:
                                val = data.get(key, '')
                                sibling.setText(str(val))
                                sibling.setToolTip(str(val))
                                # Keep SORT_ROLE in sync with the displayed value for correct sorting  # noqa: E501
                                typed_val = self._getTypedValue(val, column.dataType())
                                sibling.setData(typed_val, self.SORT_ROLE)
                    return True
                if child and child.hasChildren():
                    if _updateRecursively(child):
                        return True
            return False

        entity = self._entities.get(group)
        if entity is not None:
            entity.data().update(data)
        else:
            # Create local cache if not exists (for new entities)
            # We don't have full server info (ID etc) but enough for display
            self._entities[group] = Entity('', '', self._root, group, data, '', '', '', '', '0')

        _updateRecursively(self._model.invisibleRootItem())

    def refreshData(self) -> None:
        _entities = self._api.searchEntities(
            '',
            self._root,
            self._currentSortKey,
            self._currentSortDirection,
        )
        self._entities = {
            ent.get('group'): Entity.fromDict(ent) for ent in _entities if ent.get('group')
        }  # noqa: E501
        groupKeyNames = [grp.keyName() for grp in self._getGroups()]

        self._model.removeRows(0, self._model.rowCount())
        self._thumbnailItems.clear()
        visibleCols = self._getVisibleColumns()

        def _findChildByName(parentItem: QStandardItem, name: str) -> QStandardItem | None:
            for row in range(parentItem.rowCount()):
                child = parentItem.child(row, 0)
                if child and child.text() == name:
                    return child
            return None

        for groupKey in groupKeyNames:
            _entity = self._entities.get(groupKey)
            groupKeyParts = groupKey.split('/')
            currentParent = self._model.invisibleRootItem()

            for idx, part in enumerate(groupKeyParts):
                childItem = _findChildByName(currentParent, part)
                if childItem is not None:
                    currentParent = childItem
                else:
                    items = [QStandardItem() for _ in visibleCols]
                    items[0].setText(part)
                    items[0].setData(part.lower(), self.SORT_ROLE)
                    partPath = '/'.join(groupKeyParts[: idx + 1])
                    items[0].setToolTip(partPath)
                    items[0].setData(partPath, self.FILTER_ROLE)
                    currentParent.appendRow(items)
                    currentParent = items[0]

                if idx == len(groupKeyParts) - 1:
                    currentParent.setSizeHint(QSize(0, 70))

            parentOfCurrent = currentParent.parent() or self._model.invisibleRootItem()
            rowIdx = currentParent.row()

            for colIdx, colDef in enumerate(visibleCols):
                item = parentOfCurrent.child(rowIdx, colIdx)
                if not item:
                    continue
                item.setSizeHint(QSize(0, 70)) # Set the size hint for the item
                item.setData(groupKey, self.GROUPPATH_ROLE)
                item.setData(groupKey, self.FILTER_ROLE) # Set the filter role for the item

                if colDef.key() == 'name':
                    pass
                elif colDef.key() == 'thumbnail':
                    cacheKey = f'{self._root}/{groupKey}'
                    icon = self._thumbnailCache.get(cacheKey, self._defaultThumbnailIcon)
                    item.setIcon(icon)
                    self._thumbnailItems[groupKey] = item
                    item.setData('', self.SORT_ROLE)
                    item.setData('', self.FILTER_ROLE)
                    
                # The following block of code checks if the column key is 'cut_number'. If it is, it generates a value for that column based on the group path using the `_getGeneratedValue` method. The generated value is then set as the text and tooltip for the item, and it is also stored in the SORT_ROLE for sorting purposes. This allows for dynamic generation of values for certain columns based on the structure of the group path, which can be useful for organizing and displaying data in a meaningful way.
                elif colDef.key() == 'cut_number':
                    val = self._getGeneratedValue(colDef.key(), groupKey)
                    item.setText(val)
                    item.setToolTip(val)
                    item.setData(val.lower(), self.SORT_ROLE)
                else:
                    val = _entity.data().get(colDef.key(), '') if _entity is not None else ''
                    item.setText(str(val))
                    item.setToolTip(str(val))
                    item.setData(self._getTypedValue(val, colDef.dataType()), self.SORT_ROLE)
                    item.setData(str(val), self.FILTER_ROLE)

        self._treeWidget.expandAll()
        self._frozenColumnsTreeWidget.expandAll() # Expand all items in the frozen columns tree widget

        if self._currentSortKey in self._headerMap:
            colIdx = self._headerMap.index(self._currentSortKey)
            order = (
                Qt.SortOrder.AscendingOrder
                if self._currentSortDirection == 1
                else Qt.SortOrder.DescendingOrder
            )  # noqa: E501
            self._getHorizontalHeader().setSortIndicator(colIdx, order)
            self._proxyModel.sort(colIdx, order)
