/**
 * AssetsDataTablePanel.tsx
 *
 * Panel component for the Assets Data Table, managing state and interactions.
 * Handles filtering, sorting, pagination, column visibility, and CSV export.
 * Integrates with project and studio context, and persists user settings.
 *
 * @remarks
 * - Utilizes multiple hooks for data fetching and state management.
 * - Supports both backend and client-side filtering and sorting.
 * - Provides robust handling of column visibility with persistence.
 *
 * @module AssetsDataTablePanel
 *
 * @updateHistory
 * - 29-10-2025 - SanjayK PSI - Initial creation sorting pagination implementation.
 * - 07-11-2025 - SanjayK PSI - Column visibility toggling implementation.
 * - 20-11-2025 - SanjayK PSI - Fixed typo in filter property names handling.
 * - 24-11-2025 - SanjayK PSI - Added detailed doc comments for functions and types.
 * - 05-02-2026 - SanjayK PSI - Added components for column visibility drawer and filter status selection.
 * - 09-02-2026 - SanjayK PSI - Added take number column and updated column sections for asset data table.
 *
 * @functions
 * - AssetsDataTablePanel: Main panel component for the assets data table, managing state and interactions.
 * - CsvDownloadComponent: Handles CSV export functionality with error handling.
 * - resolveServerSort: Utility to determine server-side sort parameters based on UI sort key.
 * - enhancedCompareDates: Custom date comparison function that treats empty values as the largest.
 * - enhancedCompareStrings: Custom string comparison function that treats empty values as the largest.
 * - isEmptyValue: Utility to determine if a value should be considered "empty" for sorting purposes.
 * - formatForDisplay: Utility to format values for display, converting empty values to a consistent placeholder.
 * - AssetTableFilter: Component for filtering and customizing columns in the asset data table.
 * - AssetsDataTable: Main component rendering the assets data table.
 * - AssetsGroupedDataTable: Component for rendering the grouped view of the assets data table.
 * @types
 * - FilterProps: Type definition for the filter properties used in the asset data table.
 * - PageProps: Type definition for pagination properties.
 * - SortDir: Type definition for sort direction ('asc' | 'desc' | 'none').
 * @constants
 * - PIPE_KEY: The key used for storing hidden column settings in pipeline settings.
 * - approvalStatuses: List of possible approval statuses for filtering.
 * - workStatuses: List of possible work statuses for filtering.
 * @localStorageKeys
 * - lsKeyForProject: Utility function to generate a localStorage key for hidden columns based on the project key name.
 * @dependencies
 * - React and related hooks (useState, useEffect, useMemo, useCallback, useRef)
 * - Material-UI components for UI elements and styling.
 * - Custom hooks for data fetching (useFetchAssetsPivot, useFetchAssets, etc.)
 * - API functions for CSV generation and pipeline settings management.
 *
 */

import React, {
  FC,
  useCallback,
  useEffect,
  useRef,
  useState,
  useMemo,
} from 'react';
import { RouteComponentProps } from "react-router-dom";
import { Box, Paper, styled, MenuItem, Checkbox, Divider, Typography, Drawer, InputAdornment } from '@material-ui/core';
import { Snackbar } from '@material-ui/core';

import { ButtonProps } from '@material-ui/core/Button';
import { SelectProps } from '@material-ui/core/Select';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import TextField, { TextFieldProps } from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import ClearIcon from '@material-ui/icons/Clear';
import { fetchGenerateAssetCsv, fetchLatestAssetComment } from './api';
import {
  useFetchAssetsPivot,
  useFetchAssets,
  useFetchLatestAssetComponents,
  useFetchPipelineSettingAssetComponents,
  useFetchTopGroupNames,
  useFetchAssetThumbnails,
  useThumbnailVisibility,
} from './hooks';
import { Asset, FilterProps, PageProps, PivotGroup, SortDir } from './types';
import AssetsDataTable from './AssetsDataTable'
import AssetTableFilter from './AssetDataTableFilter';
import AssetsDataTableFooter from './AssetsDataTableFooter';
import DownloadFab from '../DownloadFab';
import { useCurrentProject } from '../../hooks';
import { Project } from '../../types';
import { useCurrentStudio } from '../../../studio/hooks';
import { queryConfig } from '../../../new-pipeline-setting/api';

import IconButton from '@material-ui/core/IconButton';
import ViewModuleIcon from '@material-ui/icons/ViewModule';
import ViewListIcon from '@material-ui/icons/ViewList';
import FilterListIcon from '@material-ui/icons/FilterList';
import Collapse from '@material-ui/core/Collapse';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import FolderIcon from '@material-ui/icons/Folder';

import AssetsGroupedDataTable from './AssetsGroupedDataTable';

const buildAssetCommentPath = (asset: any, phase: string): string => {
  const assetName = String(asset.group_1 || asset.group_1_name || asset.name || '').trim();
  const relation = String(asset.relation || '').trim();

  return `shared/publish/assets/${assetName}/${relation}/${phase}/_review`;
};

const extractLatestCommentText = (response: any): string => {
  const document = response && Array.isArray(response.documents)
    ? response.documents[0]
    : null;

  const documentInfo = document && (document.document_info || document.DocumentInfo || document);
  const commentData = documentInfo && documentInfo.comment_data;

  if (!Array.isArray(commentData) || commentData.length === 0) {
    return '';
  }

  const comment = commentData.find((item: any) => item && item.text) || commentData[0];
  return comment && comment.text ? String(comment.text) : '';
};

const StyledContainer = styled('div')(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  width: '100%',
  minWidth: 0,
  overflow: 'hidden',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)(({ theme }) => ({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
}));

const StyledContentDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'column',
  minWidth: 'fit-content',
}));

const StyledTableDiv = styled('div')(({ theme }) => ({
  flexGrow: 1,
  width: '100%',
  paddingBottom: theme.spacing(1),
}));

const FooterWrapper = styled('div')(({ theme }) => ({
  display: 'flex',
  justifyContent: 'flex-end',
  width: '100%',
  backgroundColor: theme.palette.background.paper,
  paddingRight: theme.spacing(25),
}));

const CsvDownloadComponent = ({ currentProject }: { currentProject: Project | null | undefined }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorDialogOpen, setErrorDialogOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleErrorDialogClose = () => {
    setErrorDialogOpen(false);
  };

  const handleFetchGenerateAssetCsv = useCallback(async () => {
    if (currentProject == null) {
      console.warn('Project not selected.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60 * 5000);

    try {
      const res = await fetchGenerateAssetCsv(
        currentProject.key_name,
        controller.signal,
      );

      if (res != null) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'asset_data.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }
    } catch (err) {
      console.error('Failed to download CSV:', err);
      setErrorMessage('Failed to download CSV');
      setErrorDialogOpen(true);
    } finally {
      clearTimeout(timeoutId);
      setIsLoading(false);
    }
  }, [currentProject]);

  return (
    <div>
      <DownloadFab
        onClick={handleFetchGenerateAssetCsv}
        disabled={isLoading}
      />
      <Dialog
        open={errorDialogOpen}
        onClose={handleErrorDialogClose}
        aria-labelledby="error-dialog-title"
      >
        <DialogTitle id="error-dialog-title">CSV Download Error</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {errorMessage}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleErrorDialogClose} color="primary" autoFocus>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

const approvalStatuses = [
  'check',
  'clientReview',
  'dirReview',
  'epdReview',
  'clientOnHold',
  'dirOnHold',
  'epdOnHold',
  'execRetake',
  'clientRetake',
  'dirRetake',
  'epdRetake',
  'clientApproved',
  'dirApproved',
  'epdApproved',
  'other',
  'omit',
  'approved',
  'review',
];

const workStatuses = [
  'check',
  'cgsvOnHold',
  'svOnHold',
  'leadOnHold',
  'cgsvRetake',
  'svRetake',
  'leadRetake',
  'cgsvApproved',
  'svApproved',
  'leadApproved',
  'svOther',
  'leadOther',
];

const UNASSIGNED_GROUP_LABEL = 'Unassigned';

const getAssetTopGroupName = (asset: Asset): string => {
  const direct = String(asset.top_group_node || '').trim();
  if (direct) return direct;

  const path = String(asset.group_category_path || '').trim();
  if (path) {
    const top = path.split('/').find(Boolean);
    if (top) return top;
  }

  return UNASSIGNED_GROUP_LABEL;
};

const buildAssetGroups = (assets: Asset[]): PivotGroup[] => {
  const grouped = new Map<string, Asset[]>();

  assets.forEach((asset) => {
    const groupName = getAssetTopGroupName(asset);
    const items = grouped.get(groupName) || [];
    items.push(asset);
    grouped.set(groupName, items);
  });

  return Array.from(grouped.entries()).map(([topGroupNode, items]) => ({
    top_group_node: topGroupNode,
    items,
    total_count: items.length,
  }));
};

/* ──────────────────────────────────────────────────────────────────────────
  Enhanced comparison function for dates that treats empty values as the largest
  (i.e., they appear at the bottom when sorting ascending).
  ───────────────────────────────────────────────────────────────────────── */
const parseColumnKeywordSearch = (raw: string) => {
  const text = (raw || '').trim();
  const match = text.match(/^\[([^\]]+)\]\s*:\s*(.*)$/);
  if (!match) {
    return { column: '', keyword: text.toLowerCase(), targeted: false };
  }

  return {
    column: match[1].trim(),
    keyword: match[2].trim().toLowerCase(),
    targeted: true,
  };
};

const normalizeSearchColumn = (value: string) =>
  (value || '').toLowerCase().replace(/[^a-z0-9]/g, '');

const valuesContainKeyword = (values: any[], keyword: string) =>
  values.some(value => (value == null ? '' : String(value)).toLowerCase().includes(keyword));

const getAssetColumnSearchValues = (
  asset: any,
  columnName: string,
  phaseComponents: { [key: string]: string[] },
  latestComponents: any,
) => {
  const column = normalizeSearchColumn(columnName);
  const values: any[] = [];

  Object.keys(asset || {}).forEach(key => {
    if (normalizeSearchColumn(key) === column) values.push(asset[key]);
  });

  const aliases: { [key: string]: any[] } = {
    name: [asset.group_1, asset.group_1_name, asset.name, asset.asset_name],
    assetname: [asset.group_1, asset.group_1_name, asset.name, asset.asset_name],
    group1: [asset.group_1, asset.group_1_name],
    relation: [asset.relation],
    component: [asset.component],
    topgroup: [asset.top_group_node],
    topgroupnode: [asset.top_group_node],
    groupcategorypath: [asset.group_category_path],
    leafgroupname: [asset.leaf_group_name],
  };

  if (aliases[column]) values.push(...aliases[column]);

  ['dsn', 'mdl', 'rig', 'bld', 'ldv'].forEach(phase => {
    const phaseLabel = phase.toUpperCase();
    const mappings: Array<[string, string]> = [
      [`${phaseLabel} APPR`, `${phase}_approval_status`],
      [`${phaseLabel} APPROVAL`, `${phase}_approval_status`],
      [`${phaseLabel} APPROVAL STATUS`, `${phase}_approval_status`],
      [`${phaseLabel} WORK`, `${phase}_work_status`],
      [`${phaseLabel} WORK STATUS`, `${phase}_work_status`],
      [`${phaseLabel} TAKE`, `${phase}_take`],
    ];

    mappings.forEach(([label, key]) => {
      if (normalizeSearchColumn(label) === column) values.push(asset[key]);
    });

    ((phaseComponents && phaseComponents[phase]) || []).forEach(componentId => {
      const componentColumn = normalizeSearchColumn(componentId);
      if (componentColumn !== column &&
          normalizeSearchColumn(`${componentId} Submitted`) !== column) {
        return;
      }

      const assetKey = `${asset.group_1}-${asset.relation}`;
      const componentList = latestComponents && latestComponents[assetKey] || [];
      const item = componentList.find((x: any) =>
        normalizeSearchColumn(x.component || '') === componentColumn ||
        normalizeSearchColumn(x.latest_document && x.latest_document.component || '') === componentColumn
      );
      if (item && item.latest_document) {
        values.push(item.latest_document.submitted_at_utc, item.latest_document.component);
      }
    });
  });

  return values;
};

const enhancedCompareDates = (a: any, b: any, dir: SortDir): number => {
  const isEmpty = (val: any) =>
    val === null ||
    val === undefined ||
    val === "" ||
    val === "-" ||
    val === "—";

  const aEmpty = isEmpty(a);
  const bEmpty = isEmpty(b);

  // Empty values go to TOP
  if (aEmpty && bEmpty) return 0;
  if (aEmpty) return -1;  // Changed from 1 to -1 (empty comes first)
  if (bEmpty) return 1;   // Changed from -1 to 1 (empty comes first)

  const timeA = new Date(a).getTime();
  const timeB = new Date(b).getTime();

  if (timeA === timeB) return 0;

  return dir === "asc"
    ? timeA > timeB ? 1 : -1
    : timeA < timeB ? 1 : -1;
};

/* ──────────────────────────────────────────────────────────────────────────
  Enhanced comparison function for strings that treats empty values as the largest
  (i.e., they appear at the bottom when sorting ascending).
  ───────────────────────────────────────────────────────────────────────── */
const enhancedCompareStrings = (a: any, b: any, dir: SortDir): number => {
  const isEmpty = (val: any) =>
    val === null ||
    val === undefined ||
    val === "" ||
    val === "-" ||
    val === "—";

  const aEmpty = isEmpty(a);
  const bEmpty = isEmpty(b);

  // Empty values go to TOP
  if (aEmpty && bEmpty) return 0;
  if (aEmpty) return -1;  // Changed from 1 to -1 (empty comes first)
  if (bEmpty) return 1;   // Changed from -1 to 1 (empty comes first)

  const compA = String(a).trim().toLowerCase();
  const compB = String(b).trim().toLowerCase();

  if (compA === compB) return 0;

  return dir === "asc"
    ? compA > compB ? 1 : -1
    : compA < compB ? 1 : -1;
};

/* ──────────────────────────────────────────────────────────────────────────
  Utility function to determine if a value should be considered "empty" for sorting purposes.
  This treats null, undefined, empty strings, and common placeholders as empty.
  ───────────────────────────────────────────────────────────────────────── */
const PIPE_KEY = '/ppiTracker/assets/hiddenColumns';

/* ──────────────────────────────────────────────────────────────────────────
  Utility function to generate a localStorage key for hidden columns based on the project key name.
  This ensures that hidden column settings are stored separately for each project.
  ────────────────────────────────────────────────────────────────────────── */
const AssetsDataTablePanel: React.FC<RouteComponentProps> = () => {
  const handleFilterResetClick: ButtonProps['onClick'] = () => {
    setFilterProps(initFilterProps);
    setBarSearch(''); // Clear the UI search bar
    setPageProps(initPageProps); // Reset to page 0
  };

  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };

  // View mode state (grid, list)
  const [barView, setBarView] = React.useState<'grid' | 'list'>('list');
  const [barSearch, setBarSearch] = React.useState<string>('');
  const [AssetTypeOpen, setAssetTypeOpen] = React.useState(true);
  const [ApprovalStatusOpen, setApprovalStatusOpen] = React.useState(true);
  const [workStatusOpen, setWorkStatusOpen] = React.useState(true);

  const [error, setError] = useState<string | null>(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);

  // Determine if grouped view is active based on barView state
  const isGrouped = barView === 'grid';
  const viewMode = isGrouped ? 'grouped' : 'list';

  const initFilterProps = {
    assetNameKey: '',
    approvalStatuses: [],
    workStatuses: [],

    selectPhasePriority: '',
    selectApprovalStatus: '',
    selectWorkStatus: '',
    onPhasePriorityChange: undefined,
    onApprovalStatusChange: undefined,
    onWorkStatusChange: undefined,
  };

  const [pageProps, setPageProps] = useState<PageProps>(initPageProps);
  const [filterProps, setFilterProps] = useState<FilterProps>(initFilterProps);
  const { currentProject } = useCurrentProject();
  const handleFetchAssetComment = useCallback(async (asset: any, phase: string) => {
    if (!currentProject) return '';

    const commentPath = buildAssetCommentPath(asset, phase);
    console.log('[AssetCommentCheck] fetching latest comment path:', commentPath);

    const response = await fetchLatestAssetComment(currentProject.key_name, commentPath);
    return extractLatestCommentText(response);
  }, [currentProject]);

  const { assets: rawAssets, total: rawTotal } = useFetchAssets(
    currentProject,
    pageProps.page,
    pageProps.rowsPerPage,
  );
  const { phaseComponents } = useFetchPipelineSettingAssetComponents(currentProject);
  const { currentStudio } = useCurrentStudio();
  const [timeZone, setTimeZone] = useState<string | undefined>();

  /* Server-side sorting (drives fetch) */
  const [sortKey, setSortKey] = useState<string>('group_1');
  const [sortDir, setSortDir] = useState<SortDir>('asc');

  /* Group name sorting state */
  const [groupSortDir, setGroupSortDir] = useState<SortDir>('asc');

  /* Phase priority filter state */
  const [phasePriority, setPhasePriority] = useState<string>('none');

  /* Client-side sorting (UI state) */
  const [uiSortKey, setUiSortKey] = useState<string>('group_1');
  const [uiSortDir, setUiSortDir] = useState<SortDir>('asc');

  /* Debounce timer for committing sort changes to server-side */
  const commitTimerRef = useRef<number | null>(null);

  /* Column visibility */
  const [hiddenColumns, setHiddenColumns] = useState<Set<string>>(new Set());

  /* Row selection (single click toggles a light-blue highlight on the row) */
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const handleRowSelect = (rowId: string | null) => {
    setSelectedRowId(prev => (prev === rowId ? null : rowId));
  };

  // ============================================
  // 4. UPDATE RESOLVE SERVER SORT FOR TAKE
  // ============================================
  const resolveServerSort = (key: string): { sort: string; phase: string } => {
    if (key === 'group_1') return { sort: 'group_1', phase: 'none' };
    if (key === 'relation') return { sort: 'relation', phase: 'none' };

    if (key === 'component' || key === 'component_only') {
      return { sort: 'component', phase: 'none' };
    }

    // Phase fixed columns: mdl_work, rig_appr, bld_take, etc.
    const m = key.match(/^(mdl|rig|bld|dsn|ldv)_(work|appr|submitted|take|component)$/i);
    if (m) {
      const phase = m[1].toLowerCase();
      const field = m[2].toLowerCase();
      if (field === 'submitted') return { sort: `${phase}_submitted`, phase };
      if (field === 'appr') return { sort: `${phase}_appr`, phase };
      if (field === 'take') return { sort: `${phase}_take`, phase };
      if (field === 'component') return { sort: `${phase}_component`, phase };
      return { sort: `${phase}_work`, phase };
    }

    // Dynamic component columns — look up phase from phaseComponents config
    if (phaseComponents) {
      for (const [phase, ids] of Object.entries(phaseComponents)) {
        if (ids.includes(key)) {
          return { sort: key, phase };
        }
      }
    }

    // Fallback: keep key as-is for client-side sorting
    return { sort: key, phase: 'none' };
  };

  /* -────────────────────────────────────────────────────────────────────────
      ───────────────────────────────────────────────────────────────────────── */

  /* ─────────────────────────────────────────────────────────────────────────
        ───────────────────────────────────────────────────────────────────────── */

  const approvalArray =
    ((filterProps as any).approvalStatuses ||
      filterProps.approvalStatuses || []) as string[];

  const workArray =
    ((filterProps as any).workStatuses ||
      filterProps.workStatuses || []) as string[];

  const keywordSearch = useMemo(
    () => parseColumnKeywordSearch(filterProps.assetNameKey || ''),
    [filterProps.assetNameKey],
  );

  const effectivePhase = useMemo(() => {
    const nameFilterActive = !!keywordSearch.keyword;
    const approvalSelected = approvalArray.length > 0;
    const workSelected = workArray.length > 0;

    const isFilterActive = nameFilterActive || approvalSelected || workSelected;
    if (isFilterActive) return 'none';

    if (phasePriority && phasePriority !== 'none') return phasePriority;
    return 'none';
  }, [
    phasePriority,
    keywordSearch.keyword,
    approvalArray,
    workArray,
  ]);

  const { topGroupNames } = useFetchTopGroupNames(currentProject);

  // state
  const [filterDrawerOpen, setFilterDrawerOpen] = React.useState(false);
  const [selectedTopGroups, setSelectedTopGroups] = React.useState<string[]>([]);

  const filtersActive = useMemo(() => {
    const nameActive = !!keywordSearch.keyword;
    return (
      nameActive ||
      approvalArray.length > 0 ||
      workArray.length > 0 ||
      selectedTopGroups.length > 0
    );
  }, [
    keywordSearch.keyword,
    approvalArray,
    workArray,
    selectedTopGroups,
  ]);

  /* Backend pagination adjustments based on filter state */
  const shouldFetchAllForPivot = viewMode === 'grouped' || filtersActive;
  const backendPage = shouldFetchAllForPivot ? 0 : pageProps.page;
  const backendRowsPerPage = viewMode === 'grouped' ? 10000 : shouldFetchAllForPivot ? 10000 : pageProps.rowsPerPage;

  const backendAssetNameKey = keywordSearch.targeted ? '' : filterProps.assetNameKey;

  const { assets, total, groups } = useFetchAssetsPivot(
    currentProject,
    backendPage,
    backendRowsPerPage,
    sortKey,
    sortDir,
    effectivePhase,
    backendAssetNameKey,
    approvalArray,
    workArray,
    viewMode,
  );

  const normalizedGroups = useMemo<PivotGroup[]>(() => {
    if (groups && groups.length > 0) {
      return groups as PivotGroup[];
    }
    return buildAssetGroups((assets || rawAssets || []) as Asset[]);
  }, [groups, assets, rawAssets]);

  // Now that group data is declared, we can safely use it in useMemo
  const allAssets = useMemo(() => {
    let list = [];

    if (viewMode === "grouped") {
      list = (normalizedGroups || []).flatMap((g: any) => g.items || []);
    } else {
      list = assets || rawAssets || [];
    }

    // remove duplicates
    const map = new Map();
    list.forEach(a => {
      map.set(`${a.group_1}-${a.relation}`, a);
    });

    return Array.from(map.values());
  }, [viewMode, normalizedGroups, assets, rawAssets]);
  // (Moved below the declaration of 'groups')

  const { latestComponents } = useFetchLatestAssetComponents(
    currentProject,
    allAssets,
    phaseComponents
  );


  const { enabled: showThumbnail, loading: thumbnailLoading } =
    useThumbnailVisibility(currentProject);

  const shouldShowThumbnails =
    thumbnailLoading === false && showThumbnail === true;

  const { thumbnails } = useFetchAssetThumbnails(
    currentProject!,
    allAssets,
    shouldShowThumbnails
  );

  const safeThumbnails =
    showThumbnail === true && !thumbnailLoading ? thumbnails : {};

  // Handle errors from the pivot fetch
  useEffect(() => {
    if (!assets && !groups && total === 0 && currentProject) {
      setError('Failed to load asset data. Please check your authentication or try again.');
      setSnackbarOpen(true);
    }
  }, [assets, groups, total, currentProject]);

  // ============================================
  // SIMPLER TAKE SORTING - Converts to integers
  // ============================================
  const enhancedCompareTake = useCallback(
    (a: any, b: any, dir: SortDir): number => {
      const isEmpty = (val: any) =>
        val === null ||
        val === undefined ||
        val === "" ||
        val === "-" ||
        val === "—";

      const aEmpty = isEmpty(a);
      const bEmpty = isEmpty(b);

      // Always push empty to bottom
      if (aEmpty && bEmpty) return 0;
      if (aEmpty) return 1;
      if (bEmpty) return -1;

      const aVal = parseInt(String(a).replace(/\D/g, ""), 10);
      const bVal = parseInt(String(b).replace(/\D/g, ""), 10);

      if (aVal === bVal) return 0;

      return dir === "asc"
        ? aVal > bVal ? 1 : -1
        : aVal < bVal ? 1 : -1;
    },
    []
  );

  /* Client-side filtering and sorting */
  const filteredAssets = useMemo(() => {
    if (!assets) return [];

    const nameFilter = keywordSearch.keyword;
    const approvalFilters = approvalArray.map((s) => s.toLowerCase());
    const workFilters = workArray.map((s) => s.toLowerCase());

    const phases = ['dsn', 'mdl', 'rig', 'bld', 'ldv'] as const;

    // First, filter the assets
    const base = assets.filter((asset: any) => {
      // Top-group filter
      if (selectedTopGroups.length > 0) {
        const normalizeTopGroup = (v: any) => {
          const s = (v || '').toString().trim();
          if (!s) return 'unassigned';
          const ls = s.toLowerCase();
          if (ls === 'unassigned' || ls === 'unassigned/' || ls === 'none' || ls === 'null' || ls === 'undefined') {
            return 'unassigned';
          }
          return ls;
        };

        const allowed = new Set(selectedTopGroups.map(normalizeTopGroup));
        const tg = normalizeTopGroup(asset.top_group_node);
        if (!allowed.has(tg)) return false;
      }

      // Keyword filter. Plain text keeps the old asset-name behavior; [Column]:value targets a column.
      if (nameFilter) {
        if (keywordSearch.targeted) {
          const values = getAssetColumnSearchValues(
            asset,
            keywordSearch.column,
            phaseComponents,
            latestComponents,
          );
          if (!valuesContainKeyword(values, nameFilter)) return false;
        } else {
          const name = (asset.group_1 || '').toString().toLowerCase();
          if (!name.includes(nameFilter)) return false;
        }
      }

      // Phase-locked matching
      const phase = effectivePhase && effectivePhase !== 'none'
        ? effectivePhase.toLowerCase()
        : null;

      const matchesPhase = (p: string) => {
        if (approvalFilters.length > 0) {
          const rawAppr = (asset[`${p}_approval_status`] || '')
            .toString()
            .toLowerCase();
          if (!approvalFilters.includes(rawAppr)) return false;
        }
        if (workFilters.length > 0) {
          const rawWork = (asset[`${p}_work_status`] || '')
            .toString()
            .toLowerCase();
          if (!workFilters.includes(rawWork)) return false;
        }
        return true;
      };

      // No filters at all → keep row
      if (!nameFilter && approvalFilters.length === 0 && workFilters.length === 0) {
        return true;
      }

      // If a specific phase is active, only that phase decides
      if (phase) {
        return matchesPhase(phase);
      }

      // Otherwise, keep the row if ANY phase matches
      return phases.some((p) => matchesPhase(p));
    });

    // ============================================
    // SORTING LOGIC
    // ============================================
    if (uiSortKey && uiSortDir !== 'none') {
      base.sort((a, b) => {
        // Component columns — any key that lives in phaseComponents config
        const isComponentCol = phaseComponents && Object.values(phaseComponents).flat().includes(uiSortKey);

        if (isComponentCol) {
          const aKey = `${a.group_1}-${a.relation}`;
          const bKey = `${b.group_1}-${b.relation}`;

          const aComponentList = latestComponents[aKey] || [];
          const bComponentList = latestComponents[bKey] || [];

          const aItem =
            aComponentList.find((x: any) => x.component === uiSortKey) ||
            aComponentList.find((x: any) => x.component && x.component.toLowerCase() === uiSortKey.toLowerCase());
          const bItem =
            bComponentList.find((x: any) => x.component === uiSortKey) ||
            bComponentList.find((x: any) => x.component && x.component.toLowerCase() === uiSortKey.toLowerCase());

          const aRaw = aItem && aItem.latest_document && aItem.latest_document.submitted_at_utc || null;
          const bRaw = bItem && bItem.latest_document && bItem.latest_document.submitted_at_utc || null;

          const aValue = aRaw ? new Date(aRaw).getTime() : null;
          const bValue = bRaw ? new Date(bRaw).getTime() : null;

          const aEmpty = aValue == null || isNaN(aValue);
          const bEmpty = bValue == null || isNaN(bValue);

          if (aEmpty && bEmpty) return 0;
          if (aEmpty) return 1;
          if (bEmpty) return -1;

          return uiSortDir === "asc"
            ? aValue! - bValue!
            : bValue! - aValue!;
        }

        // Regular columns
        if (uiSortKey === 'group_1') {
          return enhancedCompareStrings(a.group_1, b.group_1, uiSortDir);
        }
        if (uiSortKey === 'relation') {
          return enhancedCompareStrings(a.relation, b.relation, uiSortDir);
        }

        // Phase columns
        const m = uiSortKey.match(/^(mdl|rig|bld|dsn|ldv)_(work|appr|submitted|take|component)$/i);
        if (m) {
          const phase = m[1].toLowerCase();
          const field = m[2].toLowerCase();

          if (field === 'submitted') {
            const key = `${phase}_submitted_at_utc` as keyof typeof a;
            return enhancedCompareDates(a[key], b[key], uiSortDir);
          }

          if (field === 'take') {
            const key = `${phase}_take` as keyof typeof a;
            return enhancedCompareTake(a[key], b[key], uiSortDir);
          }

          if (field === 'component') {
            const key = `${phase}_component` as keyof typeof a;
            return enhancedCompareStrings(a[key], b[key], uiSortDir);
          }

          const key = (field === 'appr'
            ? `${phase}_approval_status`
            : `${phase}_work_status`) as keyof typeof a;

          return enhancedCompareStrings(a[key], b[key], uiSortDir);
        }

        return 0;
      });

    }

    return base;
  }, [
    assets,
    effectivePhase,
    uiSortKey,
    uiSortDir,
    keywordSearch,
    phaseComponents,
    approvalArray,
    workArray,
    selectedTopGroups,
    latestComponents,
    enhancedCompareTake,
    enhancedCompareStrings,
    enhancedCompareDates,
  ]);

  /* Effective count after filtering (for pagination display) */
  const effectiveCount = filtersActive ? filteredAssets.length : total;

  /* Load time zone from studio config on mount */
  useEffect(() => {
    if (currentStudio == null) {
      return
    }
    const controller = new AbortController();
    (async () => {
      try {
        const res: string | null = await queryConfig(
          'studio',
          currentStudio.key_name,
          'timezone',
        ).catch(e => {
          if (e.name === 'AbortError') {
            return;
          }
          throw e;
        });
        if (res != null) {
          setTimeZone(res);
        }
      } catch (e) {
        console.error(e);
      }
    })();
    return () => {
      controller.abort();
    };
  }, [currentStudio]);

  /* Load hidden columns - PRIMARY: localStorage, SECONDARY: pipeline settings */
  useEffect(() => {
    let aborted = false;

    (async () => {
      if (!currentProject) return;

      const projectKey = currentProject.key_name;

      // TRY 1: localStorage first (fast, reliable)
      try {
        const lsKey = lsKeyForProject(projectKey);
        const raw = localStorage.getItem(lsKey);

        if (raw) {
          const arr: string[] = JSON.parse(raw);
          const sanitized = arr.filter((id) => !FIXED_VISIBLE.has(id));
          if (!aborted) {
            setHiddenColumns(new Set(sanitized));
          }
          return; // Success with localStorage
        }
      } catch (lsError) {
        console.warn('localStorage load failed:', lsError);
      }

      // Default: empty set
      if (!aborted) {
        setHiddenColumns(new Set());
      }
    })();

    return () => {
      aborted = true;
    };
  }, [currentProject]);

  /* Cleanup on unmount */
  useEffect(() => {
    return () => {
      if (commitTimerRef.current != null) {
        window.clearTimeout(commitTimerRef.current);
        commitTimerRef.current = null;
      }
    };
  }, []);

  /* Handles changes to the sort order when a user interacts with the UI sort controls.*/
  const handleSortChange = (newUiKey: string) => {
    const { sort: newServerSortKey, phase } = resolveServerSort(newUiKey);

    // Determine the next direction: Flip only if clicking the currently active server key.
    const nextServerDir: SortDir =
      sortKey === newServerSortKey ? (sortDir === 'asc' ? 'desc' : 'asc') : 'asc';

    // 1. Update the server state immediately. This triggers useFetchAssetsPivot.
    setPhasePriority(phase);
    setSortKey(newServerSortKey);
    setSortDir(nextServerDir);

    // 2. Update the UI sort state immediately to reflect the arrow.
    setUiSortKey(newUiKey);
    setUiSortDir(nextServerDir);

    // 3 Reset to first page on sort change
    // setPageProps((prev) => ({ ...prev, page: 0 }));
  };

  /* Handles group name sorting toggle. */
  const handleGroupSortToggle = () => {
    setGroupSortDir(prev => prev === 'asc' ? 'desc' : 'asc');
  };

  const handleViewChange = (nextView: 'grid' | 'list') => {
    setBarView(nextView);
    setPageProps((prev) => ({ ...prev, page: 0 }));
  };

  /* Toggle column visibility */
  const toggleColumn = (id: string) => {
    if (FIXED_VISIBLE.has(id)) return;
    setHiddenColumns((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  /* Show all columns */
  const showAll = () => {
    const next = new Set<string>();
    setHiddenColumns(next);
  };

  /* Hide all non-fixed columns */
  const hideAllNonFixed = () => {
    // Build current full column id list dynamically from phaseComponents
    const phases = ['dsn', 'mdl', 'rig', 'bld', 'ldv'];
    const dynamicIds: string[] = [
      'dsn_approval_status', 'dsn_work_status', 'dsn_take', 'dsn_assign_to',
      'mdl_approval_status', 'mdl_work_status', 'mdl_take', 'modeling_assigned_to',
      'rig_approval_status', 'rig_work_status', 'rig_take', 'rigging_assigned_to',
      'bld_approval_status', 'bld_work_status', 'bld_take',
      'ldv_approval_status', 'ldv_work_status', 'ldv_take', 'lookdev_assigned_to',
      'relation',
    ];
    if (phaseComponents) {
      phases.forEach(phase => {
        const ids = phaseComponents[phase] || [];
        ids.forEach(id => dynamicIds.push(id));
      });
    }
    const next = new Set<string>(dynamicIds.filter(id => !FIXED_VISIBLE.has(id)));
    setHiddenColumns(next);
  };

  /* Count of currently visible togglable columns */
  const visibleCount = useMemo(() => {
    const phases = ['dsn', 'mdl', 'rig', 'bld', 'ldv'];
    const togglableIds: string[] = [
      'dsn_approval_status', 'dsn_work_status', 'dsn_take', 'dsn_assign_to',
      'mdl_approval_status', 'mdl_work_status', 'mdl_take', 'modeling_assigned_to',
      'rig_approval_status', 'rig_work_status', 'rig_take', 'rigging_assigned_to',
      'bld_approval_status', 'bld_work_status', 'bld_take',
      'ldv_approval_status', 'ldv_work_status', 'ldv_take', 'lookdev_assigned_to',
      'relation',
    ];
    if (phaseComponents) {
      phases.forEach(phase => {
        const ids = phaseComponents[phase] || [];
        ids.forEach(id => togglableIds.push(id));
      });
    }
    let c = 0;
    togglableIds.forEach((id) => {
      if (!hiddenColumns.has(id)) c += 1;
    });
    return c;
  }, [hiddenColumns, phaseComponents]);

  /* Handlers for filter changes that also reset pagination to page 0 */
  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  /* Handler for page changes */
  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  /* Handler for asset name filter changes */
  const handleFilterAssetNameChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      assetNameKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  /* Handlers for approval and work status filter changes */
  const handleApprovalStatusesChange: SelectProps['onChange'] = (event: React.ChangeEvent<{ value: unknown }>) => {
    setFilterProps({
      ...filterProps,
      approvalStatuses: event.target.value as string[],
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  /* Handler for work status filter changes */
  const handleWorkStatusesChange: SelectProps['onChange'] = (event: React.ChangeEvent<{ value: unknown }>) => {
    setFilterProps({
      ...filterProps,
      workStatuses: event.target.value as string[],
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  /* Handler for approval statuses chip delete */
  const handleApprovalStatusesChipDelete = (name: string) => {
    setFilterProps({
      ...filterProps,
      approvalStatuses: filterProps.approvalStatuses.filter(value => value !== name),
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  /* Handler for work statuses chip delete */
  const handleWorkStatusesChipDelete = (name: string) => {
    setFilterProps({
      ...filterProps,
      workStatuses: filterProps.workStatuses.filter(value => value !== name),
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  /* Handler for date/time formatting */
  const dateTimeFormat = new Intl.DateTimeFormat(
    undefined,
    {
      timeZone: timeZone,
      dateStyle: 'medium',
      timeStyle: 'medium'
    }
  );

  /* Memoized table footer to prevent unnecessary re-renders */
  const tableFooter = (
    <AssetsDataTableFooter
      count={effectiveCount}
      page={pageProps.page}
      rowsPerPage={pageProps.rowsPerPage}
      onChangePage={handlePageChange}
      onChangeRowsPerPage={handleRowsPerPageChange}
    />
  );

  /* Build counts from current loaded groups */
  const topGroupCounts = React.useMemo(() => {
    const map = new Map<string, number>();
    (normalizedGroups || []).forEach((g: any) => {
      const name = String(g.top_group_node || "Unassigned");
      const cnt = Array.isArray(g.items) ? g.items.length : 0;
      map.set(name, (map.get(name) || 0) + cnt);
    });
    return map;
  }, [normalizedGroups]);

  const availableTopGroupNames = React.useMemo(() => {
    const names = new Set<string>();
    (topGroupNames || []).forEach((name) => {
      if (name) names.add(name);
    });
    (normalizedGroups || []).forEach((group: any) => {
      names.add(String(group.top_group_node || UNASSIGNED_GROUP_LABEL));
    });
    return Array.from(names);
  }, [topGroupNames, normalizedGroups]);

  /* Filtered top group names based on search query */
  const filteredTopGroupNames = React.useMemo(() => {
    const q = barSearch.trim().toLowerCase();
    const names = (availableTopGroupNames || [])
      .slice()
      .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }));
    if (!q) return names;
    return names.filter((n) => n.toLowerCase().includes(q));
  }, [availableTopGroupNames, barSearch]);

  const rawGroups = normalizedGroups || [];

  /* Build total counts for top groups */
  const topGroupTotalCounts = React.useMemo(() => {
    const map = new Map<string, number>();
    rawGroups.forEach((g: any) => {
      const name = String(g.top_group_node || "Unassigned");
      const cnt = Array.isArray(g.items) ? g.items.length : 0;
      map.set(name, (map.get(name) || 0) + cnt);
    });
    return map;
  }, [rawGroups]);

  /* Client-side pagination when filters are active */
  const pagedAssets = useMemo(() => {
    if (!filtersActive) return filteredAssets;

    const start = pageProps.page * pageProps.rowsPerPage;
    const end = start + pageProps.rowsPerPage;
    return filteredAssets.slice(start, end);
  }, [filtersActive, filteredAssets, pageProps.page, pageProps.rowsPerPage]);


  /* Client-side filtering of groups based on selected top groups + other filters */
  const filteredGroups = useMemo(() => {
    const list = normalizedGroups || [];

    const nameFilter = keywordSearch.keyword;
    const approvalFilters = approvalArray.map((s) => s.toLowerCase());
    const workFilters = workArray.map((s) => s.toLowerCase());
    const phases = ['dsn', 'mdl', 'rig', 'bld', 'ldv'] as const;
    const phase = effectivePhase && effectivePhase !== 'none'
      ? effectivePhase.toLowerCase()
      : null;

    const itemMatches = (item: any) => {
      // Keyword filter. Plain text keeps the old asset-name behavior; [Column]:value targets a column.
      if (nameFilter) {
        if (keywordSearch.targeted) {
          const values = getAssetColumnSearchValues(
            item,
            keywordSearch.column,
            phaseComponents,
            latestComponents,
          );
          if (!valuesContainKeyword(values, nameFilter)) return false;
        } else {
          const n = (
            item.group_1 ||
            item.group_1_name ||
            item.name ||
            item.asset_name ||
            ''
          )
            .toString()
            .toLowerCase();
          if (!n.includes(nameFilter)) return false;
        }
      }

      const matchesPhase = (p: string) => {
        if (approvalFilters.length > 0) {
          const rawAppr = (item[`${p}_approval_status`] || '')
            .toString()
            .toLowerCase();
          if (!approvalFilters.includes(rawAppr)) return false;
        }
        if (workFilters.length > 0) {
          const rawWork = (item[`${p}_work_status`] || '')
            .toString()
            .toLowerCase();
          if (!workFilters.includes(rawWork)) return false;
        }
        return true;
      };

      // No approval/work filters → keep item (name filter already applied above)
      if (approvalFilters.length === 0 && workFilters.length === 0) {
        return true;
      }

      // If a specific phase is active (e.g. "rig"), only that phase decides.
      if (phase) return matchesPhase(phase);

      // Otherwise, keep the item if ANY phase matches.
      return phases.some((p) => matchesPhase(p));
    };

    // 1) Top-group filter
    let baseGroups: PivotGroup[] = list;

    // NO selection -> show EVERYTHING
    if (selectedTopGroups.length > 0) {
      const allowed = new Set(selectedTopGroups.map((g) => g.toLowerCase()));
      baseGroups = baseGroups.filter((g: any) =>
        allowed.has(String(g.top_group_node || '').toLowerCase())
      );
    }

    // 2) Apply asset-name / approval / work filters to items inside each group
    const out = baseGroups
      .map((g: any) => {
        const items = Array.isArray(g.items) ? g.items : [];
        const kept = items.filter(itemMatches);
        return { ...g, items: kept };
      })
      .filter((g: any) => (Array.isArray(g.items) ? g.items.length : 0) > 0);

    // If there are NO filters at all, keep all groups
    const anyInnerFilter =
      !!nameFilter || approvalFilters.length > 0 || workFilters.length > 0;
    if (!anyInnerFilter) return baseGroups;

    return out;
  }, [
    normalizedGroups,
    selectedTopGroups,
    keywordSearch,
    phaseComponents,
    latestComponents,
    approvalArray,
    workArray,
    effectivePhase,
  ]);

  /* Total count for pagination display when in grouped view with filters active. */
  const filteredTotal = React.useMemo(() => {
    if (barView !== "grid") return total || 0;

    // if no group filter -> backend total
    if (selectedTopGroups.length === 0) return total || 0;

    // sum of items in visible groups
    return (filteredGroups || []).reduce((acc: number, g: any) => {
      const items = Array.isArray(g.items) ? g.items : [];
      return acc + items.length;
    }, 0);
  }, [barView, total, selectedTopGroups, filteredGroups]);

  /* Sort groups by name before pagination (empty group names go to the end) */
  const sortedGroups = React.useMemo(() => {
    const groupsToSort = filteredGroups || [];

    // Apply group name sorting with empty values at the end
    const sorted = [...groupsToSort];

    sorted.sort((a, b) => {
      const nameA = (a.top_group_node || 'Unassigned').toLowerCase();
      const nameB = (b.top_group_node || 'Unassigned').toLowerCase();

      // Treat "Unassigned" as a special case - should go to the end
      const aIsUnassigned = nameA === 'unassigned';
      const bIsUnassigned = nameB === 'unassigned';

      if (aIsUnassigned && bIsUnassigned) return 0;
      if (aIsUnassigned) return 1;  // Unassigned goes after named groups
      if (bIsUnassigned) return -1; // Named groups go before Unassigned

      // Normal alphabetical sorting
      return groupSortDir === 'asc'
        ? nameA.localeCompare(nameB)
        : nameB.localeCompare(nameA);
    });

    return sorted;
  }, [filteredGroups, groupSortDir]);

  /* ____________________________________________________________________________________
      Sort items within each group based on the active UI sort key and direction.
      This is applied after the groups themselves have been sorted, allowing for independent
      sorting of groups and items. The sorting logic for items is similar to the main table
      sorting but is applied within each group context.
    ____________________________________________________________________________________*/
  const sortedGroupsWithItems = React.useMemo(() => {
    return sortedGroups.map(group => {
      const items = [...(group.items || [])];

      // Apply item sorting if a sort key is active
      if (uiSortKey && uiSortDir !== 'none') {
        const isComponentCol = phaseComponents && Object.values(phaseComponents).flat().includes(uiSortKey);

        items.sort((a, b) => {
          // Component columns
          if (isComponentCol) {
            const aKey = `${a.group_1}-${a.relation}`;
            const bKey = `${b.group_1}-${b.relation}`;

            const aComponentList = latestComponents[aKey] || [];
            const bComponentList = latestComponents[bKey] || [];

            const aItem =
              aComponentList.find((x: any) => x.component === uiSortKey) ||
              aComponentList.find((x: any) => x.component && x.component.toLowerCase() === uiSortKey.toLowerCase());
            const bItem =
              bComponentList.find((x: any) => x.component === uiSortKey) ||
              bComponentList.find((x: any) => x.component && x.component.toLowerCase() === uiSortKey.toLowerCase());

            const aDate = aItem && aItem.latest_document ? aItem.latest_document.submitted_at_utc : null;
            const bDate = bItem && bItem.latest_document ? bItem.latest_document.submitted_at_utc : null;

            return enhancedCompareDates(aDate, bDate, uiSortDir);
          }

          // Regular columns
          if (uiSortKey === 'group_1') {
            return enhancedCompareStrings(a.group_1, b.group_1, uiSortDir);
          }

          if (uiSortKey === 'component') {
            return enhancedCompareStrings(a.component, b.component, uiSortDir);
          }

          const m = uiSortKey.match(/^(mdl|rig|bld|dsn|ldv)_(work|appr|submitted|take|component)$/i);
          if (m) {
            const phase = m[1].toLowerCase();
            const field = m[2].toLowerCase();

            if (field === 'submitted') {
              const aVal = a[`${phase}_submitted_at_utc`] || '';
              const bVal = b[`${phase}_submitted_at_utc`] || '';
              return enhancedCompareDates(aVal, bVal, uiSortDir);
            }

            if (field === 'take') {
              const aVal = a[`${phase}_take`] || '';
              const bVal = b[`${phase}_take`] || '';
              return enhancedCompareTake(aVal, bVal, uiSortDir);
            }

            const key = field === 'appr'
              ? `${phase}_approval_status`
              : `${phase}_work_status`;

            const aVal = (a[key] || '').toString().trim();
            const bVal = (b[key] || '').toString().trim();
            return enhancedCompareStrings(aVal, bVal, uiSortDir);
          }

          return 0;
        });
      }

      return { ...group, items };
    });
  }, [
    sortedGroups,
    uiSortKey,
    uiSortDir,
    latestComponents,
    enhancedCompareTake,
    enhancedCompareStrings,
    enhancedCompareDates
  ]);

  /* ____________________________________________________________________________________
      Client-side pagination of groups and their items when filters are active.
      This logic ensures that pagination is applied to the items across groups,
      rather than paginating groups themselves.
    ____________________________________________________________________________________*/
  const pagedGroups = React.useMemo(() => {
    const pg = paginateGroups(
      sortedGroupsWithItems || [],
      pageProps.page,
      pageProps.rowsPerPage
    );

    // Attach totalCount for "visible of total" display in grouped headers
    return pg.map((g: any) => {
      const name = String(g.top_group_node || 'Unassigned');
      return {
        ...g,
        totalCount: topGroupTotalCounts.get(name) || ((g.items || []).length || 0),
      };
    });
  }, [
    sortedGroupsWithItems,
    pageProps.page,
    pageProps.rowsPerPage,
    topGroupTotalCounts,
  ]);

  /* ____________________________________________________________________________________
      Helper function to paginate groups and their items on the client side.
      It flattens the groups into a list of items, applies pagination, and then
      rebuilds the groups with only the paginated items.
    ____________________________________________________________________________________*/
  function paginateGroups(
    groups: any[],
    page: number,
    rowsPerPage: number
  ) {
    const start = page * rowsPerPage;
    const end = start + rowsPerPage;

    // Flatten items in display order
    const flat: Array<{ key: string; group: any; item: any }> = [];
    for (const g of groups || []) {
      const items = Array.isArray(g.items) ? g.items : [];
      for (const item of items) {
        flat.push({ key: String(g.top_group_node || ""), group: g, item });
      }
    }
    /* ____________________________________________________________________________________
        Apply pagination to the flattened list of items. This ensures that we are paginating
        across the entire dataset of items, regardless of their groupings.
        ____________________________________________________________________________________*/
    const slice = flat.slice(start, end);

    // Rebuild groups with sliced items (keep order)
    const out: any[] = [];
    const seen = new Map<string, any>();

    for (const row of slice) {
      if (!seen.has(row.key)) {
        const ng = { ...row.group, items: [] as any[] };
        seen.set(row.key, ng);
        out.push(ng);
      }
      seen.get(row.key).items.push(row.item);
    }

    return out;
  }

  const filterActiveColors = filtersActive ? 'primary' : 'default';
  return (
    <>
      <StyledContainer>
        <AssetTableFilter
          filterActive={filtersActive}
          showInlineFilters={false}
          phaseComponents={phaseComponents}
          headerLeft={(
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                borderRadius: 2,
                overflow: 'hidden',
                paddingLeft: 4,
                paddingRight: 4,
                paddingTop: 10,
                height: 50,
              }}
            >
              <IconButton
                size="small"
                onClick={() => handleViewChange('list')}
                style={{ padding: 6, borderRadius: 0 }}
                aria-label="List view"
                title="List view"
              >
                <ViewListIcon
                  style={{
                    fontSize: 25,
                    color: barView === 'list' ? '#00b7ff' : '#b0b0b0',
                  }}
                />
              </IconButton>

              <IconButton
                size="small"
                onClick={() => handleViewChange('grid')}
                style={{ padding: 6, borderRadius: 0 }}
                aria-label="Grouped view"
                title="Grouped view"
              >
                <ViewModuleIcon
                  style={{
                    fontSize: 25,
                    color: barView === 'grid' ? '#00b7ff' : '#b0b0b0',
                  }}
                />
              </IconButton>

              {/* Group sorting toggle */}
              {isGrouped && (
                <Box display="flex" alignItems="center" ml={2} style={{ gap: 8 }}>
                  <Typography variant="caption" style={{ color: '#aaa', fontSize: 11 }}>
                    Sort Groups:
                  </Typography>
                  <Button
                    size="small"
                    variant="outlined"
                    onClick={handleGroupSortToggle}
                    style={{
                      height: 24,
                      fontSize: 11,
                      minWidth: 80,
                      padding: '0 6px',
                      color: '#00b7ff',
                      borderColor: '#00b7ff',
                    }}
                  >
                    Name {groupSortDir === 'asc' ? 'A-Z ↑' : 'Z-A ↓'}
                  </Button>
                </Box>
              )}
            </div>
          )}
          headerRight={(
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <TextField
                placeholder={barSearch.trim().length >= 3 ? "Searching assets" : "Search Assets or [Column]:Keyword"}
                variant="outlined"
                value={barSearch}
                onChange={(e) => {
                  const v = e.target.value;
                  setBarSearch(v);

                  // Update filter only if 3+ chars or cleared
                  if (v.trim().length >= 3 || v.trim().length === 0) {
                    setFilterProps((prev) => ({ ...prev, assetNameKey: v } as any));
                    setPageProps((prev) => ({ ...prev, page: 0 }));
                  }

                }}
                InputProps={{
                  style: {
                    height: 28,
                    width: 320,
                    fontSize: 12,
                  },
                  endAdornment: barSearch.trim().length >= 3 ? (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        onClick={() => {
                          setBarSearch('');
                          setFilterProps((prev) => ({ ...prev, assetNameKey: '' } as any));
                          setPageProps((prev) => ({ ...prev, page: 0 }));
                        }}
                      >
                        <ClearIcon style={{ fontSize: 16, color: '#888' }} />
                      </IconButton>
                    </InputAdornment>
                  ) : null,
                }}
              />

              <Button
                size="small"
                variant="contained"
                startIcon={<FilterListIcon style={{
                  color: filterActiveColors === 'primary' ? '#fff' : '#ffffffff'
                }} />}
                onClick={() => setFilterDrawerOpen(true)}
                style={{
                  height: 28,
                  textTransform: 'none',
                  fontSize: 12,
                  backgroundColor: filterActiveColors === 'primary' ? '#00b7ff' : '#3d3d3dff',
                  color: '#fff',
                  borderRadius: 2,
                }}
              >
                Filter
              </Button>
              <Drawer
                anchor="right"
                open={filterDrawerOpen}
                onClose={() => setFilterDrawerOpen(false)}
                PaperProps={{
                  style: {
                    width: 320,
                    background: "#2f2f2f",
                    color: "#e0e0e0",
                    borderRadius: 2,
                    // push the drawer down below the top bar/header
                    top: 150,
                    height: "calc(100% - 150px)",
                    right: 250,
                  },
                }}
              >
                <Box style={{ height: "100%", overflowY: "auto" }}>
                  {/* Clear all */}
                  <MenuItem
                    dense
                    onClick={() => setSelectedTopGroups([])}
                    style={{ fontWeight: 600 }}
                  >
                    Clear all filters
                  </MenuItem>

                  <Divider />

                  {/* Collapsible Section Header: Asset Type */}
                  <List disablePadding>
                    <ListItem
                      button
                      dense
                      onClick={() => setAssetTypeOpen((v) => !v)}
                      style={{ paddingLeft: 12, paddingRight: 12 }}
                    >
                      <ListItemIcon style={{ minWidth: 32 }}>
                        {AssetTypeOpen ? <ExpandLess /> : <ExpandMore />}
                      </ListItemIcon>
                      <ListItemText
                        primary="Asset Groups"
                        primaryTypographyProps={{ style: { fontSize: 12, fontWeight: 700 } }}
                      />
                    </ListItem>

                    <Collapse in={AssetTypeOpen} timeout="auto" unmountOnExit>
                      <Box style={{ maxHeight: 360, overflowY: "hidden", padding: 0 }}>
                        {(filteredTopGroupNames || []).map((name) => {
                          const isChecked = selectedTopGroups.includes(name);
                          const count = topGroupCounts.get(name) || 0;

                          return (
                            <MenuItem
                              key={name}
                              dense
                              style={{
                                paddingTop: 2,
                                paddingBottom: 2,
                                minHeight: 28,
                                gap: 4, // space between items cherckbox + icon + text
                              }}
                              onClick={() => {
                                setSelectedTopGroups((prev) =>
                                  prev.includes(name)
                                    ? prev.filter((n) => n !== name)
                                    : [...prev, name]
                                );
                              }}
                            >
                              <Checkbox
                                checked={isChecked}
                                size="small"
                                style={{ padding: 4, color: '#b0b0b0' }}
                              />
                              <ListItemIcon
                                style={{
                                  minWidth: 16,
                                  color: '#f0f0f0'
                                }}>
                                <FolderIcon
                                  style={{
                                    fontSize: 14,
                                    color: isChecked ? '#00b7ff' : '#b0b0b0',
                                  }} />
                              </ListItemIcon>
                              <ListItemText
                                primary={name}
                                primaryTypographyProps={{ style: { fontSize: 12, lineHeight: '16px' } }}
                              />
                              <Box
                                style={{
                                  marginLeft: 8,
                                  opacity: 0.75,
                                  fontSize: 12
                                }}>
                                {count}
                              </Box>
                            </MenuItem>
                          );
                        })}
                      </Box>
                    </Collapse>
                  </List>
                  <Divider />
                  {/* Collapsible Section Header: Approval Status */}
                  <>
                    <List disablePadding>
                      <ListItem
                        button
                        dense
                        onClick={() => setApprovalStatusOpen((v: boolean) => !v)}
                        style={{ paddingLeft: 12, paddingRight: 12 }}
                      >
                        <ListItemIcon style={{ minWidth: 32 }}>
                          {ApprovalStatusOpen ? <ExpandLess /> : <ExpandMore />}
                        </ListItemIcon>
                        <ListItemText
                          primary="Approval Status"
                          primaryTypographyProps={{ style: { fontSize: 12, fontWeight: 700 } }}
                        />
                      </ListItem>
                      <Collapse in={ApprovalStatusOpen} timeout="auto" unmountOnExit>
                        <Box style={{ maxHeight: 1500, overflowY: "hidden" }}>
                          {approvalStatuses
                            .slice()
                            .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }))
                            .map((status: string) => {
                              const isChecked = filterProps.approvalStatuses.includes(status);
                              return (
                                <MenuItem
                                  key={status}
                                  dense
                                  style={{
                                    paddingTop: 2,
                                    paddingBottom: 2,
                                    minHeight: 28
                                  }}
                                  onClick={() => {
                                    setFilterProps((prev) => {
                                      const current = prev.approvalStatuses;
                                      const next = current.includes(status)
                                        ? current.filter((s) => s !== status)
                                        : [...current, status];
                                      return { ...prev, approvalStatuses: next };
                                    });
                                    setPageProps((prev) => ({ ...prev, page: 0 }));
                                  }}
                                >
                                  <Checkbox
                                    checked={isChecked}
                                    size="small"
                                    style={{ padding: 4, color: '#b0b0b0' }}
                                  />
                                  <ListItemText
                                    primary={status}
                                    primaryTypographyProps={{ style: { fontSize: 12 } }}
                                  />
                                </MenuItem>
                              );
                            })}
                        </Box>
                      </Collapse>
                    </List>
                    <Divider />

                    {/* Collapsible Section Header: Work Status */}
                    <List disablePadding>
                      <ListItem
                        button
                        dense
                        onClick={() => setWorkStatusOpen((v: boolean) => !v)}
                        style={{ paddingLeft: 12, paddingRight: 12 }}
                      >
                        <ListItemIcon style={{ minWidth: 32 }}>
                          {workStatusOpen ? <ExpandLess /> : <ExpandMore />}
                        </ListItemIcon>
                        <ListItemText
                          primary="Work Status"
                          primaryTypographyProps={{ style: { fontSize: 12, fontWeight: 700 } }}
                        />
                      </ListItem>
                      <Collapse in={workStatusOpen} timeout="auto" unmountOnExit>
                        <Box style={{ maxHeight: 1500, overflowY: "hidden" }}>
                          {workStatuses
                            .slice()
                            .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }))
                            .map((status: string) => {
                              const isChecked = filterProps.workStatuses.includes(status);
                              return (
                                <MenuItem
                                  key={status}
                                  dense
                                  style={{
                                    paddingTop: 2,
                                    paddingBottom: 2,
                                    minHeight: 28
                                  }}
                                  onClick={() => {
                                    setFilterProps((prev) => {
                                      const current = prev.workStatuses;
                                      const next = current.includes(status)
                                        ? current.filter((s) => s !== status)
                                        : [...current, status];
                                      return { ...prev, workStatuses: next };
                                    });
                                    setPageProps((prev) => ({ ...prev, page: 0 }));
                                  }}
                                >
                                  <Checkbox
                                    checked={isChecked}
                                    size="small"
                                    style={{ padding: 4, color: '#b0b0b0' }}
                                  />
                                  <ListItemText
                                    primary={status}
                                    primaryTypographyProps={{ style: { fontSize: 12 } }}
                                  />
                                </MenuItem>
                              );
                            })}
                        </Box>
                      </Collapse>
                    </List>
                  </>
                </Box>
              </Drawer>
            </div>
          )}
          filterAssetName={filterProps.assetNameKey}
          selectApprovalStatuses={
            filterProps.approvalStatuses
          }
          selectWorkStatuses={
            filterProps.workStatuses
          }

          onAssetNameChange={handleFilterAssetNameChange}
          onApprovalStatusesChange={handleApprovalStatusesChange}
          onWorkStatusesChange={handleWorkStatusesChange}
          onApprovalStatusChipDelete={handleApprovalStatusesChipDelete}
          onWorkStatusChipDelete={handleWorkStatusesChipDelete}
          onResetClick={handleFilterResetClick}

          /* Drawer-based column visibility */
          hiddenColumns={hiddenColumns}
          onHiddenColumnsChange={setHiddenColumns}
          onToggleColumn={toggleColumn}
          onShowAll={showAll}
          onHideAll={hideAllNonFixed}
          visibleCount={visibleCount}
        >
        </AssetTableFilter>
        <StyledTableDiv>
          <StyledPaper>
            <StyledContentDiv>
              <Box
                mb={2}
              >
                {isGrouped ? (
                  <Box fontSize={16} fontWeight={600} width="100%">
                    <AssetsGroupedDataTable
                      groups={pagedGroups}
                      thumbnails={safeThumbnails}
                      phaseComponents={phaseComponents}
                      sortKey={uiSortKey}
                      sortDir={uiSortDir}
                      groupSortDir={groupSortDir}
                      onSortChange={handleSortChange}
                      onGroupSortToggle={handleGroupSortToggle}
                      hiddenColumns={hiddenColumns}
                      dateTimeFormat={dateTimeFormat}
                      latestComponents={latestComponents}
                      selectedRowId={selectedRowId}
                      onRowSelect={handleRowSelect}
                      onFetchAssetComment={handleFetchAssetComment}
                      tableFooter={<></>}
                    />
                  </Box>
                ) : (
                  <AssetsDataTable
                    project={currentProject}
                    assets={pagedAssets}
                    phaseComponents={phaseComponents}
                    latestComponents={latestComponents}
                    tableFooter={<></>}
                    dateTimeFormat={dateTimeFormat}
                    thumbnails={safeThumbnails}

                    /* Sorting props */
                    currentSortKey={uiSortKey}
                    currentSortDir={uiSortDir}
                    hiddenColumns={hiddenColumns}
                    onSortChange={handleSortChange}

                    // Pass filter props to table (optional)
                    assetNameKey={filterProps.assetNameKey}
                    approvalStatuses={filterProps.approvalStatuses}
                    workStatuses={filterProps.workStatuses}
                    page={pageProps.page}
                    rowsPerPage={pageProps.rowsPerPage}

                    /* Row selection */
                    selectedRowId={selectedRowId}
                    onRowSelect={handleRowSelect}
                    onFetchAssetComment={handleFetchAssetComment}
                  />
                )}
              </Box>
            </StyledContentDiv>
          </StyledPaper>
        </StyledTableDiv>

        <CsvDownloadComponent
          currentProject={currentProject}
        />

        <FooterWrapper>
          {tableFooter}
        </FooterWrapper>

      </StyledContainer>

      {/* Error Snackbar */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <div style={{
          background: '#d32f',
          color: '#fff',
          borderRadius: 4,
          fontSize: 14,
        }}
        >
          {error || 'An unknown error occurred.'}
        </div>
      </Snackbar>
    </>
  );
};


// Always-visible columns
const FIXED_VISIBLE = new Set<string>(['thumbnail', 'group_1_name']);

// Settings keys
const lsKeyForProject = (projectKeyName?: string) => {
  return `ppi:assets:hiddenColumns:${projectKeyName || 'unknown'}`;
};

export default AssetsDataTablePanel;
