import React, { useMemo, useRef, useState } from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    Tooltip,
} from "@material-ui/core";
import { ShotPivot, Colors, Column, ShotsDataTableProps, RecordTableHeadProps, ReviewInfo } from "./types";
import { useFetchShotThumbnails, useFetchLatestShotComponents, useFetchShotReviewInfos } from './hooks';

/* ──────────────────────────────────────────────────────────────────────────
   Phase Colors
   ────────────────────────────────────────────────────────────────────────── */
const SHOT_PHASES: { [key: string]: Colors } = {
    lay: { lineColor: '#3295FD', backgroundColor: '#004288' },
    anm: { lineColor: '#FD5E63', backgroundColor: '#5c0003' },
    gnz: { lineColor: '#C061FD', backgroundColor: '#340055' },
    mat: { lineColor: '#FE7DB3', backgroundColor: '#5f0028' },
    matnuke: { lineColor: '#FE7DB3', backgroundColor: '#3d0019' },
    fx: { lineColor: '#FDCD44', backgroundColor: '#CCA537' },
    cmp: { lineColor: '#D5F762', backgroundColor: '#4a6101' },
    dsp: { lineColor: '#FFD35D', backgroundColor: '#FFB54C' },
    cloth: { lineColor: '#FE9880', backgroundColor: '#FE8359' },
    cfxhair: { lineColor: '#FDA342', backgroundColor: '#FD8D03' },
    crd: { lineColor: '#FF8C12', backgroundColor: '#E88600' },
    drw: { lineColor: '#FDC0FF', backgroundColor: '#FDAFFB' },
    rtcgnz: { lineColor: '#D38AFF', backgroundColor: '#C061FD' },
    rtcmat: { lineColor: '#FFA3C5', backgroundColor: '#FE7DB3' },
    rtcmatnuke: { lineColor: '#FFC4B4', backgroundColor: '#FEAD92' },
    rtcdrw: { lineColor: '#FFC3FC', backgroundColor: '#FDAFFB' },
};

const DEFAULT_PHASE_COLORS: Colors = { lineColor: '#888', backgroundColor: '#444' };

const getPhaseColors = (phase: string): Colors => {
    return SHOT_PHASES[phase.toLowerCase()] || DEFAULT_PHASE_COLORS;
};

const getOrderedPhases = (phaseComponents: { [key: string]: string[] }): string[] => {
    const knownOrder = Object.keys(SHOT_PHASES);
    const settingPhases = Object.keys(phaseComponents || {});
    const settingByLower: { [key: string]: string } = {};
    settingPhases.forEach(s => { settingByLower[s.toLowerCase()] = s; });

    const ordered: string[] = [];
    knownOrder.forEach(p => {
        if (settingByLower[p]) ordered.push(settingByLower[p]);
        else ordered.push(p);
    });
    settingPhases.forEach(s => {
        if (!knownOrder.includes(s.toLowerCase())) ordered.push(s);
    });
    return ordered;
};

const getPhaseComponentIds = (
    phase: string,
    phaseComponents: { [key: string]: string[] },
): string[] => {
    const ids = (phaseComponents && phaseComponents[phase]) || [];
    return ids.filter(id => id.toLowerCase() !== phase.toLowerCase());
};

/* ──────────────────────────────────────────────────────────────────────────
   Status Maps
   ────────────────────────────────────────────────────────────────────────── */
type Status = Readonly<{ displayName: string; color: string }>;

const APPROVAL_STATUS: { [key: string]: Status } = {
    check: { displayName: 'Check', color: '#ca25ed' },
    clientReview: { displayName: 'Client Review', color: '#005fbd' },
    dirReview: { displayName: 'Dir Review', color: '#007fff' },
    epdReview: { displayName: 'EPD Review', color: '#4fa7ff' },
    clientOnHold: { displayName: 'Client On Hold', color: '#d69b00' },
    dirOnHold: { displayName: 'Dir On Hold', color: '#ffcc00' },
    epdOnHold: { displayName: 'EPD On Hold', color: '#ffdd55' },
    execRetake: { displayName: 'Exec Retake', color: '#a60000' },
    clientRetake: { displayName: 'Client Retake', color: '#c60000' },
    dirRetake: { displayName: 'Dir Retake', color: '#ff0000' },
    epdRetake: { displayName: 'EPD Retake', color: '#ff4f4f' },
    clientApproved: { displayName: 'Client Approved', color: '#45ff0d' },
    dirApproved: { displayName: 'Dir Approved', color: '#fff04f' },
    epdApproved: { displayName: 'EPD Approved', color: '#5cda82' },
    svApproved: { displayName: 'SV Approved', color: '#83e29f' },
    other: { displayName: 'Other', color: '#9a9a9a' },
    omit: { displayName: 'Omit', color: '#646464' },
};

const WORK_STATUS: { [key: string]: Status } = {
    check: { displayName: 'Check', color: '#e287f5' },
    cgsvOnHold: { displayName: 'CGSV On Hold', color: '#ffdd55' },
    svOnHold: { displayName: 'SV On Hold', color: '#ffe373' },
    leadOnHold: { displayName: 'Lead On Hold', color: '#fff04f' },
    cgsvRetake: { displayName: 'CGSV Retake', color: '#ff4f4f' },
    svRetake: { displayName: 'SV Retake', color: '#ff8080' },
    leadRetake: { displayName: 'Lead Retake', color: '#ffbbbb' },
    cgsvApproved: { displayName: 'CGSV Approved', color: '#5cda82' },
    svApproved: { displayName: 'SV Approved', color: '#83e29f' },
    leadApproved: { displayName: 'Lead Approved', color: '#b9eec9' },
    svOther: { displayName: 'SV Other', color: '#9a9a9a' },
    leadOther: { displayName: 'Lead Other', color: '#dbdbdb' },
};

const formatReviewCommentTooltip = (reviewInfo?: ReviewInfo): string => {
    const comments = (reviewInfo && reviewInfo.review_comments || [])
        .map(comment => (comment && comment.text || '').trim())
        .filter(Boolean);
    return comments.length > 0 ? comments.join('\n') : 'No comment found';
};

/* ──────────────────────────────────────────────────────────────────────────
   Build Columns
   ────────────────────────────────────────────────────────────────────────── */
const buildColumns = (phaseComponents: { [key: string]: string[] }): Column[] => {
    const fixed: Column[] = [
        { id: 'thumbnail', label: 'THUMBNAIL', fixed: true },
        { id: 'group_1_name', label: 'NAME 1', fixed: true },
        { id: 'group_2_name', label: 'NAME 2', fixed: true },
        { id: 'group_3_name', label: 'NAME 3', fixed: true },
    ];

    const orderedPhases = getOrderedPhases(phaseComponents);

    const phaseCols: Column[] = orderedPhases.flatMap(p => {
        const colors = getPhaseColors(p);
        const label = p.toUpperCase();
        const colBase = p.toLowerCase();

        const base: Column[] = [
            { id: `${colBase}_approval_status`, label: `${label} APPR`, colors },
            { id: `${colBase}_work_status`, label: `${label} WORK`, colors },
            { id: `${colBase}_take`, label: `${label} TAKE`, colors },
            { id: `${colBase}_assign_to`, label: `${label} Assign to`, colors },
        ];

        const componentIds = getPhaseComponentIds(p, phaseComponents);

        if (componentIds.length === 0) {
            base.push({
                id: `${colBase}_submitted_at`,
                label: `${label} SUBMITTED`,
                colors,
            });
        }

        const compCols: Column[] = componentIds.map(id => ({
            id,
            label: `${id.toUpperCase()} SUBMITTED`,
            colors,
        }));

        return [...base, ...compCols];
    });

    // cam_data_type goes immediately before relation (the task's "to the left of Relation")
    return [
        ...fixed,
        ...phaseCols,
        { id: 'cam_data_type', label: 'CAMDATATYPE' },
        { id: 'relation', label: 'RELATION' },
    ];
};

const STICKY_SHOT_COLUMN_WIDTHS: { [key: string]: number } = {
    thumbnail: 120,
    group_1_name: 130,
    group_2_name: 100,
    group_3_name: 100,
};

const STICKY_SHOT_COLUMN_LEFTS: { [key: string]: number } = {
    thumbnail: 0,
    group_1_name: STICKY_SHOT_COLUMN_WIDTHS.thumbnail,
    group_2_name: STICKY_SHOT_COLUMN_WIDTHS.thumbnail + STICKY_SHOT_COLUMN_WIDTHS.group_1_name,
    group_3_name: STICKY_SHOT_COLUMN_WIDTHS.thumbnail + STICKY_SHOT_COLUMN_WIDTHS.group_1_name + STICKY_SHOT_COLUMN_WIDTHS.group_2_name,
};

const getStickyShotColumnStyle = (
    columnId: string,
    options: { header?: boolean; backgroundColor?: string } = {},
): React.CSSProperties => {
    const width = STICKY_SHOT_COLUMN_WIDTHS[columnId];
    if (!width && width !== 0) return {};

    return {
        position: 'sticky',
        left: STICKY_SHOT_COLUMN_LEFTS[columnId],
        zIndex: options.header ? 30 : 20,
        width,
        minWidth: width,
        maxWidth: width,
        backgroundColor: options.backgroundColor || '#3f3f3f',
        backgroundClip: 'padding-box',
        boxShadow: columnId === 'group_3_name' ? '2px 0 0 rgba(0, 0, 0, 0.35)' : undefined,
    };
};

/* ──────────────────────────────────────────────────────────────────────────
   MultiLineTooltipTableCell
   ────────────────────────────────────────────────────────────────────────── */
type TooltipTableCellProps = {
    status: Status | undefined;
    leftBorderStyle: string;
    rightBorderStyle: string;
    bottomBorderStyle: string;
    isSelected?: boolean;
    onDoubleClick?: () => void;
    isClickable?: boolean;
    tooltipText?: string;
};

const MultiLineTooltipTableCell: React.FC<TooltipTableCellProps> = ({
    status,
    leftBorderStyle,
    rightBorderStyle,
    bottomBorderStyle = 'none',
    isSelected = false,
    onDoubleClick,
    isClickable = false,
    tooltipText = '',
}) => {
    const [open, setOpen] = useState(false);
    const statusText = status != null ? status.displayName : '-';
    const hasTooltip = !!status && tooltipText.trim().length > 0;

    const handleTooltipClick = (event: React.MouseEvent<HTMLSpanElement>) => {
        if (!hasTooltip) return;
        event.stopPropagation();
        setOpen(true);
    };

    return (
        <TableCell
            onDoubleClick={onDoubleClick}
            style={{
                color: status != null ? status.color : '',
                borderLeft: leftBorderStyle,
                borderRight: rightBorderStyle,
                borderBottom: bottomBorderStyle,
                whiteSpace: 'nowrap',
                backgroundColor: isSelected ? 'transparent' : undefined,
                cursor: isClickable || hasTooltip ? 'pointer' : 'default',
            }}
        >
            {hasTooltip ? (
                <Tooltip
                    title={<div style={{ fontSize: '0.8rem', whiteSpace: 'pre-wrap' }}>{tooltipText}</div>}
                    onClose={() => setOpen(false)}
                    open={open}
                    arrow
                >
                    <span onClick={handleTooltipClick}>{statusText}</span>
                </Tooltip>
            ) : (
                <span>{statusText}</span>
            )}
        </TableCell>
    );
};

type ClickTooltipTextProps = {
    text: string;
    tooltipText: string;
};

const ClickTooltipText: React.FC<ClickTooltipTextProps> = ({ text, tooltipText }) => {
    const [open, setOpen] = useState(false);

    const handleClick = (event: React.MouseEvent<HTMLSpanElement>) => {
        event.stopPropagation();
        setOpen(true);
    };

    return (
        <Tooltip
            title={<div style={{ fontSize: '0.8rem', whiteSpace: 'pre-wrap' }}>{tooltipText}</div>}
            onClose={() => setOpen(false)}
            open={open}
            arrow
        >
            <span onClick={handleClick} style={{ cursor: 'pointer' }}>
                {text}
            </span>
        </Tooltip>
    );
};

/* ──────────────────────────────────────────────────────────────────────────
   Table Head
   ────────────────────────────────────────────────────────────────────────── */
const getOrderKey = (colId: string): string | null => {
    if (colId === 'group_1_name') return 'group1_only';
    if (colId === 'group_2_name') return 'group2_only';
    if (colId === 'group_3_name') return 'group3_only';
    if (colId === 'relation') return 'relation_only';

    if (colId.endsWith('_work_status')) return colId.replace('_work_status', '_work');
    if (colId.endsWith('_approval_status')) return colId.replace('_approval_status', '_appr');
    if (colId.endsWith('_submitted_at')) return colId.replace('_submitted_at', '_submitted');
    if (colId.endsWith('_take')) return colId;

    return null;
};

const RecordTableHead: React.FC<RecordTableHeadProps> = ({
    columns,
    columnsState,
    sortKey,
    sortDir,
    onSortChange,
}) => (
    <TableHead>
        <TableRow>
            {columns.map((col) => {
                const lineColor = col.colors && col.colors.lineColor;
                const borderLine = lineColor ? `solid 3px ${lineColor}` : 'none';
                const isAppr = col.id.endsWith('_approval_status');
                const wantsLeftBar = isAppr || col.id === 'cam_data_type';
                const orderKey = getOrderKey(col.id);
                const isActive = orderKey === sortKey;

                const handleSortClick = () => {
                    if (orderKey) {
                        onSortChange(orderKey);
                    }
                };

                return (
                    <TableCell
                        key={col.id}
                        onClick={handleSortClick}
                        style={{
                            backgroundColor: (col.colors && col.colors.backgroundColor) || undefined,
                            borderTop: lineColor ? borderLine : 'none',
                            borderLeft: wantsLeftBar && lineColor ? borderLine : 'none',
                            borderRight: col.id === 'cam_data_type' && lineColor ? borderLine : 'none',
                            whiteSpace: 'nowrap',
                            ...getStickyShotColumnStyle(col.id, {
                                header: true,
                                backgroundColor: (col.colors && col.colors.backgroundColor) || '#3f3f3f',
                            }),
                            cursor: orderKey ? 'pointer' : 'default',
                            fontWeight: isActive ? 'bold' : 'normal',
                            userSelect: orderKey ? 'none' : 'auto',
                        }}
                        title={orderKey ? `Click to sort ${sortDir === 'asc' ? 'descending' : 'ascending'}` : ''}
                    >
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                            <span style={{ fontSize: 12, fontWeight: 500, textAlign: 'center' }}>
                                {col.label}
                            </span>
                            {isActive && (
                                <span style={{
                                    fontSize: 11,
                                    color: '#fcfeff',
                                    lineHeight: '11px',
                                    fontWeight: 'bold',
                                    marginTop: 2,
                                }}>
                                    {sortDir === 'asc' ? '▲' : '▼'}
                                </span>
                            )}
                        </div>
                    </TableCell>
                );
            })}

        </TableRow>
    </TableHead>
);

/* ──────────────────────────────────────────────────────────────────────────
   Shot Row
   ────────────────────────────────────────────────────────────────────────── */
type ShotRowProps = {
    shot: ShotPivot;
    thumbnails: { [key: string]: string };
    dateTimeFormat: Intl.DateTimeFormat;
    isLastRow: boolean;
    columnsState: { [key: string]: boolean };
    phaseComponents: { [key: string]: string[] };
    latestComponents: { [key: string]: any[] };
    reviewInfos: { [key: string]: ReviewInfo };
    camDataTypes?: { [shotKey: string]: string };
    selectedCellIds?: Set<string>;
    onCellSelect?: (cellId: string) => void;
    selectedRowId?: string | null;
    onRowSelect?: (rowId: string | null) => void;
};

const ShotRow: React.FC<ShotRowProps> = ({
    shot,
    thumbnails,
    dateTimeFormat,
    isLastRow,
    columnsState,
    phaseComponents,
    latestComponents,
    reviewInfos,
    camDataTypes,
    selectedCellIds,
    onCellSelect,
    selectedRowId,
    onRowSelect,
}) => {
    const thumbKey = `${shot.group_1}-${shot.group_2}-${shot.group_3}-${shot.relation}`;
    const compKey = `${shot.group_1}-${shot.group_2}-${shot.group_3}-${shot.relation}`;
    const rowId = `${shot.root}|${shot.project}|${shot.group_1}|${shot.group_2}|${shot.group_3}|${shot.relation}|${shot.component}`;
    const isRowSelected = selectedRowId === rowId;

    const getCellSel = (colId: string) => {
        const cellId = `${rowId}::${colId}`;
        const isCellSelected = selectedCellIds ? selectedCellIds.has(cellId) : false;
        const onDblCellClick = onCellSelect ? () => onCellSelect(cellId) : undefined;
        const selBg = isCellSelected ? 'transparent' : undefined;
        return { cellId, isCellSelected, onDblCellClick, selBg };
    };

    const clickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
    const handleRowClick = () => {
        if (!onRowSelect) return;
        if (clickTimer.current) clearTimeout(clickTimer.current);
        clickTimer.current = setTimeout(() => {
            onRowSelect(rowId);
            clickTimer.current = null;
        }, 250);
    };
    const handleRowDoubleClick = () => {
        if (clickTimer.current) {
            clearTimeout(clickTimer.current);
            clickTimer.current = null;
        }
    };

    const orderedPhases = getOrderedPhases(phaseComponents);

    return (
        <TableRow
            hover
            onClick={handleRowClick}
            onDoubleClick={handleRowDoubleClick}
            style={{
                backgroundColor: isRowSelected ? 'rgb(12, 132, 245)' : undefined,
                cursor: onRowSelect ? 'pointer' : 'default',
            }}
        >
            {/* Thumbnail */}
            {(() => {
                const sel = getCellSel('thumbnail');
                return (
                    <TableCell
                        onDoubleClick={sel.onDblCellClick}
                        style={{
                            ...getStickyShotColumnStyle('thumbnail', { backgroundColor: sel.selBg || '#3f3f3f' }),
                            backgroundColor: sel.selBg || '#3f3f3f',
                            cursor: onCellSelect ? 'pointer' : 'default',
                        }}
                    >
                        {thumbnails[thumbKey] ? (
                            <img
                                src={thumbnails[thumbKey]}
                                alt=""
                                style={{ width: 100, height: 'auto' }}
                            />
                        ) : (
                            <span style={{ fontSize: 12 }}>No Thumbnail</span>
                        )}
                    </TableCell>
                );
            })()}

            {/* Name columns */}
            {(() => {
                const sel = getCellSel('group_1_name');
                return (
                    <TableCell
                        onDoubleClick={sel.onDblCellClick}
                        style={{
                            ...getStickyShotColumnStyle('group_1_name', { backgroundColor: sel.selBg || '#3f3f3f' }),
                            textAlign: 'center',
                            verticalAlign: 'middle',
                            backgroundColor: sel.selBg || '#3f3f3f',
                            cursor: onCellSelect ? 'pointer' : 'default',
                        }}
                    >
                        {shot.group_1}
                    </TableCell>
                );
            })()}
            {(() => {
                const sel = getCellSel('group_2_name');
                return (
                    <TableCell
                        onDoubleClick={sel.onDblCellClick}
                        style={{
                            ...getStickyShotColumnStyle('group_2_name', { backgroundColor: sel.selBg || '#3f3f3f' }),
                            textAlign: 'center',
                            verticalAlign: 'middle',
                            backgroundColor: sel.selBg || '#3f3f3f',
                            cursor: onCellSelect ? 'pointer' : 'default',
                        }}
                    >
                        {shot.group_2}
                    </TableCell>
                );
            })()}
            {(() => {
                const sel = getCellSel('group_3_name');
                return (
                    <TableCell
                        onDoubleClick={sel.onDblCellClick}
                        style={{
                            ...getStickyShotColumnStyle('group_3_name', { backgroundColor: sel.selBg || '#3f3f3f' }),
                            textAlign: 'center',
                            verticalAlign: 'middle',
                            backgroundColor: sel.selBg || '#3f3f3f',
                            cursor: onCellSelect ? 'pointer' : 'default',
                        }}
                    >
                        {shot.group_3}
                    </TableCell>
                );
            })()}

            {/* Phase columns (dynamic) */}
            {orderedPhases.map((phase, phaseIdx) => {
                const colors = getPhaseColors(phase);
                const lineColor = colors.lineColor;
                const borderLine = `solid 3px ${lineColor}`;
                const bottomLine = isLastRow ? borderLine : 'none';
                const isLastPhase = phaseIdx === orderedPhases.length - 1;

                const phaseData =
                    (shot.phases && shot.phases[phase]) ||
                    (shot.phases && shot.phases[phase.toLowerCase()]);

                const colBase = phase.toLowerCase();
                const workCol = `${colBase}_work_status`;
                const apprCol = `${colBase}_approval_status`;
                const takeCol = `${colBase}_take`;
                const assignCol = `${colBase}_assign_to`;
                const submittedCol = `${colBase}_submitted_at`;

                const workStatus =
                    phaseData && phaseData.work_status && phaseData.work_status !== '-'
                        ? WORK_STATUS[phaseData.work_status]
                        : undefined;

                const approvalStatus =
                    phaseData && phaseData.approval_status && phaseData.approval_status !== '-'
                        ? APPROVAL_STATUS[phaseData.approval_status]
                        : undefined;
                const reviewInfo = reviewInfos[`${shot.group_1}-${shot.group_2}-${shot.group_3}-${phase}`];
                const commentTooltip = formatReviewCommentTooltip(reviewInfo);

                const componentIds = getPhaseComponentIds(phase, phaseComponents);
                const hasComponents = componentIds.length > 0;

                return (
                    <React.Fragment key={phase}>
                        {columnsState[apprCol] !== false && (() => {
                            const sel = getCellSel(apprCol);
                            return (
                                <MultiLineTooltipTableCell
                                    status={approvalStatus}
                                    leftBorderStyle={borderLine}
                                    rightBorderStyle={'none'}
                                    bottomBorderStyle={bottomLine}
                                    isSelected={sel.isCellSelected}
                                    onDoubleClick={sel.onDblCellClick}
                                    isClickable={!!onCellSelect}
                                    tooltipText={approvalStatus ? commentTooltip : ''}
                                />
                            );
                        })()}

                        {columnsState[workCol] !== false && (() => {
                            const sel = getCellSel(workCol);
                            return (
                                <MultiLineTooltipTableCell
                                    status={workStatus}
                                    leftBorderStyle={'none'}
                                    rightBorderStyle={'none'}
                                    bottomBorderStyle={bottomLine}
                                    isSelected={sel.isCellSelected}
                                    onDoubleClick={sel.onDblCellClick}
                                    isClickable={!!onCellSelect}
                                    tooltipText={workStatus ? commentTooltip : ''}
                                />
                            );
                        })()}

                        {columnsState[takeCol] !== false && (() => {
                            const sel = getCellSel(takeCol);
                            return (
                                <TableCell
                                    onDoubleClick={sel.onDblCellClick}
                                    style={{
                                        whiteSpace: 'nowrap',
                                        borderBottom: bottomLine,
                                        backgroundColor: sel.selBg,
                                        cursor: onCellSelect ? 'pointer' : 'default',
                                    }}
                                >
                                    {(phaseData && phaseData.take) || '–'}
                                </TableCell>
                            );
                        })()}

                        {columnsState[assignCol] !== false && (() => {
                            const sel = getCellSel(assignCol);
                            return (
                                <TableCell
                                    onDoubleClick={sel.onDblCellClick}
                                    style={{
                                        whiteSpace: 'nowrap',
                                        borderBottom: bottomLine,
                                        backgroundColor: sel.selBg,
                                        cursor: onCellSelect ? 'pointer' : 'default',
                                    }}
                                >
                                    {(phaseData && phaseData.assign_to) || '–'}
                                </TableCell>
                            );
                        })()}

                        {!hasComponents && columnsState[submittedCol] !== false && (() => {
                            const sel = getCellSel(submittedCol);
                            const submittedAt = phaseData && phaseData.submitted_at_utc;
                            const text = submittedAt
                                ? dateTimeFormat.format(new Date(submittedAt))
                                : '–';
                            const tooltipText = [
                                `Phase: ${phase}`,
                                `Submitted: ${text}`,
                            ].join('\n');

                            return (
                                <TableCell
                                    onDoubleClick={sel.onDblCellClick}
                                    style={{
                                        whiteSpace: 'nowrap',
                                        borderBottom: bottomLine,
                                        borderRight: isLastPhase ? borderLine : 'none',
                                        backgroundColor: sel.selBg,
                                        cursor: onCellSelect ? 'pointer' : 'default',
                                    }}
                                >
                                    <ClickTooltipText
                                        text={text}
                                        tooltipText={tooltipText}
                                    />
                                </TableCell>
                            );
                        })()}

                        {componentIds.map((componentId, compIdx) => {
                            if (columnsState[componentId] === false) return null;

                            const componentList =
                                (latestComponents && latestComponents[compKey]) || [];

                            const item =
                                componentList.find(
                                    (x: any) => x.component === componentId,
                                ) ||
                                componentList.find(
                                    (x: any) =>
                                        x.component &&
                                        x.component.toLowerCase() ===
                                        componentId.toLowerCase(),
                                );

                            const submittedAt =
                                item &&
                                item.latest_document &&
                                item.latest_document.submitted_at_utc;

                            const text = submittedAt
                                ? dateTimeFormat.format(new Date(submittedAt))
                                : '–';
                            const tooltipText = item
                                ? [
                                    `Component: ${item.component || componentId}`,
                                    `Phase: ${(item.latest_document && item.latest_document.phase) || phase}`,
                                    `Submitted: ${text}`,
                                ].join('\n')
                                : 'No submission available';

                            const isLastComponentOfLastPhase =
                                isLastPhase && compIdx === componentIds.length - 1;

                            const sel = getCellSel(componentId);
                            return (
                                <TableCell
                                    key={componentId}
                                    onDoubleClick={sel.onDblCellClick}
                                    style={{
                                        whiteSpace: 'nowrap',
                                        borderBottom: bottomLine,
                                        borderRight:
                                            isLastComponentOfLastPhase ? borderLine : 'none',
                                        backgroundColor: sel.selBg,
                                        cursor: onCellSelect ? 'pointer' : 'default',
                                    }}
                                >
                                    <ClickTooltipText
                                        text={text}
                                        tooltipText={tooltipText}
                                    />
                                </TableCell>
                            );
                        })}
                    </React.Fragment>
                );
            })}

            {/* CamDataType — sits to the left of Relation */}
            {columnsState['cam_data_type'] !== false && (() => {
                const sel = getCellSel('cam_data_type');
                const shotKey = `${shot.group_1}/${shot.group_2}/${shot.group_3}/${shot.relation}`;
                const value = camDataTypes ? camDataTypes[shotKey] : undefined;
                return (
                    <TableCell
                        onDoubleClick={sel.onDblCellClick}
                        style={{
                            whiteSpace: 'nowrap',
                            cursor: onCellSelect ? 'pointer' : 'default',
                        }}
                    >
                        {value || '–'}
                    </TableCell>
                );
            })()}

            {/* Relation */}
            {columnsState['relation'] !== false && (() => {
                const sel = getCellSel('relation');
                return (
                    <TableCell
                        onDoubleClick={sel.onDblCellClick}
                        style={{ backgroundColor: sel.selBg, cursor: onCellSelect ? 'pointer' : 'default' }}
                    >
                        {shot.relation}
                    </TableCell>
                );
            })()}
        </TableRow>
    );
};

/* ──────────────────────────────────────────────────────────────────────────
   Main Table
   ────────────────────────────────────────────────────────────────────────── */
const ShotsDataTable: React.FC<ShotsDataTableProps> = ({
    project,
    shots,
    tableFooter,
    dateTimeFormat,
    columnsState,
    sortKey,
    sortDir,
    onSortChange,
    phaseComponents,
    camDataTypes,
    selectedCellIds,
    onCellSelect,
    selectedRowId,
    onRowSelect,
}) => {
    if (project == null) return null;

    const shotsForThumbnail = useMemo(() => shots.map(s => ({
        groups: [s.group_1, s.group_2, s.group_3],
        relation: s.relation,
    })), [JSON.stringify(shots)]);

    const { thumbnails } = useFetchShotThumbnails(project, shotsForThumbnail);
    const { latestComponents } = useFetchLatestShotComponents(
        project, shotsForThumbnail, phaseComponents,
    );
    const { reviewInfos } = useFetchShotReviewInfos(project, shotsForThumbnail);

    const allColumns = buildColumns(phaseComponents);
    const visibleColumns = allColumns.filter(col =>
        col.fixed || columnsState[col.id] !== false,
    );

    return (
        <>
            <Table
                stickyHeader
                style={{
                    tableLayout: 'fixed',
                    width: 'max-content',
                    minWidth: '100%',
                    borderCollapse: 'separate',
                    borderSpacing: 0,
                }}
            >
                <RecordTableHead
                    columns={visibleColumns}
                    phaseComponents={phaseComponents}
                    latestComponents={latestComponents}
                    columnsState={columnsState}
                    sortKey={sortKey}
                    sortDir={sortDir}
                    onSortChange={onSortChange}
                />
                <TableBody>
                    {shots.map((shot, index) => (
                        <ShotRow
                            key={`${shot.group_1}-${shot.group_2}-${shot.group_3}-${shot.relation}-${index}`}
                            shot={shot}
                            thumbnails={thumbnails}
                            dateTimeFormat={dateTimeFormat}
                            isLastRow={index === shots.length - 1}
                            columnsState={columnsState}
                            phaseComponents={phaseComponents}
                            latestComponents={latestComponents}
                            reviewInfos={reviewInfos}
                            camDataTypes={camDataTypes}
                            selectedCellIds={selectedCellIds}
                            onCellSelect={onCellSelect}
                            selectedRowId={selectedRowId}
                            onRowSelect={onRowSelect}
                        />
                    ))}
                </TableBody>
            </Table>
            {tableFooter}
        </>
    );
};

export default ShotsDataTable;