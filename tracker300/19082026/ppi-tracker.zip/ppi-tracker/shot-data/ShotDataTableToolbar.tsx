import React from "react";
import {
  Toolbar,
  Typography,
  IconButton,
  Box,
  List,
  ListItem,
  ListItemText,
  Divider,
  Collapse,
  Checkbox,
  Button,
  Drawer,
  TextField,
  InputAdornment,
} from "@material-ui/core";
import { styled } from "@material-ui/core/styles";
import ViewListIcon from "@material-ui/icons/ViewList";
import ViewModuleIcon from "@material-ui/icons/ViewModule";
import FilterListIcon from "@material-ui/icons/FilterList";
import ViewColumnIcon from "@material-ui/icons/ViewColumn";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import { theme } from "../../../theme";

/* ------------------------------
   Styled Components
-------------------------------- */

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderBottom: `1px solid ${theme.palette.divider}`,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding: theme.spacing(1, 2),
  minHeight: 34,
}));

const LeftSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 12,
});

const RightSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 24,
});

const ToggleContainer = styled(Box)({
  display: "flex",
  borderRadius: 4,
});

// Asset-style rounded pill wrapper for COLUMNS button
const FilterButtonWrap = styled('div')({
  border: '1px solid rgba(55, 35, 165, 0.08)',
  borderRadius: 20,
  display: 'flex',
  alignItems: 'center',
});

/* ------------------------------
   Types
-------------------------------- */

type Filters = {
  shotGroups: string[];
  approvalStatus: string[];
  workStatus: string[];
};

export type ViewMode = "list" | "group";

type ColumnItem = {
  id: string;
  label: string;
  group: string;
};

export type ColumnState = {
  [key: string]: boolean;
};

type Props = {
  viewMode: ViewMode;
  onViewChange: (mode: ViewMode) => void;
  searchValue: string;
  onSearchChange: (value: string) => void;
  filters: Filters;
  onFilterChange: (newFilters: Filters) => void;
  columnsState: ColumnState;
  onColumnsChange: (newColumns: ColumnState) => void;
  onReset?: () => void;
  shotGroupOptions: { id: string; label: string }[];
  groupSortDir: 'asc' | 'desc';
  onGroupSortToggle: () => void;
  phaseComponents: { [key: string]: string[] };
};

/* ------------------------------
   Dynamic Column Builder
-------------------------------- */

// Known phase order — mirrors SHOT_PHASES in ShotsDataTable / ShotsDataTableGroup
const KNOWN_PHASE_ORDER = [
  'lay', 'anm', 'gnz', 'mat', 'matnuke', 'fx', 'cmp',
  'dsp', 'cloth', 'cfxhair', 'crd', 'drw',
  'rtcgnz', 'rtcmat', 'rtcmatnuke', 'rtcdrw',
];

const getPhaseComponentIds = (
  phase: string,
  phaseComponents: { [key: string]: string[] },
): string[] => {
  const ids = (phaseComponents && phaseComponents[phase]) || [];
  return ids.filter(id => id.toLowerCase() !== phase.toLowerCase());
};

const getOrderedPhases = (phaseComponents: { [key: string]: string[] }): string[] => {
  const settingPhases = Object.keys(phaseComponents || {});
  const settingByLower: { [key: string]: string } = {};
  settingPhases.forEach(s => { settingByLower[s.toLowerCase()] = s; });

  const ordered: string[] = [];
  KNOWN_PHASE_ORDER.forEach(p => {
    if (settingByLower[p]) ordered.push(settingByLower[p]);
    else ordered.push(p);
  });
  settingPhases.forEach(s => {
    if (!KNOWN_PHASE_ORDER.includes(s.toLowerCase())) ordered.push(s);
  });
  return ordered;
};

/* Build the full column list dynamically from pipeline phase components. */
const buildAllColumns = (
  phaseComponents: { [key: string]: string[] } = {},
): ColumnItem[] => {
  const fixed: ColumnItem[] = [
    { id: 'thumbnail', label: 'Thumbnail', group: 'Fixed' },
    { id: 'group_1_name', label: 'Name 1', group: 'Fixed' },
    { id: 'group_2_name', label: 'Name 2', group: 'Fixed' },
    { id: 'group_3_name', label: 'Name 3', group: 'Fixed' },
  ];

  const orderedPhases = getOrderedPhases(phaseComponents);

  const phaseCols: ColumnItem[] = orderedPhases.flatMap(phase => {
    const colBase = phase.toLowerCase();
    const label = phase.toUpperCase();
    const groupId = label;

    const base: ColumnItem[] = [
      { id: `${colBase}_approval_status`, label: `${label} APPR`, group: groupId },
      { id: `${colBase}_work_status`, label: `${label} WORK`, group: groupId },
      { id: `${colBase}_take`, label: `${label} TAKE`, group: groupId },
    ];

    const componentIds = getPhaseComponentIds(phase, phaseComponents);

    if (componentIds.length === 0) {
      // Fallback: phase-level submitted_at column
      base.push({
        id: `${colBase}_submitted_at`,
        label: `${label} SUBMITTED`,
        group: groupId,
      });
    }

    const compCols: ColumnItem[] = componentIds.map(id => ({
      id,
      label: `${id.toUpperCase()} SUBMITTED`,
      group: groupId,
    }));

    return [...base, ...compCols];
  });

  return [
    ...fixed,
    ...phaseCols,
    { id: 'cam_data_type', label: 'Cam Data Type', group: 'Other' },
    { id: 'relation', label: 'Relation', group: 'Other' },
  ];
};

const FIXED_IDS = ['thumbnail', 'group_1_name', 'group_2_name', 'group_3_name'];

/* Build the default column state (all toggleable columns visible). */
export const buildDefaultColumnState = (
  phaseComponents: { [key: string]: string[] } = {},
): ColumnState => {
  const all = buildAllColumns(phaseComponents);
  const toggleable = all.filter(col => !FIXED_IDS.includes(col.id));
  return toggleable.reduce((acc, col) => {
    acc[col.id] = true;
    return acc;
  }, {} as ColumnState);
};

/* ------------------------------
   Filter Menu (unchanged)
-------------------------------- */

const FilterContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  backgroundColor: theme.palette.background.paper,
}));

const FilterHeader = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottom: `1px solid ${theme.palette.divider}`,
  flexShrink: 0,
  backgroundColor: 'transparent',
}));

const FilterScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflowY: 'auto',
  minHeight: 0,
  padding: theme.spacing(1, 0),
  backgroundColor: 'transparent',
  '&::-webkit-scrollbar': { width: 6 },
  '&::-webkit-scrollbar-track': { background: '#f1f1f1', borderRadius: 3 },
  '&::-webkit-scrollbar-thumb': {
    background: '#999',
    borderRadius: 3,
    '&:hover': { background: '#666' },
  },
}));

const FilterFooter = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  borderTop: `1px solid ${theme.palette.divider}`,
  backgroundColor: 'transparent',
  flexShrink: 0,
  display: 'flex',
  justifyContent: 'flex-end',
  alignItems: 'center',
}));

const FilterSection = styled(Box)({
  width: '100%',
});

const FilterSectionHeader = styled(ListItem)(({ theme }) => ({
  backgroundColor: theme.palette.action.hover,
  '&:hover': {
    backgroundColor: theme.palette.action.selected,
  },
}));

const FilterMenu: React.FC<{
  filters: Filters;
  onChange: (newFilters: Filters) => void;
  shotGroupOptions: { id: string; label: string }[];
}> = ({ filters, onChange, shotGroupOptions }) => {
  const [open, setOpen] = React.useState(false);
  const [openSections, setOpenSections] = React.useState<string[]>(['approvalStatus', 'workStatus']);

  const handleFilterChange = (section: keyof Filters, optionId: string) => {
    const currentArray = filters[section] as string[] || [];
    const newArray = currentArray.includes(optionId)
      ? currentArray.filter(v => v !== optionId)
      : [...currentArray, optionId];
    onChange({ ...filters, [section]: newArray });
  };

  const handleClearAll = () => {
    onChange({ shotGroups: [], approvalStatus: [], workStatus: [] });
  };

  const handleHideAll = () => setOpen(false);

  const activeFilterCount = Object.values(filters).flat().length;

  const toggleSection = (section: string) => {
    setOpenSections(prev =>
      prev.includes(section) ? prev.filter(s => s !== section) : [...prev, section]
    );
  };

  const isChildSelected = (section: string, childId: string) => {
    return (filters[section as keyof Filters] as string[] || []).includes(childId);
  };

  const approvalStatusOptions = [
    { id: "check", label: "Check", phase: "Review" },
    { id: "clientReview", label: "Client Review", phase: "Review" },
    { id: "dirReview", label: "Dir Review", phase: "Review" },
    { id: "epdReview", label: "EPD Review", phase: "Review" },
    { id: "clientOnHold", label: "Client On Hold", phase: "Hold" },
    { id: "dirOnHold", label: "Dir On Hold", phase: "Hold" },
    { id: "epdOnHold", label: "EPD On Hold", phase: "Hold" },
    { id: "execRetake", label: "Exec Retake", phase: "Retake" },
    { id: "clientRetake", label: "Client Retake", phase: "Retake" },
    { id: "dirRetake", label: "Dir Retake", phase: "Retake" },
    { id: "epdRetake", label: "EPD Retake", phase: "Retake" },
    { id: "clientApproved", label: "Client Approved", phase: "Approved" },
    { id: "dirApproved", label: "Dir Approved", phase: "Approved" },
    { id: "epdApproved", label: "EPD Approved", phase: "Approved" },
    { id: "other", label: "Other", phase: "Other" },
    { id: "omit", label: "Omit", phase: "Other" },
  ];

  const workStatusOptions = [
    { id: "check", label: "Check", phase: "Review" },
    { id: "cgsvOnHold", label: "CGSV On Hold", phase: "Hold" },
    { id: "svOnHold", label: "SV On Hold", phase: "Hold" },
    { id: "leadOnHold", label: "Lead On Hold", phase: "Hold" },
    { id: "cgsvRetake", label: "CGSV Retake", phase: "Retake" },
    { id: "svRetake", label: "SV Retake", phase: "Retake" },
    { id: "leadRetake", label: "Lead Retake", phase: "Retake" },
    { id: "cgsvApproved", label: "CGSV Approved", phase: "Approved" },
    { id: "svApproved", label: "SV Approved", phase: "Approved" },
    { id: "leadApproved", label: "Lead Approved", phase: "Approved" },
    { id: "svOther", label: "SV Other", phase: "Other" },
    { id: "leadOther", label: "Lead Other", phase: "Other" },
  ];

  const renderFilterItems = (section: string, options: Array<{ id: string; label: string; phase?: string }>) => {
    if (section === 'approvalStatus' || section === 'workStatus') {
      const sortedOptions = [...options].sort((a, b) =>
        a.label.localeCompare(b.label, undefined, { numeric: true, sensitivity: 'base' })
      );

      return sortedOptions.map(option => (
        <ListItem
          key={option.id}
          button
          dense
          onClick={(e) => {
            e.stopPropagation();
            handleFilterChange(section as keyof Filters, option.id);
          }}
          style={{ paddingTop: 2, paddingBottom: 2, paddingLeft: 16, backgroundColor: 'transparent' }}
        >
          <Checkbox
            edge="start"
            checked={isChildSelected(section, option.id)}
            size="small"
            disableRipple
            style={{
              padding: 4,
              color: '#dbe1e7',
            }}
          />
          <ListItemText
            primary={option.label}
            primaryTypographyProps={{ variant: 'body2' }}
          />
        </ListItem>
      ));
    } else {
      return options.map(option => (
        <ListItem
          key={option.id}
          button
          dense
          onClick={(e) => {
            e.stopPropagation();
            handleFilterChange(section as keyof Filters, option.id);
          }}
          style={{ paddingTop: 2, paddingBottom: 2, paddingLeft: 16, backgroundColor: 'transparent' }}
        >
          <Checkbox
            edge="start"
            checked={isChildSelected(section, option.id)}
            size="small"
            disableRipple
            style={{
              padding: 4,
              color: '#dbe1e7',
            }}
          />
          <ListItemText
            primary={option.label}
            primaryTypographyProps={{ variant: 'body2' }}
          />
        </ListItem>
      ));
    }
  };

  return (
    <>
      <Button
        size="small"
        variant="contained"
        startIcon={<FilterListIcon style={{ color: '#fff' }} />}
        onClick={() => setOpen(true)}
        style={{
          height: 28,
          textTransform: 'none',
          fontSize: 12,
          backgroundColor: activeFilterCount > 0 ? '#00b7ff' : '#3d3d3d',
          color: '#fff',
          borderRadius: 4,
          marginRight: 12,
        }}
      >
        Filter
        {activeFilterCount > 0 && (
          <Box
            component="span"
            style={{
              backgroundColor: '#fff',
              color: '#00b7ff',
              borderRadius: '50%',
              width: 18,
              height: 18,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 12,
              marginLeft: 6,
              fontWeight: 600,
            }}
          >
            {activeFilterCount}
          </Box>
        )}
      </Button>

      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          style: {
            width: 320,
            maxHeight: '80vh',
            marginTop: '150px',
            marginRight: '200px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            overflow: 'hidden',
            backgroundColor: 'transparent',
          }
        }}
      >
        <FilterContainer>
          <FilterHeader>
            <Typography variant="h6">Filters</Typography>
            <Button
              size="small"
              onClick={handleClearAll}
              disabled={activeFilterCount === 0}
              style={{ minWidth: 'auto' }}
            >
              CLEAR ALL
            </Button>
          </FilterHeader>

          <FilterScrollArea>
            <FilterSection>
              <FilterSectionHeader button onClick={() => toggleSection('shotGroups')}>
                <ListItemText
                  primary="Shot Groups"
                  secondary={`${filters.shotGroups.length}/${shotGroupOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                <Typography variant="caption" style={{ color: '#888' }}>
                  {openSections.includes('shotGroups') ? 'Hide' : 'Show'}
                </Typography>
              </FilterSectionHeader>
              <Collapse in={openSections.includes('shotGroups')} timeout="auto">
                <Box >
                  {renderFilterItems('shotGroups', shotGroupOptions)}
                </Box>
              </Collapse>
            </FilterSection>

            <Divider />

            <FilterSection>
              <FilterSectionHeader button onClick={() => toggleSection('approvalStatus')}>
                <ListItemText
                  primary="Approval Status"
                  secondary={`${filters.approvalStatus.length}/${approvalStatusOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                <Typography variant="caption" style={{ color: '#888' }}>
                  {openSections.includes('approvalStatus') ? 'Hide' : 'Show'}
                </Typography>
              </FilterSectionHeader>
              <Collapse in={openSections.includes('approvalStatus')} timeout="auto">
                <Box>

                  {renderFilterItems('approvalStatus', approvalStatusOptions)}
                </Box>
              </Collapse>
            </FilterSection>

            <Divider />

            <FilterSection>
              <FilterSectionHeader button onClick={() => toggleSection('workStatus')}>
                <ListItemText
                  primary="Work Status"
                  secondary={`${filters.workStatus.length}/${workStatusOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                <Typography variant="caption" style={{ color: '#888' }}>
                  {openSections.includes('workStatus') ? 'Hide' : 'Show'}
                </Typography>
              </FilterSectionHeader>
              <Collapse in={openSections.includes('workStatus')} timeout="auto">
                <Box>
                  {renderFilterItems('workStatus', workStatusOptions)}
                </Box>
              </Collapse>
            </FilterSection>
          </FilterScrollArea>
        </FilterContainer>
      </Drawer>
    </>
  );
};

/* ------------------------------
   Column Selector
-------------------------------- */

const DrawerContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  backgroundColor: theme.palette.background.paper,
}));

const ScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflowY: 'auto',
  minHeight: 0,
  padding: theme.spacing(1, 0),
  backgroundColor: 'transparent',
  '&::-webkit-scrollbar': { width: 6 },
  '&::-webkit-scrollbar-track': { background: '#f1f1f1', borderRadius: 3 },
  '&::-webkit-scrollbar-thumb': {
    background: '#999',
    borderRadius: 3,
    '&:hover': { background: '#666' },
  },
}));

const Footer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  borderTop: `1px solid ${theme.palette.divider}`,
  backgroundColor: 'transparent',
  flexShrink: 0,
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
}));

const ColumnSelector: React.FC<{
  columnState: ColumnState;
  onChange: (state: ColumnState) => void;
  phaseComponents: { [key: string]: string[] };
}> = ({ columnState, onChange, phaseComponents }) => {
  const [open, setOpen] = React.useState(false);
  const [openGroups, setOpenGroups] = React.useState<string[]>([]);

  const allColumns = React.useMemo(
    () => buildAllColumns(phaseComponents),
    [phaseComponents],
  );

  const toggleableColumns = React.useMemo(
    () => allColumns.filter(col => !FIXED_IDS.includes(col.id)),
    [allColumns],
  );

  const grouped = React.useMemo(() => {
    return toggleableColumns.reduce((acc, col) => {
      if (!acc[col.group]) acc[col.group] = [];
      acc[col.group].push(col);
      return acc;
    }, {} as Record<string, ColumnItem[]>);
  }, [toggleableColumns]);

  const activeColumnCount = toggleableColumns.filter(col => columnState[col.id]).length;
  const allHidden = activeColumnCount === 0;

  const handleHideAll = () => {
    const newState = { ...columnState };
    toggleableColumns.forEach(col => {
      newState[col.id] = allHidden ? true : false;
    });
    onChange(newState);
  };

  React.useEffect(() => {
    if (open) setOpenGroups(Object.keys(grouped));
  }, [open, grouped]);

  return (
    <>
      <FilterButtonWrap>
        <Button
          variant="contained"
          color="primary"
          startIcon={<ViewColumnIcon />}
          endIcon={<ArrowDropDownIcon />}
          onClick={() => setOpen(true)}
          style={{
            borderRadius: 4,
            paddingLeft: 5,
            paddingRight: 5,
            marginRight: 12,
          }}
        >
          {`COLUMNS (${activeColumnCount + 4})`}
        </Button>
      </FilterButtonWrap>

      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          style: {
            width: 320,
            maxHeight: '80vh',
            marginTop: '150px',
            marginRight: '150px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            overflow: 'hidden',
            backgroundColor: 'transparent',
          }
        }}
      >
        <DrawerContainer>
          <ScrollArea>
            {Object.entries(grouped).map(([group, cols], index) => (
              <React.Fragment key={group}>
                {index !== 0 && <Divider />}
                <ListItem
                  button
                  onClick={() =>
                    setOpenGroups(prev =>
                      prev.includes(group)
                        ? prev.filter(g => g !== group)
                        : [...prev, group]
                    )
                  }
                  style={{ backgroundColor: '#444242af' }}
                >
                  <ListItemText primary={group.substring(0, 3).toUpperCase()} />
                  <Typography variant="caption" style={{ color: '#888' }}>
                    {openGroups.includes(group) ? 'Hide' : 'Show'}
                  </Typography>
                </ListItem>

                <Collapse in={openGroups.includes(group)} timeout="auto">
                  <Box>
                    {cols.map(col => (
                      <ListItem
                        key={col.id}
                        button
                        dense
                        style={{
                          paddingTop: 2,
                          paddingBottom: 2,
                          paddingLeft: 32,
                          // backgroundColor: '#070707d7',
                        }}
                        onClick={() =>
                          onChange({
                            ...columnState,
                            [col.id]: !columnState[col.id],
                          })
                        }
                      >
                        <Checkbox
                          checked={columnState[col.id] || false}
                          size="small"
                          edge="start"
                          disableRipple
                          style={{
                            padding: 4,
                            color: '#dbe1e7'
                          }}
                        />
                        <ListItemText
                          primary={col.label}
                          primaryTypographyProps={{ variant: 'body2' }}
                        />
                      </ListItem>
                    ))}
                  </Box>
                </Collapse>
              </React.Fragment>
            ))}
          </ScrollArea>

          <Footer>
            <Button
              size="small"
              onClick={handleHideAll}
              variant="outlined"
              style={{ borderColor: '#ddd', color: '#666' }}
            >
              {allHidden ? "SHOW ALL" : "HIDE ALL"}
            </Button>
          </Footer>
        </DrawerContainer>
      </Drawer>
    </>
  );
};

/* ------------------------------
   View Toggle
-------------------------------- */

const ViewToggle: React.FC<{
  viewMode: ViewMode;
  onChange: (mode: ViewMode) => void;
}> = ({ viewMode, onChange }) => (
  <ToggleContainer>
    <IconButton
      onClick={() => onChange("list")}
      size="small"
      style={{ padding: 6, borderRadius: 0 }}
      title="List View"
      aria-label="List view"
    >
      <ViewListIcon
        style={{
          fontSize: 25,
          color: viewMode === "list" ? '#00b7ff' : '#b0b0b0',
        }}
      />
    </IconButton>
    <IconButton
      onClick={() => onChange("group")}
      size="small"
      style={{ padding: 6, borderRadius: 0 }}
      title="Group View"
      aria-label="Grouped view"
    >
      <ViewModuleIcon
        style={{
          fontSize: 25,
          color: viewMode === "group" ? '#00b7ff' : '#b0b0b0',
        }}
      />
    </IconButton>
  </ToggleContainer>
);

/* ------------------------------
   Main Toolbar
-------------------------------- */

const ShotDataTableToolbar: React.FC<Props> = ({
  viewMode,
  onViewChange,
  searchValue,
  onSearchChange,
  filters,
  onFilterChange,
  columnsState,
  onColumnsChange,
  onReset,
  shotGroupOptions,
  groupSortDir,
  onGroupSortToggle,
  phaseComponents,
}) => {

  const DEFAULT_FILTERS: Filters = {
    shotGroups: [],
    approvalStatus: [],
    workStatus: [],
  };

  const defaultColumnState = React.useMemo(
    () => buildDefaultColumnState(phaseComponents),
    [phaseComponents],
  );

  const handleReset = () => {
    onSearchChange("");
    onFilterChange(DEFAULT_FILTERS);
    onColumnsChange({ ...defaultColumnState });
    if (onReset) onReset();
  };

  const hasChanges =
    searchValue !== "" ||
    Object.values(filters).flat().length > 0 ||
    Object.entries(columnsState)
      .filter(([id]) => !FIXED_IDS.includes(id))
      .some(([id, value]) => value !== defaultColumnState[id]);

  return (
    <StyledToolbar>
      <LeftSection>
        <ViewToggle viewMode={viewMode} onChange={onViewChange} />
        {viewMode === "group" && (
          <Box display="flex" alignItems="center" ml={2} style={{ gap: 8 }}>
            <Typography variant="caption" style={{ color: '#aaa', fontSize: 11 }}>
              Sort Groups:
            </Typography>
            <Button
              size="small"
              variant="outlined"
              onClick={onGroupSortToggle}
              style={{
                height: 24,
                fontSize: 11,
                minWidth: 80,
                padding: '0 6px',
                color: '#00b7ff',
                borderColor: '#00b7ff',
              }}
            >
              Name {groupSortDir === 'asc' ? 'A-Z ↑' : 'Z-A ↓'}
            </Button>
          </Box>
        )}
      </LeftSection>

      <RightSection>
        <TextField
          placeholder={searchValue.trim().length >= 3 ? "Searching groups" : "Search groups or [Column]:Keyword"}
          variant="outlined"
          value={searchValue}
          onChange={(e) => onSearchChange(e.target.value)}
          InputProps={{
            style: {
              height: 28,
              width: 320,
              fontSize: 12,
              marginRight: 12,
            },
            endAdornment: searchValue.trim().length >= 3 ? (
              <InputAdornment position="end">
                <Button
                  size="small"
                  onClick={() => onSearchChange('')}
                  style={{ minWidth: 36, fontSize: 11 }}
                >
                  Clear
                </Button>
              </InputAdornment>
            ) : null,
          }}
        />

        <FilterMenu
          filters={filters}
          onChange={onFilterChange}
          shotGroupOptions={shotGroupOptions}
        />

        <ColumnSelector
          columnState={columnsState}
          onChange={onColumnsChange}
          phaseComponents={phaseComponents}
        />

        <Button
          variant="outlined"
          onClick={handleReset}
          // disabled={!hasChanges}
          style={{
            borderRadius: 4,
            alignItems: 'center',
          }}
        >
          RESET
        </Button>
      </RightSection>
    </StyledToolbar>
  );
};

export default ShotDataTableToolbar;
