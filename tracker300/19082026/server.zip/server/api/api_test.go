package api

import (
	"encoding/json"
	"io/ioutil"
	"net/http"
	"testing"
)

func TestAPI(t *testing.T) {
	rootAPI := GetAPIRootURL()
	apiURL, err := GetAPIURL("/proprtylist/entries?depth=1")
	if err != nil {
		t.Fatal(err)
	}
	expect := rootAPI + "/proprtylist/entries?depth=1"
	got := apiURL
	if got != expect {
		t.Fatal(got)
	}
}

func fetchDirectories(reqURL string) (*interface{}, error) {
	resp, err := http.Get(reqURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var directories interface{}
	err = json.Unmarshal(data, &directories)
	if err != nil {
		return nil, err
	}
	return &directories, nil
}

func TestModifyPrevNextURL(t *testing.T) {
	reqURL := "https://ppip30dev-api.polygonpictures.jp/projects/potoodev/directories?page=2"
	directories, err := fetchDirectories(reqURL)
	if err != nil {
		t.Fatal(err)
	}
	err = ModifyPrevNextURL("https://ppip30dev-web.polygonpictures.jp/api", directories)
	if err != nil {
		t.Fatal(err)
	}
	expectPrevURL := "https://ppip30dev-web.polygonpictures.jp/api/projects/potoodev/directories?page=1"
	expectNextURL := "https://ppip30dev-web.polygonpictures.jp/api/projects/potoodev/directories?page=3"
	modifiedMap, ok := (*directories).(map[string]interface{})
	if !ok {
		t.Fatalf("failed to convert modified data to map")
	}
	if modifiedMap["prev"].(string) != expectPrevURL {
		t.Fatalf("failed to modify prev: %s", modifiedMap["prev"])
	}
	if modifiedMap["next"].(string) != expectNextURL {
		t.Fatalf("failed to modify next: %s", modifiedMap["next"])
	}
}
