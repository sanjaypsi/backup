package api

import (
	"fmt"
	"net/url"
	"os"
	"path"
)

const Scheme = "http"

// GetAPIRootURL return API root URL
func GetAPIRootURL() string {
	value, ok := os.LookupEnv("PPI_CENTRAL_API_ROOT")
	if !ok {
		value = "https://ppip30dev-api.polygonpictures.jp"
	}
	return value
}

// GetAPIURL returns url to the api
func GetAPIURL(endPoint string) (string, error) {
	rURL, err := url.Parse(GetAPIRootURL())
	if err != nil {
		return "", err
	}
	epURL, err := url.Parse(endPoint)
	if err != nil {
		return "", err
	}
	rURL.Path = path.Join(rURL.Path, epURL.Path)
	rURL.RawQuery = epURL.Query().Encode()
	return rURL.String(), nil
}

// ModifyPrevNextURL data(JSON)にprevとnextのキーがあれば、そのURL値をwebURLから始まるURLに変更する
func ModifyPrevNextURL(webURL string, data *interface{}) error {
	typed, ok := (*data).(map[string]interface{})
	if !ok {
		return nil
	}

	srcURL, err := url.Parse(webURL)
	if err != nil {
		return fmt.Errorf("failed to parse url %s", webURL)
	}

	for _, key := range []string{"prev", "next"} {
		value, ok := typed[key]
		if !ok {
			continue
		}
		keyPath, ok := value.(string)
		if !ok {
			continue
		}
		keyURL, err := url.Parse(keyPath)
		if err != nil {
			continue
		}
		keyURL.Scheme = srcURL.Scheme
		keyURL.Host = srcURL.Host
		keyURL.Path = path.Join(srcURL.Path, keyURL.Path)
		typed[key] = keyURL.String()
	}

	return nil
}
