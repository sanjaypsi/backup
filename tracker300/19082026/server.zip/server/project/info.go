// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package project

import (
	"github.com/PolygonPictures/central30-web/front/libs"
)

// Info represents a project info.
type Info struct {
	Name string
	libs.BaseInfo
}

// Scan scans the Scanner.
func (i *Info) Scan(s libs.Scanner) error {
	return s.Scan(
		&i.Name,
		&i.CreatedAtUtc,
		&i.ModifiedAtUtc,
		&i.Deleted,
		&i.ModifiedBy,
		&i.CreatedBy,
		&i.ID,
	)
}
