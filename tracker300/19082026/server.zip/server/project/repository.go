// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package project

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/PolygonPictures/central30-web/front/libs"
)

// Repository represents a repository.
type Repository struct {
	db *sql.DB
}

// NewRepository returns a new repository.
func NewRepository(db *sql.DB) *Repository {
	return &Repository{
		db: db,
	}
}

// GetByName returns a project.
func (r *Repository) GetByName(
	ctx *libs.Context,
	name string,
) (*Info, error) {
	row := ctx.Tx.QueryRowContext(
		ctx.Context,
		fmt.Sprintf(
			"SELECT `name`, `created_at_utc`, `modified_at_utc`, `deleted`, `modified_by`, `created_by`, `id` FROM %s WHERE `name` = ? AND `deleted` = 0",
			libs.ProjectInfoTableName,
		),
		name,
	)
	var info Info
	if err := info.Scan(row); err != nil {
		return nil, err
	}
	return &info, nil
}

// BeginTx returns a transaction object.
func (r *Repository) BeginTx(ctx context.Context, options *sql.TxOptions) (*sql.Tx, error) {
	return r.db.BeginTx(ctx, options)
}
