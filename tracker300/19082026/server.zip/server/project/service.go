// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package project

import (
	"context"
	"database/sql"
	"fmt"
	"log"

	"github.com/PolygonPictures/central30-web/front/libs"
)

// Service represents a service.
type Service struct {
	repo *Repository
}

// NewService returns a new service.
func NewService(repo *Repository) *Service {
	return &Service{
		repo: repo,
	}
}

// GetByName returns a project.
func (s *Service) GetByName(ctx *libs.Context, name string) (*Entity, error) {
	info, err := s.repo.GetByName(ctx, name)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("project %q not found", name)
	}
	return NewEntity(info, s.repo), nil
}

// BeginTx returns a transaction object.
func (s *Service) BeginTx(ctx context.Context, options *sql.TxOptions) (*sql.Tx, error) {
	return s.repo.BeginTx(ctx, options)
}
