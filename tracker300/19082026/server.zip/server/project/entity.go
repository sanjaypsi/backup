// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package project

// Entity represents a project entity.
type Entity struct {
	*Info
	repo *Repository
}

// NewEntity returns a new entity.
func NewEntity(info *Info, repo *Repository) *Entity {
	return &Entity{
		Info: info,
		repo: repo,
	}
}
