// https://github.com/go-playground/validator/blob/master/_examples/gin-upgrading-overriding/v8_to_v9.go

package main

import (
	"fmt"
	"log"
	"reflect"
	"regexp"
	"strconv"
	"strings"
	"sync"

	"github.com/go-playground/validator/v10"
)

const (
	alphaNumericUnderscoreRegexString = `^[a-zA-Z0-9_]+$`
	startsWithNumberRegexString       = `^[0-9]`
	revisionRegexString               = `^\d{20}\.s\d{3}[rt]\d{4}$`
	splitParamsRegexString            = `'[^']*'|\S+`
	dateRegexString                   = `^[2-9][0-9]{3}(?:(?:-[01][0-9]-)|(?:/[01][0-9]/))[0-3][0-9]$` // YYYY-MM-DD or YYYY/MM/DD
)

var (
	alphaNumericUnderscoreRegex = regexp.MustCompile(alphaNumericUnderscoreRegexString)
	startsWithNumberRegex       = regexp.MustCompile(startsWithNumberRegexString)
	revisionRegex               = regexp.MustCompile(revisionRegexString)
	splitParamsRegex            = regexp.MustCompile(splitParamsRegexString)
	dateRegex                   = regexp.MustCompile(dateRegexString)
)

type defaultValidator struct {
	once     sync.Once
	validate *validator.Validate
}

func (v *defaultValidator) ValidateStruct(obj interface{}) error {
	value := reflect.ValueOf(obj)
	if elemOfValue(value).Kind() == reflect.Struct {
		v.lazyinit()
		if err := v.validate.Struct(obj); err != nil {
			return err
		}
	}
	return nil
}

func (v *defaultValidator) Engine() interface{} {
	v.lazyinit()
	return v.validate
}

func (v *defaultValidator) lazyinit() {
	v.once.Do(func() {
		v.validate = validator.New()
		v.validate.SetTagName("binding")

		// Register custom validations

		v.validate.RegisterValidation("startsnotwithdigit", startsNotWithDigit)
		v.validate.RegisterValidation("startsnotwithdot", startsNotWithDot)
		v.validate.RegisterValidation("alphanumunderscore", isAlphaNumUnderscore)
		v.validate.RegisterValidation("revision", isRevision)
		v.validate.RegisterValidation("shouldoneof", shouldOneOf)
		v.validate.RegisterValidation("dirpath", dirPath)
		v.validate.RegisterValidation("parameterlocation", parameterLocation)
		v.validate.RegisterValidation("grppath", grpPath)
		v.validate.RegisterValidation("date", isDate)
	})
}

func elemOfValue(value reflect.Value) reflect.Value {
	if value.Kind() == reflect.Ptr {
		return value.Elem()
	}
	return value
}

func startsNotWithDigit(fl validator.FieldLevel) bool {
	return !startsWithDigit(fl)
}

func startsWithDigit(fl validator.FieldLevel) bool {
	return startsWithNumberRegex.MatchString(fl.Field().String())
}

func startsNotWithDot(fl validator.FieldLevel) bool {
	return !startsWithDot(fl)
}

func startsWithDot(fl validator.FieldLevel) bool {
	return strings.HasPrefix(fl.Field().String(), ".")
}

func isAlphaNumUnderscore(fl validator.FieldLevel) bool {
	return alphaNumericUnderscoreRegex.MatchString(fl.Field().String())
}

func isRevision(fl validator.FieldLevel) bool {
	return revisionRegex.MatchString(fl.Field().String())
}

func isDate(fl validator.FieldLevel) bool {
	return dateRegex.MatchString(fl.Field().String())
}

// shouldOneOf returns true even if the value is not in the list, but will print a warning log.
func shouldOneOf(fl validator.FieldLevel) bool {
	vals := parseOneOfParam2(fl.Param())
	field := fl.Field()
	var v string
	switch field.Kind() {
	case reflect.String:
		v = field.String()
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		v = strconv.FormatInt(field.Int(), 10)
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		v = strconv.FormatUint(field.Uint(), 10)
	default:
		panic(fmt.Sprintf("Bad field type %T", field.Interface()))
	}
	for i := 0; i < len(vals); i++ {
		if vals[i] == v {
			return true
		}
	}
	key := elemOfValue(fl.Parent()).Type().Name() + "." + fl.FieldName()
	log.Printf(
		"WARNING: Key: %q Warning: Field validation warned on the %q tag: %q is not the one of %q.",
		key, fl.GetTag(), v, vals,
	)
	return true
}

func parseOneOfParam2(s string) []string {
	vals := splitParamsRegex.FindAllString(s, -1)
	for i := 0; i < len(vals); i++ {
		vals[i] = strings.Replace(vals[i], "'", "", -1)
	}
	return vals
}

func dirPath(fl validator.FieldLevel) bool {
	s := fl.Field().String()
	if s == "" {
		return false
	}
	for _, dir := range strings.Split(s, "/") {
		if dir == "" {
			return false
		}
		if strings.HasPrefix(dir, ".") {
			return false
		}
	}
	return true
}

func parameterLocation(fl validator.FieldLevel) bool {
	s := fl.Field().String()
	if s == "" {
		return true
	}
	for _, dir := range strings.Split(s, "/") {
		if dir == "" {
			return false
		}
		if strings.HasPrefix(dir, ".") {
			return false
		}
	}
	return true
}

func grpPath(fl validator.FieldLevel) bool {
	s := strings.Split(fl.Field().String(), "/")
	for _, d := range s {
		if !alphaNumericUnderscoreRegex.MatchString(d) {
			return false
		}
	}
	return true
}
