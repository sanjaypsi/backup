package delivery

/* ──────────────────────────────────────────────────────────────────────────
	Module Name:
    	delivery/reviewInfo.go

	Module Description:
		HTTP delivery handlers for review information management.

	Details:

	Update and Modification History:
		* - 29-10-2025 - SanjayK PSI - Initial creation sorting pagination implementation.
		* - 07-11-2025 - SanjayK PSI - Column visibility toggling implementation.
		* - 20-11-2025 - SanjayK PSI - Fixed typo in filter property names handling.

	Functions:
		* NewReviewInfo: Creates a new ReviewInfo handler.
		* (ReviewInfo) List: Handles listing review information with filtering and pagination.
		* (ReviewInfo) Get: Handles retrieving a specific review information by ID.
		* (ReviewInfo) Post: Handles creating new review information.
		* (ReviewInfo) Update: Handles updating existing review information.
		* (ReviewInfo) Delete: Handles deleting review information by ID.
		* (ReviewInfo) ListAssets: Handles listing assets with filtering and pagination.
		* (ReviewInfo) ListAssetReviewInfos: Handles listing review information for a specific asset.
		* (ReviewInfo) ListShotReviewInfos: Handles listing review information for specific shots.
		* (splitCSV) – utility function: Splits a comma-separated string into a slice of trimmed strings.
		* (ReviewInfo) ListAssetsPivot: Handles listing pivoted assets with filtering and sorting.
	────────────────────────────────────────────────────────────────────────── */

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type listReviewInfoParams struct {
	Studio        *string    `form:"studio"`
	TaskID        *string    `form:"task_id"`
	SubtaskID     *string    `form:"subtask_id"`
	Root          *string    `form:"root"`
	Group         *string    `form:"groups"`
	Relation      *string    `form:"relation"`
	Phase         *string    `form:"phase"`
	Component     *string    `form:"component"`
	Take          *string    `form:"take"`
	PerPage       *int       `form:"per_page"`
	Page          *int       `form:"page"`
	ModifiedSince *time.Time `form:"modified_since"`
}

// listReviewInfoFlexibleParams extends the standard list parameters with
// selectable "fields" and "group_sets".
type listReviewInfoFlexibleParams struct {
	listReviewInfoParams
	GroupSets  *string `form:"group_sets"`
	Fields     *string `form:"fields"`
}

func (p *listReviewInfoParams) Entity(project string) *entity.ListReviewInfoParams {
	var group []string
	if p.Group != nil {
		group = strings.Split(*p.Group, "/")
	}
	var relation []string
	if p.Relation != nil {
		relation = strings.Split(*p.Relation, ",")
	}
	var phase []string
	if p.Phase != nil {
		phase = strings.Split(*p.Phase, ",")
	}
	params := &entity.ListReviewInfoParams{
		Project:   project,
		Studio:    p.Studio,
		TaskID:    p.TaskID,
		SubtaskID: p.SubtaskID,
		Root:      p.Root,
		Group:     group,
		Relation:  relation,
		Phase:     phase,
		Component: p.Component,
		Take:      p.Take,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
	if p.ModifiedSince != nil {
		params.ModifiedSince = p.ModifiedSince
	}

	return params
}

// EntityFlexible converts the request parameters into entity parameters for
// flexible review listing.
//
// It parses "fields" and "group_sets" into structured values used by the
// flexible listing use case.
func (p *listReviewInfoFlexibleParams) EntityFlexible(
	project string,
) *entity.ListReviewInfoParamsFlexible {
	base := p.listReviewInfoParams.Entity(project)

	var groupSetTokens []string
	if p.GroupSets != nil {
		groupSetTokens = splitCSV(*p.GroupSets)
	}

	groupSets := make([][]string, 0)
	for _, token := range groupSetTokens {
		// Each token represents a slash-separated Group path, such as ep101/sq01.
		if token == "" {
			continue
		}

		groups := strings.Split(token, "/")
		groupSets = append(groupSets, groups)
	}

	var fields []string
	if p.Fields != nil {
		fields = splitCSV(*p.Fields)
	}

	return &entity.ListReviewInfoParamsFlexible{
		ListReviewInfoParams: base,
		Fields:               fields,
		GroupSets:            groupSets,
	}
}

type createReviewInfoParams struct {
	TaskID                    string              `json:"task_id"`
	SubtaskID                 string              `json:"subtask_id"`
	Studio                    string              `json:"studio"`
	ProjectPath               string              `json:"project_path"`
	ReviewComments            []*libs.CommentInfo `json:"review_comments"`
	Path                      *string             `json:"path"`
	TakePath                  string              `json:"take_path" binding:"required_without=Path"`
	Root                      string              `json:"root"`
	Groups                    []string            `json:"groups"`
	Relation                  string              `json:"relation"`
	Phase                     string              `json:"phase"`
	Component                 string              `json:"component"`
	Take                      string              `json:"take"`
	ApprovalStatus            string              `json:"approval_status"`
	ApprovalStatusUpdatedUser string              `json:"approval_status_updated_user"`
	WorkStatus                string              `json:"work_status"`
	WorkStatusUpdatedUser     string              `json:"work_status_updated_user"`
	ReviewTarget              []*libs.Content     `json:"review_target"`
	ReviewData                []*libs.Content     `json:"review_data"`
	OutputContents            []*libs.Content     `json:"output_contents"`
	SubmittedAtUtc            time.Time           `json:"submitted_at_utc"`
	SubmittedComputer         string              `json:"submitted_computer"`
	SubmittedOS               string              `json:"submitted_os"`
	SubmittedOSVersion        string              `json:"submitted_os_version"`
	SubmittedUser             string              `json:"submitted_user"`
	ExecutedAtUtc             time.Time           `json:"executed_at_utc"`
	ExecutedComputer          string              `json:"executed_computer"`
	ExecutedOS                string              `json:"executed_os"`
	ExecutedOSVersion         string              `json:"executed_os_version"`
	ExecutedUser              string              `json:"executed_user"`
	AllFiles                  []*libs.File        `json:"all_files"`
	NumAllFiles               uint32              `json:"num_all_files"`
	SizeAllFiles              uint64              `json:"size_all_files"`
	TargetComponents          []string            `json:"target_components"`

	Duration                    *int32  `json:"duration,omitempty"`
	DurationTimeline            *string `json:"duration_timeline,omitempty"`
	ExportShotsVersions         *bool   `json:"export_shotsVersions,omitempty"`
	ExportShotsVersionsRevision *string `json:"export_shotsVersions_revision,omitempty"`
	ExportShotsVersionsPath     *string `json:"export_shotsVersions_path,omitempty"`
}

func (p *createReviewInfoParams) Entity(
	project string,
	createdBy *string,
) *entity.CreateReviewInfoParams {
	takePath := p.TakePath
	if takePath == "" && p.Path != nil {
		takePath = *p.Path
	}
	return &entity.CreateReviewInfoParams{
		Project:   project,
		CreatedBy: createdBy,

		TaskID:                    p.TaskID,
		SubtaskID:                 p.SubtaskID,
		Studio:                    p.Studio,
		ProjectPath:               p.ProjectPath,
		ReviewComments:            p.ReviewComments,
		TakePath:                  takePath,
		Root:                      p.Root,
		Groups:                    p.Groups,
		Relation:                  p.Relation,
		Phase:                     p.Phase,
		Component:                 p.Component,
		Take:                      p.Take,
		ApprovalStatus:            p.ApprovalStatus,
		ApprovalStatusUpdatedUser: p.ApprovalStatusUpdatedUser,
		WorkStatus:                p.WorkStatus,
		WorkStatusUpdatedUser:     p.WorkStatusUpdatedUser,
		ReviewTarget:              p.ReviewTarget,
		ReviewData:                p.ReviewData,
		OutputContents:            p.OutputContents,
		SubmittedAtUtc:            p.SubmittedAtUtc,
		SubmittedComputer:         p.SubmittedComputer,
		SubmittedOS:               p.SubmittedOS,
		SubmittedOSVersion:        p.SubmittedOSVersion,
		SubmittedUser:             p.SubmittedUser,
		ExecutedAtUtc:             p.ExecutedAtUtc,
		ExecutedComputer:          p.ExecutedComputer,
		ExecutedOS:                p.ExecutedOS,
		ExecutedOSVersion:         p.ExecutedOSVersion,
		ExecutedUser:              p.ExecutedUser,
		AllFiles:                  p.AllFiles,
		NumAllFiles:               p.NumAllFiles,
		SizeAllFiles:              p.SizeAllFiles,
		TargetComponents:          p.TargetComponents,

		Duration:                    p.Duration,
		DurationTimeline:            p.DurationTimeline,
		ExportShotsVersions:         p.ExportShotsVersions,
		ExportShotsVersionsRevision: p.ExportShotsVersionsRevision,
		ExportShotsVersionsPath:     p.ExportShotsVersionsPath,
	}
}

type createReviewInfoParams2 struct {
	TaskID                    string              `json:"task_id"`
	SubtaskID                 string              `json:"subtask_id"`
	Studio                    string              `json:"studio"`
	ProjectPath               string              `json:"project_path"`
	ReviewComments            []*libs.CommentInfo `json:"review_comments"`
	Path                      *string             `json:"path"`
	TakePath                  string              `json:"take_path" binding:"required_without=Path"`
	Root                      string              `json:"root"`
	Groups                    []string            `json:"groups"`
	Relation                  string              `json:"relation"`
	Phase                     string              `json:"phase"`
	Component                 string              `json:"component"`
	Take                      string              `json:"take"`
	ApprovalStatus            string              `json:"approval_status"`
	ApprovalStatusUpdatedUser string              `json:"approval_status_updated_user"`
	WorkStatus                string              `json:"work_status"`
	WorkStatusUpdatedUser     string              `json:"work_status_updated_user"`
	ReviewTarget              []*libs.Content     `json:"review_target"`
	ReviewData                []*libs.Content     `json:"review_data"`
	OutputContents            []*libs.Content     `json:"output_contents"`
	SubmittedAtUtc            time.Time           `json:"submitted_at_utc"`
	SubmittedComputer         string              `json:"submitted_computer"`
	SubmittedOS               string              `json:"submitted_os"`
	SubmittedOSVersion        string              `json:"submitted_os_version"`
	SubmittedUser             string              `json:"submitted_user"`
	ExecutedAtUtc             time.Time           `json:"executed_at_utc"`
	ExecutedComputer          string              `json:"executed_computer"`
	ExecutedOS                string              `json:"executed_os"`
	ExecutedOSVersion         string              `json:"executed_os_version"`
	ExecutedUser              string              `json:"executed_user"`
	AllFiles                  []*libs.File        `json:"all_files"`
	NumAllFiles               uint32              `json:"num_all_files"`
	SizeAllFiles              uint64              `json:"size_all_files"`
	TargetComponents          []string            `json:"target_components"`

	Duration                    *int32  `json:"duration,omitempty"`
	DurationTimeline            *string `json:"duration_timeline,omitempty"`
	ExportShotsVersions         *bool   `json:"export_shotsVersions,omitempty"`
	ExportShotsVersionsRevision *string `json:"export_shotsVersions_revision,omitempty"`
	ExportShotsVersionsPath     *string `json:"export_shotsVersions_path,omitempty"`

	Custom entity.JSONObject `json:"custom,omitempty"`
}

func (p *createReviewInfoParams2) Entity(
	project string,
	createdBy *string,
) *entity.CreateReviewInfoParams2 {
	takePath := p.TakePath
	if takePath == "" && p.Path != nil {
		takePath = *p.Path
	}
	return &entity.CreateReviewInfoParams2{
		Project:   project,
		CreatedBy: createdBy,

		TaskID:                    p.TaskID,
		SubtaskID:                 p.SubtaskID,
		Studio:                    p.Studio,
		ProjectPath:               p.ProjectPath,
		ReviewComments:            p.ReviewComments,
		TakePath:                  takePath,
		Root:                      p.Root,
		Groups:                    p.Groups,
		Relation:                  p.Relation,
		Phase:                     p.Phase,
		Component:                 p.Component,
		Take:                      p.Take,
		ApprovalStatus:            p.ApprovalStatus,
		ApprovalStatusUpdatedUser: p.ApprovalStatusUpdatedUser,
		WorkStatus:                p.WorkStatus,
		WorkStatusUpdatedUser:     p.WorkStatusUpdatedUser,
		ReviewTarget:              p.ReviewTarget,
		ReviewData:                p.ReviewData,
		OutputContents:            p.OutputContents,
		SubmittedAtUtc:            p.SubmittedAtUtc,
		SubmittedComputer:         p.SubmittedComputer,
		SubmittedOS:               p.SubmittedOS,
		SubmittedOSVersion:        p.SubmittedOSVersion,
		SubmittedUser:             p.SubmittedUser,
		ExecutedAtUtc:             p.ExecutedAtUtc,
		ExecutedComputer:          p.ExecutedComputer,
		ExecutedOS:                p.ExecutedOS,
		ExecutedOSVersion:         p.ExecutedOSVersion,
		ExecutedUser:              p.ExecutedUser,
		AllFiles:                  p.AllFiles,
		NumAllFiles:               p.NumAllFiles,
		SizeAllFiles:              p.SizeAllFiles,
		TargetComponents:          p.TargetComponents,

		Duration:                    p.Duration,
		DurationTimeline:            p.DurationTimeline,
		ExportShotsVersions:         p.ExportShotsVersions,
		ExportShotsVersionsRevision: p.ExportShotsVersionsRevision,
		ExportShotsVersionsPath:     p.ExportShotsVersionsPath,

		Custom: p.Custom,
	}
}

type updateReviewInfoParams struct {
	ApprovalStatus            *string `json:"approval_status,omitempty"`
	ApprovalStatusUpdatedUser *string `json:"approval_status_updated_user,omitempty"`
	WorkStatus                *string `json:"work_status,omitempty"`
	WorkStatusUpdatedUser     *string `json:"work_status_updated_user,omitempty"`
}

func (p *updateReviewInfoParams) Entity(
	project string,
	id int32,
	modifiedBy *string,
) *entity.UpdateReviewInfoParams {
	return &entity.UpdateReviewInfoParams{
		ApprovalStatus:            p.ApprovalStatus,
		ApprovalStatusUpdatedUser: p.ApprovalStatusUpdatedUser,
		WorkStatus:                p.WorkStatus,
		WorkStatusUpdatedUser:     p.WorkStatusUpdatedUser,
		Project:                   project,
		ID:                        id,
		ModifiedBy:                modifiedBy,
	}
}

func NewReviewInfo(
	uc *usecase.ReviewInfo,
) *ReviewInfo {
	return &ReviewInfo{
		uc: uc,
	}
}

type ReviewInfo struct {
	uc *usecase.ReviewInfo
}

func (h *ReviewInfo) List(c *gin.Context) {
	var p listReviewInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"))
	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse("reviews", entities, c.Request, params, total)
	c.PureJSON(http.StatusOK, res)
}

func (h *ReviewInfo) List2(c *gin.Context) {
	var p listReviewInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"))
	entities, shotEntities, total, err := h.uc.List2(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse2("reviews", entities, "shots", shotEntities, c.Request, params, total)
	c.PureJSON(http.StatusOK, res)
}

// buildFlexibleReviewInfoResponse builds review response objects containing
// only the requested fields.
func buildFlexibleReviewInfoResponse(
	entries []*entity.ReviewInfo,
	fields []string,
) []map[string]any {
	results := make([]map[string]any, 0, len(entries))

	for _, entry := range entries {
		result := make(map[string]any, len(fields))

		for _, field := range fields {
			switch field {
			case "task_id":
				result["task_id"] = entry.TaskID
			case "subtask_id":
				result["subtask_id"] = entry.SubtaskID
			case "studio":
				result["studio"] = entry.Studio
			case "project":
				result["project"] = entry.Project
			case "project_path":
				result["project_path"] = entry.ProjectPath
			case "review_comments":
				result["review_comments"] = entry.ReviewComments
			case "take_path":
				result["take_path"] = entry.TakePath
			case "root":
				result["root"] = entry.Root
			case "groups":
				result["groups"] = entry.Groups
			case "relation":
				result["relation"] = entry.Relation
			case "phase":
				result["phase"] = entry.Phase
			case "component":
				result["component"] = entry.Component
			case "take":
				result["take"] = entry.Take
			case "approval_status":
				result["approval_status"] = entry.ApprovalStatus
			case "approval_status_updated_user":
				result["approval_status_updated_user"] = entry.ApprovalStatusUpdatedUser
			case "approval_status_updated_at_utc":
				result["approval_status_updated_at_utc"] = entry.ApprovalStatusUpdatedAtUtc
			case "work_status":
				result["work_status"] = entry.WorkStatus
			case "work_status_updated_user":
				result["work_status_updated_user"] = entry.WorkStatusUpdatedUser
			case "work_status_updated_at_utc":
				result["work_status_updated_at_utc"] = entry.WorkStatusUpdatedAtUtc
			case "review_target":
				result["review_target"] = entry.ReviewTarget
			case "review_data":
				result["review_data"] = entry.ReviewData
			case "output_contents":
				result["output_contents"] = entry.OutputContents
			case "submitted_at_utc":
				result["submitted_at_utc"] = entry.SubmittedAtUtc
			case "submitted_computer":
				result["submitted_computer"] = entry.SubmittedComputer
			case "submitted_os":
				result["submitted_os"] = entry.SubmittedOS
			case "submitted_os_version":
				result["submitted_os_version"] = entry.SubmittedOSVersion
			case "submitted_user":
				result["submitted_user"] = entry.SubmittedUser
			case "executed_at_utc":
				result["executed_at_utc"] = entry.ExecutedAtUtc
			case "executed_computer":
				result["executed_computer"] = entry.ExecutedComputer
			case "executed_os":
				result["executed_os"] = entry.ExecutedOS
			case "executed_os_version":
				result["executed_os_version"] = entry.ExecutedOSVersion
			case "executed_user":
				result["executed_user"] = entry.ExecutedUser
			case "all_files":
				result["all_files"] = entry.AllFiles
			case "num_all_files":
				result["num_all_files"] = entry.NumAllFiles
			case "size_all_files":
				result["size_all_files"] = entry.SizeAllFiles
			case "target_components":
				result["target_components"] = entry.TargetComponents

			case "duration":
				result["duration"] = entry.Duration
			case "duration_timeline":
				result["duration_timeline"] = entry.DurationTimeline
			case "export_shots_versions":
				result["export_shots_versions"] = entry.ExportShotsVersions
			case "export_shots_versions_revision":
				result["export_shots_versions_revision"] = entry.ExportShotsVersionsRevision
			case "export_shots_versions_path":
				result["export_shots_versions_path"] = entry.ExportShotsVersionsPath

			case "created_at_utc":
				result["created_at_utc"] = entry.CreatedAtUTC
			case "modified_at_utc":
				result["modified_at_utc"] = entry.ModifiedAtUTC
			case "deleted":
				result["deleted"] = entry.Deleted
			case "modified_by":
				result["modified_by"] = entry.ModifiedBy
			case "created_by":
				result["created_by"] = entry.CreatedBy
			case "id":
				result["id"] = entry.ID
			}
		}

		results = append(results, result)
	}

	return results
}

// ListFlexible handles requests for flexible review listing.
//
// It supports selectable "fields" and "group_sets", and validates the
// requested fields before invoking the use case.
func (h *ReviewInfo) ListFlexible(c *gin.Context) {
	var p listReviewInfoFlexibleParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.EntityFlexible(c.Param("project"))
	// Reject unknown fields before using them to build the SELECT clause.
	for _, f := range params.Fields {
		if !entity.IsAllowedReviewInfoSelectableField(f) {
			badRequest(c, fmt.Errorf("invalid field: %s", f))
			return
		}
	}
	entities, shotEntities, total, err := h.uc.ListFlexible(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	reviewEntries := any(entities)

	// Return only the requested fields when field selection is specified.
	if len(params.Fields) > 0 {
		reviewEntries = buildFlexibleReviewInfoResponse(entities, params.Fields)
	}

	res := libs.CreateListResponse2("reviews", reviewEntries, "shots", shotEntities, c.Request, params, total)
	c.PureJSON(http.StatusOK, res)
}

func (h *ReviewInfo) Get(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	params := &entity.GetReviewParams{
		Project: c.Param("project"),
		ID:      int32(id),
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("review info with ID %d not found", params.ID))
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *ReviewInfo) Post(c *gin.Context) {
	var p createReviewInfoParams2
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"), nil)
	e, err := h.uc.Create2(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *ReviewInfo) Post2(c *gin.Context) {
	var p createReviewInfoParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"), nil)
	e, err := h.uc.Create(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *ReviewInfo) Update(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	var p updateReviewInfoParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"), int32(id), nil)
	e, err := h.uc.Update(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("review info with ID %d not found", params.ID))
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *ReviewInfo) Delete(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	params := &entity.DeleteReviewInfoParams{
		Project:    c.Param("project"),
		ID:         int32(id),
		ModifiedBy: nil,
	}
	if err := h.uc.Delete(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("review info with ID %d not found", params.ID))
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

type assetListParams struct {
	Studio  *string `form:"studio"`
	PerPage *int    `form:"per_page"`
	Page    *int    `form:"page"`
}

func (p *assetListParams) Entity(project string) *entity.AssetListParams {
	params := &entity.AssetListParams{
		Project: project,
		Studio:  p.Studio,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}

	return params
}

func (h *ReviewInfo) ListAssets(c *gin.Context) {
	var p assetListParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"))
	entities, total, err := h.uc.ListAssets(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse("assets", entities, c.Request, params, total)
	c.PureJSON(http.StatusOK, res)
}

func (p *listReviewInfoParams) assetReviewInfoEntity(
	project string,
	asset string,
	relation string,
) *entity.AssetReviewInfoListParams {
	params := &entity.AssetReviewInfoListParams{
		Project:  project,
		Asset:    asset,
		Relation: relation,
	}

	return params
}

func (h *ReviewInfo) ListAssetReviewInfos(c *gin.Context) {
	var p listReviewInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}

	params := p.assetReviewInfoEntity(
		c.Param("project"),
		c.Param("asset"),
		c.Param("relation"),
	)
	entities, err := h.uc.ListAssetReviewInfos(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := map[string]interface{}{
		"reviews": entities,
	}
	c.PureJSON(http.StatusOK, res)
}

func (p *listReviewInfoParams) shotReviewInfoEntity(
	project string,
	group string,
	relation string,
) *entity.ShotReviewInfoListParams {
	var groups []string
	if group != "" {
		groups = strings.Split(group, "/")
	}
	params := &entity.ShotReviewInfoListParams{
		Project:  project,
		Groups:   groups,
		Relation: relation,
	}

	return params
}

func (h *ReviewInfo) ListShotReviewInfos(c *gin.Context) {
	var p listReviewInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}

	params := p.shotReviewInfoEntity(
		c.Param("project"),
		c.Query("groups"),
		c.Query("relation"),
	)
	entities, err := h.uc.ListShotReviewInfos(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := map[string]interface{}{
		"reviews": entities,
	}
	c.PureJSON(http.StatusOK, res)
}

/*
* ========================================================================================
  - splitCSV – utility function
  - Splits a comma-separated string into a slice of trimmed strings.
  - Ignores empty entries.

==========================================================================================
*/
func splitCSV(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	parts := strings.Split(raw, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if t := strings.TrimSpace(p); t != "" {
			out = append(out, t)
		}
	}
	return out
}

/*
========================================================================================
  - ListAssetsPivot – handler function
  - Handles HTTP requests to list pivoted assets with filtering, sorting, and pagination.
  - Extracts parameters from the request, invokes the usecase, and returns the results as JSON.

========================================================================================
*/
func (h *ReviewInfo) ListAssetsPivot(c *gin.Context) {
	// ---- Required path param ----
	project := strings.TrimSpace(c.Param("project"))
	if project == "" {
		badRequest(c, fmt.Errorf("project is required"))
		return
	}

	// ---- Query params ----
	root := strings.TrimSpace(c.DefaultQuery("root", "assets"))
	if root == "" {
		root = "assets"
	}

	view := strings.TrimSpace(c.DefaultQuery("view", "list")) // list | grouped

	sortKey := strings.TrimSpace(c.DefaultQuery("sort", "group_1"))
	dir := strings.TrimSpace(c.DefaultQuery("dir", "asc")) // usecase will normalize

	phase := strings.TrimSpace(c.DefaultQuery("phase", "none"))
	if phase == "" {
		phase = "none"
	}

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	if page < 1 {
		page = 1
	}

	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "15"))
	if perPage < 1 {
		perPage = 15
	}

	assetNameKey := strings.TrimSpace(c.DefaultQuery("name", ""))

	// Support both new & old query keys
	approvalRaw := c.Query("approval_status")
	if approvalRaw == "" {
		approvalRaw = c.Query("appr")
	}
	workRaw := c.Query("work_status")
	if workRaw == "" {
		workRaw = c.Query("work")
	}

	approvalStatuses := splitCSV(approvalRaw)
	workStatuses := splitCSV(workRaw)

	// ---- Context timeout ----
	ctx, cancel := context.WithTimeout(c.Request.Context(), 30*time.Second)
	defer cancel()

	// ---- NEW usecase signature: (ctx, params) -> (result, error) ----
	params := usecase.ListAssetsPivotParams{
		Project:          project,
		Root:             root,
		PreferredPhase:   phase,
		OrderKey:         sortKey,
		Direction:        dir,
		Page:             page,
		PerPage:          perPage,
		AssetNameKey:     assetNameKey,
		ApprovalStatuses: approvalStatuses,
		WorkStatuses:     workStatuses,
		View:             view,
	}

	result, err := h.uc.ListAssetsPivot(ctx, params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := gin.H{
		"assets":    result.Assets,
		"total":     result.Total,
		"page":      result.Page,
		"per_page":  result.PerPage,
		"page_last": result.PageLast,
		"has_next":  result.HasNext,
		"has_prev":  result.HasPrev,
		"sort":      result.Sort,
		"dir":       result.Dir,
		"project":   project,
		"root":      root,
		"view":      view,
	}
	if len(result.Groups) > 0 {
		res["groups"] = result.Groups
	}

	c.PureJSON(http.StatusOK, res)
}

// --- New Query Params Structs for Pivot Endpoints ---
func (h *ReviewInfo) ListReviewShotsPivot(c *gin.Context) {
	project := c.Param("project")
	orderKey := c.DefaultQuery("orderKey", "group1_only")
	direction := c.DefaultQuery("direction", "ASC")

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("perPage", "15"))

	phases := c.QueryArray("phase")    // empty => resolved dynamically
	statuses := c.QueryArray("status") // empty => repo default ("check")

	result, err := h.uc.ListReviewShotsPivot(
		c.Request.Context(),
		usecase.ListReviewShotsPivotParams{
			Project:   project,
			Phases:    phases,
			Statuses:  statuses,
			OrderKey:  orderKey,
			Direction: direction,
			Page:      page,
			PerPage:   perPage,
		},
	)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"items": result.Shots, "phases": result.Phases, "total": result.Total,
		"page": result.Page, "perPage": result.PerPage, "pageLast": result.PageLast,
		"hasNext": result.HasNext, "hasPrev": result.HasPrev,
		"sort": result.Sort, "dir": result.Dir,
	})
}
