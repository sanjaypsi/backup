package delivery

import (
	"log"
	"net/http"
	"strings"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type PublishOperationInfo struct {
	uc *usecase.PublishOperationInfo
}

func NewPublishOperationInfo(uc *usecase.PublishOperationInfo) *PublishOperationInfo {
	return &PublishOperationInfo{
		uc: uc,
	}
}

type latestAssetComponentDocumentsParams struct {
	Asset     string   `form:"asset" binding:"required"`
	Relation  string   `form:"relation" binding:"required"`
	Component []string `form:"component" binding:"required,dive,max=100"`
}

func (p *latestAssetComponentDocumentsParams) Entity(
	project string,
) *entity.LatestAssetComponentParams {
	return &entity.LatestAssetComponentParams{
		Project:   project,
		Asset:     p.Asset,
		Relation:  p.Relation,
		Component: p.Component,
	}
}

func (poi *PublishOperationInfo) ListLatestAssetDocuments(ctx *gin.Context) {
	var p latestAssetComponentDocumentsParams
	if err := ctx.ShouldBindQuery(&p); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"message": err.Error()})
		return
	}
	param := p.Entity(ctx.Param("project"))
	documents, err := poi.uc.ListLatestAssetDocuments(ctx, param)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"message": err.Error()})
		return
	}
	ctx.PureJSON(http.StatusOK, documents)
}

type shotListParams struct {
	Studio  *string `form:"studio"`
	PerPage *int    `form:"per_page"`
	Page    *int    `form:"page"`
}

func (p *shotListParams) Entity(project string) *entity.ShotListParams {
	return &entity.ShotListParams{
		Project: project,
		Studio:  p.Studio,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
}

func (poi *PublishOperationInfo) ListShots(ctx *gin.Context) {
	var p shotListParams
	if err := ctx.ShouldBindQuery(&p); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"message": err.Error()})
		return
	}
	params := p.Entity(ctx.Param("project"))
	documents, total, err := poi.uc.ListShots(ctx, params)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"message": err.Error()})
		return
	}

	data := &entity.ShotListResponse{
		Documents: documents,
		Total:     total,
	}
	ctx.PureJSON(http.StatusOK, data)
}

type latestShotComponentDocumentsParams struct {
	Group1    string   `form:"group1" binding:"required"`
	Group2    string   `form:"group2" binding:"required"`
	Group3    string   `form:"group3" binding:"required"`
	Relation  string   `form:"relation" binding:"required"`
	Component []string `form:"component" binding:"required,dive,max=100"`
}

func (p *latestShotComponentDocumentsParams) Entity(
	project string,
) *entity.LatestShotComponentParams {
	return &entity.LatestShotComponentParams{
		Project:   project,
		Group1:    p.Group1,
		Group2:    p.Group2,
		Group3:    p.Group3,
		Relation:  p.Relation,
		Component: p.Component,
	}
}

func (poi *PublishOperationInfo) ListLatestShotDocuments(ctx *gin.Context) {
	var p latestShotComponentDocumentsParams
	if err := ctx.ShouldBindQuery(&p); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"message": err.Error()})
		return
	}
	param := p.Entity(ctx.Param("project"))
	documents, err := poi.uc.ListLatestShotDocuments(ctx, param)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"message": err.Error()})
		return
	}
	ctx.PureJSON(http.StatusOK, documents)
}

// ListLatestCamDataTypes handles
//
//	GET /projects/:project/shots/camDataTypes?shots=g1/g2/g3/rel&shots=...
//
// Returns: { "items": { "g1/g2/g3/rel": ["typeA", "typeB"], ... } }
func (d *PublishOperationInfo) ListLatestCamDataTypes(c *gin.Context) {
	project := c.Param("project")
	rawShots := c.QueryArray("shots")

	log.Printf("[CamDataType] Handler called - project=%s, raw shots count=%d", project, len(rawShots))
	log.Printf("[CamDataType] Raw shots from query: %v", rawShots)

	keys := make([]repository.CamDataTypeShotKey, 0, len(rawShots))
	for _, s := range rawShots {
		parts := strings.Split(s, "/")
		if len(parts) != 4 {
			log.Printf("[CamDataType] Warning: skipping malformed shot: %q (got %d parts)", s, len(parts))
			continue
		}
		keys = append(keys, repository.CamDataTypeShotKey{
			Group1:   parts[0],
			Group2:   parts[1],
			Group3:   parts[2],
			Relation: parts[3],
		})
	}

	log.Printf("[CamDataType] Parsed %d valid shot keys", len(keys))

	result, err := d.uc.GetLatestCamDataTypes(c.Request.Context(), project, keys)
	if err != nil {
		log.Printf("[CamDataType] Usecase error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	log.Printf("[CamDataType] Response: %d entries", len(result))
	c.JSON(http.StatusOK, gin.H{"items": result})
}
