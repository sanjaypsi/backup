package main

import (
	"bufio"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/golang-jwt/jwt"
)

func main() {
	// CLI arguments
	studio := flag.String("studio", "", "Studio name")
	service := flag.String("service", "", "Service account name")
	year := flag.String("year", "", "Expiration year (e.g. 2023)")
	month := flag.String(
		"month", "", "Expiration month (if entering 1, token will expire at Feb 1st 00:00:00)",
	)
	noenc := flag.Bool(
		"noenc", false, "Set when generate plain token string (mainly for SFTP servers)",
	)

	// check if arguments are entered properly
	flag.Parse()
	if *studio == "" {
		fmt.Printf("Error: -studio is required")
		return
	}
	if *year == "" {
		fmt.Printf("Error: -year is required")
		return
	}
	if *month == "" {
		fmt.Printf("Error: -month is required")
		return
	}

	// generate plain token string

	intYear, err := strconv.Atoi(*year)
	if err != nil {
		fmt.Printf("Error: enter numeric letter for year")
		return
	}
	intMonth, err := strconv.Atoi(*month)
	if err != nil {
		fmt.Printf("Error: enter numeric letter for month")
		return
	}
	intMonth = intMonth%12 + 1
	if intMonth == 1 {
		intYear++
	}

	t := jwt.New(jwt.GetSigningMethod("RS256"))
	entry := Entry{Name: *studio}
	if *service != "" {
		entry.Service = *service
	}
	t.Claims = &CustomClaims{
		&jwt.StandardClaims{
			IssuedAt:  time.Now().Unix(),
			ExpiresAt: time.Date(intYear, time.Month(intMonth), 1, 0, 0, 0, 0, time.UTC).Unix(),
		},
		0,
		entry,
	}
	sigkey := "./_keys/signingkey-%s.pem"
	if *studio == "ppidev" {
		sigkey = fmt.Sprintf(sigkey, "dev")
	} else {
		sigkey = fmt.Sprintf(sigkey, "prod")
	}
	fpriv, err := os.Open(sigkey)
	if err != nil {
		panic(err)
	}
	defer fpriv.Close()
	bpriv, err := io.ReadAll(fpriv)
	if err != nil {
		panic(err)
	}
	signingKey, err := loadPrivateKey(strings.Replace(string(bpriv), `\n`, "\n", -1))
	if err != nil {
		fmt.Printf("Error: failed to load private key")
		return
	}
	signed, err := t.SignedString(signingKey)
	if err != nil {
		panic(err)
	}

	// for SFTP server
	serviceDir := *studio
	if *service != "" {
		serviceDir = fmt.Sprintf("%s/%s", serviceDir, *service)
	}
	tokendir := fmt.Sprintf("./%s", serviceDir)
	if *noenc {
		os.MkdirAll(fmt.Sprintf("%s/plain/archive", tokendir), 0444)
		file, err := os.Create(fmt.Sprintf("%s/plain/token.yaml", tokendir))
		if err != nil {
			panic(err)
		}
		defer file.Close()

		output := fmt.Sprintf("# studio: %s (SFTP)\n", *studio)
		expiresat := fmt.Sprintf("%04d-%02d-01 00:00:00 +0000 UTC", intYear, intMonth)
		output += fmt.Sprintf("# expires_at: %s\n", expiresat)
		output += fmt.Sprintf("access_token: %s", signed)
		file.Write(([]byte)(output))

		file, err = os.Create(
			fmt.Sprintf("%s/plain/archive/token_%4d_%2d.yaml", tokendir, intYear, intMonth),
		)
		if err != nil {
			panic(err)
		}
		defer file.Close()

		file.Write(([]byte)(output))

		fmt.Print("Generation completed. Press any key to exit.")
		scanner := bufio.NewScanner(os.Stdin)
		scanner.Scan()
		return
	}

	tb := []byte(signed)

	padSize := aes.BlockSize - (len(tb) % aes.BlockSize)
	pad := bytes.Repeat([]byte{byte(padSize)}, padSize)
	paddedtext := append(tb, pad...)

	// generate symmetric key with length less than the publickey
	keyByte := make([]byte, aes.BlockSize*2)
	if _, err := rand.Read(keyByte); err != nil {
		panic(err)
	}

	// generate initialization vector
	iv := make([]byte, aes.BlockSize)
	if _, err := rand.Read(iv); err != nil {
		panic(err)
	}
	symmetrickey := base64.StdEncoding.EncodeToString(keyByte)
	symkeydir := fmt.Sprintf("./%s/symmetrickey", serviceDir)
	os.MkdirAll(fmt.Sprintf("%s/archive", symkeydir), 0444)
	keyfile, err := os.Create(fmt.Sprintf("%s/symmetrickey.pem", symkeydir))
	if err != nil {
		panic(err)
	}
	defer keyfile.Close()
	keyfile.Write(([]byte)(symmetrickey))
	keyfile, err = os.Create(
		fmt.Sprintf("%s/archive/symmetrickey_%4d_%2d.pem", symkeydir, intYear, intMonth),
	)
	if err != nil {
		panic(err)
	}
	defer keyfile.Close()
	keyfile.Write(([]byte)(symmetrickey))

	// encrypt the token string with the symmetric key encoding with base64
	c, err := aes.NewCipher(keyByte)
	if err != nil {
		panic(err)
	}
	encToken := make([]byte, len(paddedtext))
	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(encToken, paddedtext)
	base64Token := base64.StdEncoding.EncodeToString(encToken)

	// get the key contents from a pem file
	prefix := *studio
	if *service != "" {
		prefix = fmt.Sprintf("%s-%s", *service, prefix)
	}
	p, err := os.Open(fmt.Sprintf("./_keys/%s-pubkey.pem", prefix))
	if err != nil {
		panic(err)
	}
	defer p.Close()
	pb, err := io.ReadAll(p)
	if err != nil {
		panic(err)
	}
	pubkey, err := loadPublicKey(pb)
	if err != nil {
		panic(err)
	}

	// encrypt the symmetric key with the public key encoding with base64
	rng := rand.Reader
	keyIV := append(keyByte, iv...)
	encKey, err := rsa.EncryptOAEP(sha256.New(), rng, pubkey, keyIV, []byte{})
	if err != nil {
		panic(err)
	}
	base64Key := base64.StdEncoding.EncodeToString(encKey)

	// hopefully return a single yaml file
	os.MkdirAll(fmt.Sprintf("%s/archive", tokendir), 0444)
	file, err := os.Create(fmt.Sprintf("%s/token.yaml", tokendir))
	if err != nil {
		panic(err)
	}
	defer file.Close()

	output := fmt.Sprintf("# studio: %s\n", *studio)
	if *service != "" {
		output += fmt.Sprintf("# service: %s\n", *service)
	}
	expiresat := fmt.Sprintf("%04d-%02d-01 00:00:00 +0000 UTC", intYear, intMonth)
	output += fmt.Sprintf("# expires_at: %s\n", expiresat)
	output += fmt.Sprintf("enc_access_token: %s\n", base64Token)
	output += fmt.Sprintf("enc_key: %s\n", base64Key)
	file.Write(([]byte)(output))

	file, err = os.Create(
		fmt.Sprintf("%s/archive/token_%4d_%2d.yaml", tokendir, intYear, intMonth),
	)
	if err != nil {
		panic(err)
	}
	defer file.Close()

	file.Write(([]byte)(output))

	fmt.Print("Generation completed. Press any key to exit.")
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
}

func loadPrivateKey(stringkey string) (*rsa.PrivateKey, error) {
	content := []byte(stringkey)
	block, _ := pem.Decode(content)
	if block == nil {
		return nil, errors.New("failed to decode PEM block containing private key")
	}
	if block.Type != "RSA PRIVATE KEY" {
		return nil, fmt.Errorf("invalid private key type: %s", block.Type)
	}
	return x509.ParsePKCS1PrivateKey(block.Bytes)
}

func loadPublicKey(key []byte) (*rsa.PublicKey, error) {
	block, _ := pem.Decode(key)
	if block == nil {
		return nil, errors.New("failed to decode PEM block containing public key")
	}
	if block.Type != "RSA PUBLIC KEY" {
		return nil, fmt.Errorf("invalid public key type: %s", block.Type)
	}
	return x509.ParsePKCS1PublicKey(block.Bytes)
}

type Entry struct {
	Name    string
	Service string
}

type CustomClaims struct {
	*jwt.StandardClaims
	Section int
	Entry   Entry
}
