package testutil

import (
	"bytes"
	"database/sql"
	"log"
	"os"
	"testing"

	"github.com/dolthub/go-mysql-server/driver"
	"github.com/dolthub/go-mysql-server/memory"
	sqle "github.com/dolthub/go-mysql-server/sql"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/gorm/schema"

	"github.com/PolygonPictures/central30-web/front/repository/model"
)

type factory string

// Resolve implements go-mysql-server/driver.Provider interface
func (f factory) Resolve(
	dsn string,
	options *driver.Options,
) (string, sqle.DatabaseProvider, error) {
	db := memory.NewDatabase(string(f))
	db.EnablePrimaryKeyIndexes()
	return dsn, memory.NewDBProvider(db), nil
}

func NewTestDB(name string) *gorm.DB {
	drv := driver.New(factory(name), nil)
	conn, err := drv.OpenConnector(name)
	must(err)

	db := sql.OpenDB(conn)
	_, err = db.Exec("USE " + name)
	must(err)

	mysqlConfig := mysql.Config{Conn: db}
	gormConfig := gorm.Config{
		Logger:                 logger.Default.LogMode(logger.Silent),
		SkipDefaultTransaction: true,
		NamingStrategy: schema.NamingStrategy{
			TablePrefix:   "t_",
			SingularTable: true,
		},
		DisableForeignKeyConstraintWhenMigrating: true,
	}
	gormDB, err := gorm.Open(mysql.New(mysqlConfig), &gormConfig)
	must(err)

	return gormDB
}

func must(err error) {
	if err != nil {
		panic(err)
	}
}

func SetupTablesWithCleanup(t *testing.T, db *gorm.DB) {
	t.Helper()

	models := []any{
		&model.ConfigEntry{},
		&model.Directory{},
		&model.DirectoryDeletionLog{},
		&model.GroupDirectory{},
		&model.PreferenceEntry{},
		&model.ProjectInfo{},
		&model.ProjectStudioMap{},
		&model.StudioInfo{},
	}

	db.AutoMigrate(models...)

	t.Cleanup(func() {
		db.Migrator().DropTable(models...)
	})
}

func Ptr[T any](v T) *T {
	return &v
}

func AssertNoError(t *testing.T, err error) {
	t.Helper()

	if err != nil {
		t.Fatal(err)
	}
}

func AssertInt(t *testing.T, got, want int) {
	t.Helper()

	if got != want {
		t.Errorf("got %d, want %d", got, want)
	}
}

func AddProjectPreference(t *testing.T, db *gorm.DB, project, key string, value *string) {
	t.Helper()

	if err := db.Create(&model.PreferenceEntry{
		SectionType: "project",
		SectionName: project,
		Key:         key,
		Value:       value,
	}).Error; err != nil {
		t.Fatal(err)
	}
}

func CaptureLog(t *testing.T) *bytes.Buffer {
	t.Helper()

	var buf bytes.Buffer
	log.SetOutput(&buf)
	t.Cleanup(func() {
		log.SetOutput(os.Stderr)
	})

	return &buf
}

func CaptureGORMLog(t *testing.T, db *gorm.DB) *bytes.Buffer {
	t.Helper()

	var buf bytes.Buffer
	newLogger := logger.New(
		log.New(&buf, "\r\n", 0),
		logger.Config{LogLevel: logger.Info},
	)

	origLogger := db.Logger
	t.Cleanup(func() {
		db.Logger = origLogger
	})
	db.Logger = newLogger
	return &buf
}
