package testutil

import (
	"reflect"
	"testing"

	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
)

var projectInfoDisplayNameCasesForGet = []struct {
	name               string
	studioKeyName      string
	projectKeyName     string
	projectDisplayName string
	want               *entity.ProjectInfo2
}{
	{
		name:               "Get project info with display name",
		studioKeyName:      "ppidev",
		projectKeyName:     "potoodev",
		projectDisplayName: "Potoo Dev",
		want: &entity.ProjectInfo2{
			KeyName:     "potoodev",
			DisplayName: Ptr("Potoo Dev"),
		},
	},
	{
		name:               "Get project info without display name",
		studioKeyName:      "ppidev2",
		projectKeyName:     "potoodev2",
		projectDisplayName: "",
		want: &entity.ProjectInfo2{
			KeyName:     "potoodev2",
			DisplayName: nil,
		},
	},
}

var projectInfoDisplayNameCasesForCreate = []struct {
	name               string
	projectKeyName     string
	projectDisplayName string
	want               *entity.ProjectInfo2
}{
	{
		name:               "Create project info with display name",
		projectKeyName:     "potoodev",
		projectDisplayName: "Potoo Dev",
		want: &entity.ProjectInfo2{
			KeyName:     "potoodev",
			DisplayName: Ptr("Potoo Dev"),
		},
	},
	{
		name:               "Create project info without display name",
		projectKeyName:     "potoodev2",
		projectDisplayName: "",
		want: &entity.ProjectInfo2{
			KeyName:     "potoodev2",
			DisplayName: nil,
		},
	},
}

func AssertProjectInfoList(
	t *testing.T,
	db *gorm.DB,
	f func(studioKeyName string) ([]*entity.ProjectInfo2, int, error),
) {
	for _, test := range projectInfoDisplayNameCasesForGet {
		t.Run(test.name, func(t *testing.T) {
			CreateProjectInfo(t, db, test.studioKeyName, test.projectKeyName)
			if test.projectDisplayName != "" {
				CreateProjectDisplayName(t, db, test.projectKeyName, test.projectDisplayName)
			}

			entities, total, err := f(test.studioKeyName)
			AssertNoError(t, err)
			AssertInt(t, total, 1)
			got := entities[0]
			assertProjectInfo2Names(t, got, test.want)
		})
	}
}

func AssertProjectInfoGet(
	t *testing.T,
	db *gorm.DB,
	f func(projectKeyName string) (*entity.ProjectInfo2, error),
) {
	for _, test := range projectInfoDisplayNameCasesForGet {
		t.Run(test.name, func(t *testing.T) {
			CreateProjectInfo(t, db, test.studioKeyName, test.projectKeyName)
			if test.projectDisplayName != "" {
				CreateProjectDisplayName(t, db, test.projectKeyName, test.projectDisplayName)
			}

			got, err := f(test.projectKeyName)
			AssertNoError(t, err)
			assertProjectInfo2Names(t, got, test.want)
		})
	}
}

func AssertProjectInfoCreate(
	t *testing.T,
	db *gorm.DB,
	f func(projectKeyName string) (*entity.ProjectInfo2, error),
) {
	for _, test := range projectInfoDisplayNameCasesForCreate {
		t.Run(test.name, func(t *testing.T) {
			if test.projectDisplayName != "" {
				CreateProjectDisplayName(t, db, test.projectKeyName, test.projectDisplayName)
			}

			got, err := f(test.projectKeyName)
			AssertNoError(t, err)
			assertProjectInfo2Names(t, got, test.want)
		})
	}
}

func CreateProjectInfo(t *testing.T, db *gorm.DB, studioKeyName, projectKeyName string) {
	t.Helper()

	db.Create(&model.ProjectInfo{KeyName: projectKeyName})
	db.Create(&model.ProjectStudioMap{Project: projectKeyName, Studio: studioKeyName})
}

func CreateProjectDisplayName(
	t *testing.T,
	db *gorm.DB,
	projectKeyName,
	projectDisplayName string,
) {
	t.Helper()

	db.Create(&model.ConfigEntry{
		SectionType: "project",
		SectionName: projectKeyName,
		Key:         "displayName",
		Value:       &projectDisplayName,
	})
}

func assertProjectInfo2Names(t *testing.T, got, want *entity.ProjectInfo2) {
	t.Helper()

	type names struct {
		KeyName     string
		DisplayName *string
	}

	gotNames := names{KeyName: got.KeyName, DisplayName: got.DisplayName}
	wantNames := names{KeyName: want.KeyName, DisplayName: want.DisplayName}

	if !reflect.DeepEqual(gotNames, wantNames) {
		t.Errorf("got %+v, want %+v", gotNames, wantNames)
	}
}
