package web

import (
	"github.com/PolygonPictures/central30-web/front/entity"
)

type DocumentQueries interface {
	Entity() *entity.QueryDocumentsParam
}

type baseDocumentQueries struct {
	OrderBy *string `form:"order_by"`
	Page    *int    `form:"page" binding:"omitempty,min=1"`
	PerPage *int    `form:"per_page" binding:"omitempty,min=1"`
}

func (d *baseDocumentQueries) Entity() *entity.QueryDocumentsParam {
	params := &entity.QueryDocumentsParam{}
	page := 1
	if d.Page != nil {
		page = *d.Page
	}
	params.Page = &page

	perPage := 500
	if d.PerPage != nil {
		perPage = *d.PerPage
	}
	params.PerPage = &perPage

	if d.OrderBy != nil {
		if err := params.ParseOrderBy(*d.OrderBy); err != nil {
			return nil
		}
	}

	return params
}

type commentQueries struct {
	baseDocumentQueries
	Path *string `form:"path" binding:"omitempty,min=1"`
}

func (c *commentQueries) Entity() *entity.QueryDocumentsParam {
	params := c.baseDocumentQueries.Entity()
	filters := map[string]interface{}{}
	if c.Path != nil {
		filters["path"] = c.Path
	}
	params.Filters = filters

	return params
}

type documentListResponse struct {
	Documents []*entity.Document `json:"documents"`
	Prev      *string            `json:"prev"`
	Next      *string            `json:"next"`
	Total     int                `json:"total"`
}
