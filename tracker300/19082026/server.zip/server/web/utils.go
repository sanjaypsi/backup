package web

import (
	"net/url"
	"strconv"
)

func getPaginationURL(u *url.URL, page int) *string {
	q := u.Query()
	q.Set("page", strconv.Itoa(page))
	u.RawQuery = q.Encode()
	s := u.String()
	return &s
}

func getPrevNextURL(u *url.URL, perPage, page, total int) (prev, next *string) {
	if page-1 > 0 {
		prev = getPaginationURL(u, page-1)
	}
	if perPage*(page+1) <= total+perPage-1 {
		next = getPaginationURL(u, page+1)
	}
	return
}
