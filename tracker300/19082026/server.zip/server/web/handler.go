package web

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/PolygonPictures/central30-web/front/delivery"
	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/dataDependency"
	"github.com/PolygonPictures/central30-web/front/entity/pipelineParameter"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/service"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/go-playground/validator/v10"
)

// Handler represents a web handler.
type Handler struct {
	service                     *service.CentralService
	pipelineParameterRepository *repository.PipelineParameter
	// depRepo can be a nil value, so check it before using it.
	depRepo      *repository.DataDepRepository
	readTimeout  *time.Duration
	writeTimeout *time.Duration
}

// NewHandler is a function that creates a new handler.
func NewHandler(
	service *service.CentralService,
	depRepo *repository.DataDepRepository,
) *Handler {
	return &Handler{
		service: service,
		depRepo: depRepo,
	}
}

func (h *Handler) SetRepositoryParams(
	pipelineParameterRepository *repository.PipelineParameter,
	readTimeout time.Duration,
	writeTimeout time.Duration,

) {
	h.pipelineParameterRepository = pipelineParameterRepository
	h.readTimeout = &readTimeout
	h.writeTimeout = &writeTimeout
}

// CreateDocument creates a new document
func (h *Handler) CreateDocument(c *gin.Context) {
	lgr := delivery.NewLogger(c.Request)

	h.wrapHandler(c, func(ctx context.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		lgr.SetProject(projectName)
		collectionName := c.Param("collection")
		lgr.Set("collection", collectionName)

		var param map[string]interface{}
		err = c.Bind(&param)
		if err != nil {
			return
		}

		lgr.Set("param", param)

		project, err := h.service.GetProjectByName(ctx, projectName)
		if err != nil {
			return
		}

		document, err := project.CreateDocument(ctx, collectionName, param)
		if err != nil {
			return
		}

		h.UpsertLatestThumbnailRevision(lgr, document, projectName, ctx)
		h.UpsertFrameRange(lgr, document, projectName, ctx)
		if collectionName == "publishOperationInfo" {
			h.registerDataDependencies(ctx, lgr, projectName, param)
		}

		return http.StatusOK, document, nil
	})
}

func getComponentInfo(document *entity.Document) (map[string]interface{}, error) {
	rawcomponentinfo, ok := (*document.DocumentInfo)["component_info"]
	if !ok {
		return map[string]interface{}{}, fmt.Errorf("Field 'component_info' is not found")
	}
	componentinfo, ok := rawcomponentinfo.(map[string]interface{})
	if !ok {
		return map[string]interface{}{}, fmt.Errorf("Fail to convert 'component_info' into map")
	}
	return componentinfo, nil
}

func getRoot(document *entity.Document) (string, error) {
	rawRoot, ok := (*document.DocumentInfo)["root"]
	if !ok {
		return "", fmt.Errorf("Field 'root' is not found")
	}
	root, ok := rawRoot.(string)
	if !ok {
		return "", fmt.Errorf("Fail to convert 'root' into string")
	}
	return root, nil
}

func getGroups(document *entity.Document) ([]string, error) {
	strGroups := []string{}
	rawGroups, ok := (*document.DocumentInfo)["groups"]
	if !ok {
		return strGroups, fmt.Errorf("Field 'groups' is not found")
	}
	groups, ok := rawGroups.([]interface{})
	if !ok {
		return strGroups, fmt.Errorf("Fail to convert 'groups' into slice")
	}
	for _, group := range groups {
		strGroup, ok := group.(string)
		if !ok {
			return strGroups, fmt.Errorf("Fail to convert 'group' into string")
		}
		strGroups = append(strGroups, strGroup)
	}
	return strGroups, nil
}

func getPhase(document *entity.Document) (string, error) {
	rawPhase, ok := (*document.DocumentInfo)["phase"]
	if !ok {
		return "", fmt.Errorf("Field 'phase' is not found")
	}
	phase, ok := rawPhase.(string)
	if !ok {
		return "", fmt.Errorf("Fail to convert 'phase' into string")
	}
	return phase, nil
}

func (h *Handler) UpsertLatestThumbnailRevision(
	lgr entity.Logger,
	document *entity.Document,
	projectName string,
	ctx context.Context,
) {
	logHeader := "[LatestThumbnail Registration]"
	componentinfo, errMsg := getComponentInfo(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	rawhasthumbnail, ok := componentinfo["has_thumbnail"]
	if !ok {
		lgr.Infof("%s Field 'has_thumbnail' is not found", logHeader)
		return
	}
	hasthumbnail, ok := rawhasthumbnail.(bool)
	if !ok {
		lgr.Warnf("%s Fail to convert 'has_thumbnail' into bool", logHeader)
		return
	}
	if !hasthumbnail {
		lgr.Infof("%s has_thumbnail is false", logHeader)
		return
	}
	root, errMsg := getRoot(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	groups, errMsg := getGroups(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	rawrelation, ok := (*document.DocumentInfo)["relation"]
	if !ok {
		lgr.Warnf("%s Field 'relation' is not found", logHeader)
		return
	}
	relation, ok := rawrelation.(string)
	if !ok {
		lgr.Errorf("%s Fail to convert 'relation' into string", logHeader)
		return
	}
	phase, errMsg := getPhase(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	slicelocation := append([]string{root}, groups...)
	slicelocation = append(slicelocation, relation, phase)
	location := strings.Join(slicelocation, "/")
	keyname := "latestThumbnail"
	timeoutCtx, cancel := context.WithTimeout(ctx, *h.readTimeout)
	defer cancel()
	db := h.pipelineParameterRepository.WithContext(timeoutCtx)
	pipelineparam, err := h.pipelineParameterRepository.GetParameter(
		db,
		lgr,
		pipelineParameter.GetParameterParams{
			KeyName: keyname,
		},
	)
	if err != nil {
		if !errors.Is(err, entity.ErrRecordNotFound) {
			log.Printf(
				"%s Error in finding existing paramter '%s': %s",
				logHeader,
				keyname,
				err.Error(),
			)
			return
		}
		jsonobject := entity.JSONObject(map[string]interface{}{"type": "string"})
		displayname := "Latest Thumbnail"
		description := "Latest revision with thumbnail"
		pipelineparam, err = h.pipelineParameterRepository.CreateParameter(
			db,
			lgr,
			pipelineParameter.CreateParameterParams{
				KeyName:     keyname,
				Schema:      jsonobject,
				DisplayName: &displayname,
				Description: &description,
			},
		)
		if err != nil {
			log.Printf(
				"%s Error in creating paramter '%s': %s",
				logHeader,
				keyname,
				err.Error(),
			)
			return
		}
	}
	existinglocations, _, err := h.pipelineParameterRepository.ListLocations(
		db,
		lgr,
		pipelineParameter.ListLocationsParams{
			Project:   projectName,
			Parameter: &pipelineparam.KeyName,
		},
	)
	if err != nil && !errors.Is(err, entity.ErrRecordNotFound) {
		log.Printf(
			"%s Error in finding existing location '%s': %s",
			logHeader,
			location,
			err.Error(),
		)
		return
	}
	var locationparam *pipelineParameter.Location
	for _, existinglocation := range existinglocations {
		if existinglocation.Path == location {
			locationparam = existinglocation
			break
		}
	}
	if locationparam == nil {
		locationparam, err = h.pipelineParameterRepository.CreateLocation(
			db,
			lgr,
			pipelineParameter.CreateLocationParams{
				Project:   projectName,
				Parameter: pipelineparam.KeyName,
				Path:      location,
			},
		)
		if err != nil {
			log.Printf(
				"%s Error in creating location '%s': %s",
				logHeader,
				location,
				err.Error(),
			)
			return
		}
	}
	values, count, err := h.pipelineParameterRepository.ListValues(
		db,
		lgr,
		pipelineParameter.ListValuesParams{
			Parameter: &pipelineparam.KeyName,
			Projects:  []string{projectName},
			Location:  &locationparam.Path,
		},
	)
	if err != nil && !errors.Is(err, entity.ErrRecordNotFound) {
		log.Printf(
			"%s Error in finding existing value for parameter '%s' and location '%s': %s",
			logHeader,
			pipelineparam.KeyName,
			locationparam.Path,
			err.Error(),
		)
		return
	}
	rawrevision, ok := (*document.DocumentInfo)["revision"]
	if !ok {
		lgr.Warnf("%s Field 'revision' is not found", logHeader)
		return
	}
	revision, ok := rawrevision.(string)
	if !ok {
		lgr.Errorf("%s Fail to convert 'revision' into string", logHeader)
		return
	}
	if count > 1 {
		log.Printf(
			"%s Multiple value records are found for parameter '%s' and location '%s': %s",
			logHeader,
			pipelineparam.KeyName,
			location,
			err.Error(),
		)
		return
	}
	if count == 1 {
		existingvalue := values[0]
		if existingvalue.Value == revision {
			log.Printf(
				"%s Value '%s' for parameter '%s' and location '%s' is unchanged ",
				logHeader,
				revision,
				keyname,
				locationparam.Path,
			)
			return
		}
		_, err := h.pipelineParameterRepository.UpdateValue(
			db,
			lgr,
			&pipelineParameter.UpdateValueParams{
				ID:        existingvalue.ID,
				Parameter: pipelineparam.KeyName,
				Value:     revision,
			},
		)
		if err != nil {
			log.Printf(
				"%s Error in updating value '%s' for parameter '%s' and location '%s': %s",
				logHeader,
				revision,
				keyname,
				locationparam.Path,
				err.Error(),
			)
			return
		}
		lgr.Info(
			fmt.Sprintf(
				"%s Value is successfully updated to '%s' from '%s' for parameter '%s' and location '%s'",
				logHeader,
				revision,
				existingvalue.Value,
				keyname,
				locationparam.Path,
			),
		)
	} else {
		_, err := h.pipelineParameterRepository.CreateValue(
			db,
			lgr,
			&pipelineParameter.CreateValueParams{
				Parameter: pipelineparam.KeyName,
				Project:   &projectName,
				Location:  locationparam.Path,
				Value:     revision,
			},
		)
		if err != nil {
			log.Printf(
				"%s Error in creating value '%s' for parameter '%s' and location '%s': %s",
				logHeader,
				revision,
				keyname,
				locationparam.Path,
				err.Error(),
			)
			return
		}
		lgr.Info(
			fmt.Sprintf(
				"%s Value '%s' is successfully created for parameter '%s' and location '%s'",
				logHeader,
				revision,
				keyname,
				locationparam.Path,
			),
		)
	}
}

func (h *Handler) UpsertFrameRange(
	lgr entity.Logger,
	document *entity.Document,
	projectName string,
	ctx context.Context,
) {
	logHeader := "[FrameRange Registration]"
	componentInfo, errMsg := getComponentInfo(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}

	// Get first_frame and last_frame from component_info
	rawTimeRange, ok := componentInfo["timerange"]
	if !ok {
		lgr.Infof("%s Field 'timerange' is not found", logHeader)
		return
	}
	timeRange, ok := rawTimeRange.(map[string]interface{})
	if !ok {
		lgr.Infof("%s Fail to convert 'timerange' into map", logHeader)
		return
	}
	rawFirstFrame, ok := timeRange["first_frame"]
	if !ok {
		lgr.Infof("%s Failed 'first_frame' is not found", logHeader)
		return
	}
	firstFrame, ok := rawFirstFrame.(float64)
	if !ok {
		lgr.Infof("%s Fail to convert 'first_frame' into float64", logHeader)
		return
	}
	rawLastFrame, ok := timeRange["last_frame"]
	if !ok {
		lgr.Infof("%s Failed 'last_frame' is not found", logHeader)
		return
	}
	lastFrame, ok := rawLastFrame.(float64)
	if !ok {
		lgr.Infof("%s Fail to convert 'last_frame' into float64", logHeader)
		return
	}
	frameRange := [2]float64{firstFrame, lastFrame}

	// Get location
	root, errMsg := getRoot(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	const targetRoot = "shots"
	if targetRoot != root {
		lgr.Infof(
			"%s FrameRange registration is not required in this root '%s'",
			logHeader,
			root,
		)
		return
	}
	groups, errMsg := getGroups(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	phase, errMsg := getPhase(document)
	if errMsg != nil {
		lgr.Errorf("%s %s", logHeader, errMsg)
		return
	}
	targetPhases := []string{"lay", "anm", "anmp", "rel"}
	if !slices.Contains(targetPhases, phase) {
		lgr.Infof(
			"%s FrameRange registration is not required in this phase '%s'",
			logHeader,
			phase,
		)
		return
	}
	sliceLocation := append([]string{root}, groups...)
	location := strings.Join(sliceLocation, "/")

	// Register frame range
	keyName := "frameRange"
	timeoutCtx, cancel := context.WithTimeout(ctx, *h.readTimeout)
	defer cancel()
	db := h.pipelineParameterRepository.WithContext(timeoutCtx)
	pipelineParam, err := h.pipelineParameterRepository.GetParameter(
		db,
		lgr,
		pipelineParameter.GetParameterParams{
			KeyName: keyName,
		},
	)
	if err != nil {
		if !errors.Is(err, entity.ErrRecordNotFound) {
			lgr.Errorf(
				"%s Error in finding existing paramter '%s': %s",
				logHeader,
				keyName,
				err.Error(),
			)
			return
		}
		jsonObject := entity.JSONObject(map[string]interface{}{"type": "string"})
		displayName := "Frame Range"
		description := "Frame Range"
		pipelineParam, err = h.pipelineParameterRepository.CreateParameter(
			db,
			lgr,
			pipelineParameter.CreateParameterParams{
				KeyName:     keyName,
				Schema:      jsonObject,
				DisplayName: &displayName,
				Description: &description,
			},
		)
		if err != nil {
			lgr.Errorf(
				"%s Error in creating paramter '%s': %s",
				logHeader,
				keyName,
				err.Error(),
			)
			return
		}
	}
	existingLocations, _, err := h.pipelineParameterRepository.ListLocations(
		db,
		lgr,
		pipelineParameter.ListLocationsParams{
			Project:   projectName,
			Parameter: &pipelineParam.KeyName,
		},
	)
	if err != nil && !errors.Is(err, entity.ErrRecordNotFound) {
		lgr.Errorf(
			"%s Error in finding existing location '%s': %s",
			logHeader,
			location,
			err.Error(),
		)
		return
	}
	var locationParam *pipelineParameter.Location
	for _, existingLocation := range existingLocations {
		if existingLocation.Path == location {
			locationParam = existingLocation
			break
		}
	}
	if locationParam == nil {
		locationParam, err = h.pipelineParameterRepository.CreateLocation(
			db,
			lgr,
			pipelineParameter.CreateLocationParams{
				Project:   projectName,
				Parameter: pipelineParam.KeyName,
				Path:      location,
			},
		)
		if err != nil {
			lgr.Errorf(
				"%s Error in creating location '%s': %s",
				logHeader,
				location,
				err.Error(),
			)
			return
		}
	}
	values, count, err := h.pipelineParameterRepository.ListValues(
		db,
		lgr,
		pipelineParameter.ListValuesParams{
			Parameter: &pipelineParam.KeyName,
			Projects:  []string{projectName},
			Location:  &locationParam.Path,
		},
	)
	if err != nil && !errors.Is(err, entity.ErrRecordNotFound) {
		lgr.Errorf(
			"%s Error in finding existing value for parameter '%s' and location '%s': %s",
			logHeader,
			pipelineParam.KeyName,
			locationParam.Path,
			err.Error(),
		)
		return
	}
	if count > 1 {
		lgr.Errorf(
			"%s Multiple value records are found for parameter '%s' and location '%s': %s",
			logHeader,
			pipelineParam.KeyName,
			location,
			err.Error(),
		)
		return
	}
	if count == 1 {
		existingValue := values[0]
		_, err := h.pipelineParameterRepository.UpdateValue(
			db,
			lgr,
			&pipelineParameter.UpdateValueParams{
				ID:        existingValue.ID,
				Parameter: pipelineParam.KeyName,
				Value:     frameRange,
			},
		)
		if err != nil {
			// existingValue.Value ( interface{} ) と frameRange ( [2]float64 ) が上手く比較出来なかったため
			// 取り急ぎエラーメッセージを見て判定しています。あまりよくないと思うので、今後修正した方がよいと思います。
			if err.Error() == "value are not modified: not modified" {
				lgr.Infof(
					"%s Value '%f' for parameter '%s' and location '%s' is unchanged ",
					logHeader,
					frameRange,
					keyName,
					locationParam.Path,
				)
				return
			}
			lgr.Errorf(
				"%s Error in updating value '%f' for parameter '%s' and location '%s': %s",
				logHeader,
				frameRange,
				keyName,
				locationParam.Path,
				err.Error(),
			)
			return
		}
		lgr.Infof(
			"%s Value is successfully updated to '%f' from '%f' for parameter '%s' and location '%s'",
			logHeader,
			frameRange,
			existingValue.Value,
			keyName,
			locationParam.Path,
		)
	} else {
		_, err := h.pipelineParameterRepository.CreateValue(
			db,
			lgr,
			&pipelineParameter.CreateValueParams{
				Parameter: pipelineParam.KeyName,
				Project:   &projectName,
				Location:  locationParam.Path,
				Value:     frameRange,
			},
		)
		if err != nil {
			lgr.Errorf(
				"%s Error in creating value '%f' for parameter '%s' and location '%s': %s",
				logHeader,
				frameRange,
				keyName,
				locationParam.Path,
				err.Error(),
			)
			return
		}
		lgr.Infof(
			"%s Value '%f' is successfully created for parameter '%s' and location '%s'",
			logHeader,
			frameRange,
			keyName,
			locationParam.Path,
		)
	}
}

// registerDataDependencies registers dependencies between content based on the input parameters.
// Even if there are multiple dependency requests, we consider the relevance of each to be low,
// so even if the registration of one of the data dependencies fails, the other registrations are
// not canceled.
func (h *Handler) registerDataDependencies(
	ctx context.Context,
	lgr entity.Logger,
	project string,
	params map[string]any,
) {
	logHeader := "[Data Dependency Registration]"

	if h.depRepo == nil {
		return
	}

	rawDataDependencies, ok := params["data_dependencies"].([]any)
	if !ok || len(rawDataDependencies) == 0 {
		return
	}
	dataDependencies := make([]map[string]any, len(rawDataDependencies))
	for i, dataDep := range rawDataDependencies {
		dataDepMap, ok := dataDep.(map[string]any)
		if !ok {
			lgr.Warnf(
				"%s Failed to convert data dependency %d to map: dataDependency=%v",
				logHeader,
				i,
				dataDep,
			)
			return
		}
		dataDependencies[i] = dataDepMap
	}

	root, ok := params["root"].(string)
	if !ok {
		lgr.Warnf("%s Field 'root' is not found or not a string: params=%v", logHeader, params)
		return
	}

	rowGroups, ok := params["groups"].([]any)
	if !ok {
		lgr.Warnf(
			"%s Field 'groups' is not found or not a slice: params=%v", logHeader, params,
		)
		return
	}
	groups := make([]string, len(rowGroups))
	for i, group := range rowGroups {
		groupStr, ok := group.(string)
		if !ok {
			lgr.Warnf(
				"%s Failed to convert group %d to string: params=%v", logHeader, i, params,
			)
			return
		}
		groups[i] = groupStr
	}

	group := strings.Join(groups, "/")
	relation, ok := params["relation"].(string)
	if !ok {
		lgr.Warnf("%s Field 'relation' is not found or not a string: params=%v", logHeader, params)
		return
	}
	phase, ok := params["phase"].(string)
	if !ok {
		lgr.Warnf("%s Field 'phase' is not found or not a string: params=%v", logHeader, params)
		return
	}
	component, ok := params["component"].(string)
	if !ok {
		lgr.Warnf(
			"%s Field 'component' is not found or not a string: params=%v", logHeader, params,
		)
		return
	}
	revision, ok := params["revision"].(string)
	if !ok {
		lgr.Warnf("%s Field 'revision' is not found or not a string: params=%v", logHeader, params)
		return
	}
	createdBy, _ := params["created_by"].(string) // Optional

	timeoutCtx, cancel := context.WithTimeout(ctx, *h.readTimeout)
	defer cancel()

	var wg sync.WaitGroup
	wg.Add(len(dataDependencies))
	for i, dataDep := range dataDependencies {
		newLgr := lgr.With("dependencyIndex", i)
		go func(dataDep map[string]any, lgr entity.Logger) {
			defer wg.Done()
			parsedData, err := parseDataDependencyParams(dataDep)
			if err != nil {
				lgr.Errorf(
					"%s Failed to parse data dependencies: %s: dataDependency=%v",
					logHeader,
					err.Error(),
					dataDep,
				)
				return
			}
			depParams := &dataDependency.AddContentDependenciesParams{
				CreatedBy:    &createdBy,
				Dependencies: parsedData.Dependencies,
			}
			err = binding.Validator.ValidateStruct(depParams)
			if err != nil {
				var fieldErrors validator.ValidationErrors
				if errors.As(err, &fieldErrors) {
					for _, err := range fieldErrors {
						lgr.Errorf(
							"%s Failed to validate parameter: field=%s, tag=%s, param=%s",
							logHeader,
							err.Field(),
							err.Tag(),
							err.Param(),
						)
					}
				}
				return
			}
			depWithFile, err := h.depRepo.AddContentDependencies(
				timeoutCtx,
				lgr,
				project,
				root,
				group,
				relation,
				phase,
				component,
				revision,
				parsedData.Content,
				depParams,
			)
			if err != nil {
				lgr.Errorf(
					"%s Problem occurred while registering data dependencies: %s: root=%s group=%s relation=%s phase=%s component=%s revision=%s content=%s",
					logHeader,
					err.Error(),
					root,
					group,
					relation,
					phase,
					component,
					revision,
					parsedData.Content,
				)
				return
			}
			lgr.Set("registeredContentAndDependenciesWithFile", depWithFile)
			fileContent := depWithFile.Content
			lgr.Infof(
				"%s Data dependencies registered successfully: root=%s group=%s relation=%s phase=%s component=%s revision=%s fileName=%s numberOfDependencies=%d",
				logHeader,
				fileContent.Root,
				fileContent.Group,
				fileContent.Relation,
				fileContent.Phase,
				fileContent.Component,
				fileContent.Revision,
				fileContent.FileName,
				len(depWithFile.Dependencies),
			)
		}(dataDep, newLgr)
	}
	wg.Wait()
}

// parseDataDependencyParams parses a map representing data dependency parameters into a
// DataDependency object. It expects the map to contain a "content" field of type string and a
// "dependencies" field which is a slice of maps.
func parseDataDependencyParams(dataDep map[string]any) (*dataDependency.DataDependency, error) {
	content, ok := dataDep["content"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'content' is not found or not a string")
	}
	rawDependencies, ok := dataDep["dependencies"].([]any)
	if !ok {
		return nil, fmt.Errorf("field 'dependencies' is not found or not a slice")
	}
	dependencies := make([]map[string]any, len(rawDependencies))
	for i, dep := range rawDependencies {
		depMap, ok := dep.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("failed to convert dependency %d to map: %v", i, dep)
		}
		dependencies[i] = depMap
	}
	depObjs := make([]*dataDependency.Dependency, len(dependencies))
	for i, dep := range dependencies {
		depObj, err := parseDependencyParams(dep)
		if err != nil {
			return nil, fmt.Errorf("failed to parse dependency parameters: %w", err)
		}
		depObjs[i] = depObj
	}
	return &dataDependency.DataDependency{
		Content:      content,
		Dependencies: depObjs,
	}, nil
}

// parseDependencyParams parses a map of dependency parameters into a dataDependency.Dependency
// object.
func parseDependencyParams(dep map[string]any) (*dataDependency.Dependency, error) {
	var (
		depObj dataDependency.Dependency
		ok     bool
	)
	depObj.Root, ok = dep["root"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'root' is not found or not a string")
	}
	depObj.Group, ok = dep["group"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'group' is not found or not a string")
	}
	depObj.Relation, ok = dep["relation"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'relation' is not found or not a string")
	}
	depObj.Phase, ok = dep["phase"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'phase' is not found or not a string")
	}
	depObj.Component, ok = dep["component"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'component' is not found or not a string")
	}
	depObj.Revision, ok = dep["revision"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'revision' is not found or not a string")
	}
	depObj.FileName, ok = dep["file_name"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'file_name' is not found or not a string")
	}
	storageSection, ok := dep["storage_section"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'storage_section' is not found or not a string")
	}
	depObj.StorageSection = dataDependency.StorageSection(storageSection)
	depObj.FilePath, ok = dep["file_path"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'file_path' is not found or not a string")
	}
	strength, ok := dep["strength"].(string)
	if !ok {
		return nil, fmt.Errorf("field 'strength' is not found or not a string")
	}
	depObj.Strength = dataDependency.DependencyStrength(strength)
	return &depObj, nil
}

// GetDocuments returns corresponding documents.
func (h *Handler) GetDocuments(c *gin.Context) {
	h.wrapHandler(c, func(ctx context.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		collectionName := c.Param("collection")

		var query DocumentQueries
		var docQuery baseDocumentQueries
		if collectionName == "comment" {
			query = &commentQueries{
				baseDocumentQueries: docQuery,
			}
		} else {
			query = &docQuery
		}

		err = c.BindQuery(query)
		if err != nil {
			return
		}

		params := query.Entity()

		project, err := h.service.GetProjectByName(ctx, projectName)
		if err != nil {
			return
		}

		documents, total, err := project.GetDocuments(ctx, collectionName, params)

		// https://jira.ppi.co.jp/browse/POTOO-1401
		scheme := "http"
		if val, ok := c.Request.Header["X-Forwarded-Proto"]; ok {
			scheme = val[0]
		}

		u, _ := url.Parse(c.Request.URL.String())
		u.Scheme = scheme
		u.Host = c.Request.Host
		prev, next := getPrevNextURL(u, *params.PerPage, *params.Page, total)

		data = &documentListResponse{
			Documents: documents,
			Prev:      prev,
			Next:      next,
			Total:     total,
		}
		return http.StatusOK, data, nil
	})
}

// GetDocument returns a document.
func (h *Handler) GetDocument(c *gin.Context) {
	h.wrapHandler(c, func(ctx context.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		collectionName := c.Param("collection")
		id := c.Param("id")

		project, err := h.service.GetProjectByName(ctx, projectName)
		if err != nil {
			return
		}

		document, err := project.GetDocumentByID(ctx, collectionName, id)
		if err != nil {
			return
		}

		return http.StatusOK, document, nil
	})
}

// PatchDocument updates a document that matches the id.
func (h *Handler) PatchDocument(c *gin.Context) {
	h.wrapHandler(c, func(ctx context.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		collectionName := c.Param("collection")
		id := c.Param("id")
		var param map[string]interface{}
		err = c.Bind(&param)
		if err != nil {
			return
		}

		project, err := h.service.GetProjectByName(ctx, projectName)
		if err != nil {
			return
		}

		document, err := project.UpdateDocument(ctx, collectionName, id, param)
		if err != nil {
			return
		}

		return http.StatusOK, document, nil
	})
}

// DeleteDocument deletes a document that matches the id.
func (h *Handler) DeleteDocument(c *gin.Context) {
	h.wrapHandler(c, func(ctx context.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		collectionName := c.Param("collection")
		id := c.Param("id")

		project, err := h.service.GetProjectByName(ctx, projectName)
		if err != nil {
			return
		}

		err = project.DeleteDocument(ctx, collectionName, id)
		if err != nil {
			return
		}

		return http.StatusNoContent, nil, nil
	})
}

func (h *Handler) wrapHandler(c *gin.Context, f func(ctx context.Context) (int, interface{}, error)) {
	var (
		tx     *sql.Tx
		status int
		data   interface{}
		err    error
	)

	defer func() {
		if p := recover(); p != nil {
			if tx != nil {
				tx.Rollback()
			}
			c.PureJSON(http.StatusInternalServerError, gin.H{"message": "internal server error"})
			panic(p)
		}

		if err != nil {
			if tx != nil {
				tx.Rollback()
			}
			c.PureJSON(status, gin.H{"message": err.Error()})
			log.Println(err)
			return
		}

		if tx != nil {
			err := tx.Commit()
			if err != nil {
				c.PureJSON(status, gin.H{"message": err.Error()})
				log.Println(err)
			} else {
				if data == nil {
					c.Status(status)
				} else {
					c.PureJSON(status, data)
				}
			}
		}
	}()

	ctx := c.Request.Context()

	// TODO: Once the authentication mechanism is in place, get the authenticated user name
	var user string
	ctx = context.WithValue(ctx, entity.KeyUser, user)

	tx, err = h.service.BeginTx(ctx, &sql.TxOptions{})
	if err != nil {
		status = http.StatusInternalServerError
		return
	}
	ctx = context.WithValue(ctx, entity.KeyTx, tx)

	status, data, err = f(ctx)
}
