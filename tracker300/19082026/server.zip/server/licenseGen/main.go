package main

import (
	"flag"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/license"
)

func main() {
	expiresAfter := flag.String("expires-after", "", "Expiration date in format YYYY-MM-DD (Example: 2021-03-18)")
	studio := flag.String("studio", "", "Studio name (Example: ppi)")
	tools := flag.String("tools", "ppip30", "Comma-separated list of tool names (Example: ppip25,ppip30)")
	out := flag.String("out", "license.ppilic", "Output file name")
	note := flag.String("note", "", "Notes (e.g. ticket link)")
	email := flag.String("email", "pipeline30@ppi.co.jp,td@ppi.co.jp", "E-mail addresses")
	outMeta := flag.String("out-meta", "meta.csv", "Output meta file name")

	flag.Parse()

	if *expiresAfter == "" {
		fmt.Println("Error: -expires-after is required")
		return
	}
	if *studio == "" {
		fmt.Println("Error: -studio is required")
		return
	}

	createdBy := os.Getenv("USER")
	if createdBy == "" {
		createdBy = os.Getenv("USERNAME")
	}
	// ea, err := time.Parse(time.DateOnly, strings.ReplaceAll(*expiresAfter, "/", "-")) // go >= v1.20
	ea, err := time.Parse("2006-01-02", strings.ReplaceAll(*expiresAfter, "/", "-"))
	if err != nil {
		fmt.Printf("Error: %s", err.Error())
		return
	}
	params := &license.CreateToolLicenseParams{
		ExpiresAfter: ea,
		Studio:       *studio,
		Tools:        strings.Split(*tools, ","),
		CreatedBy:    createdBy,
	}
	lic, err := license.Create(params)
	if err != nil {
		fmt.Printf("Error: %s", err.Error())
		return
	}

	file, err := os.Create(*out)
	if err != nil {
		fmt.Printf("Error: %s", err.Error())
	}
	defer file.Close()

	err = license.FormatLicense(file, lic)
	if err != nil {
		fmt.Printf("Error: %s", err.Error())
		return
	}

	mf, err := os.Create(*outMeta)
	if err != nil {
		fmt.Println("Error:", err.Error())
		return
	}
	defer mf.Close()
	if err = license.FormatMeta(mf, lic, *note, *email); err != nil {
		fmt.Println("Error:", err.Error())
	}
}
