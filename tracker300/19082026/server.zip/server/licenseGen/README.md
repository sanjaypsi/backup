# PPI Tools license generation command-line tool

## Build

```bash
cd front/server/licenseGen

# for Linux
go build -o ../../../build/licenseGen

# for Windows
go build -o ..\..\..\build\licenseGen.exe
```

### Show Help

```bash
licenseGen -h
```

### Generate license

```bash
cd front/build

licenseGen -studio ppidev -expires-after 2019-12-31 -note 'link to the ticket'
# File license.ppilic will be created
```

Place created license file to `{/pipelineRoot}/unshared/lic/license.ppilic`.
