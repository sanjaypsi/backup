-- MySQL dump 10.13  Distrib 8.0.20, for Linux (x86_64)
--
-- Host: 10.33.11.103    Database: central30
-- ------------------------------------------------------
-- Server version       8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_config_entry`
--

DROP TABLE IF EXISTS `t_config_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_config_entry` (
  `section_type` varchar(20) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_config_entry_1` (`section_type`,`section_name`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_datamaster_entry`
--

DROP TABLE IF EXISTS `t_datamaster_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_datamaster_entry` (
  `key` varchar(255) NOT NULL,
  `data` text,
  `description_ja` text,
  `description_en` text,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_datamaster_entry_1` (`key`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_directory`
--

DROP TABLE IF EXISTS `t_directory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_directory` (
  `project` varchar(30) NOT NULL,
  `path` varchar(1000) NOT NULL,
  `depth` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_directory_1` (`project`,`path`(255),`deleted`),
  KEY `ix_directory_2` (`project`,`modified_at_utc`,`deleted`),
  KEY `ix_directory_3` (`project`,`path`(255),`status`,`depth`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=355 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_directory_deletion_log`
--

DROP TABLE IF EXISTS `t_directory_deletion_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_directory_deletion_log` (
  `directory_id` int(11) NOT NULL,
  `studio` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_directory_deleteion_log_1` (`directory_id`,`studio`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_environment_entry`
--

DROP TABLE IF EXISTS `t_environment_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_environment_entry` (
  `section_type` varchar(20) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `ix_environment_entry_1` (`section_type`,`section_name`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=6982 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_keylist_entry`
--

DROP TABLE IF EXISTS `t_keylist_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_keylist_entry` (
  `key_type` varchar(50) NOT NULL,
  `key` varchar(255) NOT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_keylist_entry_1` (`key_type`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2810 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_preference_entry`
--

DROP TABLE IF EXISTS `t_preference_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_preference_entry` (
  `section_type` varchar(20) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_preference_entry_1` (`section_type`,`section_name`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2196 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_project_info`
--

DROP TABLE IF EXISTS `t_project_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_project_info` (
  `name` varchar(30) NOT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_project_info_1` (`name`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_project_info`
--

LOCK TABLES `t_project_info` WRITE;
/*!40000 ALTER TABLE `t_project_info` DISABLE KEYS */;
INSERT INTO `t_project_info`
VALUES
  ('potoodev','2019-07-17 05:21:45.000000','2019-07-17 05:21:45.000000',0,'thamada','thamada',2);
/*!40000 ALTER TABLE `t_project_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_project_studio_map`
--

DROP TABLE IF EXISTS `t_project_studio_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_project_studio_map` (
  `project` varchar(30) NOT NULL,
  `studio` varchar(30) NOT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_project_studio_map` (`project`,`studio`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_project_studio_map`
--

LOCK TABLES `t_project_studio_map` WRITE;
/*!40000 ALTER TABLE `t_project_studio_map` DISABLE KEYS */;
INSERT INTO `t_project_studio_map`
VALUES
  ('potoodev','ppidev','2019-07-17 05:22:54.000000','2019-07-17 05:22:54.000000',0,'thamada','thamada',3);
/*!40000 ALTER TABLE `t_project_studio_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_propertylist_entry`
--

DROP TABLE IF EXISTS `t_propertylist_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_propertylist_entry` (
  `key_type` varchar(50) NOT NULL,
  `key` varchar(255) NOT NULL,
  `property` varchar(30) NOT NULL,
  `data` text,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_propertylist_entry_1` (`key_type`,`key`,`property`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=9801 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_review`
--

DROP TABLE IF EXISTS `t_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_review` (
  `project` varchar(30) NOT NULL,
  `root` varchar(30) NOT NULL,
  `group1` varchar(100) NOT NULL,
  `group2` varchar(100) NOT NULL DEFAULT '',
  `group3` varchar(100) NOT NULL DEFAULT '',
  `group4` varchar(100) NOT NULL DEFAULT '',
  `group5` varchar(100) NOT NULL DEFAULT '',
  `relation` varchar(100) NOT NULL,
  `phase` varchar(100) NOT NULL,
  `subtask_id` varchar(50) NOT NULL,
  `task_id` varchar(36) NOT NULL,
  `review_target` text,
  `review_data` text,
  `approval_status` varchar(20) NOT NULL,
  `approval_status_updated_user` varchar(100) DEFAULT NULL,
  `approval_status_updated_utc` datetime(6) DEFAULT NULL,
  `work_status` varchar(20) NOT NULL,
  `work_status_updated_user` varchar(100) DEFAULT NULL,
  `work_status_updated_utc` datetime(6) DEFAULT NULL,
  `path` varchar(1000) NOT NULL,
  `studio` varchar(30) DEFAULT NULL,
  `published_user` varchar(100) DEFAULT NULL,
  `published_utc` datetime(6) DEFAULT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `ix_review_1` (`project`,`root`,`group1`,`group2`,`group3`,`group4`,`group5`,`relation`,`phase`,`deleted`),
  KEY `ix_review_2` (`project`,`path`(255),`deleted`),
  KEY `ix_review_3` (`project`,`subtask_id`,`deleted`),
  KEY `ix_review_4` (`project`,`task_id`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_review_info`
--

DROP TABLE IF EXISTS `t_review_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_review_info` (
  `task_id` varchar(36) NOT NULL,
  `subtask_id` varchar(36) NOT NULL,
  `studio` varchar(30) NOT NULL,
  `project` varchar(30) NOT NULL,
  `review_comments` json NOT NULL,
  `take_path` varchar(1000) NOT NULL,
  `root` varchar(30) NOT NULL,
  `groups` json NOT NULL,
  `relation` varchar(100) NOT NULL,
  `phase` varchar(100) NOT NULL,
  `component` varchar(100) NOT NULL,
  `take` varchar(30) NOT NULL,
  `approval_status` varchar(20) NOT NULL,
  `approval_status_updated_user` varchar(100) NOT NULL,
  `approval_status_updated_at_utc` datetime(6) NOT NULL,
  `work_status` varchar(20) NOT NULL,
  `work_status_updated_user` varchar(100) NOT NULL,
  `work_status_updated_at_utc` datetime(6) NOT NULL,
  `review_target` json NOT NULL,
  `review_data` json NOT NULL,
  `submitted_at_utc` datetime(6) NOT NULL,
  `submitted_computer` varchar(30) NOT NULL,
  `submitted_os` varchar(3) NOT NULL,
  `submitted_os_version` varchar(1000) NOT NULL,
  `submitted_user` varchar(100) NOT NULL,
  `executed_at_utc` datetime(6) NOT NULL,
  `executed_computer` varchar(30) NOT NULL,
  `executed_os` varchar(3) NOT NULL,
  `executed_os_version` varchar(1000) NOT NULL,
  `executed_user` varchar(100) NOT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_timeline` varchar(100) DEFAULT NULL,
  `export_shotsVersions` tinyint(1) DEFAULT NULL,
  `export_shotsVersions_revision` varchar(100) DEFAULT NULL,
  `export_shotsVersions_path` varchar(1000) DEFAULT NULL,
  `created_at_utc` datetime(6) NOT NULL,
  `modified_at_utc` datetime(6) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_path` varchar(1000) DEFAULT NULL,
  `export_shots_versions_path` varchar(1000) DEFAULT NULL,
  `output_contents` json DEFAULT NULL,
  `export_shots_versions_revision` varchar(100) DEFAULT NULL,
  `export_shots_versions` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_review_info_1` (`project`,`root`,`relation`,`phase`,`component`,`take`,`deleted`),
  KEY `ix_review_info_2` (`project`,`take_path`(255),`deleted`),
  KEY `ix_review_info_3` (`project`,`subtask_id`,`deleted`),
  KEY `ix_review_info_4` (`project`,`task_id`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_setting_definition`
--

DROP TABLE IF EXISTS `t_setting_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_setting_definition` (
  `group` varchar(20) NOT NULL,
  `key` varchar(255) NOT NULL,
  `definition` json DEFAULT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_setting_definition_1` (`group`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_setting_schema`
--

DROP TABLE IF EXISTS `t_setting_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_setting_schema` (
  `group` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `key` varchar(255) NOT NULL,
  `schema` json DEFAULT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_setting_schema_1` (`group`,`section`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3021 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_setting_value`
--

DROP TABLE IF EXISTS `t_setting_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_setting_value` (
  `group` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `entry` varchar(50) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` json DEFAULT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `index_setting_value_1` (`group`,`section`,`entry`,`key`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5020 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_shot_property`
--

DROP TABLE IF EXISTS `t_shot_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_shot_property` (
  `id` int(11) AUTO_INCREMENT NOT NULL PRIMARY KEY,
  `project` VARCHAR(30),
  `path` VARCHAR(765),
  `root` varchar(30),
  `group_1` varchar(100),
  `group_2` varchar(100),
  `group_3` varchar(100),
  `group_4` varchar(100),
  `group_5` varchar(100),
  `relation` varchar(100),
  `phase` varchar(100),
  `component` varchar(100),
  `revision` varchar(30),
  `data` JSON,
  `created_at_utc` datetime(6) NOT NULL,
  `modified_at_utc` datetime(6) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  KEY `ix_shot_property_1` (`project`, `path`, `deleted`),
  KEY `ix_shot_property_2` (`project`, `root`, `group_1`, `group_2`, `group_3`, `group_4`, `group_5`, `deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_studio_info`
--

DROP TABLE IF EXISTS `t_studio_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_studio_info` (
  `name` varchar(30) NOT NULL,
  `created_at_utc` datetime(6) DEFAULT NULL,
  `modified_at_utc` datetime(6) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `modified_by` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_studio_info_1` (`name`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_studio_info`
--

LOCK TABLES `t_studio_info` WRITE;
/*!40000 ALTER TABLE `t_studio_info` DISABLE KEYS */;
INSERT INTO `t_studio_info`
VALUES
  ('ppidev','2019-05-31 05:24:51.000000','2019-05-31 05:24:51.000000',0,'thamada','thamada',3);
/*!40000 ALTER TABLE `t_studio_info` ENABLE KEYS */;
UNLOCK TABLES;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-21  3:20:06
