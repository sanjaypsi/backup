// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package libs

import (
	"context"
	"database/sql"
)

// Context represents a context object.
type Context struct {
	Context context.Context
	Tx      *sql.Tx
	User    string
}

// NewContext returns a new Context.
func NewContext(ctx context.Context, tx *sql.Tx, user string) *Context {
	return &Context{
		Context: ctx,
		Tx:      tx,
		User:    user,
	}
}
