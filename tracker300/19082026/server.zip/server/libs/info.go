// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package libs

import "time"

// Scanner represents a scanner.
type Scanner interface {
	Scan(dest ...interface{}) error
}

// BaseInfo represents base information.
type BaseInfo struct {
	CreatedAtUtc  *time.Time `json:"created_at_utc"`
	ModifiedAtUtc *time.Time `json:"modified_at_utc"`
	Deleted       int        `json:"-"`
	CreatedBy     *string    `json:"created_by"`
	ModifiedBy    *string    `json:"modified_by"`
	ID            int64      `json:"id"`
}

// SubtaskOption represents a subtask option.
type SubtaskOption struct {
	Key   string      `json:"key"`
	Value interface{} `json:"value"`
}

// CommentInfo represents comment information.
type CommentInfo struct {
	Language              string   `json:"language"`
	Text                  string   `json:"text"`
	Attachments           []string `json:"attachments"`
	NeedTranslation       bool     `json:"need_translation"`
	IsTranslated          bool     `json:"is_translated"`
	ResponsiblePersonRole *string  `json:"responsible_person_role,omitempty"`
}

// File represents a file.
type File struct {
	Path string `json:"path"`
	Size int    `json:"size"`
}

// Content represents content file.
type Content struct {
	Path         string  `json:"path"`
	ToReview     bool    `json:"to_review"`
	IsAttachment bool    `json:"is_attachment"`
	Size         *int    `json:"size,omitempty"`
	AllFiles     []*File `json:"all_files"`
	Type         *string `json:"type,omitempty"`
	IsSequence   *bool   `json:"is_sequence,omitempty"`
	Frames       *[]int  `json:"frames,omitempty"`
}

// OrderDirection represents the direction of order.
type OrderDirection int

const (
	// Asc is in ascending order.
	Asc OrderDirection = iota
	// Desc is in descending order.
	Desc
)

// OrderColumn represents an ordered column.
type OrderColumn struct {
	Name      string
	Direction OrderDirection
}
