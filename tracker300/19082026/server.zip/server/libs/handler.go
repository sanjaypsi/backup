// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package libs

import (
	"net/http"
	"net/url"
	"reflect"
	"strconv"
)

func getPaginationURL(u *url.URL, page int) *string {
	q := u.Query()
	q.Set("page", strconv.Itoa(page))
	u.RawQuery = q.Encode()
	s := u.String()
	return &s
}

// GetPrevNextURL returns a pair of urls.
func GetPrevNextURL(u *url.URL, perPage, page, total int) (prev, next *string) {
	if page-1 > 0 {
		prev = getPaginationURL(u, page-1)
	}
	if perPage*(page+1) <= total+perPage-1 {
		next = getPaginationURL(u, page+1)
	}
	return
}

func getRequestURL(req *http.Request) *url.URL {
	u := *req.URL // copy
	// https://jira.ppi.co.jp/browse/POTOO-1401
	scheme := "http"
	if val, ok := req.Header["X-Forwarded-Proto"]; ok {
		scheme = val[0]
	}
	u.Scheme = scheme
	u.Host = req.Host
	return &u
}

type GetListParams interface {
	GetPerPage() int
	GetPage() int
}

func CreateListResponse(
	keyName string,
	entries interface{},
	req *http.Request,
	params GetListParams,
	total int,
) map[string]interface{} {
	u := getRequestURL(req)
	prev, next := GetPrevNextURL(u, params.GetPerPage(), params.GetPage(), total)
	// Avoid displaying the empty slice as null.
	if reflect.ValueOf(entries).IsNil() {
		entries = []interface{}{}
	}
	return map[string]interface{}{
		keyName: entries,
		"prev":  prev,
		"next":  next,
		"total": total,
    }
}

func CreateListResponse2(
    keyName string,
    entries interface{},
    keyName2 string,
    entries2 interface{},
    req *http.Request,
    params GetListParams,
    total int,
) map[string]interface{} {
    u := getRequestURL(req)
    prev, next := GetPrevNextURL(u, params.GetPerPage(), params.GetPage(), total)
    // Avoid displaying the empty slice as null.
    if reflect.ValueOf(entries).IsNil() {
        entries = []interface{}{}
    }
    if reflect.ValueOf(entries2).IsNil() {
        entries2 = []interface{}{}
    }
    return map[string]interface{}{
        keyName:  entries,
        keyName2: entries2,
        "prev":   prev,
        "next":   next,
        "total":  total,
	}
}
