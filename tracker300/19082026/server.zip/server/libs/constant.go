// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package libs

// TableName represents a table name.
type TableName string

const (
	// ProjectInfoTableName represents a project info table name.
	ProjectInfoTableName TableName = "t_project_info"
)

// DefaultPerPage is a default number of per page of the response.
const DefaultPerPage = 500
