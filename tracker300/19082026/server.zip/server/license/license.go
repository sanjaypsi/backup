package license

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/asn1"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"reflect"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

const publicPem = `-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA2baFE0pDN8EAo7qcnpJ0aTneZUiNhUysx829UtgzKHVZbqY7
lfYEspqW6WlAtU1VJXXgPb+tGY652J+TKFOD9v1gBFvhxeLFlaeOy3NICirilx3a
ZepTOpMZV3Qus4wS5C2ayLBanUcOU1gTfWp98JNYwoJbnE8Aa0Bqxqv/4bPZcwmH
VtWcBn2ZrfJqYJ5uN9TmZgmMs/JBwuV0NTYkyrDOCc4L5PfGBtUVUNko7F1dRLaY
KJfc47RGUjCdmdiRLBNRq1cMIXzdF2gcv40+FB4LV4rtasLrx2AyzW5KrnsRzZbH
aqN4aTHjevFX5456gfHcth0FLfRzxS+db5IuqwIDAQABAoIBAAP4QwbuBLnAiC10
GqT9kKfWiUqZfxMeKcxe4QPgs1Yaha3x1AZQ/RbwoK3S4H4t0c6kDpmxpAtiQdtE
VZ+XnkFjr1uE/WHpV6b57i2hhX/B9m3A+pl/I1NfGUgx8yQM+s80Ua01IgHaKNW2
NmzEA1XeqfCqBdeczSone4rx2fGYmE2p9s1COxqFWirfORGazputVvO24bNwOs/D
sSqyssjgNwmABAfmYjDJIG1QDmmmQ7UhLEcwo3vQLHzp9/2CrdPgRYPeefYoJMye
HFMbe3JRgxQYr5oLD6BP+zTLbO0g0umwfEZjZBSugmDHdT5XKOx+ZukEuEkSot8N
vzYNiKkCgYEA/cDrJ+o7dEuk+xcMsShvpFgh50xkNJlYQO738imMfnvQtCRK80xI
C0KznyQRE6UpisUXHX13ehGnAa9BmPMMsvm2AACGn6NXsYyCpxn8zK8mOg35MtaN
fL70AxxspFIkD8fyrH24IySqAb5GS5wGwXKBGIYF7gcmrKlhdxrkhyUCgYEA26Ps
JOSPy3OgIW73uy82PaqVFZUTXgifF1KkQeiO+3Jv3Yu9d01nhBoue91qGMTO2GmV
Ur6jj+znSR3NMOTHS/nJoi+i1HiNge0+zdxyjABKbHiJAp3rz5GcfYDibsHvvgCg
5kDA0NxKYtp7DnsAfV2QK8h77P5U92A5omkVnY8CgYAq1MNci2bZrGL+ltdnl8Gw
ZcfjOLu5PSDuZOepEmZKey+xGGcmRfvrGqki9X2EaV5ns/jA24qtKgmceS6DWJMO
KqQTwAL5MyL8LxFmjzZifjXfmrgzYo+jPMAHPmcAHXVEzKUjhFzuYaPog2tuG7nw
MRmlQAoEMWTPxA9VgU6NmQKBgQCGH2+Qh9IXVyAtymmU8JuaxJQNfd85yOH9iAWu
Calmetc83pxwQeA4lxRTpz2mqmf1V2RMBwYyWWRTDdPDS7E3/+zVEWnJfWRMNufn
Jfr86yCHZIOmCXF6a1y4dv/Oyrbvu8qFUH1uDVePTgNfMFV4OK5VTjP+4MBZ33TS
bIE6mQKBgHUQj9ElIzqWtC+26Qc5cRe0fojCf9zp7DjF1XWIAF+IyeBCFTl4DVJW
DxgXxQ1jZwaQdkxhpxOgOTmgICyM5ZZsd2wGvYX+wTIwuscdi+5HLYRVmrs4EClW
HHqCAeEdJPWv2VFbNMGPv24IbuWrEPwMSY4uWIp3jIaGs50FG0ja
-----END RSA PRIVATE KEY-----
`

// Entity

type ToolLicense struct {
	ExpiresAfter time.Time `json:"expires_after"`
	Studio       string    `json:"studio"`
	Tools        []string  `json:"tools"`
	Signature    string    `json:"signature"`

	// PublicKeyDigest is a value to identify the public key to be used for authentication. Note that the key pair may change to a new pair.
	PublicKeyDigest string `json:"public_key_digest"`

	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
	ID        int32     `json:"id"`
}

func (l ToolLicense) GetJSONKey(name string) string {
	t := reflect.TypeOf(l)
	field, _ := t.FieldByName(name)
	return field.Tag.Get("json")
}

type CreateToolLicenseParams struct {
	ExpiresAfter time.Time `json:"expires_after" binding:"date"`
	Studio       string    `json:"studio" binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Tools        []string  `json:"tools"`
	CreatedBy    string    `json:"created_by" binding:"max=100"`
}

// Model

type Model struct {
	ExpiresAfter time.Time `gorm:"not null;type:date;uniqueIndex:uix_tool_license_1"`
	Studio       string    `gorm:"not null;size:50;uniqueIndex:uix_tool_license_1;index:ix_tool_license_2"`
	Tools        string    `gorm:"not null;size:100;uniqueIndex:uix_tool_license_1"`
	Signature    string    `gorm:"not null;size:512"`

	// PublicKeyDigest is a value to identify the public key to be used for authentication. Note that the key pair may change to a new pair.
	PublicKeyDigest string `gorm:"not null;size:50;uniqueIndex:uix_tool_license_1"`

	CreatedAt time.Time `gorm:"not null;type:datetime(6)"`
	CreatedBy string    `gorm:"not null;type:datetime(6)"`
	Deleted   int32     `gorm:"not null;default:0;uniqueIndex:uix_tool_license_1"`
	ID        int32     `gorm:"not null;primaryKey;autoIncrement"`
}

func NewModel(
	p *CreateToolLicenseParams,
	signature string,
	publicKeyDigest string,
) *Model {
	tools := strings.Join(p.Tools, ",")
	now := time.Now().UTC()
	return &Model{
		ExpiresAfter:    p.ExpiresAfter,
		Studio:          p.Studio,
		Tools:           tools,
		Signature:       signature,
		PublicKeyDigest: publicKeyDigest,
		CreatedAt:       now,
		CreatedBy:       p.CreatedBy,
	}
}

func (l *Model) Entity() *ToolLicense {
	tools := strings.Split(l.Tools, ",")
	return &ToolLicense{
		ExpiresAfter:    l.ExpiresAfter,
		Studio:          l.Studio,
		Tools:           tools,
		Signature:       l.Signature,
		PublicKeyDigest: l.PublicKeyDigest,
		CreatedAt:       l.CreatedAt,
		CreatedBy:       l.CreatedBy,
		ID:              l.ID,
	}
}

//

func loadPrivateKey() (*rsa.PrivateKey, error) {
	content := []byte(publicPem)
	block, _ := pem.Decode(content)
	if block == nil {
		return nil, errors.New("failed to decode PEM block containing private key")
	}
	if block.Type != "RSA PRIVATE KEY" {
		return nil, fmt.Errorf("invalid private key type: %s", block.Type)
	}
	privateKey, err := x509.ParsePKCS1PrivateKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	return privateKey, nil
}

func createSignature(
	privateKey *rsa.PrivateKey,
	expiresAfter time.Time,
	studio string,
	tools []string,
) ([]byte, error) {
	data := fmt.Sprintf(
		"%s,%s,%s",
		// expiresAfter.Format(time.DateOnly), // go >= v1.20
		expiresAfter.Format("2006-01-02"),
		studio,
		strings.Join(tools, ","),
	)
	hashed := sha256.Sum256([]byte(data))
	signature, err := rsa.SignPKCS1v15(rand.Reader, privateKey, crypto.SHA256, hashed[:])
	if err != nil {
		return nil, err
	}
	return signature, nil
}

func encodePublicKey(publicKey rsa.PublicKey) (*string, error) {
	asn1Bytes, err := asn1.Marshal(publicKey)
	if err != nil {
		return nil, err
	}
	pemBlock := &pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: asn1Bytes,
	}
	publicPem := string(pem.EncodeToMemory(pemBlock))
	return &publicPem, nil
}

// Create creates license data
func Create(params *CreateToolLicenseParams) (*ToolLicense, error) {
	privateKey, err := loadPrivateKey()
	if err != nil {
		return nil, err
	}
	signature, err := createSignature(
		privateKey,
		params.ExpiresAfter,
		params.Studio,
		params.Tools,
	)
	if err != nil {
		return nil, err
	}
	publicPem, err := encodePublicKey(privateKey.PublicKey)
	if err != nil {
		return nil, err
	}

	h := sha256.New()
	for _, line := range strings.SplitAfter(*publicPem, "\n") {
		h.Write([]byte(line))
	}
	d := base64.StdEncoding.EncodeToString(h.Sum(nil))

	lic := NewModel(params, fmt.Sprintf("%x", signature), d)
	return lic.Entity(), nil
}

// FormatLicense writes formatted license infos to the buffer
func FormatLicense(buf io.Writer, license *ToolLicense) error {
	fmt.Fprintf(buf, "# Created at: %s\n", license.CreatedAt.Format(time.RFC3339))
	fmt.Fprintf(buf, "# Created by: %s\n", license.CreatedBy)

	fmt.Fprintf(buf, "\n[LICENSE]\n")
	// fmt.Fprintf(buf, "%s = %s\n", license.GetJSONKey("ExpiresAfter"), license.ExpiresAfter.Format(time.DateOnly)) // go >= v1.20
	fmt.Fprintf(buf, "%s = %s\n", license.GetJSONKey("ExpiresAfter"), license.ExpiresAfter.Format("2006-01-02"))
	fmt.Fprintf(buf, "%s = %s\n", license.GetJSONKey("Studio"), license.Studio)
	fmt.Fprintf(buf, "%s = %s\n", license.GetJSONKey("Tools"), strings.Join(license.Tools, ","))
	fmt.Fprintf(buf, "%s = %s\n", license.GetJSONKey("Signature"), license.Signature)
	return nil
}

func FormatMeta(buf io.Writer, license *ToolLicense, note string, email string) error {
	var (
		err error
	)
	if _, err = fmt.Fprintf(buf, "%q\t", license.CreatedAt.Format("2006/01/02")); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", license.CreatedBy); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", license.Studio); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", strings.Join(license.Tools, ",")); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", license.ExpiresAfter.Format("2006/01/02")); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", license.Signature); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", note); err != nil {
		return err
	}
	if _, err = fmt.Fprintf(buf, "%q\t", email); err != nil {
		return err
	}
	return nil
}

// PostLicense creates a new license
func PostLicense(c *gin.Context) {
	var params CreateToolLicenseParams
	if err := c.ShouldBindJSON(&params); err != nil {
		c.PureJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		log.Println(err)
		return
	}
	if len(params.Tools) == 0 {
		params.Tools = []string{"ppip30"}
	}

	lic, err := Create(&params)
	if err != nil {
		c.PureJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		log.Println(err)
		return
	}
	c.PureJSON(http.StatusCreated, lic)
}
