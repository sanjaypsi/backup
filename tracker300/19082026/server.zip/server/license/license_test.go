package license

import (
	"bytes"
	"testing"
	"time"
)

func TestLicense(t *testing.T) {
	// expiresAfter, _ := time.Parse(time.DateOnly, "2019-06-12") // go >= v1.20
	expiresAfter, _ := time.Parse("2006-01-02", "2019-06-12")
	params := &CreateToolLicenseParams{
		ExpiresAfter: expiresAfter,
		Studio:       "ppidev",
		Tools:        []string{"ppip30"},
		CreatedBy:    "test_user",
	}
	license, err := Create(params)
	if err != nil {
		t.Fatal(err)
	}
	var buf bytes.Buffer
	err = FormatLicense(&buf, license)
	if err != nil {
		t.Fatal(err)
	}
	// t.Fatal(buf.String())
}
