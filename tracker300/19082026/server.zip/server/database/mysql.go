package database

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/PolygonPictures/central30-web/front/entity"
)

const (
	tableNameDirectoryDeletionInfo = "t_directory_deletion_log"
	tableNameDirectoryInfo         = "t_directory"
	tableNameProjectInfo           = "t_project_info"
	tableNameProjectStudioMap      = "t_project_studio_map"
	tableNameReviewInfo            = "t_review_info"
	tableNameReviewStatusLog       = "t_review_status_log"
	tableNameStudioInfo            = "t_studio_info"
	tableNameShotProperty          = "t_shot_property"
)

func contextValue(ctx context.Context) (string, *sql.Tx, error) {
	user, ok := ctx.Value(entity.KeyUser).(string)
	if !ok {
		return "", nil, errors.New("failed to get user name")
	}

	tx, ok := ctx.Value(entity.KeyTx).(*sql.Tx)
	if !ok {
		return user, nil, errors.New("failed to get transaction object")
	}

	return user, tx, nil
}

// MySQLRepository represents a MySQL repository.
type MySQLRepository struct {
	db *sql.DB
}

// NewMySQLRepository creates a new MySQLRepository.
func NewMySQLRepository(db *sql.DB) entity.InfoRepository {
	return &MySQLRepository{db: db}
}

// BeginTx creates a new Tx object.
func (r *MySQLRepository) BeginTx(ctx context.Context, opts *sql.TxOptions) (*sql.Tx, error) {
	return r.db.BeginTx(ctx, opts)
}

// GetProjectByName returns the ProjectInfo corresponding to the name.
func (r *MySQLRepository) GetProjectByName(ctx context.Context, name string) (*entity.ProjectInfo, error) {
	_, tx, err := contextValue(ctx)
	if err != nil {
		return nil, err
	}

	row := tx.QueryRowContext(
		ctx,
		fmt.Sprintf(
			"SELECT `name`, `created_at_utc`, `modified_at_utc`, `deleted`, `modified_by`, `created_by`, `id` FROM %s WHERE `name` = ? AND `deleted` = 0",
			tableNameProjectInfo,
		),
		name,
	)
	var info entity.ProjectInfo
	err = info.Scan(row)
	if err != nil {
		return nil, err
	}
	return &info, nil
}

// GetStudiosByProject returns StudioInfos corresponding to the project name.
func (r *MySQLRepository) GetStudiosByProject(ctx context.Context, project string) ([]*entity.StudioInfo, error) {
	_, tx, err := contextValue(ctx)
	if err != nil {
		return nil, err
	}

	rows, err := tx.QueryContext(
		ctx,
		fmt.Sprintf(
			"SELECT %[1]s.name, %[1]s.created_at_utc, %[1]s.modified_at_utc, %[1]s.deleted, %[1]s.modified_by, %[1]s.created_by, %[1]s.id FROM %[1]s INNER JOIN %[2]s ON %[2]s.project = ? AND %[1]s.name = %[2]s.studio AND %[1]s.deleted = 0",
			tableNameStudioInfo,
			tableNameProjectStudioMap,
		),
		project,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	infos := []*entity.StudioInfo{}
	for rows.Next() {
		var info entity.StudioInfo
		err := info.Scan(rows)
		if err != nil {
			return nil, err
		}
		infos = append(infos, &info)
	}
	err = rows.Err()
	if err != nil {
		return nil, err
	}
	return infos, nil
}
