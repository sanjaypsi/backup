package database

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// MongoRepository represents a MongoDB repository.
type MongoRepository struct {
	db               *mongo.Database
	MetaKey          string
	CollectionPrefix string
}

// NewMongoRepository creates a new MongoRepository.
func NewMongoRepository(db *mongo.Database) entity.DocumentRepository {
	return &MongoRepository{
		db:               db,
		MetaKey:          "_central",
		CollectionPrefix: "pc_",
	}
}

func (r *MongoRepository) getCollection(name string) *mongo.Collection {
	return r.db.Collection(r.CollectionPrefix + name)
}

func (r *MongoRepository) dataToInfo(data bson.M) (*entity.DocumentInfo, error) {
	info := entity.DocumentInfo{}
	for key, val := range data {
		if strings.HasPrefix(key, "_") {
			continue
		}
		info[key] = val
	}
	info["id"] = data["_id"]

	central, ok := data[r.MetaKey].(bson.M)
	if !ok {
		return nil, fmt.Errorf("failed to convert %s data", r.MetaKey)
	}
	info["created_at_utc"] = central["created_at_utc"]
	info["modified_at_utc"] = central["modified_at_utc"]
	info["created_by"] = central["created_by"]
	info["modified_by"] = central["modified_by"]
	info["project"] = central["project"]

	return &info, nil
}

// CreateDocument creates a new document.
func (r *MongoRepository) CreateDocument(
	ctx context.Context,
	project string,
	collection string,
	params map[string]interface{},
) (*entity.DocumentInfo, error) {
	col := r.getCollection(collection)
	user, ok := ctx.Value(entity.KeyUser).(string)
	if !ok {
		return nil, errors.New("failed to get user name")
	}
	now := time.Now().UTC()
	data := bson.M{}
	for key, val := range params {
		data[key] = val
	}
	central := bson.M{
		"deleted":         0,
		"project":         project,
		"created_at_utc":  now,
		"created_by":      user,
		"modified_at_utc": now,
		"modified_by":     user,
	}
	data[r.MetaKey] = central
	res, err := col.InsertOne(ctx, data)
	if err != nil {
		return nil, err
	}
	data["_id"] = res.InsertedID
	result, err := r.dataToInfo(data)
	if err != nil {
		return nil, err
	}
	return result, nil
}

// GetDocumentByID returns a document info corresponding to ID.
func (r *MongoRepository) GetDocumentByID(
	ctx context.Context,
	project string,
	collection string,
	id string,
) (*entity.DocumentInfo, error) {
	col := r.getCollection(collection)
	objectID, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}
	filter := bson.M{
		"_id":                  objectID,
		r.MetaKey + ".project": project,
		r.MetaKey + ".deleted": 0,
	}
	var data bson.M
	err = col.FindOne(ctx, filter).Decode(&data)
	if err != nil {
		return nil, err
	}
	info, err := r.dataToInfo(data)
	if err != nil {
		return nil, err
	}
	return info, nil
}

// GetDocumentsByFields returns the documents specified by general filter props.
func (r *MongoRepository) GetDocumentsByFields(
	ctx context.Context,
	project string,
	collection string,
	param *entity.QueryDocumentsParam,
) (infos []*entity.DocumentInfo, total int, err error) {
	filter := bson.M{
		r.MetaKey + ".deleted": 0,
		r.MetaKey + ".project": project,
	}
	for key, field := range param.Filters {
		filter[key] = field
	}
	return r.queryDocuments(ctx, collection, param, filter)
}

/*
GetDocumentsByOfficialRevisionFilters returns the documents specified by
OfficialRevision-specific filter props.
*/
func (r *MongoRepository) GetDocumentsByOfficialRevisionFilters(
	ctx context.Context,
	project string,
	collection string,
	param *entity.QueryDocumentsParam,
	fields *map[string]interface{},
) (infos []*entity.DocumentInfo, total int, err error) {
	filter := bson.M{
		r.MetaKey + ".deleted": 0,
		r.MetaKey + ".project": project,
	}
	for key, field := range *fields {
		if !strings.HasPrefix(key, "group") && !strings.HasSuffix(key, "_exact") {
			strVal, ok := field.(string)
			if !ok {
				return nil, 0, errors.New("error in converting string")
			}
			if strings.HasPrefix(key, "revision") {
				strVal = fmt.Sprintf(`\.[sr0-9]*%s[sr0-9]*$`, strVal)
			}
			filter[key] = primitive.Regex{
				Pattern: strVal,
				Options: "i",
			}
		} else {
			key = strings.Replace(key, "_exact", "", -1)
			if key == "revision" {
				strVal, ok := field.(string)
				if !ok {
					return nil, 0, errors.New("error in converting string")
				}
				strVal = fmt.Sprintf(`\.%s$`, strVal)

				filter[key] = primitive.Regex{
					Pattern: strVal,
					Options: "i",
				}
			} else {
				filter[key] = field
			}
		}
	}
	return r.queryDocuments(ctx, collection, param, filter)
}

func (r *MongoRepository) queryDocuments(
	ctx context.Context,
	collection string,
	param *entity.QueryDocumentsParam,
	filter primitive.M,
) (infos []*entity.DocumentInfo, total int, err error) {
	col := r.getCollection(collection)
	count, err := col.CountDocuments(ctx, filter)
	if err != nil {
		return nil, 0, err
	}
	total = int(count)
	optionsToFind := options.Find()
	orderBy := bson.D{}

	if len(param.OrderBy) > 0 {
		for _, oc := range param.OrderBy {
			dir := 1
			if oc.Direction == libs.Desc {
				dir = -1
			}
			orderBy = append(orderBy, bson.E{Key: oc.Name, Value: dir})
		}
	} else if param.IsIdSortOrDefault() {
		orderBy = append(orderBy, bson.E{Key: "_id", Value: 1})
	}

	optionsToFind.SetSort(orderBy)
	if param.PerPage != nil {
		optionsToFind.SetLimit(int64(*param.PerPage))
		if param.Page != nil {
			offset := (*param.Page - 1) * *param.PerPage
			optionsToFind.SetSkip(int64(offset))
		}
	}

	if len(param.Projection) > 0 {
		proj := bson.M{}
		hasMetaKey := false
		for _, field := range param.Projection {
			proj[field] = 1
			if field == r.MetaKey {
				hasMetaKey = true
			}
		}
		if r.MetaKey != "" && !hasMetaKey {
			proj[r.MetaKey] = 1
		}
		optionsToFind.SetProjection(proj)
	}

	if param.IndexHint != "" {
		optionsToFind.SetHint(param.IndexHint)
	}

	cur, err := col.Find(ctx, filter, optionsToFind)
	if err != nil {
		return nil, total, err
	}
	defer cur.Close(ctx)
	for cur.Next(ctx) {
		var result bson.M
		err = cur.Decode(&result)
		if err != nil {
			return nil, total, err
		}
		info, err := r.dataToInfo(result)
		if err != nil {
			return infos, total, err
		}
		infos = append(infos, info)
	}
	if err = cur.Err(); err != nil {
		return infos, total, err
	}

	return infos, total, nil
}

// UpdateDocument updates the document that matches the id..
func (r *MongoRepository) UpdateDocument(
	ctx context.Context,
	project string,
	collection string,
	id string,
	params map[string]interface{},
) (*entity.DocumentInfo, error) {
	col := r.getCollection(collection)
	user, ok := ctx.Value(entity.KeyUser).(string)
	if !ok {
		return nil, errors.New("failed to get user name")
	}
	now := time.Now().UTC()
	objectID, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}
	filter := bson.M{
		"_id":                  objectID,
		r.MetaKey + ".deleted": 0,
	}
	setData := bson.M{}
	re := regexp.MustCompile(fmt.Sprintf(`^%s\.?`, r.MetaKey))
	for key, val := range params {
		if re.MatchString(key) {
			continue
		}
		setData[key] = val
	}
	setData[r.MetaKey+".modified_at_utc"] = now
	setData[r.MetaKey+".modified_by"] = user
	data := bson.M{
		"$set": setData,
	}
	rd := options.After
	optionsToFind := &options.FindOneAndUpdateOptions{
		ReturnDocument: &rd,
	}
	res := col.FindOneAndUpdate(ctx, filter, data, optionsToFind)
	var m bson.M
	err = res.Decode(&m)
	if err != nil {
		return nil, err
	}
	return r.dataToInfo(m)
}

// DeleteDocument logically deletes the document matching id.
func (r *MongoRepository) DeleteDocument(
	ctx context.Context,
	project string,
	collection string,
	id string,
) error {
	col := r.getCollection(collection)
	user, ok := ctx.Value(entity.KeyUser).(string)
	if !ok {
		return errors.New("failed to get user name")
	}
	now := time.Now().UTC()
	objectID, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return err
	}
	filter := bson.M{
		"_id":                  objectID,
		r.MetaKey + ".project": project,
		r.MetaKey + ".deleted": 0,
	}
	setData := bson.M{
		r.MetaKey + ".deleted":         id,
		r.MetaKey + ".modified_at_utc": now,
		r.MetaKey + ".modified_by":     user,
	}
	data := bson.M{
		"$set": setData,
	}
	res, err := col.UpdateOne(ctx, filter, data)
	if err != nil {
		return err
	}
	if res.ModifiedCount == 0 {
		return fmt.Errorf("deleted no document: %s", id)
	}
	return nil
}
