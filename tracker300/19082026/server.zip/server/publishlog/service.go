// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package publishlog

import (
	"fmt"
	"log"
	"strings"

	"github.com/PolygonPictures/central30-web/front/libs"
)

// Service represents a service.
type Service struct {
	repo *Repository
}

// NewService returns a new service.
func NewService(repo *Repository) *Service {
	return &Service{
		repo: repo,
	}
}

// Get returns publish logs.
func (s *Service) Get(ctx *libs.Context, project string, params *QueryParams) ([]*Entity, int, error) {
	options := &QueryOptions{
		Project:     project,
		CreatedFrom: params.CreatedFrom,
		CreatedTo:   params.CreatedTo,
	}

	// OrderBy
	var columns []*libs.OrderColumn
	for _, column := range params.OrderBy {
		if strings.HasPrefix(column, "-") {
			columns = append(columns, &libs.OrderColumn{
				Name:      column[1:],
				Direction: libs.Desc,
			})
		} else {
			columns = append(columns, &libs.OrderColumn{
				Name:      column,
				Direction: libs.Asc,
			})
		}
	}
	if len(columns) == 0 {
		columns = append(columns, &libs.OrderColumn{
			Name:      "id",
			Direction: libs.Desc,
		})
	}
	options.OrderBy = columns

	// Limit and Offset
	if params.Page != nil && params.PerPage != nil {
		perPage := *params.PerPage
		page := *params.Page
		options.Limit = &perPage
		offset := perPage * (page - 1)
		options.Offset = &offset
	}

	infos, total, err := s.repo.Get(ctx, project, options)
	if err != nil {
		log.Println(err)
		return nil, 0, fmt.Errorf("failed to get publish logs by options %v", options)
	}
	entities := []*Entity{}
	for _, info := range infos {
		entity, err := NewEntity(info, s.repo)
		if err != nil {
			log.Println(err)
			continue
		}
		entities = append(entities, entity)
	}
	return entities, total, nil
}

// GetByID returns a publish log with ID.
func (s *Service) GetByID(ctx *libs.Context, project string, id string) (*Entity, error) {
	info, err := s.repo.GetByID(ctx, project, id)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("publish log not found for id %q", id)
	}
	return NewEntity(info, s.repo)
}

// Create creates a new publish log.
func (s *Service) Create(ctx *libs.Context, project string, param *createPublishLogParam) (*Entity, error) {
	info, err := s.repo.Create(ctx, project, param)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("failed to create publish log with param %v", param)
	}
	return NewEntity(info, s.repo)
}
