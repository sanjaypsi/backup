// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package publishlog

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/libs"
)

// Entity represents a publish log.
type Entity struct {
	*Info
	repo            *Repository
	Lines           []*interface{}        `json:"lines"`
	InputContents   []*libs.Content       `json:"input_contents"`
	SubtaskOptions  []*libs.SubtaskOption `json:"subtask_options"`
	PublishComments []*libs.CommentInfo   `json:"publish_comments"`
}

func (r *Entity) String() string {
	return fmt.Sprintf("%v", r.Info)
}

// NewEntity create a new Entity.
func NewEntity(info *Info, repo *Repository) (*Entity, error) {
	lines := []*interface{}{}
	for _, l := range info.Lines {
		var line interface{}
		err := json.Unmarshal([]byte(l), &line)
		if err != nil {
			return nil, err
		}
		lines = append(lines, &line)
	}

	inputContents := []*libs.Content{}
	for _, c := range info.InputContents {
		var content libs.Content
		err := json.Unmarshal([]byte(c), &content)
		if err != nil {
			return nil, err
		}
		inputContents = append(inputContents, &content)
	}

	subtaskOptions := []*libs.SubtaskOption{}
	for _, o := range info.SubtaskOptions {
		var option libs.SubtaskOption
		err := json.Unmarshal([]byte(o), &option)
		if err != nil {
			return nil, err
		}
		subtaskOptions = append(subtaskOptions, &option)
	}

	publishComments := []*libs.CommentInfo{}
	for _, c := range info.PublishComments {
		var comment libs.CommentInfo
		err := json.Unmarshal([]byte(c), &comment)
		if err != nil {
			return nil, err
		}
		publishComments = append(publishComments, &comment)
	}

	return &Entity{
		Info:            info,
		repo:            repo,
		Lines:           lines,
		InputContents:   inputContents,
		SubtaskOptions:  subtaskOptions,
		PublishComments: publishComments,
	}, nil
}

// QueryParams represents query parameters.
type QueryParams struct {
	CreatedFrom *time.Time `form:"created_from" binding:"omitempty"`
	CreatedTo   *time.Time `form:"created_to" binding:"omitempty"`
	OrderBy     []string   `form:"order_by"`
	Page        *int       `form:"page" binding:"omitempty,min=1"`
	PerPage     *int       `form:"per_page" binding:"omitempty,min=1"`
}

type publishLogListResponse struct {
	PublishLogs []*Entity `json:"publish_logs"`
	Prev        *string   `json:"prev"`
	Next        *string   `json:"next"`
	Total       int       `json:"total"`
}

type createPublishLogParam struct {
	Lines              []interface{}         `json:"lines"`
	Result             string                `json:"result"`
	TaskID             string                `json:"task_id"`
	SubtaskID          string                `json:"subtask_id"`
	InputContents      []*libs.Content       `json:"input_contents"`
	Component          string                `json:"component"`
	Revision           string                `json:"revision"`
	SubtaskOptions     []*libs.SubtaskOption `json:"subtask_options"`
	Studio             string                `json:"studio"`
	Project            string                `json:"project"`
	PublishComments    []*libs.CommentInfo   `json:"publish_comments"`
	Root               string                `json:"root"`
	Groups             []string              `json:"groups"`
	Relation           string                `json:"relation"`
	Phase              string                `json:"phase"`
	Tool               string                `json:"tool"`
	SubmittedAtUTC     time.Time             `json:"submitted_at_utc"`
	SubmittedComputer  string                `json:"submitted_computer"`
	SubmittedOS        string                `json:"submitted_os"`
	SubmittedOSVersion string                `json:"submitted_os_version"`
	SubmittedUser      string                `json:"submitted_user"`
	ExecutedAtUTC      time.Time             `json:"executed_at_utc"`
	ExecutedComputer   string                `json:"executed_computer"`
	ExecutedOS         string                `json:"executed_os"`
	ExecutedOSVersion  string                `json:"executed_os_version"`
	ExecutedUser       string                `json:"executed_user"`
	LogID              string                `json:"log_id"`
}
