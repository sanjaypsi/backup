// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package publishlog

import (
	"database/sql"
	"log"
	"net/http"
	"net/url"
	"strings"

	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/project"
	"github.com/gin-gonic/gin"
)

// Handler represents a publish log handler.
type Handler struct {
	service        *Service
	projectService *project.Service
}

// NewHandler returns a new handler.
func NewHandler(service *Service, projectService *project.Service) *Handler {
	return &Handler{
		service:        service,
		projectService: projectService,
	}
}

// Get returns publish logs.
func (h *Handler) Get(c *gin.Context) {
	h.wrapHandler(c, func(ctx *libs.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		project, err := h.projectService.GetByName(ctx, projectName)
		if err != nil {
			return
		}

		var params QueryParams
		err = c.BindQuery(&params)
		if err != nil {
			return
		}
		var orderBy []string
		for _, part := range params.OrderBy {
			for _, column := range strings.Split(part, ",") {
				if len(column) == 0 || column == "-" {
					continue
				}
				orderBy = append(orderBy, column)
			}
		}
		params.OrderBy = orderBy
		if params.Page == nil {
			page := 1
			params.Page = &page
		}
		if params.PerPage == nil {
			// Since the amount of data per entry is large, reduce the default number of cases
			// than usual.
			perPage := 5
			params.PerPage = &perPage
		}
		publishLogs, total, err := h.service.Get(ctx, project.Name, &params)
		if err != nil {
			return
		}

		// https://jira.ppi.co.jp/browse/POTOO-1401
		scheme := "http"
		if val, ok := c.Request.Header["X-Forwarded-Proto"]; ok {
			scheme = val[0]
		}

		u, _ := url.Parse(c.Request.URL.String())
		u.Scheme = scheme
		u.Host = c.Request.Host
		prev, next := libs.GetPrevNextURL(u, *params.PerPage, *params.Page, total)

		data = &publishLogListResponse{
			PublishLogs: publishLogs,
			Prev:        prev,
			Next:        next,
			Total:       total,
		}
		return http.StatusOK, data, nil
	})
}

// GetByID returns a publish log with ID.
func (h *Handler) GetByID(c *gin.Context) {
	h.wrapHandler(c, func(ctx *libs.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")
		id := c.Param("id")

		project, err := h.projectService.GetByName(ctx, projectName)
		if err != nil {
			return
		}

		publishLog, err := h.service.GetByID(ctx, project.Name, id)
		if err != nil {
			return
		}

		return http.StatusOK, publishLog, nil
	})
}

// Post creates a publish log.
func (h *Handler) Post(c *gin.Context) {
	h.wrapHandler(c, func(ctx *libs.Context) (status int, data interface{}, err error) {
		status = http.StatusBadRequest

		projectName := c.Param("project")

		var params createPublishLogParam
		err = c.Bind(&params)
		if err != nil {
			return
		}

		project, err := h.projectService.GetByName(ctx, projectName)
		if err != nil {
			return
		}

		publishLog, err := h.service.Create(ctx, project.Name, &params)
		if err != nil {
			return
		}

		return http.StatusOK, publishLog, nil
	})
}

func (h *Handler) wrapHandler(c *gin.Context, f func(ctx *libs.Context) (int, interface{}, error)) {
	var (
		tx     *sql.Tx
		status int
		data   interface{}
		err    error
	)

	defer func() {
		if p := recover(); p != nil {
			if tx != nil {
				tx.Rollback()
			}
			c.PureJSON(http.StatusInternalServerError, gin.H{"message": "internal server error"})
			panic(p)
		}

		if err != nil {
			if tx != nil {
				tx.Rollback()
			}
			c.PureJSON(status, gin.H{"message": err.Error()})
			log.Println(err)
			return
		}

		if tx != nil {
			err := tx.Commit()
			if err != nil {
				c.PureJSON(status, gin.H{"message": err.Error()})
				log.Println(err)
			} else {
				if data == nil {
					c.Status(status)
				} else {
					c.PureJSON(status, data)
				}
			}
		}
	}()

	ctx := c.Request.Context()

	// TODO: Once the authentication mechanism is in place, get the authenticated user name
	var user string

	tx, err = h.projectService.BeginTx(ctx, &sql.TxOptions{})
	if err != nil {
		status = http.StatusInternalServerError
		return
	}

	status, data, err = f(libs.NewContext(ctx, tx, user))
}
