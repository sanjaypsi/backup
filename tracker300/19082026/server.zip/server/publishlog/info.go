// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package publishlog

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/libs"
)

// Info represents publish log info.
// https://confluence.ppi.co.jp/display/POTOO/PublishLog
type Info struct {
	Lines              []string  `json:"lines" bigquery:"lines"`
	Result             string    `json:"result" bigquery:"result"`
	TaskID             string    `json:"task_id" bigquery:"task_id"`
	SubtaskID          string    `json:"subtask_id" bigquery:"subtask_id"`
	InputContents      []string  `json:"input_contents" bigquery:"input_contents"`
	Component          string    `json:"component" bigquery:"component"`
	Revision           string    `json:"revision" bigquery:"revision"`
	SubtaskOptions     []string  `json:"subtask_options" bigquery:"subtask_options"`
	Studio             string    `json:"studio" bigquery:"studio"`
	Project            string    `json:"project" bigquery:"project"`
	PublishComments    []string  `json:"publish_comments" bigquery:"publish_comments"`
	Root               string    `json:"root" bigquery:"root"`
	Groups             []string  `json:"groups" bigquery:"groups"`
	Relation           string    `json:"relation" bigquery:"relation"`
	Phase              string    `json:"phase" bigquery:"phase"`
	Tool               string    `json:"tool" bigquery:"tool"`
	SubmittedAtUTC     time.Time `json:"submitted_at_utc" bigquery:"submitted_at_utc"`
	SubmittedComputer  string    `json:"submitted_computer" bigquery:"submitted_computer"`
	SubmittedOS        string    `json:"submitted_os" bigquery:"submitted_os"`
	SubmittedOSVersion string    `json:"submitted_os_version" bigquery:"submitted_os_version"`
	SubmittedUser      string    `json:"submitted_user" bigquery:"submitted_user"`
	ExecutedAtUTC      time.Time `json:"executed_at_utc" bigquery:"executed_at_utc"`
	ExecutedComputer   string    `json:"executed_computer" bigquery:"executed_computer"`
	ExecutedOS         string    `json:"executed_os" bigquery:"executed_os"`
	ExecutedOSVersion  string    `json:"executed_os_version" bigquery:"executed_os_version"`
	ExecutedUser       string    `json:"executed_user" bigquery:"executed_user"`
	LogID              string    `json:"log_id" bigquery:"log_id"`

	ID           string    `json:"id" bigquery:"id"`
	CreatedAtUTC time.Time `json:"created_at_utc" bigquery:"created_at_utc"`
	CreatedBy    string    `json:"created_by" bigquery:"created_by"`
}

// QueryOptions represents query options to get publish logs.
type QueryOptions struct {
	Project     string
	CreatedFrom *time.Time
	CreatedTo   *time.Time
	OrderBy     []*libs.OrderColumn
	Limit       *int
	Offset      *int
}
