// Copyright © 2020 Polygon Pictures Inc. All rights reserved.

package publishlog

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"strconv"
	"strings"
	"time"

	"cloud.google.com/go/bigquery"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/oklog/ulid"
	"google.golang.org/api/iterator"
)

// Repository represents a repository of the publish logs.
type Repository struct {
	client  *bigquery.Client
	dataset *bigquery.Dataset
}

// NewRepository returns a new Repository.
func NewRepository(client *bigquery.Client, dataset *bigquery.Dataset) *Repository {
	return &Repository{
		client:  client,
		dataset: dataset,
	}
}

func (r *Repository) getTableNames(ctx context.Context, createdFrom, createdTo *time.Time) ([]string, error) {
	tableIt := r.dataset.Tables(ctx)
	var tables []*bigquery.Table
	for {
		t, err := tableIt.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}
		tables = append(tables, t)
	}
	var tableNames []string
	for _, t := range tables {
		year, err := strconv.Atoi(t.TableID[len(t.TableID)-4:])
		if err != nil {
			log.Println(err)
			continue
		}
		if createdFrom != nil {
			if year < (*createdFrom).UTC().Year() {
				continue
			}
		}
		if createdTo != nil {
			if year > (*createdTo).UTC().Year() {
				continue
			}
		}
		tableName := t.DatasetID + "." + t.TableID
		tableNames = append(tableNames, tableName)
	}
	return tableNames, nil
}

// Get returns publish logs.
func (r *Repository) Get(ctx *libs.Context, project string, options *QueryOptions) ([]*Info, int, error) {
	tableNames, err := r.getTableNames(ctx.Context, options.CreatedFrom, options.CreatedTo)
	if err != nil {
		return nil, 0, err
	}
	infos := []*Info{}
	if len(tableNames) == 0 {
		return infos, 0, nil
	}

	var filters []string
	if options.CreatedFrom != nil {
		createdFrom := (*options.CreatedFrom).UTC().Format(time.RFC3339Nano)
		filters = append(filters, fmt.Sprintf(`TIMESTAMP("%s") < %s`, createdFrom, timePartitioning.Field))
	}
	if options.CreatedTo != nil {
		createdTo := (*options.CreatedTo).UTC().Format(time.RFC3339Nano)
		filters = append(filters, fmt.Sprintf(`%s < TIMESTAMP("%s")`, timePartitioning.Field, createdTo))
	}
	filters = append(filters, fmt.Sprintf(`project = "%s"`, options.Project))

	// Build a query like the following:
	// ```
	// SELECT *
	// FROM (
	// 	SELECT * FROM `ppip30_publishlog_dev.ppip30_publishlog_dev_2020` UNION ALL
	// 	SELECT * FROM `ppi-gcp-pj001.ppip30_publishlog_dev.ppip30_publishlog_dev_2021`
	// )
	// WHERE `project` = "potoodev"
	// ```

	query := `
		FROM (`
	for i, tableName := range tableNames {
		query += `
			SELECT * FROM ` + "`" + tableName + "`"
		if i < len(tableNames)-1 {
			query += " UNION ALL"
		}
	}
	query += `
		)
		WHERE ` + strings.Join(filters, " AND ")

	q := r.client.Query(`SELECT COUNT(*) ` + query)
	rowIt, err := q.Read(ctx.Context)
	if err != nil {
		return nil, 0, err
	}
	var value []bigquery.Value
	err = rowIt.Next(&value)
	if err != nil {
		return nil, 0, err
	}
	total := int(value[0].(int64))

	var orderBy []string
	schema, err := bigquery.InferSchema(Info{})
	if err != nil {
		return nil, 0, err
	}
	columns := map[string]*bigquery.FieldSchema{}
	for _, field := range schema {
		columns[field.Name] = field
	}
	for _, column := range options.OrderBy {
		field, ok := columns[column.Name]
		if !ok {
			return nil, 0, fmt.Errorf("unrecognized name: `%s`", column.Name)
		}
		if field.Repeated {
			return nil, 0, fmt.Errorf("ORDER BY does not support expressions of type ARRAY<STRING>")
		}
		if column.Direction == libs.Desc {
			orderBy = append(orderBy, fmt.Sprintf("`%s` DESC", column.Name))
		} else {
			orderBy = append(orderBy, fmt.Sprintf("`%s`", column.Name))
		}
	}
	if len(orderBy) != 0 {
		query += `
		ORDER BY ` + strings.Join(orderBy, ", ")
	}
	if options.Limit != nil {
		query += `
		LIMIT ` + strconv.Itoa(*options.Limit)
	}
	if options.Offset != nil {
		query += `
		OFFSET ` + strconv.Itoa(*options.Offset)
	}
	q = r.client.Query(`SELECT * ` + query)
	rowIt, err = q.Read(ctx.Context)
	if err != nil {
		return nil, 0, err
	}
	for {
		var info Info
		err := rowIt.Next(&info)
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, 0, err
		}
		infos = append(infos, &info)
	}
	return infos, total, nil
}

// GetByID returns a publish log with ID.
func (r *Repository) GetByID(ctx *libs.Context, project string, id string) (*Info, error) {
	// Narrow the scan range by filtering the partition table by date.

	parsed, err := ulid.Parse(id)
	if err != nil {
		return nil, err
	}
	t := ulid.Time(parsed.Time()).UTC()

	tableNames, err := r.getTableNames(ctx.Context, &t, &t)
	if err != nil {
		return nil, err
	}
	if len(tableNames) == 0 {
		return nil, fmt.Errorf("no tables found")
	}

	var filters []string
	filters = append(filters, fmt.Sprintf(`DATE(%s) = "%s"`, timePartitioning.Field, t.Format("2006-01-02")))
	filters = append(filters, fmt.Sprintf(`project = "%s"`, project))
	filters = append(filters, fmt.Sprintf(`id = "%s"`, id))

	query := `
		SELECT *
		FROM (`
	for i, tableName := range tableNames {
		query += `
			SELECT * FROM ` + "`" + tableName + "`"
		if i < len(tableNames)-1 {
			query += " UNION ALL "
		}
	}
	query += `
		)
		WHERE ` + strings.Join(filters, " AND ") + `
		LIMIT 1`
	q := r.client.Query(query)
	rowIt, err := q.Read(ctx.Context)
	if err != nil {
		return nil, err
	}
	var info Info
	err = rowIt.Next(&info)
	if err != nil {
		return nil, err
	}
	return &info, nil
}

// Create creates a publish log.
func (r *Repository) Create(ctx *libs.Context, project string, param *createPublishLogParam) (*Info, error) {
	user := ctx.User
	now := time.Now().UTC()

	lines := []string{}
	for _, l := range param.Lines {
		bytes, err := json.Marshal(l)
		if err != nil {
			return nil, err
		}
		lines = append(lines, string(bytes))
	}

	inputContents := []string{}
	for _, c := range param.InputContents {
		bytes, err := json.Marshal(c)
		if err != nil {
			return nil, err
		}
		inputContents = append(inputContents, string(bytes))
	}

	subtaskOptions := []string{}
	for _, o := range param.SubtaskOptions {
		bytes, err := json.Marshal(o)
		if err != nil {
			return nil, err
		}
		subtaskOptions = append(subtaskOptions, string(bytes))
	}

	publishComments := []string{}
	for _, c := range param.PublishComments {
		bytes, err := json.Marshal(c)
		if err != nil {
			return nil, err
		}
		publishComments = append(publishComments, string(bytes))
	}

	info := &Info{
		Lines:              lines,
		Result:             param.Result,
		TaskID:             param.TaskID,
		SubtaskID:          param.SubtaskID,
		InputContents:      inputContents,
		Component:          param.Component,
		Revision:           param.Revision,
		SubtaskOptions:     subtaskOptions,
		Studio:             param.Studio,
		Project:            project,
		PublishComments:    publishComments,
		Root:               param.Root,
		Groups:             param.Groups,
		Relation:           param.Relation,
		Phase:              param.Phase,
		Tool:               param.Tool,
		SubmittedAtUTC:     param.SubmittedAtUTC,
		SubmittedComputer:  param.SubmittedComputer,
		SubmittedOS:        param.SubmittedOS,
		SubmittedOSVersion: param.SubmittedOSVersion,
		SubmittedUser:      param.SubmittedUser,
		ExecutedAtUTC:      param.ExecutedAtUTC,
		ExecutedComputer:   param.ExecutedComputer,
		ExecutedOS:         param.ExecutedOS,
		ExecutedOSVersion:  param.ExecutedOSVersion,
		ExecutedUser:       param.ExecutedUser,
		LogID:              param.LogID,

		ID:           createID(now).String(),
		CreatedAtUTC: now,
		CreatedBy:    user,
	}

	table, err := getTable(ctx.Context, r.dataset, now.Year())
	if err != nil {
		return nil, err
	}
	ins := table.Inserter()
	err = ins.Put(ctx.Context, []*Info{info})
	if err != nil {
		return nil, err
	}
	return info, nil
}

func createID(t time.Time) ulid.ULID {
	src := rand.NewSource(time.Now().UnixNano())
	return ulid.MustNew(ulid.Timestamp(t), rand.New(src))
}

func getTable(ctx context.Context, dataset *bigquery.Dataset, year int) (*bigquery.Table, error) {
	tableID := fmt.Sprintf("%s_%d", dataset.DatasetID, year)
	return getPartitionTable(ctx, dataset, tableID)
}

// getPartitionTable returns the Partition Table with the tableID.
// If the table with tableID is not found, it will be created.
func getPartitionTable(ctx context.Context, dataset *bigquery.Dataset, tableID string) (*bigquery.Table, error) {
	tableRef := dataset.Table(tableID)
	_, err := tableRef.Metadata(ctx) // Check if the table exists
	if err != nil {
		schema, err := bigquery.InferSchema(Info{})
		if err != nil {
			return nil, err
		}
		if err := tableRef.Create(ctx, &bigquery.TableMetadata{
			Schema:           schema,
			TimePartitioning: &timePartitioning,
		}); err != nil {
			return nil, err
		}
		metadata, err := tableRef.Metadata(ctx)
		if err != nil {
			return nil, err
		}
		log.Printf("Table %q created.", metadata.FullID)
	}
	return tableRef, nil
}

var timePartitioning = bigquery.TimePartitioning{
	Type:  bigquery.DayPartitioningType,
	Field: "created_at_utc",
}
