package http

import (
	"github.com/PolygonPictures/central30-web/front/setting/domain"
	"github.com/PolygonPictures/central30-web/front/setting/usecase"
	"github.com/gin-gonic/gin"
)

// ResponseValueEntries represent response values for the settings
type ResponseValueEntries struct {
	*usecase.ValuesInfo
	Prev *string `json:"prev"`
	Next *string `json:"next"`
}

// ResponseSchemaEntries represent response schemas for the settings
type ResponseSchemaEntries struct {
	*usecase.SchemasInfo
	Prev *string `json:"prev"`
	Next *string `json:"next"`
}

// ResponseDefinitionEntries represent response Definitions for the settings
type ResponseDefinitionEntries struct {
	*usecase.DefinitionsInfo
	Prev *string `json:"prev"`
	Next *string `json:"next"`
}

// ResponseError represent the response error struct
type ResponseError struct {
	Message string `json:"message"`
}

// Handler delivers http handlers
type Handler interface {
	HandleGetDefinitions(group domain.Group) gin.HandlerFunc
	HandleGetDefinitionByID(group domain.Group) gin.HandlerFunc
	HandlePostDefinition(group domain.Group) gin.HandlerFunc
	HandlePatchDefinition(group domain.Group) gin.HandlerFunc
	HandleDeleteDefinition(group domain.Group) gin.HandlerFunc

	HandleGetValues(group domain.Group) gin.HandlerFunc
	HandleGetValueByID(group domain.Group) gin.HandlerFunc
	HandlePostValue(group domain.Group) gin.HandlerFunc
	HandlePatchValue(group domain.Group) gin.HandlerFunc
	HandleDeleteValue(group domain.Group) gin.HandlerFunc

	HandleGetSchemas(group domain.Group) gin.HandlerFunc
	HandleGetSchemaByID(group domain.Group) gin.HandlerFunc
	HandlePostSchema(group domain.Group) gin.HandlerFunc
	HandlePatchSchema(group domain.Group) gin.HandlerFunc
	HandleDeleteSchema(group domain.Group) gin.HandlerFunc
}
