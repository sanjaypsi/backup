package http

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"strconv"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
	"github.com/PolygonPictures/central30-web/front/setting/usecase"
	"github.com/gin-gonic/gin"
)

type valuesResult struct {
	Info *usecase.ValuesInfo
	Err  error
}

type valueResult struct {
	Value *domain.ValueEntry
	Err   error
}

type schemasResult struct {
	Info *usecase.SchemasInfo
	Err  error
}

type schemaResult struct {
	Schema *domain.SchemaEntry
	Err    error
}

type definitionsResult struct {
	Info *usecase.DefinitionsInfo
	Err  error
}

type definitionResult struct {
	Definition *domain.DefinitionEntry
	Err        error
}

type settingDelivery struct {
	Usecase usecase.Usecase
}

// NewSettingDelivery will initialize the /setting resources endpoint
func NewSettingDelivery(u usecase.Usecase) Handler {
	return &settingDelivery{Usecase: u}
}

func (d *settingDelivery) HandleGetValues(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		params, err := parseQueryParams(c)
		if err != nil {
			log.Println(err)
			return
		}

		ch := make(chan *valuesResult)
		cCp := c.Copy()
		go func() {
			valuesInfo, err := d.Usecase.FindValues(cCp.Request.Context(), group, params)
			ch <- &valuesResult{valuesInfo, err}
		}()
		res := <-ch

		err = res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			return
		}

		valuesInfo := res.Info
		if valuesInfo.Values == nil {
			valuesInfo.Values = []*domain.ValueEntry{}
		}
		if valuesInfo.EntryTags == nil {
			valuesInfo.EntryTags = []string{}
		}
		prev, next := d.getPrevNextURL(c.Request, params.PerPage, params.Page, valuesInfo.Total)
		c.PureJSON(http.StatusOK, &ResponseValueEntries{
			ValuesInfo: valuesInfo,
			Prev:       prev,
			Next:       next,
		})
	}
}

func (d *settingDelivery) HandleGetValueByID(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan *valueResult)
		go func() {
			value, err := d.Usecase.FindValueByID(cCp.Request.Context(), group, id)
			ch <- &valueResult{value, err}
		}()
		res := <-ch

		err = res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		c.PureJSON(http.StatusOK, res.Value)
	}
}

func (d *settingDelivery) HandlePostValue(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		var inputData usecase.CreateValueInputData
		if err := c.Bind(&inputData); err != nil {
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan *valueResult)
		go func() {
			value, err := d.Usecase.StoreValue(cCp.Request.Context(), group, &inputData)
			ch <- &valueResult{value, err}
		}()
		res := <-ch

		err := res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		value := res.Value
		c.PureJSON(http.StatusCreated, value)
		bytes, err := json.Marshal(inputData)
		if err == nil {
			log.Printf("value posted: %s\n", bytes)
		}
	}
}

func (d *settingDelivery) HandlePatchValue(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}
		inputData := &usecase.UpdateValueInputData{ID: id}
		if err = c.Bind(inputData); err != nil {
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan error)
		go func() {
			ch <- d.Usecase.UpdateValue(cCp.Request.Context(), group, inputData)
		}()
		err = <-ch
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		c.Status(http.StatusNoContent)
		bytes, err := json.Marshal(*inputData)
		if err == nil {
			log.Printf("value updated: %s\n", bytes)
		}
	}
}

func (d *settingDelivery) HandleDeleteValue(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan error)
		go func() {
			ch <- d.Usecase.DeleteValue(cCp.Request.Context(), group, id)
		}()
		err = <-ch
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		c.Status(http.StatusNoContent)
		log.Printf(`value deleted: {"id":%d}\n`, id)
	}
}

func (d *settingDelivery) HandleGetSchemas(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		params, err := parseQueryParams(c)
		if err != nil {
			log.Println(err)
			return
		}

		ch := make(chan *schemasResult)
		ctx := c.Request.Context()

		go func() {
			schemasInfo, err := d.Usecase.FindSchemas(ctx, group, params)
			ch <- &schemasResult{schemasInfo, err}
		}()
		res := <-ch

		err = res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		schemasInfo := res.Info
		if schemasInfo.Schemas == nil {
			schemasInfo.Schemas = []*domain.SchemaEntry{}
		}
		if schemasInfo.SectionTags == nil {
			schemasInfo.SectionTags = []string{}
		}
		prev, next := d.getPrevNextURL(c.Request, params.PerPage, params.Page, schemasInfo.Total)
		c.PureJSON(http.StatusOK, &ResponseSchemaEntries{
			SchemasInfo: schemasInfo,
			Prev:        prev,
			Next:        next,
		})
	}
}

func (d *settingDelivery) HandleGetSchemaByID(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{err.Error()})
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan *schemaResult)
		go func() {
			schema, err := d.Usecase.FindSchemaByID(cCp.Request.Context(), group, id)
			ch <- &schemaResult{schema, err}
		}()
		res := <-ch

		err = res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		c.PureJSON(http.StatusOK, res.Schema)
	}
}

func (d *settingDelivery) HandlePostSchema(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		var inputData usecase.CreateSchemaInputData
		if err := c.Bind(&inputData); err != nil {
			log.Println(err)
			return
		}

		if group == domain.Config {
			if inputData.Section == "" {
				err := fmt.Errorf("section field is required for config schema")
				c.PureJSON(http.StatusBadRequest, ResponseError{Message: err.Error()})
				log.Println(err)
				return
			}
		} else {
			if inputData.Section != "" {
				err := fmt.Errorf("don't provide section field for %s schema", group)
				c.PureJSON(http.StatusBadRequest, ResponseError{Message: err.Error()})
				log.Println(err)
				return
			}
		}

		cCp := c.Copy()
		ch := make(chan *schemaResult)
		go func() {
			schema, err := d.Usecase.StoreSchema(cCp.Request.Context(), group, &inputData)
			ch <- &schemaResult{schema, err}
		}()
		res := <-ch

		err := res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}
		c.PureJSON(http.StatusCreated, res.Schema)
	}
}

func (d *settingDelivery) HandlePatchSchema(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{err.Error()})
			log.Println(err)
			return
		}

		inputData := &usecase.UpdateSchemaInputData{ID: id}
		if err := c.Bind(inputData); err != nil {
			log.Println(err)
			return
		}

		ch := make(chan error)
		cCp := c.Copy()
		go func() {
			ch <- d.Usecase.UpdateSchema(cCp.Request.Context(), group, inputData)
		}()
		err = <-ch
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		c.Status(http.StatusNoContent)
		bytes, err := json.Marshal(*inputData)
		if err == nil {
			log.Printf("schema updated: %s\n", bytes)
		}
	}
}

func (d *settingDelivery) HandleDeleteSchema(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{err.Error()})
			log.Println(err)
			return
		}

		ch := make(chan error)
		cCp := c.Copy()
		go func() {
			ch <- d.Usecase.DeleteSchema(cCp.Request.Context(), group, id)
		}()
		err = <-ch
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		c.Status(http.StatusNoContent)
		log.Printf(`schema deleted: {"id":%d}\n`, id)
	}
}

func (d *settingDelivery) HandleGetDefinitions(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		params, err := parseQueryParams(c)
		if err != nil {
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan *definitionsResult)
		go func() {
			definitionsInfo, err := d.Usecase.FindDefinitions(cCp.Request.Context(), group, params)
			ch <- &definitionsResult{definitionsInfo, err}
		}()
		res := <-ch

		err = res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{Message: err.Error()})
			log.Println(err)
			return
		}

		definitionsInfo := res.Info
		if definitionsInfo.Definitions == nil {
			definitionsInfo.Definitions = []*domain.DefinitionEntry{}
		}
		prev, next := d.getPrevNextURL(c.Request, params.PerPage, params.Page, definitionsInfo.Total)
		c.PureJSON(http.StatusOK, &ResponseDefinitionEntries{
			DefinitionsInfo: definitionsInfo,
			Prev:            prev,
			Next:            next,
		})
	}
}

func (d *settingDelivery) HandleGetDefinitionByID(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{err.Error()})
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan *definitionResult)
		go func() {
			definition, err := d.Usecase.FindDefinitionByID(cCp.Request.Context(), group, id)
			ch <- &definitionResult{definition, err}
		}()
		res := <-ch

		err = res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		c.PureJSON(http.StatusOK, res.Definition)
	}
}

func (d *settingDelivery) HandlePostDefinition(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		var inputData usecase.CreateDefinitionInputData
		if err := c.Bind(&inputData); err != nil {
			log.Println(err)
			return
		}

		cCp := c.Copy()
		ch := make(chan *definitionResult)
		go func() {
			def, err := d.Usecase.StoreDefinition(cCp.Request.Context(), group, &inputData)
			ch <- &definitionResult{def, err}
		}()
		res := <-ch

		err := res.Err
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		def := res.Definition
		c.PureJSON(http.StatusCreated, def)
		bytes, err := json.Marshal(inputData)
		if err == nil {
			log.Printf("definition posted: %s\n", bytes)
		}
	}
}

func (d *settingDelivery) HandlePatchDefinition(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{err.Error()})
			log.Println(err)
			return
		}

		inputData := &usecase.UpdateDefinitionInputData{ID: id}
		if err := c.Bind(inputData); err != nil {
			log.Println(err)
			return
		}

		ch := make(chan error)
		cCp := c.Copy()
		go func() {
			ch <- d.Usecase.UpdateDefinition(cCp.Request.Context(), group, inputData)
		}()
		err = <-ch
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		c.Status(http.StatusNoContent)
		bytes, err := json.Marshal(*inputData)
		if err == nil {
			log.Printf("definition updated: %s\n", bytes)
		}
	}
}

func (d *settingDelivery) HandleDeleteDefinition(group domain.Group) gin.HandlerFunc {
	return func(c *gin.Context) {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			c.PureJSON(http.StatusBadRequest, ResponseError{err.Error()})
			log.Println(err)
			return
		}

		ch := make(chan error)
		cCp := c.Copy()
		go func() {
			ch <- d.Usecase.DeleteDefinition(cCp.Request.Context(), group, id)
		}()
		err = <-ch
		if err != nil {
			c.PureJSON(getStatusCode(err), ResponseError{err.Error()})
			log.Println(err)
			return
		}

		c.Status(http.StatusNoContent)
		log.Printf(`definition deleted: {"id":%d}\n`, id)
	}
}

func (d *settingDelivery) getPrevNextURL(request *http.Request, perPage, page, total int) (prev, next *string) {
	// https://jira.ppi.co.jp/browse/POTOO-1401
	scheme := "http"
	if val, ok := request.Header["X-Forwarded-Proto"]; ok {
		scheme = val[0]
	}
	srcURL := request.URL
	host := request.Host
	if page-1 > 0 {
		prev = d.getPaginationURL(scheme, srcURL, host, page-1)
	}
	if perPage*(page+1) < total+perPage-1 {
		next = d.getPaginationURL(scheme, srcURL, host, page+1)
	}
	return
}

func (d *settingDelivery) getPaginationURL(scheme string, srcURL *url.URL, host string, page int) *string {
	u, _ := url.Parse(srcURL.String())
	u.Scheme = scheme
	u.Host = host
	q := u.Query()
	q.Set("page", strconv.Itoa(page))
	u.RawQuery = q.Encode()
	s := u.String()
	return &s
}

func parseQueryParams(c *gin.Context) (*usecase.QueryParams, error) {
	var params usecase.QueryParams
	err := c.BindQuery(&params)
	if err != nil {
		return nil, err
	}
	if params.PerPage < 1 {
		params.PerPage = 500
	}
	if params.Page < 1 {
		params.Page = 1
	}
	return &params, nil
}

func getStatusCode(err error) int {
	if err == nil {
		return http.StatusOK
	}
	log.Println(err)
	switch err {
	case domain.ErrInternalServerError:
		return http.StatusInternalServerError
	case domain.ErrNotFound:
		return http.StatusNotFound
	case domain.ErrConflict:
		return http.StatusConflict
	case domain.ErrBadParamInput:
		return http.StatusBadRequest
	default:
		return http.StatusInternalServerError
	}
}
