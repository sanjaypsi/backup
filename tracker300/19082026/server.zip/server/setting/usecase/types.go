package usecase

import (
	"context"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
)

// QueryParams represent query paramters
type QueryParams struct {
	Section   string `form:"section"`
	Entry     string `form:"entry"`
	SearchKey string `form:"search_key"`
	Key       string `form:"key"`
	PerPage   int    `form:"per_page"`
	Page      int    `form:"page"`
}

// CreateValueInputData represents input data for creating value
type CreateValueInputData struct {
	Key     string      `json:"key" binding:"required"`
	Value   interface{} `json:"value" binding:"required"`
	Section string      `json:"section" binding:"required"`
	Entry   string      `json:"entry" binding:"required"`
}

// CreateSchemaInputData represents input data for creating schema
type CreateSchemaInputData struct {
	Key      string      `json:"key" binding:"required"`
	Schema   interface{} `json:"schema" binding:"required"`
	Required bool        `json:"required"`
	Section  string      `json:"section"`
}

// CreateDefinitionInputData represents input data for creating definition
type CreateDefinitionInputData struct {
	Key        string      `json:"key" binding:"required"`
	Definition interface{} `json:"definition" binding:"required"`
}

// UpdateValueInputData represents input data for changing value
type UpdateValueInputData struct {
	ID      int         `json:"id" binding:"required"`
	Value   interface{} `json:"value,omitempty"`
	Section *string     `json:"section,omitempty"`
	Entry   *string     `json:"entry,omitempty"`
}

// UpdateSchemaInputData represents input data for changing value
type UpdateSchemaInputData struct {
	ID       int         `json:"id" binding:"required"`
	Schema   interface{} `json:"schema,omitempty"`
	Required *bool       `json:"required,omitempty"`
	Section  *string     `json:"section,omitempty"`
}

// UpdateDefinitionInputData represents input data for changing definition
type UpdateDefinitionInputData struct {
	ID         int         `json:"id" binding:"required"`
	Definition interface{} `json:"definition,omitempty"`
}

// ValuesInfo represent setting values with meta info
type ValuesInfo struct {
	Values    []*domain.ValueEntry `json:"values"`
	EntryTags []string            `json:"entry_tags"`
	Total     int                 `json:"total"`
}

// SchemasInfo represent setting schemas with meta info
type SchemasInfo struct {
	Schemas     []*domain.SchemaEntry `json:"schemas"`
	SectionTags []string             `json:"section_tags"`
	Total       int                  `json:"total"`
}

// DefinitionsInfo represent setting definition with meta info
type DefinitionsInfo struct {
	Definitions []*domain.DefinitionEntry `json:"definitions"`
	Total       int                      `json:"total"`
}

// Repository represent the setting's repository contract
type Repository interface {
	FindValues(ctx context.Context, group domain.Group, params *QueryParams) (*ValuesInfo, error)
	FindValueByID(ctx context.Context, group domain.Group, id int) (*domain.ValueEntry, error)
	FindValuesByKey(ctx context.Context, group domain.Group, key string, section string) ([]*domain.ValueEntry, error) // -> FindValues()
	FindValueByKey(ctx context.Context, group domain.Group, key string, section string) (*domain.ValueEntry, error)
	StoreValue(ctx context.Context, group domain.Group, inputData *CreateValueInputData) (*domain.ValueEntry, error)
	UpdateValue(ctx context.Context, group domain.Group, inputData *UpdateValueInputData) error
	DeleteValue(ctx context.Context, group domain.Group, id int) error

	FindSchemas(ctx context.Context, group domain.Group, params *QueryParams) (*SchemasInfo, error)
	FindSchemaByID(ctx context.Context, group domain.Group, id int) (*domain.SchemaEntry, error)
	FindSchemaByKey(ctx context.Context, group domain.Group, key string, section string) (*domain.SchemaEntry, error)
	StoreSchema(ctx context.Context, group domain.Group, inputData *CreateSchemaInputData) (*domain.SchemaEntry, error)
	UpdateSchema(ctx context.Context, group domain.Group, inputData *UpdateSchemaInputData) error
	DeleteSchema(ctx context.Context, group domain.Group, id int) error

	FindDefinitions(ctx context.Context, group domain.Group, params *QueryParams) (*DefinitionsInfo, error)
	FindDefinitionByID(ctx context.Context, group domain.Group, id int) (*domain.DefinitionEntry, error)
	FindDefinitionByKey(ctx context.Context, group domain.Group, key string) (*domain.DefinitionEntry, error)
	StoreDefinition(ctx context.Context, group domain.Group, inputData *CreateDefinitionInputData) (*domain.DefinitionEntry, error)
	UpdateDefinition(ctx context.Context, group domain.Group, inputData *UpdateDefinitionInputData) error
	DeleteDefinition(ctx context.Context, group domain.Group, id int) error
}

// Usecase represent the setting's usecase contract
type Usecase interface {
	FindValues(ctx context.Context, group domain.Group, params *QueryParams) (*ValuesInfo, error)
	FindValueByID(ctx context.Context, group domain.Group, id int) (*domain.ValueEntry, error)
	StoreValue(ctx context.Context, group domain.Group, inputData *CreateValueInputData) (*domain.ValueEntry, error)
	UpdateValue(ctx context.Context, group domain.Group, inputData *UpdateValueInputData) error
	DeleteValue(ctx context.Context, group domain.Group, id int) error

	FindSchemas(ctx context.Context, group domain.Group, params *QueryParams) (*SchemasInfo, error)
	FindSchemaByID(ctx context.Context, group domain.Group, id int) (*domain.SchemaEntry, error)
	StoreSchema(ctx context.Context, group domain.Group, inputData *CreateSchemaInputData) (*domain.SchemaEntry, error)
	UpdateSchema(ctx context.Context, group domain.Group, inputData *UpdateSchemaInputData) error
	DeleteSchema(ctx context.Context, group domain.Group, id int) error

	FindDefinitions(ctx context.Context, group domain.Group, params *QueryParams) (*DefinitionsInfo, error)
	FindDefinitionByID(ctx context.Context, group domain.Group, id int) (*domain.DefinitionEntry, error)
	StoreDefinition(ctx context.Context, group domain.Group, inputData *CreateDefinitionInputData) (*domain.DefinitionEntry, error)
	UpdateDefinition(ctx context.Context, group domain.Group, inputData *UpdateDefinitionInputData) error
	DeleteDefinition(ctx context.Context, group domain.Group, id int) error
}
