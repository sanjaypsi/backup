package usecase

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
	"github.com/xeipuuv/gojsonschema"
)

type settingUsecase struct {
	repository   Repository
	readTimeout  time.Duration
	writeTimeout time.Duration
}

// NewSettingUsecase will create a new settinUsecase object
func NewSettingUsecase(
	s Repository,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) Usecase {
	return &settingUsecase{
		repository:   s,
		readTimeout:  readTimeout,
		writeTimeout: writeTimeout,
	}
}

func (u *settingUsecase) FindValues(c context.Context, group domain.Group, params *QueryParams) (*ValuesInfo, error) {
	ctx, cancel := context.WithTimeout(c, u.readTimeout)
	defer cancel()
	return u.repository.FindValues(ctx, group, params)
}

func (u *settingUsecase) FindValueByID(c context.Context, group domain.Group, id int) (*domain.ValueEntry, error) {
	ctx, cancel := context.WithTimeout(c, u.readTimeout)
	defer cancel()
	return u.repository.FindValueByID(ctx, group, id)
}

func (u *settingUsecase) StoreValue(c context.Context, group domain.Group, inputData *CreateValueInputData) (*domain.ValueEntry, error) {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()

	value, _ := u.repository.FindValueByKey(ctx, group, inputData.Key, inputData.Section)
	if value != nil {
		return nil, domain.ErrConflict
	}
	schema, err := u.repository.FindSchemaByKey(ctx, group, inputData.Key, inputData.Section)
	if err != nil {
		return nil, fmt.Errorf("schema not found for key: %s, section: %s", inputData.Key, inputData.Section)
	}

	resolvedSchema, err := u.resolveSchema(ctx, group, schema.Schema)
	if err != nil {
		return nil, err
	}
	err = validateValue(resolvedSchema, inputData.Value)
	if err != nil {
		log.Println("validation failed")
		return nil, err
	}

	return u.repository.StoreValue(ctx, group, inputData)
}

func (u *settingUsecase) UpdateValue(c context.Context, group domain.Group, inputData *UpdateValueInputData) error {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()

	value, err := u.repository.FindValueByID(ctx, group, inputData.ID)
	if err != nil {
		return fmt.Errorf("value not found for id: %d", inputData.ID)
	}

	var section string
	if inputData.Section != nil {
		section = *inputData.Section
	} else {
		section = value.Section
	}
	schema, err := u.repository.FindSchemaByKey(ctx, group, value.Key, section)
	if err != nil {
		return fmt.Errorf("schema not found for key: %s, section: %s", value.Key, section)
	}

	if inputData.Value != nil {
		resolvedSchema, err := u.resolveSchema(ctx, group, schema.Schema)
		if err != nil {
			return err
		}
		err = validateValue(resolvedSchema, inputData.Value)
		if err != nil {
			return err
		}
	}

	return u.repository.UpdateValue(ctx, group, inputData)
}

func (u *settingUsecase) DeleteValue(c context.Context, group domain.Group, id int) (err error) {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()
	_, err = u.repository.FindValueByID(ctx, group, id)
	if err != nil {
		return
	}
	return u.repository.DeleteValue(ctx, group, id)
}

func (u *settingUsecase) FindSchemas(c context.Context, group domain.Group, params *QueryParams) (*SchemasInfo, error) {
	ctx, cancel := context.WithTimeout(c, u.readTimeout)
	defer cancel()
	return u.repository.FindSchemas(ctx, group, params)
}

func (u *settingUsecase) FindSchemaByID(c context.Context, group domain.Group, id int) (*domain.SchemaEntry, error) {
	ctx, cancel := context.WithTimeout(c, u.readTimeout)
	defer cancel()
	return u.repository.FindSchemaByID(ctx, group, id)
}

func (u *settingUsecase) StoreSchema(c context.Context, group domain.Group, inputData *CreateSchemaInputData) (*domain.SchemaEntry, error) {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()

	resolvedSchema, err := u.resolveSchema(ctx, group, inputData.Schema)
	if err != nil {
		return nil, err
	}
	err = validateSchema(resolvedSchema)
	if err != nil {
		return nil, err
	}

	_, err = u.repository.FindSchemaByKey(ctx, group, inputData.Key, inputData.Section)
	if err == nil {
		return nil, domain.ErrConflict
	}

	return u.repository.StoreSchema(ctx, group, inputData)
}

func (u *settingUsecase) UpdateSchema(c context.Context, group domain.Group, inputData *UpdateSchemaInputData) error {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()

	if inputData.Schema != nil {
		resolvedSchema, err := u.resolveSchema(ctx, group, inputData.Schema)
		if err != nil {
			return err
		}
		err = validateSchema(resolvedSchema)
		if err != nil {
			return err
		}
	}

	return u.repository.UpdateSchema(ctx, group, inputData)
}

func (u *settingUsecase) DeleteSchema(c context.Context, group domain.Group, id int) error {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()
	_, err := u.repository.FindSchemaByID(ctx, group, id)
	if err != nil {
		return err
	}
	return u.repository.DeleteSchema(ctx, group, id)
}

func (u *settingUsecase) FindDefinitions(c context.Context, group domain.Group, params *QueryParams) (*DefinitionsInfo, error) {
	ctx, cancel := context.WithTimeout(c, u.readTimeout)
	defer cancel()
	return u.repository.FindDefinitions(ctx, group, params)
}

func (u *settingUsecase) FindDefinitionByID(c context.Context, group domain.Group, id int) (*domain.DefinitionEntry, error) {
	ctx, cancel := context.WithTimeout(c, u.readTimeout)
	defer cancel()
	return u.repository.FindDefinitionByID(ctx, group, id)
}

func (u *settingUsecase) StoreDefinition(c context.Context, group domain.Group, inputData *CreateDefinitionInputData) (*domain.DefinitionEntry, error) {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()

	err := validateSchema(inputData.Definition)
	if err != nil {
		return nil, err
	}

	_, err = u.repository.FindDefinitionByKey(ctx, group, inputData.Key)
	if err == nil {
		return nil, domain.ErrConflict
	}

	return u.repository.StoreDefinition(ctx, group, inputData)
}

func (u *settingUsecase) UpdateDefinition(c context.Context, group domain.Group, inputData *UpdateDefinitionInputData) error {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()

	_, err := u.repository.FindDefinitionByID(ctx, group, inputData.ID)
	if err != nil {
		return fmt.Errorf("definition not found for id: %d", inputData.ID)
	}

	err = validateSchema(inputData.Definition)
	if err != nil {
		return err
	}

	return u.repository.UpdateDefinition(ctx, group, inputData)
}

func (u *settingUsecase) DeleteDefinition(c context.Context, group domain.Group, id int) error {
	ctx, cancel := context.WithTimeout(c, u.writeTimeout)
	defer cancel()
	_, err := u.repository.FindDefinitionByID(ctx, group, id)
	if err != nil {
		return err
	}
	return u.repository.DeleteDefinition(ctx, group, id)
}

func (u *settingUsecase) resolveSchema(ctx context.Context, group domain.Group, schema interface{}) (interface{}, error) {
	retSchema, err := deepcopySchema(schema)
	if err != nil {
		return nil, err
	}
	schemaMap, ok := retSchema.(map[string]interface{})
	if ok {
		ref, ok := schemaMap["$ref"]
		if ok {
			val, ok := ref.(string)
			if ok {
				if strings.HasPrefix(val, "#/definitions/") {
					name := strings.TrimPrefix(val, "#/definitions/")
					definitionsInfo, err := u.FindDefinitions(ctx, group, &QueryParams{
						SearchKey: name,
						PerPage:   0,
						Page:      1,
					})
					if err != nil {
						return nil, err
					}
					schemaDefs, ok := schemaMap["definitions"]
					if !ok {
						schemaMap["definitions"] = map[string]interface{}{}
						schemaDefs = schemaMap["definitions"]
					}
					defs, ok := schemaDefs.(map[string]interface{})
					if ok {
						for _, definition := range definitionsInfo.Definitions {
							key := definition.Key
							defs[key] = definition.Definition
						}
					}
				}
			}
		}
	}
	return retSchema, nil
}

func deepcopySchema(schema interface{}) (interface{}, error) {
	bytes, err := json.Marshal(schema)
	if err != nil {
		return nil, err
	}
	var retSchema interface{}
	err = json.Unmarshal(bytes, &retSchema)
	if err != nil {
		return nil, err
	}
	return retSchema, nil
}

func validateSchema(schema interface{}) error {
	loader := gojsonschema.NewGoLoader(schema)
	_, err := gojsonschema.NewSchema(loader)
	return err
}

func validateValue(schema interface{}, value interface{}) error {
	schemaLoader := gojsonschema.NewGoLoader(schema)
	valueLoader := gojsonschema.NewGoLoader(value)
	result, err := gojsonschema.Validate(schemaLoader, valueLoader)
	if err != nil {
		return err
	}
	if !result.Valid() {
		return fmt.Errorf("%v", result.Errors())
	}
	return nil
}
