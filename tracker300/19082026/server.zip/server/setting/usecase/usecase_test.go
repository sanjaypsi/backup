package usecase_test

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/url"
	"testing"
	"time"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
	repository "github.com/PolygonPictures/central30-web/front/setting/repository/mysql"
	"github.com/PolygonPictures/central30-web/front/setting/usecase"
	_ "github.com/go-sql-driver/mysql"
)

var dsn string

func init() {
	dbUser := "user"
	dbPass := "password"
	dbHost := "127.17.0.2"
	dbPort := "3306"
	dbName := "central30"
	connection := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s", dbUser, dbPass, dbHost, dbPort, dbName)
	val := url.Values{}
	val.Add("charset", "utf8")
	val.Add("parseTime", "1")
	dsn = fmt.Sprintf("%s?%s", connection, val.Encode())
}

func addConfigSchema(ctx context.Context, uc usecase.Usecase, inputData *usecase.CreateSchemaInputData) (*domain.SchemaEntry, error) {
	schemaEntry, err := uc.StoreSchema(ctx, domain.Config, inputData)
	if err != nil {
		return nil, err
	}
	bytes, _ := json.Marshal(schemaEntry)
	fmt.Printf("schema created: %s\n", bytes)
	return schemaEntry, nil
}

func findConfigSchemas(ctx context.Context, uc usecase.Usecase, params *usecase.QueryParams, sectionTag string) error {
	schemasInfo, err := uc.FindSchemas(ctx, domain.Config, params)
	if err != nil {
		return err
	}
	for i, schema := range schemasInfo.Schemas {
		bytes, _ := json.Marshal(schema)
		fmt.Printf("schema found at %d: %s\n", i, bytes)
	}
	if !contains(schemasInfo.SectionTags, sectionTag) {
		return fmt.Errorf(`section '"%s"' not found`, sectionTag)
	}
	if schemasInfo.Total == 0 {
		return fmt.Errorf("no entry found")
	}
	return nil
}

func findConfigSchemaByID(ctx context.Context, uc usecase.Usecase, id int) error {
	_, err := uc.FindSchemaByID(ctx, domain.Config, id)
	if err != nil {
		return err
	}
	fmt.Printf("schema found by id: %d\n", id)
	return nil
}

func updateConfigSchema(ctx context.Context, uc usecase.Usecase, inputData *usecase.UpdateSchemaInputData) error {
	err := uc.UpdateSchema(ctx, domain.Config, inputData)
	if err != nil {
		return err
	}
	fmt.Printf("schema updated\n")
	return nil
}

func deleteConfigSchema(ctx context.Context, uc usecase.Usecase, id int) error {
	err := uc.DeleteSchema(ctx, domain.Config, id)
	if err != nil {
		return err
	}
	fmt.Printf("schema deleted: %d\n", id)
	return nil
}

func addConfigValue(ctx context.Context, uc usecase.Usecase, inputData *usecase.CreateValueInputData) (*domain.ValueEntry, error) {
	valueEntry, err := uc.StoreValue(ctx, domain.Config, inputData)
	if err != nil {
		return nil, err
	}
	bytes, _ := json.Marshal(valueEntry)
	fmt.Printf("value created: %s\n", bytes)
	return valueEntry, nil
}

func findConfigValues(ctx context.Context, uc usecase.Usecase, params *usecase.QueryParams, entryTag string) error {
	valuesInfo, err := uc.FindValues(ctx, domain.Config, params)
	if err != nil {
		return err
	}
	for i, value := range valuesInfo.Values {
		bytes, _ := json.Marshal(value)
		fmt.Printf("value found at %d: %s\n", i, bytes)
	}
	if !contains(valuesInfo.EntryTags, entryTag) {
		return fmt.Errorf(`entry tag "%s" not found`, entryTag)
	}
	if valuesInfo.Total == 0 {
		return fmt.Errorf("no entry found")
	}
	return nil
}

func findConfigValueByID(ctx context.Context, uc usecase.Usecase, id int) error {
	_, err := uc.FindValueByID(ctx, domain.Config, id)
	if err != nil {
		return err
	}
	fmt.Printf("value found by id: %d\n", id)
	return nil
}

func updateConfigValue(ctx context.Context, uc usecase.Usecase, inputData *usecase.UpdateValueInputData) error {
	err := uc.UpdateValue(ctx, domain.Config, inputData)
	if err != nil {
		return err
	}
	fmt.Printf("value updated\n")
	return nil
}

func deleteConfigValue(ctx context.Context, uc usecase.Usecase, id int) error {
	err := uc.DeleteValue(ctx, domain.Config, id)
	if err != nil {
		return err
	}
	fmt.Printf("value deleted: %d\n", id)
	return nil
}

func TestConfig(t *testing.T) {
	key := "test6"
	searchKey := "test6"
	section := "studio"
	entry := "ppidev"
	schema := map[string]string{"type": "string"}
	value := "value"
	sectionTag := "studio"

	db, err := sql.Open("mysql", dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	repo := repository.NewRepository(db)
	uc := usecase.NewSettingUsecase(repo, 20*time.Second, 40*time.Second)
	ctx := context.Background()

	schemaEntry, err := addConfigSchema(ctx, uc, &usecase.CreateSchemaInputData{
		Key:     key,
		Section: section,
		Schema:  schema,
	})
	if err != nil {
		t.Fatal(err)
	}

	err = findConfigSchemas(ctx, uc, &usecase.QueryParams{
		Section:   section,
		SearchKey: searchKey,
		PerPage:   100,
		Page:      1,
	}, sectionTag)
	if err != nil {
		t.Fatal(err)
	}

	err = findConfigSchemaByID(ctx, uc, schemaEntry.ID)
	if err != nil {
		t.Fatal(err)
	}

	valueEntry, err := addConfigValue(ctx, uc, &usecase.CreateValueInputData{
		Section: section,
		Entry:   entry,
		Key:     key,
		Value:   value,
	})
	if err != nil {
		t.Fatal(err)
	}

	err = findConfigValueByID(ctx, uc, valueEntry.ID)
	if err != nil {
		t.Fatal(err)
	}

	s := "project"
	r := true
	e := "potoodev"
	entryTag := fmt.Sprintf("%s/%s", s, e)

	err = updateConfigSchema(ctx, uc, &usecase.UpdateSchemaInputData{
		Section:  &s,
		Required: &r,
		Schema:   map[string]string{"type": "integer"},
		ID:       schemaEntry.ID,
	})
	if err != nil {
		t.Fatal(err)
	}

	err = updateConfigValue(ctx, uc, &usecase.UpdateValueInputData{
		Section: &s,
		Entry:   &e,
		Value:   123,
		ID:      valueEntry.ID,
	})
	if err != nil {
		t.Fatal(err)
	}

	params := &usecase.QueryParams{
		Section:   s,
		Entry:     e,
		SearchKey: searchKey,
		PerPage:   100,
		Page:      1,
	}
	err = findConfigValues(ctx, uc, params, entryTag)
	if err != nil {
		t.Fatal(err)
	}

	err = deleteConfigValue(ctx, uc, valueEntry.ID)
	if err != nil {
		t.Fatal(err)
	}

	err = deleteConfigSchema(ctx, uc, schemaEntry.ID)
	if err != nil {
		t.Fatal(err)
	}
}

func contains(s []string, e string) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}
