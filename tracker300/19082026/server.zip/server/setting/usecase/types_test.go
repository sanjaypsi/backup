package usecase

import (
	"encoding/json"
	"testing"
)

func TestUpdateSchemaInputDataEmpty(t *testing.T) {
	var inputData UpdateSchemaInputData
	err := json.Unmarshal([]byte(`{
		"id": 1
	}`), &inputData)
	if err != nil {
		t.Fatal(err)
	}
	if inputData.Schema != nil {
		t.Fatal(inputData.Schema)
	}
	if inputData.Required != nil {
		t.Fatal(inputData.Required)
	}
	if inputData.Section != nil {
		t.Fatal(inputData.Section)
	}
}

func TestUpdateSchemaInputData(t *testing.T) {
	var inputData UpdateSchemaInputData
	err := json.Unmarshal([]byte(`{
		"id": 1,
		"schema": {
			"type": "string"
		},
		"required": false,
		"section": "common"
	}`), &inputData)
	if err != nil {
		t.Fatal(err)
	}
	if inputData.Schema == nil {
		t.Fatal(inputData.Schema)
	}
	if inputData.Required == nil {
		t.Fatal(inputData.Required)
	}
	if inputData.Section == nil {
		t.Fatal(inputData.Section)
	}
	if *inputData.Required != false {
		t.Fatal(*inputData.Required)
	}
	if *inputData.Section != "common" {
		t.Fatal(*inputData.Section)
	}
}
