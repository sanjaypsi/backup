package setting

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

// groupsResponse is a response object of the pipeline setting groups
type groupsResponse struct {
	Groups []string `json:"groups"`
}

// typesResponse is a response object for the pipeline setting types
type typesResponse struct {
	Types []string `json:"types"`
}

// sectionsResponse is a response object for the pipeline setting sections
type sectionsResponse struct {
	Sections []string `json:"sections"`
}

type entriesResponse struct {
	Entries []string `json:"entries"`
}

type stringsResult struct {
	Result []string
	Err    error
}

type errorResponse struct {
	Message string `json:"message"`
}

// fetchGroups returns a list of pipeline setting groups
func fetchGroups() ([]string, error) {
	groups := []string{
		"config",
		"environment",
		"preference",
	}
	return groups, nil
}

// fetchTypes return a list of pipeline setting types
func fetchTypes() ([]string, error) {
	types := []string{
		"definition",
		"schema",
		"value",
	}
	return types, nil
}

// fetchSections returns a list of pipeline setting sections
func fetchSections() ([]string, error) {
	sections := []string{
		"common",
		"project",
		"studio",
	}
	return sections, nil
}

func fetchEntries(section string) ([]string, error) {
	entries := []string{
		"common/default",
		"project/potoodev",
		"studio/ppidev",
	}
	if section == "" {
		return entries, nil
	}
	filtered := []string{}
	for _, entry := range entries {
		parts := strings.Split(entry, "/")
		if parts[0] == section {
			filtered = append(filtered, entry)
		}
	}
	return filtered, nil
}

// GetGroups responses groups of the pipeline settings
func GetGroups(c *gin.Context) {
	ch := make(chan stringsResult)

	go func() {
		groups, err := fetchGroups()
		ch <- stringsResult{groups, err}
	}()
	res := <-ch

	err := res.Err
	if err != nil {
		c.PureJSON(http.StatusServiceUnavailable, errorResponse{err.Error()})
		log.Println(err)
		return
	}
	groups := res.Result
	c.PureJSON(http.StatusOK, &groupsResponse{groups})
}

// GetTypes return a list of pipeline setting types
func GetTypes(c *gin.Context) {
	ch := make(chan stringsResult)

	go func() {
		types, err := fetchTypes()
		ch <- stringsResult{types, err}
	}()
	res := <-ch

	err := res.Err
	if err != nil {
		c.PureJSON(http.StatusServiceUnavailable, errorResponse{err.Error()})
		log.Println(err)
		return
	}
	types := res.Result
	c.PureJSON(http.StatusOK, &typesResponse{types})
}

// GetSections returns a list of pipeline setting sections
func GetSections(c *gin.Context) {
	ch := make(chan stringsResult)

	go func() {
		sections, err := fetchSections()
		ch <- stringsResult{sections, err}
	}()
	res := <-ch

	err := res.Err
	if err != nil {
		c.PureJSON(http.StatusServiceUnavailable, errorResponse{err.Error()})
		log.Println(err)
		return
	}
	sections := res.Result
	c.PureJSON(http.StatusOK, &sectionsResponse{sections})
}

// GetEntries returns a list of pipeline setting entries
func GetEntries(c *gin.Context) {
	ch := make(chan stringsResult)
	section := c.Query("section")

	go func() {
		entries, err := fetchEntries(section)
		ch <- stringsResult{entries, err}
	}()
	res := <-ch

	err := res.Err
	if err != nil {
		c.PureJSON(http.StatusServiceUnavailable, errorResponse{err.Error()})
		log.Println(err)
		return
	}
	entries := res.Result
	c.PureJSON(http.StatusOK, &entriesResponse{entries})
}
