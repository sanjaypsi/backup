package legacy

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
	"github.com/PolygonPictures/central30-web/front/setting/usecase"
)

type scanner func(rows *sql.Rows)

// ValueRecord is a mysql record for the legacy value
type ValueRecord struct {
	SectionType   string
	SectionName   string
	Key           string
	Value         string
	CreatedAtUTC  *time.Time
	ModifiedAtUTC *time.Time
	Deleted       int
	ModifiedBy    *string
	CreatedBy     *string
	ID            int
}

// PropertylistRecord is a mysql record for the legacy propertylist
type PropertylistRecord struct {
	KeyType       string
	Key           string
	Property      string
	Data          string
	CreatedAtUTC  *time.Time
	ModifiedAtUTC *time.Time
	Deleted       int
	ModifiedBy    *string
	CreatedBy     *string
	ID            int
}

type legacyRepository struct {
	DB *sql.DB
}

// NewRepository will create an object that represent the setting.Repository interface
func NewRepository(DB *sql.DB) usecase.Repository {
	return &legacyRepository{DB}
}

func (r *legacyRepository) doQuery(ctx context.Context, query string, scanner scanner, args ...interface{}) error {
	rows, err := r.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	scanner(rows)
	return rows.Err()
}

func (r *legacyRepository) fetchLegacyValues(ctx context.Context, query string, args ...interface{}) ([]*ValueRecord, error) {
	var records []*ValueRecord
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		records = scanLegacyValues(rows)
	}, args...)
	return records, err
}

func (r *legacyRepository) fetchLegacyProperties(ctx context.Context, query string, args ...interface{}) ([]*PropertylistRecord, error) {
	var records []*PropertylistRecord
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		records = scanLegacyProperties(rows)
	}, args...)
	return records, err
}

func (r *legacyRepository) fetchValues(ctx context.Context, group domain.Group, query string, args ...interface{}) ([]*domain.ValueEntry, error) {
	records, err := r.fetchLegacyValues(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	var values []*domain.ValueEntry
	if group == domain.Environment {
		values, err = convertEnvironmentValues(group, records)
	} else {
		values, err = convertConfPrefValues(group, records)
	}
	return values, err
}

func (r *legacyRepository) fetchSchemas(ctx context.Context, group domain.Group, query string, args ...interface{}) ([]*domain.SchemaEntry, error) {
	records, err := r.fetchLegacyProperties(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	var schemas []*domain.SchemaEntry
	if group == domain.Environment {
		schemas = convertEnvironmentSchemas(group, records)
	} else {
		schemas = convertConfPrefSchemas(group, records)
	}
	return schemas, nil
}

func (r *legacyRepository) getTotalCount(ctx context.Context, query string, args ...interface{}) (int, error) {
	var totals []int
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			var total int
			err := rows.Scan(&total)
			if err != nil {
				continue
			}
			totals = append(totals, total)
		}
	}, args...)
	if err != nil {
		return 0, err
	}

	if len(totals) != 1 {
		return 0, fmt.Errorf("total count returns multiple values: %v", totals)
	}

	total := totals[0]
	return total, nil
}

func (r *legacyRepository) getSectionTags(ctx context.Context, query string, args ...interface{}) ([]string, error) {
	var sectionTags []string
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			var keyType string
			err := rows.Scan(&keyType)
			if err != nil {
				continue
			}
			section := strings.TrimSuffix(keyType, "configKey")
			sectionTags = append(sectionTags, section)
		}
	}, args...)
	return sectionTags, err
}

func (r *legacyRepository) getEntryTags(ctx context.Context, query string, args ...interface{}) ([]string, error) {
	var entryTags []string
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			var section string
			var entry string
			err := rows.Scan(&section, &entry)
			if err != nil {
				continue
			}
			entryTag := fmt.Sprintf("%s/%s", section, entry)
			entryTags = append(entryTags, entryTag)
		}
	}, args...)
	return entryTags, err
}

func (r *legacyRepository) convertValueTypes(ctx context.Context, values []*domain.ValueEntry, group domain.Group, params *usecase.QueryParams) error {
	schemaParams := &usecase.QueryParams{
		Section:   params.Section,
		SearchKey: params.SearchKey,
		PerPage:   0, // get all schemas
		Page:      1,
	}
	schemasInfo, err := r.FindSchemas(ctx, group, schemaParams)
	if err != nil {
		return err
	}
	for i, value := range values {
		valueType, err := findValueType(schemasInfo.Schemas, value.Section, value.Key)
		if err != nil {
			log.Println(err)
			continue
		}
		converted, err := convertValue(value.Value, valueType)
		if err != nil {
			log.Println(err)
			continue
		}
		value.Value = converted
		values[i] = value
	}
	return nil
}

func (r *legacyRepository) FindValues(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.ValuesInfo, error) {
	tableName, err := getTableName(group)
	if err != nil {
		return nil, err
	}

	filter := fmt.Sprintf("FROM %s WHERE deleted = 0", tableName)
	var args []interface{}
	valuesInfo := &usecase.ValuesInfo{}

	entryTags, err := r.getEntryTags(ctx, "SELECT DISTINCT section_type, section_name "+filter, args...)
	if err != nil {
		return nil, err
	}
	valuesInfo.EntryTags = entryTags

	if params.Section != "" {
		filter += " AND section_type = ?"
		args = append(args, params.Section)
	}
	if params.Entry != "" {
		filter += " AND section_name = ?"
		args = append(args, params.Entry)
	}
	if params.SearchKey != "" {
		filter += " AND `key` LIKE CONCAT('%', ?, '%')"
		args = append(args, params.SearchKey)
	}

	var values []*domain.ValueEntry
	if group == domain.Config || group == domain.Preference {
		valuesInfo.Total, err = r.getTotalCount(ctx, "SELECT COUNT(*) "+filter, args...)
		if err != nil {
			return nil, err
		}
		if valuesInfo.Total == 0 {
			return valuesInfo, err
		}

		filter += " ORDER BY `key`"
		if params.PerPage != 0 { // params.PerPage=0 で全件取得（内部利用専用）
			filter += " LIMIT ?, ?"
			offset := params.PerPage * (params.Page - 1)
			args = append(args, offset, params.PerPage)
		}
		values, err = r.fetchValues(ctx, group, "SELECT * "+filter, args...)
		if err != nil {
			return nil, err
		}
		r.convertValueTypes(ctx, values, group, params)

	} else {
		filter += " ORDER BY `key`"
		values, err = r.fetchValues(ctx, group, "SELECT * "+filter, args...)
		if err != nil {
			return nil, err
		}

		valuesInfo.Total = len(values)
		if params.PerPage != 0 { // params.PerPage=0 で全件取得（内部利用専用）
			start, end := getStartEnd(valuesInfo.Total, params.PerPage, params.Page)
			values = values[start:end]
		}
	}
	valuesInfo.Values = values

	return valuesInfo, nil
}

func (r *legacyRepository) FindValueByID(ctx context.Context, group domain.Group, id int) (*domain.ValueEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) FindValuesByKey(ctx context.Context, group domain.Group, key string, section string) ([]*domain.ValueEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) FindValueByKey(ctx context.Context, group domain.Group, key string, section string) (*domain.ValueEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) StoreValue(ctx context.Context, group domain.Group, inputData *usecase.CreateValueInputData) (*domain.ValueEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) UpdateValue(ctx context.Context, group domain.Group, inputData *usecase.UpdateValueInputData) (err error) {
	return errors.New("no implementation")
}

func (r *legacyRepository) DeleteValue(ctx context.Context, group domain.Group, id int) (err error) {
	return errors.New("no implementation")
}

func (r *legacyRepository) FindSchemas(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.SchemasInfo, error) {
	tableName := "t_propertylist_entry"
	filter := fmt.Sprintf("FROM %s WHERE deleted = 0", tableName)
	var args []interface{}
	var sectionTags []string
	var err error

	switch group {
	case domain.Config:
		filter += " AND key_type LIKE '%configKey'"
		sectionTags, err = r.getSectionTags(ctx, "SELECT DISTINCT key_type "+filter, args...)
		if err != nil {
			return nil, err
		}
		if params.Section != "" {
			filter += " AND key_type = ?"
			args = append(args, params.Section+"configKey")
		}
	case domain.Environment:
		filter += " AND key_type = ? AND `key` LIKE '%:value'"
		args = append(args, "environmentKey")
		sectionTags = append(sectionTags, "")
	case domain.Preference:
		filter += " AND key_type = ?"
		args = append(args, "preferenceKey")
		sectionTags = append(sectionTags, "")
	default:
		err = fmt.Errorf("unknown setting group")
	}

	if params.SearchKey != "" {
		filter += " AND `key` LIKE CONCAT('%', ?, '%')"
		args = append(args, params.SearchKey)
	}

	filter += " ORDER BY `key`"
	schemas, err := r.fetchSchemas(ctx, group, "SELECT * "+filter, args...)

	total := len(schemas)
	if params.PerPage != 0 { // params.PerPage=0 で全件取得（内部利用専用）
		start, end := getStartEnd(total, params.PerPage, params.Page)
		schemas = schemas[start:end]
	}
	schemasInfo := &usecase.SchemasInfo{
		Schemas:     schemas,
		SectionTags: sectionTags,
		Total:       total,
	}
	return schemasInfo, nil
}

func (r *legacyRepository) FindSchemaByID(ctx context.Context, group domain.Group, id int) (*domain.SchemaEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) FindSchemaByKey(ctx context.Context, group domain.Group, key string, section string) (*domain.SchemaEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) StoreSchema(ctx context.Context, group domain.Group, inputData *usecase.CreateSchemaInputData) (*domain.SchemaEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) UpdateSchema(ctx context.Context, group domain.Group, inputData *usecase.UpdateSchemaInputData) (err error) {
	return errors.New("no implementation")
}

func (r *legacyRepository) DeleteSchema(ctx context.Context, group domain.Group, id int) (err error) {
	return errors.New("no implementation")
}

func (r *legacyRepository) getEnvironmentDefinitions(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.DefinitionsInfo, error) {
	data := `{
		"$schema": "http://json-schema.org/draft-04/schema#",
		"additionalProperties": false,
		"title": "Basic Environment",
		"description": "Basic environment schema",
		"properties": {
			"key": {
				"pattern": "^[0-9A-Za-z_]+$",
				"type": "string"
			},
			"method": {
				"enum": ["set", "append", "prepend", "remove"],
				"type": "string"
			},
			"osName": {
				"enum": ["com", "win", "mac", "lnx"],
				"type": "string"
			},
			"sortOrder": {
				"type": "integer"
			},
			"usage": {
				"pattern": "^[\\w:;/.?@%#&=+-]+$",
				"type": "string"
			},
			"value": {
				"pattern": "^[\\w:;/.?@%#&=+-]+$",
				"type": "string"
			}
		},
		"required": ["key", "method", "osName", "sortOrder", "value"],
		"type": "object"
	}`

	var parsed interface{}
	err := json.Unmarshal([]byte(data), &parsed)
	if err != nil {
		return nil, err
	}

	createdAt, err := time.Parse("2006-01-02T15:04:05.999999Z", "2019-06-24T18:01:00.000000Z")
	if err != nil {
		return nil, err
	}
	modifiedAt, err := time.Parse("2006-01-02T15:04:05.999999Z", "2019-06-24T18:01:00.000000Z")
	definition := &domain.DefinitionEntry{
		Group:         group.String(),
		Key:           "environment",
		Definition:    parsed,
		ID:            1,
		CreatedAtUTC:  &createdAt,
		CreatedBy:     "tnishizawa",
		ModifiedAtUTC: &modifiedAt,
		ModifiedBy:    "tnishizawa",
	}

	entries := []*domain.DefinitionEntry{definition}

	if params.SearchKey != "" {
		for _, entry := range entries {
			filteredEntries := []*domain.DefinitionEntry{}
			if strings.Contains(entry.Key, params.SearchKey) {
				filteredEntries = append(filteredEntries, entry)
			}
			entries = filteredEntries
		}
	}

	definitionsInfo := &usecase.DefinitionsInfo{
		Definitions: entries,
		Total:       len(entries),
	}
	return definitionsInfo, nil
}

func (r *legacyRepository) FindDefinitions(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.DefinitionsInfo, error) {
	if group == domain.Environment {
		return r.getEnvironmentDefinitions(ctx, group, params)
	}
	definitionsInfo := &usecase.DefinitionsInfo{
		Definitions: []*domain.DefinitionEntry{},
		Total:       0,
	}
	return definitionsInfo, nil
}

func (r *legacyRepository) FindDefinitionByID(ctx context.Context, group domain.Group, id int) (*domain.DefinitionEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) FindDefinitionByKey(ctx context.Context, group domain.Group, key string) (*domain.DefinitionEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) StoreDefinition(ctx context.Context, group domain.Group, inputData *usecase.CreateDefinitionInputData) (*domain.DefinitionEntry, error) {
	return nil, errors.New("no implementation")
}

func (r *legacyRepository) UpdateDefinition(ctx context.Context, group domain.Group, inputData *usecase.UpdateDefinitionInputData) error {
	return errors.New("no implementation")
}

func (r *legacyRepository) DeleteDefinition(ctx context.Context, group domain.Group, id int) error {
	return errors.New("no implementation")
}

func getTableName(group domain.Group) (tableName string, err error) {
	switch group {
	case domain.Config:
		tableName = "t_config_entry"
	case domain.Environment:
		tableName = "t_environment_entry"
	case domain.Preference:
		tableName = "t_preference_entry"
	default:
		err = fmt.Errorf("unknown setting group")
	}
	return tableName, err
}
