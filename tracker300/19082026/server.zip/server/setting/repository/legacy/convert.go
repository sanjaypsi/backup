package legacy

import (
	"database/sql"
	"fmt"
	"log"
	"regexp"
	"strconv"
	"strings"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
)

type uniqueKey struct {
	Section string
	Entry   string
	Key     string
}

type environmentValue struct {
	Key       string `json:"key"`
	Method    string `json:"method"`
	OSName    string `json:"osName"`
	SortOrder int    `json:"sortOrder"`
	Usage     string `json:"usage"`
	Value     string `json:"value"`
}

func scanLegacyValues(rows *sql.Rows) []*ValueRecord {
	var records []*ValueRecord
	for rows.Next() {
		record := &ValueRecord{}
		err := rows.Scan(
			&record.SectionType,
			&record.SectionName,
			&record.Key,
			&record.Value,
			&record.CreatedAtUTC,
			&record.ModifiedAtUTC,
			&record.Deleted,
			&record.ModifiedBy,
			&record.CreatedBy,
			&record.ID,
		)
		if err != nil {
			log.Println(err)
			continue
		}
		records = append(records, record)
	}
	return records
}

func scanLegacyProperties(rows *sql.Rows) []*PropertylistRecord {
	var records []*PropertylistRecord
	for rows.Next() {
		record := &PropertylistRecord{}
		err := rows.Scan(
			&record.KeyType,
			&record.Key,
			&record.Property,
			&record.Data,
			&record.CreatedAtUTC,
			&record.ModifiedAtUTC,
			&record.Deleted,
			&record.ModifiedBy,
			&record.CreatedBy,
			&record.ID,
		)
		if err != nil {
			log.Println(err)
			continue
		}
		records = append(records, record)
	}
	return records
}

func convertConfPrefValues(group domain.Group, records []*ValueRecord) ([]*domain.ValueEntry, error) {
	var values []*domain.ValueEntry
	for _, record := range records {
		var (
			createdBy  string
			modifiedBy string
		)
		if record.CreatedBy != nil {
			createdBy = *record.CreatedBy
		}
		if record.ModifiedBy != nil {
			modifiedBy = *record.ModifiedBy
		}
		value := &domain.ValueEntry{
			Group:         group.String(),
			Section:       record.SectionType,
			Entry:         record.SectionName,
			Key:           record.Key,
			Value:         record.Value,
			CreatedAtUTC:  record.CreatedAtUTC,
			ModifiedAtUTC: record.ModifiedAtUTC,
			ModifiedBy:    modifiedBy,
			CreatedBy:     createdBy,
			ID:            record.ID,
		}
		values = append(values, value)
	}
	return values, nil
}

func convertEnvironmentValues(group domain.Group, records []*ValueRecord) ([]*domain.ValueEntry, error) {
	valueMap := map[uniqueKey]*domain.ValueEntry{}
	dataMap := map[uniqueKey]*environmentValue{}
	valueKeys := []uniqueKey{}
	re := regexp.MustCompile(`^((.*)/environment[0-9]+):(.*)$`)

	for _, record := range records {
		matched := re.FindStringSubmatch(record.Key)
		key, propBase, propName := matched[1], matched[2], matched[3]

		mapKey := uniqueKey{
			Section: record.SectionType,
			Entry:   record.SectionName,
			Key:     key,
		}

		if _, ok := valueMap[mapKey]; !ok {
			valueMap[mapKey] = &domain.ValueEntry{
				Group:         group.String(),
				Key:           propBase,
				Value:         &environmentValue{},
				ID:            -1,
				Section:       record.SectionType,
				Entry:         record.SectionName,
				CreatedAtUTC:  nil,
				CreatedBy:     "",
				ModifiedAtUTC: nil,
				ModifiedBy:    "",
			}
			dataMap[mapKey] = &environmentValue{}
			valueKeys = append(valueKeys, mapKey)
		}
		switch propName {
		case "key":
			dataMap[mapKey].Key = record.Value
		case "method":
			dataMap[mapKey].Method = record.Value
		case "osName":
			dataMap[mapKey].OSName = record.Value
		case "sortOrder":
			converted, err := strconv.Atoi(record.Value)
			if err == nil {
				dataMap[mapKey].SortOrder = converted
			}
		case "usage":
			dataMap[mapKey].Usage = record.Value
		case "value":
			var (
				createdBy  string
				modifiedBy string
			)
			if record.CreatedBy != nil {
				createdBy = *record.CreatedBy
			}
			if record.ModifiedBy != nil {
				modifiedBy = *record.ModifiedBy
			}
			dataMap[mapKey].Value = record.Value
			valueMap[mapKey].ID = record.ID
			valueMap[mapKey].CreatedAtUTC = record.CreatedAtUTC
			valueMap[mapKey].CreatedBy = createdBy
			valueMap[mapKey].ModifiedAtUTC = record.ModifiedAtUTC
			valueMap[mapKey].ModifiedBy = modifiedBy
		}
	}

	var values []*domain.ValueEntry
	for _, mapKey := range valueKeys {
		value, ok := valueMap[mapKey]
		if !ok {
			continue
		}
		data, ok := dataMap[mapKey]
		if !ok {
			continue
		}
		value.Value = data
		values = append(values, value)
	}
	return values, nil
}

func getStartEnd(total, perPage, page int) (start, end int) {
	start = perPage * (page - 1)
	if start > total {
		start = total
	}
	end = start + perPage
	if end > total {
		end = total
	}
	return
}

// convertValueは、inValueをvalueType（JSONSchemaの型）で指定された型に変換します
func convertValue(inValue interface{}, valueType string) (interface{}, error) {
	switch valueType {
	case "array":
		str, ok := inValue.(string)
		if !ok {
			return nil, fmt.Errorf("conversion error. value must be string: %v", inValue)
		}
		converted := []string{}
		if str != "" {
			converted = strings.Split(str, ",")
		}
		return converted, nil
	case "integer":
		str, ok := inValue.(string)
		if !ok {
			return nil, fmt.Errorf("conversion error. value must be string: %v", inValue)
		}
		converted, err := strconv.Atoi(str)
		if err != nil {
			return nil, err
		}
		return converted, nil
	case "number":
		str, ok := inValue.(string)
		if !ok {
			return nil, fmt.Errorf("conversion error. value must be string: %v", inValue)
		}
		converted, err := strconv.ParseFloat(str, 64)
		if err != nil {
			return nil, err
		}
		return converted, nil
	case "boolean":
		str, ok := inValue.(string)
		if !ok {
			return nil, fmt.Errorf("conversion error. value must be string: %v", inValue)
		}
		converted, err := strconv.ParseBool(str)
		if err != nil {
			return nil, err
		}
		return converted, nil
	case "string":
		str, ok := inValue.(string)
		if !ok {
			return nil, fmt.Errorf("conversion error. value must be string: %v", inValue)
		}
		return str, nil
	default:
		return nil, fmt.Errorf("Unsuppotrd value type: %s", valueType)
	}
}

// toJSONType 旧APIで使われていたデータ型をJSONSchemaで使われるデータ型に変換する
func toJSONType(legacyType string) (string, error) {
	switch legacyType {
	case "list":
		return "array", nil
	case "enum", "unicode":
		return "string", nil
	case "int":
		return "integer", nil
	case "bool":
		return "boolean", nil
	case "float":
		return "number", nil
	default:
		return "", fmt.Errorf("Unsupported data type: %s", legacyType)
	}
}

func convertEnvironmentSchemas(group domain.Group, props []*PropertylistRecord) []*domain.SchemaEntry {
	schemas := []*domain.SchemaEntry{}
	for _, entry := range props {
		propBase := strings.TrimSuffix(entry.Key, "/environment*:value")
		// 古いAPIで取得できるSchemaの定義は信用できないものなので、Schemaはすべて初期値を使う
		var (
			createdBy  string
			modifiedBy string
		)
		if entry.CreatedBy != nil {
			createdBy = *entry.CreatedBy
		}
		if entry.ModifiedBy != nil {
			modifiedBy = *entry.ModifiedBy
		}
		schema := &domain.SchemaEntry{
			Group:         group.String(),
			Key:           propBase,
			Schema:        map[string]string{"$ref": "#/definitions/environment"},
			ID:            entry.ID,
			CreatedAtUTC:  entry.CreatedAtUTC,
			CreatedBy:     createdBy,
			ModifiedAtUTC: entry.ModifiedAtUTC,
			ModifiedBy:    modifiedBy,
		}
		schemas = append(schemas, schema)
	}
	return schemas
}

// convertConfPrefSchemas 旧PropertylistをPreference/Config Schemaのリストに変換する
func convertConfPrefSchemas(group domain.Group, props []*PropertylistRecord) []*domain.SchemaEntry {
	schemaMap := map[uniqueKey]map[string]interface{}{}
	schemaKeys := []uniqueKey{}
	requiredMap := map[uniqueKey]struct{}{}
	valueMap := map[uniqueKey]*PropertylistRecord{}

	for _, entry := range props {
		var section string
		switch entry.KeyType {
		case "commonconfigKey":
			section = "common"
		case "studioconfigKey":
			section = "studio"
		case "projectconfigKey":
			section = "project"
		}

		mapKey := uniqueKey{
			Section: section,
			Key:     entry.Key,
		}

		if _, ok := schemaMap[mapKey]; !ok {
			schemaMap[mapKey] = map[string]interface{}{}
			schemaKeys = append(schemaKeys, mapKey)
		}
		if entry.Property == "default" && entry.Data != "" {
			schemaMap[mapKey]["default"] = entry.Data
		}
		if entry.Property == "format" && entry.Data != "" {
			schemaMap[mapKey]["pattern"] = entry.Data
		}
		if entry.Property == "minimum" && entry.Data != "" {
			schemaMap[mapKey]["minimum"] = entry.Data
		}
		if entry.Property == "maximum" && entry.Data != "" {
			schemaMap[mapKey]["maximum"] = entry.Data
		}
		if entry.Property == "required" {
			if v, err := strconv.ParseBool(entry.Data); err == nil && v {
				requiredMap[mapKey] = struct{}{}
			}
		}
		if entry.Property == "type" && entry.Data != "" {
			jsonType, err := toJSONType(entry.Data)
			if err != nil {
				log.Println(err.Error())
				continue
			}
			schemaMap[mapKey]["type"] = jsonType
			valueMap[mapKey] = entry
		}
		if entry.Property == "items" && entry.Data != "" {
			schemaMap[mapKey]["enum"] = strings.Split(entry.Data, ",")
		}
	}

	for _, val := range schemaMap {
		if _, ok := val["type"]; !ok {
			continue
		}

		valueType, ok := val["type"].(string)
		if !ok {
			continue
		}

		// items
		if valueType == "array" {
			// itemsの定義を追加（typeはstring）
			items := map[string]string{"type": "string"}
			if pattern, ok := val["pattern"]; ok {
				// patternはitemsのpatternに変更
				str, ok := pattern.(string)
				if !ok {
					continue
				}
				items["pattern"] = str
				delete(val, "pattern")
			}
			val["items"] = items
		}

		// default
		if _, ok := val["default"]; ok {
			v, err := convertValue(val["default"], valueType)
			if err == nil {
				val["default"] = v
			} else {
				delete(val, "default")
			}
		}

		// minimum
		if value, ok := val["minimum"]; ok {
			v, err := convertValue(value, valueType)
			if err == nil {
				val["minimum"] = v
			} else {
				delete(val, "minimum")
			}
		}

		// maximum
		if value, ok := val["maximum"]; ok {
			v, err := convertValue(value, valueType)
			if err == nil {
				val["maximum"] = v
			} else {
				delete(val, "maximum")
			}
		}
	}

	var schemas []*domain.SchemaEntry
	for _, mapKey := range schemaKeys {
		val, ok := schemaMap[mapKey]
		if !ok {
			log.Printf(
				"WARNING: Invalid entry: %v. There is no definition of schema.. Skipped.", mapKey,
			)
			continue
		}
		_, required := requiredMap[mapKey]
		propEntry, ok := valueMap[mapKey]
		if !ok {
			log.Printf(
				"WARNING: Invalid entry: %v. The value of 'type' is missing or invalid. Skipped.", mapKey,
			)
			continue
		}
		var (
			createdBy  string
			modifiedBy string
		)
		if propEntry.CreatedBy != nil {
			createdBy = *propEntry.CreatedBy
		}
		if propEntry.ModifiedBy != nil {
			modifiedBy = *propEntry.ModifiedBy
		}
		schema := &domain.SchemaEntry{
			Group:         group.String(),
			Key:           mapKey.Key,
			Schema:        val,
			Required:      required,
			Section:       mapKey.Section,
			ID:            propEntry.ID,
			CreatedAtUTC:  propEntry.CreatedAtUTC,
			CreatedBy:     createdBy,
			ModifiedAtUTC: propEntry.ModifiedAtUTC,
			ModifiedBy:    modifiedBy,
		}
		schemas = append(schemas, schema)
	}

	return schemas
}

func findValueType(schemas []*domain.SchemaEntry, section, key string) (string, error) {
	for _, schema := range schemas {
		schemaSection := schema.Section
		if (schemaSection == "" || schemaSection == section) && schema.Key == key {
			schemaMap, ok := schema.Schema.(map[string]interface{})
			if !ok {
				continue
			}
			if valueType, ok := schemaMap["type"]; ok {
				return valueType.(string), nil
			}
		}
	}
	err := fmt.Errorf("no schema found for section: %s, key: %s", section, key)
	return "", err
}
