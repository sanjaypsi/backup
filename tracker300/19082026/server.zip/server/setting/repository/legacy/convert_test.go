package legacy

import (
	"reflect"
	"testing"
)

func TestToJSONType(t *testing.T) {
	data := map[string]string{
		"list":    "array",
		"enum":    "string",
		"unicode": "string",
		"int":     "integer",
		"bool":    "boolean",
		"float":   "number",
	}
	for input, expect := range data {
		got, err := toJSONType(input)
		if err != nil {
			t.Fatal(err)
		}
		if got != expect {
			t.Fatal(got)
		}
	}
}

func TestGetStartEnd(t *testing.T) {
	expect := []int{3, 6}
	start, end := getStartEnd(10, 3, 2)
	if !reflect.DeepEqual([]int{start, end}, expect) {
		t.Fatal(start, end)
	}
}

func TestGetStartEndLast(t *testing.T) {
	expect := []int{9, 10}
	start, end := getStartEnd(10, 3, 4)
	if !reflect.DeepEqual([]int{start, end}, expect) {
		t.Fatal(start, end)
	}
}

func TestGetStartEndOver(t *testing.T) {
	expect := []int{10, 10}
	start, end := getStartEnd(10, 3, 6)
	if !reflect.DeepEqual([]int{start, end}, expect) {
		t.Fatal(start, end)
	}
}

func TestConvertValueArray(t *testing.T) {
	var value interface{} = "lnx,mac,win"
	var expect interface{} = []string{"lnx", "mac", "win"}
	got, err := convertValue(value, "array")
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, expect) {
		t.Fatal(got)
	}
}

func TestConvertValueInteger(t *testing.T) {
	var value interface{} = "123"
	var expect interface{} = 123
	got, err := convertValue(value, "integer")
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, expect) {
		t.Fatal(got)
	}
}

func TestConvertValueFloat(t *testing.T) {
	var value interface{} = "123.456"
	var expect interface{} = 123.456
	got, err := convertValue(value, "number")
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, expect) {
		t.Fatal(got)
	}
}

func TestConvertValueBoolean(t *testing.T) {
	var value interface{} = "False"
	var expect interface{} = false
	got, err := convertValue(value, "boolean")
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, expect) {
		t.Fatal(got)
	}
}

func TestConvertValueString(t *testing.T) {
	var value interface{} = "abc"
	var expect interface{} = "abc"
	got, err := convertValue(value, "string")
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, expect) {
		t.Fatal(got)
	}
}
