package mysql

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/setting/domain"
	"github.com/PolygonPictures/central30-web/front/setting/usecase"
)

const (
	definitionTable = "t_setting_definition"
	schemaTable     = "t_setting_schema"
	valueTable      = "t_setting_value"
)

type rowsScanner func(rows *sql.Rows)

type row interface {
	Scan(dest ...interface{}) error
}

func scanValue(row row) (*domain.ValueEntry, error) {
	value := &domain.ValueEntry{}
	var data []byte
	err := row.Scan(
		&value.Group,
		&value.Section,
		&value.Entry,
		&value.Key,
		&data,
		&value.CreatedAtUTC,
		&value.ModifiedAtUTC,
		&value.Deleted,
		&value.ModifiedBy,
		&value.CreatedBy,
		&value.ID,
	)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(data, &value.Value)
	if err != nil {
		return nil, err
	}
	return value, nil
}

func scanSchema(row row) (*domain.SchemaEntry, error) {
	schema := &domain.SchemaEntry{}
	var data []byte
	err := row.Scan(
		&schema.Group,
		&schema.Section,
		&schema.Required,
		&schema.Key,
		&data,
		&schema.CreatedAtUTC,
		&schema.ModifiedAtUTC,
		&schema.Deleted,
		&schema.ModifiedBy,
		&schema.CreatedBy,
		&schema.ID,
	)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(data, &schema.Schema)
	if err != nil {
		return nil, err
	}
	return schema, nil
}

func scanDefinition(row row) (*domain.DefinitionEntry, error) {
	def := &domain.DefinitionEntry{}
	var data []byte
	err := row.Scan(
		&def.Group,
		&def.Key,
		&data,
		&def.CreatedAtUTC,
		&def.ModifiedAtUTC,
		&def.Deleted,
		&def.ModifiedBy,
		&def.CreatedBy,
		&def.ID,
	)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(data, &def.Definition)
	if err != nil {
		return nil, err
	}
	return def, nil
}

type mysqlRepository struct {
	DB *sql.DB
}

// NewRepository creates an object that represents the usecase.Repository interface
func NewRepository(DB *sql.DB) usecase.Repository {
	return &mysqlRepository{DB}
}

func (r *mysqlRepository) doQuery(ctx context.Context, query string, scanner rowsScanner, args ...interface{}) error {
	rows, err := r.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	scanner(rows)
	return rows.Err()
}

func (r *mysqlRepository) doExec(ctx context.Context, query string, args ...interface{}) (res sql.Result, err error) {
	stmt, err := r.DB.PrepareContext(ctx, query)
	if err != nil {
		return
	}
	defer stmt.Close()

	res, err = stmt.ExecContext(ctx, args...)
	if err != nil {
		return
	}
	return
}

func (r *mysqlRepository) getSectionTags(ctx context.Context, query string, args ...interface{}) ([]string, error) {
	var sectionTags []string
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			var section string
			err := rows.Scan(&section)
			if err != nil {
				log.Println(err)
				continue
			}
			sectionTags = append(sectionTags, section)
		}
	}, args...)
	return sectionTags, err
}

func (r *mysqlRepository) getEntryTags(ctx context.Context, query string, args ...interface{}) ([]string, error) {
	var entryTags []string
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			var section string
			var entry string
			err := rows.Scan(&section, &entry)
			if err != nil {
				continue
			}
			entryTag := section + "/" + entry
			entryTags = append(entryTags, entryTag)
		}
	}, args...)
	return entryTags, err
}

func (r *mysqlRepository) getTotalCount(ctx context.Context, query string, args ...interface{}) (int, error) {
	var total int
	row := r.DB.QueryRowContext(ctx, query, args...)
	err := row.Scan(&total)
	return total, err
}

func (r *mysqlRepository) fetchValues(ctx context.Context, query string, args ...interface{}) ([]*domain.ValueEntry, error) {
	var values []*domain.ValueEntry
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			value, err := scanValue(rows)
			if err != nil {
				log.Println(err)
				continue
			}
			values = append(values, value)
		}
	}, args...)
	return values, err
}

func (r *mysqlRepository) fetchSchemas(ctx context.Context, query string, args ...interface{}) ([]*domain.SchemaEntry, error) {
	var schemas []*domain.SchemaEntry
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			schema, err := scanSchema(rows)
			if err != nil {
				log.Println(err)
				continue
			}
			schemas = append(schemas, schema)
		}
	}, args...)
	return schemas, err
}

func (r *mysqlRepository) fetchDefinitions(ctx context.Context, query string, args ...interface{}) ([]*domain.DefinitionEntry, error) {
	var definitions []*domain.DefinitionEntry
	err := r.doQuery(ctx, query, func(rows *sql.Rows) {
		for rows.Next() {
			definition, err := scanDefinition(rows)
			if err != nil {
				log.Println(err)
				continue
			}
			definitions = append(definitions, definition)
		}
	}, args...)
	return definitions, err
}

func (r *mysqlRepository) FindValues(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.ValuesInfo, error) {
	valuesInfo := &usecase.ValuesInfo{}
	filter := fmt.Sprintf("FROM `%s` WHERE `group` = ? AND deleted = 0", valueTable)
	args := []interface{}{group.String()}
	var err error

	if params.SearchKey != "" {
		filter += " AND `key` LIKE CONCAT('%', ?, '%')"
		args = append(args, params.SearchKey)
	}

	if params.Key != "" {
		filter += " AND `key` = ?"
		args = append(args, params.Key)
	}

	valuesInfo.EntryTags, err = r.getEntryTags(ctx, "SELECT DISTINCT section, entry "+filter, args...)
	if err != nil {
		return nil, err
	}

	if params.Section != "" {
		filter += " AND section = ?"
		args = append(args, params.Section)
	}

	if params.Entry != "" {
		filter += " AND entry = ?"
		args = append(args, params.Entry)
	}

	valuesInfo.Total, err = r.getTotalCount(ctx, "SELECT COUNT(*) "+filter, args...)
	if err != nil {
		return nil, err
	}
	if valuesInfo.Total == 0 {
		return valuesInfo, nil
	}

	filter += " ORDER BY `key`"
	if params.PerPage != 0 { // params.PerPage=0 で全件取得（内部利用専用）
		filter += " LIMIT ?, ?"
		offset := params.PerPage * (params.Page - 1)
		args = append(args, offset, params.PerPage)
	}
	valuesInfo.Values, err = r.fetchValues(ctx, "SELECT * "+filter, args...)
	if err != nil {
		return nil, err
	}
	return valuesInfo, nil
}

func (r *mysqlRepository) FindValueByID(ctx context.Context, group domain.Group, id int) (*domain.ValueEntry, error) {
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE `group` = ? AND id = ? AND deleted = 0", valueTable)
	args := []interface{}{group.String(), id}
	row := r.DB.QueryRowContext(ctx, query, args...)
	value, err := scanValue(row)
	if err != nil {
		return nil, domain.ErrNotFound
	}
	return value, nil
}

func (r *mysqlRepository) FindValuesByKey(ctx context.Context, group domain.Group, key string, section string) ([]*domain.ValueEntry, error) {
	query := fmt.Sprintf("SELECT * FROM %s WHERE `group` = ? AND `key` = ? AND section = ? AND deleted = 0", valueTable)
	args := []interface{}{group.String(), key, section}
	return r.fetchValues(ctx, query, args)
}

func (r *mysqlRepository) FindValueByKey(ctx context.Context, group domain.Group, key string, section string) (*domain.ValueEntry, error) {
	values, err := r.FindValuesByKey(ctx, group, key, section)
	if err != nil {
		return nil, err
	}
	if len(values) == 0 {
		return nil, domain.ErrNotFound
	}
	if len(values) != 1 {
		return nil, fmt.Errorf("multiple values are found: %d", len(values))
	}
	return values[0], nil
}

func (r *mysqlRepository) StoreValue(ctx context.Context, group domain.Group, inputData *usecase.CreateValueInputData) (*domain.ValueEntry, error) {
	now := time.Now().UTC()
	user := ""
	query := strings.Join([]string{
		fmt.Sprintf("INSERT INTO `%s`", valueTable),
		"  (`group`, section, entry, `key`, value, created_at_utc, modified_at_utc, modified_by, created_by)",
		"VALUES",
		"  (?, ?, ?, ?, ?, ?, ?, ?, ?)",
	}, "\n")

	bytes, err := json.Marshal(inputData.Value)
	if err != nil {
		return nil, err
	}
	args := []interface{}{group.String(), inputData.Section, inputData.Entry, inputData.Key, bytes, now, now, user, user}
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	lastID, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	value := &domain.ValueEntry{
		Group:         group.String(),
		Key:           inputData.Key,
		Value:         inputData.Value,
		ID:            int(lastID),
		Section:       inputData.Section,
		Entry:         inputData.Entry,
		CreatedAtUTC:  &now,
		CreatedBy:     user,
		ModifiedAtUTC: &now,
		ModifiedBy:    user,
	}
	return value, nil
}

func (r *mysqlRepository) UpdateValue(ctx context.Context, group domain.Group, inputData *usecase.UpdateValueInputData) error {
	now := time.Now().UTC()
	user := ""
	query := fmt.Sprintf("UPDATE `%s` SET modified_at_utc = ?, modified_by = ?", valueTable)
	args := []interface{}{now, user}

	if inputData.Section != nil {
		query += ", section = ?"
		args = append(args, *inputData.Section)
	}
	if inputData.Entry != nil {
		query += ", entry = ?"
		args = append(args, *inputData.Entry)
	}
	if inputData.Value != nil {
		query += ", value = ?"
		bytes, err := json.Marshal(inputData.Value)
		if err != nil {
			return err
		}
		args = append(args, bytes)
	}

	query += " WHERE id = ? AND deleted = 0"
	args = append(args, inputData.ID)
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if affected == 0 {
		return errors.New("there is no update")
	}
	return nil
}

func (r *mysqlRepository) DeleteValue(ctx context.Context, group domain.Group, id int) error {
	query := fmt.Sprintf(
		"UPDATE `%s` SET deleted = id, modified_at_utc = ?, modified_by = ? WHERE id = ? AND deleted = 0",
		valueTable,
	)
	args := []interface{}{time.Now().UTC(), "", id}

	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return err
	}
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rowsAffected == 0 {
		return fmt.Errorf("weird behaviour. total affected: %d", rowsAffected)
	}
	return nil
}

func (r *mysqlRepository) FindSchemas(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.SchemasInfo, error) {
	schemasInfo := &usecase.SchemasInfo{}
	filter := fmt.Sprintf("FROM `%s` WHERE `group` = ? AND deleted = 0", schemaTable)
	args := []interface{}{group.String()}
	var err error

	if params.SearchKey != "" {
		filter += " AND `key` LIKE CONCAT('%', ?, '%')"
		args = append(args, params.SearchKey)
	}

	if params.Key != "" {
		filter += " AND `key` = ?"
		args = append(args, params.Key)
	}

	schemasInfo.SectionTags, err = r.getSectionTags(ctx, "SELECT DISTINCT section "+filter, args...)
	if err != nil {
		return nil, err
	}

	if params.Section != "" {
		filter += " AND section = ?"
		args = append(args, params.Section)
	}

	schemasInfo.Total, err = r.getTotalCount(ctx, "SELECT COUNT(*) "+filter, args...)
	if err != nil {
		return nil, err
	}
	if schemasInfo.Total == 0 {
		return schemasInfo, nil
	}

	filter += " ORDER BY `key`"
	if params.PerPage != 0 { // params.PerPage=0 で全件取得（内部利用専用）
		filter += " LIMIT ?, ?"
		offset := params.PerPage * (params.Page - 1)
		args = append(args, offset, params.PerPage)
	}
	schemasInfo.Schemas, err = r.fetchSchemas(ctx, "SELECT * "+filter, args...)
	if err != nil {
		return nil, err
	}
	return schemasInfo, nil
}

func (r *mysqlRepository) FindSchemaByID(ctx context.Context, group domain.Group, id int) (*domain.SchemaEntry, error) {
	query := fmt.Sprintf("SELECT * FROM %s WHERE `group` = ? AND id = ? AND deleted = 0", schemaTable)
	args := []interface{}{group.String(), id}
	row := r.DB.QueryRowContext(ctx, query, args...)
	schema, err := scanSchema(row)
	if err != nil {
		return nil, domain.ErrNotFound
	}
	return schema, nil
}

func (r *mysqlRepository) FindSchemaByKey(ctx context.Context, group domain.Group, key string, section string) (*domain.SchemaEntry, error) {
	query := fmt.Sprintf("SELECT * FROM %s WHERE `group` = ? AND `key` = ? AND (section = ? OR section = '') AND deleted = 0", schemaTable)
	args := []interface{}{group.String(), key, section}
	row := r.DB.QueryRowContext(ctx, query, args...)
	return scanSchema(row)
}

func (r *mysqlRepository) StoreSchema(ctx context.Context, group domain.Group, inputData *usecase.CreateSchemaInputData) (*domain.SchemaEntry, error) {
	now := time.Now().UTC()
	user := ""
	query := strings.Join([]string{
		fmt.Sprintf("INSERT INTO `%s`", schemaTable),
		"  (`group`, section, required, `key`, `schema`, created_at_utc, modified_at_utc, modified_by, created_by)",
		"VALUES",
		"  (?, ?, ?, ?, ?, ?, ?, ?, ?)",
	}, "\n")
	bytes, err := json.Marshal(inputData.Schema)
	if err != nil {
		return nil, err
	}
	args := []interface{}{group.String(), inputData.Section, inputData.Required, inputData.Key, bytes, now, now, user, user}
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	lastID, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	schema := &domain.SchemaEntry{
		Group:         group.String(),
		Key:           inputData.Key,
		Schema:        inputData.Schema,
		Required:      inputData.Required,
		Section:       inputData.Section,
		ID:            int(lastID),
		CreatedAtUTC:  &now,
		CreatedBy:     user,
		Deleted:       0,
		ModifiedAtUTC: &now,
		ModifiedBy:    user,
	}
	return schema, nil
}

func (r *mysqlRepository) UpdateSchema(ctx context.Context, group domain.Group, inputData *usecase.UpdateSchemaInputData) error {
	now := time.Now().UTC()
	user := ""
	query := fmt.Sprintf("UPDATE %s SET modified_at_utc = ?, modified_by = ?", schemaTable)
	args := []interface{}{now, user}

	if inputData.Section != nil {
		query += ", section = ?"
		args = append(args, *inputData.Section)
	}
	if inputData.Required != nil {
		query += ", required = ?"
		args = append(args, *inputData.Required)
	}
	if inputData.Schema != nil {
		query += ", `schema` = ?"
		bytes, err := json.Marshal(inputData.Schema)
		if err != nil {
			return err
		}
		args = append(args, bytes)
	}

	query += " WHERE id = ? AND deleted = 0"
	args = append(args, inputData.ID)
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if affected == 0 {
		return fmt.Errorf("no update")
	}
	return nil
}

func (r *mysqlRepository) DeleteSchema(ctx context.Context, group domain.Group, id int) error {
	now := time.Now().UTC()
	user := ""
	query := fmt.Sprintf(
		"UPDATE %s SET deleted = id, modified_at_utc = ?, modified_by = ? WHERE id = ? AND deleted = 0",
		schemaTable,
	)
	args := []interface{}{now, user, id}
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if affected == 0 {
		return fmt.Errorf("no record deleted")
	}
	return nil
}

func (r *mysqlRepository) FindDefinitions(ctx context.Context, group domain.Group, params *usecase.QueryParams) (*usecase.DefinitionsInfo, error) {
	definitionsInfo := &usecase.DefinitionsInfo{}
	filter := fmt.Sprintf("FROM `%s` WHERE `group` = ? AND deleted = 0", definitionTable)
	args := []interface{}{group.String()}
	var err error

	if params.SearchKey != "" {
		filter += " AND `key` LIKE CONCAT('%', ?, '%')"
		args = append(args, params.SearchKey)
	}

	if params.Key != "" {
		filter += " AND `key` = ?"
		args = append(args, params.Key)
	}

	definitionsInfo.Total, err = r.getTotalCount(ctx, "SELECT COUNT(*) "+filter, args...)
	if err != nil {
		return nil, err
	}
	if definitionsInfo.Total == 0 {
		return definitionsInfo, nil
	}

	filter += " ORDER BY `key`"
	if params.PerPage != 0 { // params.PerPage=0 で全件取得（内部利用専用）
		filter += " LIMIT ?, ?"
		offset := params.PerPage * (params.Page - 1)
		args = append(args, offset, params.PerPage)
	}
	definitionsInfo.Definitions, err = r.fetchDefinitions(ctx, "SELECT * "+filter, args...)
	if err != nil {
		return nil, err
	}
	return definitionsInfo, nil
}

func (r *mysqlRepository) FindDefinitionByID(ctx context.Context, group domain.Group, id int) (*domain.DefinitionEntry, error) {
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE `group` = ? AND id = ? AND deleted = 0", definitionTable)
	args := []interface{}{group.String(), id}
	row := r.DB.QueryRowContext(ctx, query, args...)
	definition, err := scanDefinition(row)
	if err != nil {
		return nil, domain.ErrNotFound
	}
	return definition, nil
}

func (r *mysqlRepository) FindDefinitionByKey(ctx context.Context, group domain.Group, key string) (*domain.DefinitionEntry, error) {
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE `group` = ? AND `key` = ? AND deleted = 0", definitionTable)
	args := []interface{}{group.String(), key}
	row := r.DB.QueryRowContext(ctx, query, args...)
	return scanDefinition(row)
}

func (r *mysqlRepository) StoreDefinition(ctx context.Context, group domain.Group, inputData *usecase.CreateDefinitionInputData) (*domain.DefinitionEntry, error) {
	now := time.Now().UTC()
	user := ""
	query := strings.Join([]string{
		fmt.Sprintf("INSERT INTO `%s`", definitionTable),
		"  (`group`, `key`, `definition`, created_at_utc, modified_at_utc, modified_by, created_by)",
		"VALUES",
		"  (?, ?, ?, ?, ?, ?, ?)",
	}, "\n")
	bytes, err := json.Marshal(inputData.Definition)
	if err != nil {
		return nil, err
	}
	args := []interface{}{group.String(), inputData.Key, bytes, now, now, user, user}
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	lastID, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	def := &domain.DefinitionEntry{
		Group:         group.String(),
		Key:           inputData.Key,
		Definition:    inputData.Definition,
		ID:            int(lastID),
		CreatedAtUTC:  &now,
		CreatedBy:     user,
		Deleted:       0,
		ModifiedAtUTC: &now,
		ModifiedBy:    user,
	}
	return def, nil
}

func (r *mysqlRepository) UpdateDefinition(ctx context.Context, group domain.Group, inputData *usecase.UpdateDefinitionInputData) error {
	now := time.Now().UTC()
	user := ""
	query := fmt.Sprintf("UPDATE `%s` SET modified_at_utc = ?, modified_by = ?", definitionTable)
	args := []interface{}{now, user}

	query += ", definition = ?"
	bytes, err := json.Marshal(inputData.Definition)
	if err != nil {
		return err
	}
	args = append(args, bytes)

	query += " WHERE id = ? AND deleted = 0"
	args = append(args, inputData.ID)
	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if affected == 0 {
		return errors.New("there is no update")
	}
	return nil
}

func (r *mysqlRepository) DeleteDefinition(ctx context.Context, group domain.Group, id int) error {
	query := fmt.Sprintf(
		"UPDATE `%s` SET deleted = id, modified_at_utc = ?, modified_by = ? WHERE id = ? AND deleted = 0",
		definitionTable,
	)
	args := []interface{}{time.Now().UTC(), "", id}

	res, err := r.doExec(ctx, query, args...)
	if err != nil {
		return err
	}
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rowsAffected == 0 {
		return fmt.Errorf("weired behaviour. total affected: %d", rowsAffected)
	}
	return nil
}
