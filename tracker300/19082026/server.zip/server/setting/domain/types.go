package domain

// Group is a representation of the setting group
type Group int

const (
	// Config is a config group of the setting
	Config Group = iota + 1
	// Environment is a environment group of the setting
	Environment
	// Preference is a preference group of the setting
	Preference
)

func (c Group) String() string {
	switch c {
	case Config:
		return "config"
	case Environment:
		return "environment"
	case Preference:
		return "preference"
	default:
		return "unknown"
	}
}

// Types is a representation of the setting type
type Types int

const (
	// Definition is a definition type of the setting
	Definition Types = iota + 1
	// Schema is a schema type of the setting
	Schema
	// Value is a value type of the settings
	Value
)

func (t Types) String() string {
	switch t {
	case Definition:
		return "definition"
	case Schema:
		return "schema"
	case Value:
		return "value"
	default:
		return "unknown"
	}
}
