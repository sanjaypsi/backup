package domain

import "errors"

// ErrInternalServerError will thow if any the internal server error happen
var ErrInternalServerError = errors.New("Internal Server Error")

// ErrNotFound will throw if the request item is not exist
var ErrNotFound = errors.New("Your request item is not found")

// ErrConflict will throw if the current action already exists
var ErrConflict = errors.New("Your item already exist")

// ErrBadParamInput will throw if the given request-body or param is not valid
var ErrBadParamInput = errors.New("Given param is not valid")
