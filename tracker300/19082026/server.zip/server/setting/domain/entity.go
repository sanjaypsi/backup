package domain

import "time"

// DefinitionEntry is a definition entry
type DefinitionEntry struct {
	Group         string      `json:"group"`
	Key           string      `json:"key"`
	Definition    interface{} `json:"definition"`
	ID            int         `json:"id"`
	CreatedAtUTC  *time.Time  `json:"created_at_utc"`
	CreatedBy     string      `json:"created_by"`
	Deleted       int32       `json:"-"`
	ModifiedAtUTC *time.Time  `json:"modified_at_utc"`
	ModifiedBy    string      `json:"modified_by"`
}

// SchemaEntry is a schema for the config or preference
type SchemaEntry struct {
	Group         string      `json:"group"`
	Section       string      `json:"section"`
	Key           string      `json:"key"`
	Schema        interface{} `json:"schema"`
	Required      bool        `json:"required"`
	ID            int         `json:"id"`
	CreatedAtUTC  *time.Time  `json:"created_at_utc"`
	CreatedBy     string      `json:"created_by"`
	Deleted       int32       `json:"-"`
	ModifiedAtUTC *time.Time  `json:"modified_at_utc"`
	ModifiedBy    string      `json:"modified_by"`
}

// ValueEntry Config Value
type ValueEntry struct {
	Group         string      `json:"group"`
	Key           string      `json:"key"`
	Value         interface{} `json:"value"`
	ID            int         `json:"id"`
	Section       string      `json:"section"`
	Entry         string      `json:"entry"`
	CreatedAtUTC  *time.Time  `json:"created_at_utc"`
	CreatedBy     string      `json:"created_by"`
	Deleted       int32       `json:"-"`
	ModifiedAtUTC *time.Time  `json:"modified_at_utc"`
	ModifiedBy    string      `json:"modified_by"`
}
