package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

type entry interface {
	getTableArgs() ([]interface{}, error)
}

type baseEntry struct {
	Group         string     `json:"group"`
	Key           string     `json:"key"`
	ID            int        `json:"id"`
	CreatedAtUTC  *time.Time `json:"created_at_utc"`
	CreatedBy     string     `json:"created_by"`
	ModifiedAtUTC *time.Time `json:"modified_at_utc"`
	ModifiedBy    string     `json:"modified_by"`
}

type definitionEntry struct {
	Definition interface{} `json:"definition"`
	baseEntry
}

func (e *definitionEntry) getTableArgs() ([]interface{}, error) {
	bytes, err := json.Marshal(e.Definition)
	if err != nil {
		return nil, err
	}
	return []interface{}{e.Group, e.Key, bytes, e.CreatedAtUTC, e.ModifiedAtUTC, e.ModifiedBy, e.CreatedBy}, nil
}

type schemaEntry struct {
	Section  string      `json:"section"`
	Schema   interface{} `json:"schema"`
	Required bool        `json:"required"`
	baseEntry
}

func (e *schemaEntry) getTableArgs() ([]interface{}, error) {
	bytes, err := json.Marshal(e.Schema)
	if err != nil {
		return nil, err
	}
	return []interface{}{e.Group, e.Section, e.Required, e.Key, bytes, e.CreatedAtUTC, e.ModifiedAtUTC, e.ModifiedBy, e.CreatedBy}, nil
}

type valueEntry struct {
	Value   interface{} `json:"value"`
	Section string      `json:"section"`
	Entry   string      `json:"entry"`
	baseEntry
}

func (e *valueEntry) getTableArgs() ([]interface{}, error) {
	bytes, err := json.Marshal(e.Value)
	if err != nil {
		return nil, err
	}
	return []interface{}{e.Group, e.Section, e.Entry, e.Key, bytes, e.CreatedAtUTC, e.ModifiedAtUTC, e.ModifiedBy, e.CreatedBy}, nil
}

type response interface {
	hasNext() bool
	getNext() string
	getTableName() string
	getEntries() []entry
	getTableKeys() string
	getTableValues() string
}

type baseResponse struct {
	Total int     `json:"total"`
	Prev  *string `json:"prev"`
	Next  *string `json:"next"`
}

func (r *baseResponse) hasNext() bool {
	return r.Next != nil
}

func (r *baseResponse) getNext() string {
	return *r.Next
}

type definitionsResponse struct {
	Definitions []*definitionEntry `json:"definitions"`
	baseResponse
}

func newDefinitionsResponse(bytes []byte) (response, error) {
	var resp definitionsResponse
	err := json.Unmarshal(bytes, &resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

func (r *definitionsResponse) getTableName() string {
	return "t_setting_definition"
}

func (r *definitionsResponse) getEntries() (entries []entry) {
	for _, definition := range r.Definitions {
		entries = append(entries, definition)
	}
	return
}

func (r *definitionsResponse) getTableKeys() string {
	return "(`group`, `key`, `definition`, `created_at_utc`, `modified_at_utc`, `modified_by`, `created_by`)"
}

func (r *definitionsResponse) getTableValues() string {
	return "(?, ?, ?, ?, ?, ?, ?)"
}

type schemasResponse struct {
	Schemas     []*schemaEntry `json:"schemas"`
	SectionTags []string       `json:"section_tags"`
	baseResponse
}

func newSchemasResponse(bytes []byte) (response, error) {
	var resp schemasResponse
	err := json.Unmarshal(bytes, &resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

func (r *schemasResponse) getTableName() string {
	return "t_setting_schema"
}

func (r *schemasResponse) getEntries() (entries []entry) {
	for _, schema := range r.Schemas {
		entries = append(entries, schema)
	}
	return
}

func (r *schemasResponse) getTableKeys() string {
	return "(`group`, `section`, `required`, `key`, `schema`, `created_at_utc`, `modified_at_utc`, `modified_by`, `created_by`)"
}

func (r *schemasResponse) getTableValues() string {
	return "(?, ?, ?, ?, ?, ?, ?, ?, ?)"
}

type valuesResponse struct {
	Values    []*valueEntry `json:"values"`
	EntryTags []string      `json:"entry_tags"`
	baseResponse
}

func newValuesResponse(bytes []byte) (response, error) {
	var resp valuesResponse
	err := json.Unmarshal(bytes, &resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

func (r *valuesResponse) getTableName() string {
	return "t_setting_value"
}

func (r *valuesResponse) getEntries() (entries []entry) {
	for _, value := range r.Values {
		entries = append(entries, value)
	}
	return
}

func (r *valuesResponse) getTableKeys() string {
	return "(`group`, `section`, `entry`, `key`, `value`, `created_at_utc`, `modified_at_utc`, `modified_by`, `created_by`)"
}

func (r *valuesResponse) getTableValues() string {
	return "(?, ?, ?, ?, ?, ?, ?, ?, ?)"
}

func getSourceURL() string {
	srcURL := os.Getenv("PPI_DEV_LEGACY_API")
	if srcURL == "" {
		srcURL = "https://ppip30dev-web.polygonpictures.jp/api/setting"
	}
	return srcURL
}

func getTargetConnection() (string, error) {
	tgtConn := os.Getenv("PPI_DEV_MIGRATION_DB")
	if tgtConn == "" {
		tgtConn = os.Getenv("PPI_DEV_LEGACY_DB")
	}
	if tgtConn == "" {
		return "", errors.New("environment variable PPI_DEV_MIGRATION_DB is not set")
	}
	return tgtConn, nil
}

func prepareTables(db *sql.DB) error {
	for _, table := range []string{
		"t_setting_definition",
		"t_setting_schema",
		"t_setting_value",
	} {
		_, err := db.Exec(fmt.Sprintf("DROP TABLE IF EXISTS `%s`", table))
		if err != nil {
			return err
		}
	}

	var lines []string
	var err error

	lines = []string{
		"CREATE TABLE `t_setting_definition` (",
		"	`group` varchar(20) NOT NULL,",
		"	`key` varchar(255) NOT NULL,",
		"	`definition` json DEFAULT NULL,",
		"	`created_at_utc` datetime(6) DEFAULT NULL,",
		"	`modified_at_utc` datetime(6) DEFAULT NULL,",
		"	`deleted` int(11) NOT NULL DEFAULT '0',",
		"	`modified_by` varchar(100) DEFAULT NULL,",
		"	`created_by` varchar(100) DEFAULT NULL,",
		"	`id` int(11) NOT NULL AUTO_INCREMENT,",
		"	PRIMARY KEY (`id`),",
		"	KEY `index_setting_definition_1` (`group`, `key`, `deleted`)",
		") ENGINE=InnoDB DEFAULT CHARSET=UTF8",
	}
	_, err = db.Exec(strings.Join(lines, "\n"))
	if err != nil {
		return err
	}

	lines = []string{
		"CREATE TABLE `t_setting_schema` (",
		"  `group` varchar(20) NOT NULL,",
		"  `section` varchar(20) NOT NULL,",
		"  `required` boolean NOT NULL DEFAULT FALSE,",
		"  `key` varchar(255) NOT NULL,",
		"  `schema` json DEFAULT NULL,",
		"  `created_at_utc` datetime(6) DEFAULT NULL,",
		"  `modified_at_utc` datetime(6) DEFAULT NULL,",
		"  `deleted` int(11) NOT NULL DEFAULT '0',",
		"  `modified_by` varchar(100) DEFAULT NULL,",
		"  `created_by` varchar(100) DEFAULT NULL,",
		"  `id` int(11) NOT NULL AUTO_INCREMENT,",
		"  PRIMARY KEY (`id`),",
		"  KEY `index_setting_schema_1` (`group`, `section`, `key`, `deleted`)",
		") ENGINE=InnoDB DEFAULT CHARSET=UTF8",
	}
	_, err = db.Exec(strings.Join(lines, "\n"))
	if err != nil {
		return err
	}

	lines = []string{
		"CREATE TABLE `t_setting_value` (",
		"  `group` varchar(20) NOT NULL,",
		"  `section` varchar(20) NOT NULL,",
		"  `entry` varchar(50) NOT NULL,",
		"  `key` varchar(255) NOT NULL,",
		"  `value` json DEFAULT NULL,",
		"  `created_at_utc` datetime(6) DEFAULT NULL,",
		"  `modified_at_utc` datetime(6) DEFAULT NULL,",
		"  `deleted` int(11) NOT NULL DEFAULT '0',",
		"  `modified_by` varchar(100) DEFAULT NULL,",
		"  `created_by` varchar(100) DEFAULT NULL,",
		"  `id` int(11) NOT NULL AUTO_INCREMENT,",
		"  PRIMARY KEY (`id`),",
		"  KEY `index_setting_value_1` (`group`, `section`, `entry`, `key`, `deleted`)",
		") ENGINE=InnoDB DEFAULT CHARSET=UTF8",
	}
	_, err = db.Exec(strings.Join(lines, "\n"))
	if err != nil {
		return err
	}

	return nil
}

func insertValues(db *sql.DB, res response) error {
	lines := []string{
		fmt.Sprintf("INSERT INTO `%s`", res.getTableName()),
		"  " + res.getTableKeys(),
		"VALUES",
	}
	var values []string
	var args []interface{}

	tableValues := "  " + res.getTableValues()
	for _, e := range res.getEntries() {
		values = append(values, "  "+tableValues)
		valueArgs, err := e.getTableArgs()
		if err != nil {
			fmt.Println(err)
			continue
		}
		args = append(args, valueArgs...)
	}

	if len(values) == 0 {
		return nil
	}

	lines = append(lines, strings.Join(values, ",\n"))
	query := strings.Join(lines, "\n")
	_, err := db.Exec(query, args...)
	if err != nil {
		return err
	}
	log.Printf("%d records inserted\n", len(values))

	return nil
}

func main() {
	srcURL := getSourceURL()
	log.Printf("source api is '%s'", srcURL)

	tgtConn, err := getTargetConnection()
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("target db is '%s'", tgtConn)

	tgtDB, err := sql.Open("mysql", tgtConn+"?charset=utf8&parseTime=1")
	if err != nil {
		log.Fatal(err)
	}
	defer tgtDB.Close()

	err = prepareTables(tgtDB)
	if err != nil {
		log.Fatal(err)
	}

	for _, typeName := range []string{"definitions", "schemas", "values"} {
		for _, group := range []string{"config", "environment", "preference"} {
			log.Printf("migrating %s/%s", group, typeName)

			nextURL := fmt.Sprintf("%s/%s/%s", srcURL, group, typeName)
			for {
				resp, err := http.Get(nextURL)
				if err != nil {
					log.Fatal(err)
				}
				defer resp.Body.Close()

				body, err := ioutil.ReadAll(resp.Body)
				if err != nil {
					log.Fatal(err)
				}

				var res response
				switch typeName {
				case "definitions":
					res, err = newDefinitionsResponse(body)
				case "schemas":
					res, err = newSchemasResponse(body)
				case "values":
					res, err = newValuesResponse(body)
				default:
					err = fmt.Errorf("unknown type: %s", typeName)
				}
				if err != nil {
					log.Fatal(err)
				}

				err = insertValues(tgtDB, res)
				if err != nil {
					log.Fatal(err)
				}

				if !res.hasNext() {
					break
				}
				nextURL = res.getNext()
			}
		}
	}

	log.Println("done")
}
