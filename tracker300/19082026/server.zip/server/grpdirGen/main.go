package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("error: no command")
		os.Exit(int(exitError))
	}

	db, err := openMySQLFromEnv(dbName)
	if err != nil {
		fmt.Printf("error: failed to open MySQL from env: %s", err)
		os.Exit(int(exitError))
	}

	code := exitOK
	subArgs := os.Args[2:]
	switch os.Args[1] {
	case "extract":
		code = extract(db, subArgs)
	case "insert":
		code = insert(db, subArgs)
	default:
		fmt.Printf("error: unknown command: %q\n", os.Args[1])
		code = exitError
	}

	os.Exit(int(code))
}
