package main

import (
	"encoding/csv"
	"flag"
	"fmt"
	"os"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"

	"github.com/PolygonPictures/central30-web/front/repository/model"
)

func insert(db *gorm.DB, args []string) exitCode {
	fs := flag.NewFlagSet("extract", flag.ExitOnError)
	batchSize := fs.Uint("batchsize", 100, "number of insert records per commit")
	createdBy := fs.String("createdby", "", "value of `created_by` field")
	fs.Parse(args)

	r := csv.NewReader(os.Stdin)
	records, err := r.ReadAll()
	if err != nil {
		fmt.Printf("error: failed to read csv: %s\n", err)
		return exitError
	}

	if len(records) == 0 {
		fmt.Println("error: no record")
		return exitError
	}

	fmt.Printf("records: %d\n", len(records))

	var groupDirs []*model.GroupDirectory
	for _, record := range records {
		groupPath, err := NewGroupPathFromRecord(record)
		if err != nil {
			fmt.Printf("error: failed to create group path from record: %s\n", err)
			return exitError
		}
		groupDir := groupPath.ToGroupDirectory(*createdBy)
		groupDirs = append(groupDirs, groupDir)
	}

	onConflict := clause.OnConflict{DoNothing: true}
	result := db.Clauses(onConflict).CreateInBatches(groupDirs, int(*batchSize))
	fmt.Printf("rows affected: %d\n", result.RowsAffected)
	if err := result.Error; err != nil {
		fmt.Printf("error: %s\n", err)
		return exitError
	}

	return exitOK
}
