package main

import (
	"io"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/PolygonPictures/central30-web/front/testutil"
)

func TestNewGroupNumInfo(t *testing.T) {
	type pref struct {
		project, key, group string
	}

	tests := []struct {
		name   string
		preset []pref
		want   GroupNumInfo
	}{
		{
			name:   "no preference",
			preset: []pref{},
			want:   GroupNumInfo{},
		},
		{
			name: "single root",
			preset: []pref{
				{"potoodev", "/ppip/roots/assets/groups", "asset"},
			},
			want: GroupNumInfo{
				{"potoodev", "assets"}: 1,
			},
		},
		{
			name: "multiple roots",
			preset: []pref{
				{"potoodev", "/ppip/roots/assets/groups", "asset"},
				{"potoodev", "/ppip/roots/shots/groups", "episode,sequence,shot"},
			},
			want: GroupNumInfo{
				{"potoodev", "assets"}: 1,
				{"potoodev", "shots"}:  3,
			},
		},
		{
			name: "multiple projects",
			preset: []pref{
				{"potoodev", "/ppip/roots/assets/groups", "asset"},
				{"potoo", "/ppip/roots/shots/groups", "episode,sequence,shot"},
			},
			want: GroupNumInfo{
				{"potoodev", "assets"}: 1,
				{"potoo", "shots"}:     3,
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)

			for _, p := range test.preset {
				testutil.AddProjectPreference(t, testDB, p.project, p.key, &p.group)
			}

			info, err := newGroupNumInfo(testDB)
			assert.Nil(t, err)
			assert.Equal(t, test.want, info)
		})
	}
}

func TestGroupNumInfo_Get(t *testing.T) {
	tests := map[string]struct {
		info          GroupNumInfo
		project, root string
		want          int
	}{
		"not found": {
			info:    GroupNumInfo{},
			project: "potoodev",
			root:    "assets",
			want:    0,
		},
		"found": {
			info:    GroupNumInfo{{"potoodev", "assets"}: 1},
			project: "potoodev",
			root:    "assets",
			want:    1,
		},
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			assert.Equal(t, test.want, test.info.get(test.project, test.root))
		})
	}
}

func TestGroupNumInfo_Set(t *testing.T) {
	info := GroupNumInfo{}
	info.set("potoodev", "assets", 1)
	want := GroupNumInfo{{"potoodev", "assets"}: 1}
	assert.Equal(t, want, info)
}

func TestParseToGroupPaths(t *testing.T) {
	tests := map[string]struct {
		info          GroupNumInfo
		project, path string
		want          []GroupPath
	}{
		"single group": {
			info:    GroupNumInfo{{"potoodev", "assets"}: 1},
			project: "potoodev",
			path:    "shared/publish/assets/testHero",
			want: []GroupPath{
				{
					Project:    "potoodev",
					Path:       "shared/publish/assets/testHero",
					Root:       "assets",
					Depth:      4,
					GroupDepth: 1,
				},
			},
		},
		"multiple groups": {
			info:    GroupNumInfo{{"potoodev", "shots"}: 3},
			project: "potoodev",
			path:    "shared/publish/shots/ep01/sq01/sh01",
			want: []GroupPath{
				{
					Project:    "potoodev",
					Path:       "shared/publish/shots/ep01",
					Root:       "shots",
					Depth:      4,
					GroupDepth: 1,
				},
				{
					Project:    "potoodev",
					Path:       "shared/publish/shots/ep01/sq01",
					Root:       "shots",
					Depth:      5,
					GroupDepth: 2,
				},
				{
					Project:    "potoodev",
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					Root:       "shots",
					Depth:      6,
					GroupDepth: 3,
				},
			},
		},
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			got, err := parseToGroupPaths(test.info, test.project, test.path)
			assert.Nil(t, err)
			assert.Equal(t, test.want, got)
		})
	}
}

func TestExtract(t *testing.T) {
	type pref struct {
		project, key, group string
	}

	tests := []struct {
		name  string
		prefs []pref
		dirs  []model.Directory
		args  []string
		want  string
	}{
		{
			name: "no project",
			prefs: []pref{
				{"potoodev", "/ppip/roots/assets/groups", "asset"},
			},
			dirs: []model.Directory{
				{
					Project: "potoodev",
					Path:    "shared/publish/assets/testHero",
					Status:  "active",
				},
			},
			args: []string{},
			want: "potoodev,shared/publish/assets/testHero,assets,4,1\n",
		},
		{
			name: "project specified",
			prefs: []pref{
				{"potoodev", "/ppip/roots/assets/groups", "asset"},
				{"potoo", "/ppip/roots/shots/groups", "episode,sequence,shot"},
			},
			dirs: []model.Directory{
				{
					Project: "potoodev",
					Path:    "shared/publish/assets/testHero",
					Status:  "active",
				},
				{
					Project: "potoo",
					Path:    "shared/publish/shots/ep01/sq01/sh01",
					Status:  "active",
				},
			},
			args: []string{"-project", "potoo"},
			want: `potoo,shared/publish/shots/ep01,shots,4,1
potoo,shared/publish/shots/ep01/sq01,shots,5,2
potoo,shared/publish/shots/ep01/sq01/sh01,shots,6,3
`,
		},
		{
			name: "dedup",
			prefs: []pref{
				{"potoo", "/ppip/roots/shots/groups", "episode,sequence,shot"},
			},
			dirs: []model.Directory{
				{
					Project: "potoo",
					Path:    "shared/publish/shots/ep01/sq01",
					Status:  "active",
				},
				{
					Project: "potoo",
					Path:    "shared/publish/shots/ep01/sq02",
					Status:  "active",
				},
			},
			args: []string{},
			want: `potoo,shared/publish/shots/ep01,shots,4,1
potoo,shared/publish/shots/ep01/sq01,shots,5,2
potoo,shared/publish/shots/ep01/sq02,shots,5,2
`,
		},
		{
			name:  "missing groups in pipipline setting (est3-test)",
			prefs: nil,
			dirs: []model.Directory{
				{
					Project: "est3",
					Path:    "shared/publish/test/test/test",
					Status:  "active",
				},
			},
			args: []string{},
			want: `est3,shared/publish/test/test,test,4,1
est3,shared/publish/test/test/test,test,5,2
`,
		},
		{
			name:  "missing groups in pipipline setting (hm-previz)",
			prefs: nil,
			dirs: []model.Directory{
				{
					Project: "hm",
					Path:    "shared/publish/previz/ep01/sq01/sh01",
					Status:  "active",
				},
			},
			args: []string{},
			want: `hm,shared/publish/previz/ep01,previz,4,1
hm,shared/publish/previz/ep01/sq01,previz,5,2
hm,shared/publish/previz/ep01/sq01/sh01,previz,6,3
`,
		},
		{
			name:  "missing groups in pipipline setting (pol-library)",
			prefs: nil,
			dirs: []model.Directory{
				{
					Project: "pol",
					Path:    "shared/publish/library/a/b",
					Status:  "active",
				},
			},
			args: []string{},
			want: `pol,shared/publish/library/a,library,4,1
pol,shared/publish/library/a/b,library,5,2
`,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			for _, p := range test.prefs {
				testutil.AddProjectPreference(t, testDB, p.project, p.key, &p.group)
			}
			for _, d := range test.dirs {
				testDB.Create(&d)
			}

			oldStdout := os.Stdout
			defer func() {
				os.Stdout = oldStdout
			}()

			r, w, err := os.Pipe()
			require.Nil(t, err)
			defer r.Close()
			defer w.Close()

			os.Stdout = w
			code := extract(testDB, test.args)
			os.Stdout = oldStdout
			w.Close()

			out, err := io.ReadAll(r)
			require.Nil(t, err)
			assert.Equal(t, exitOK, code)
			assert.Equal(t, test.want, string(out))
		})
	}
}
