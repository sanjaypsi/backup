package main

import (
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/stretchr/testify/assert"

	"github.com/PolygonPictures/central30-web/front/repository/model"
)

func TestGroupPath_ToRecord(t *testing.T) {
	gp := GroupPath{
		Project:    "potoodev",
		Path:       "shared/publish/assets/testHero",
		Root:       "assets",
		Depth:      4,
		GroupDepth: 1,
	}
	got := gp.ToRecord()
	want := []string{"potoodev", "shared/publish/assets/testHero", "assets", "4", "1"}
	assert.Equal(t, want, got)
}

func TestToGroupDirectory(t *testing.T) {
	ptr := func(s string) *string {
		return &s
	}

	gp := GroupPath{
		Project:    "potoodev",
		Path:       "shared/publish/assets/testHero",
		Root:       "assets",
		Depth:      4,
		GroupDepth: 1,
	}
	got := gp.ToGroupDirectory("testuser")
	want := &model.GroupDirectory{
		Project:    "potoodev",
		Root:       "assets",
		Depth:      4,
		Path:       "shared/publish/assets/testHero",
		GroupDepth: 1,
		Status:     "active",
		CreatedBy:  ptr("testuser"),
		ModifiedBy: ptr("testuser"),
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(t, cmp.Diff(want, got, diffOpt))
}

func TestNewGroupPathFromRecord(t *testing.T) {
	record := []string{"potoodev", "shared/publish/assets/testHero", "assets", "4", "1"}
	got, err := NewGroupPathFromRecord(record)
	want := &GroupPath{
		Project:    "potoodev",
		Path:       "shared/publish/assets/testHero",
		Root:       "assets",
		Depth:      4,
		GroupDepth: 1,
	}
	assert.Nil(t, err)
	assert.Equal(t, want, got)
}
