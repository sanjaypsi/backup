package main

import (
	"fmt"
	"os"
	"strconv"

	_ "github.com/go-sql-driver/mysql"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/gorm/schema"

	"github.com/PolygonPictures/central30-web/front/repository/model"
)

type exitCode int

const (
	exitOK    exitCode = 0
	exitError exitCode = 1

	dbName = "central30"
)

type GroupPath struct {
	Project    string
	Path       string
	Root       string
	Depth      int
	GroupDepth int
}

func (gp GroupPath) ToRecord() []string {
	return []string{
		gp.Project,
		gp.Path,
		gp.Root,
		strconv.Itoa(gp.Depth),
		strconv.Itoa(gp.GroupDepth),
	}
}

func (gp GroupPath) ToGroupDirectory(createdBy string) *model.GroupDirectory {
	return model.NewGroupDirectory(
		gp.Project,
		gp.Root,
		int32(gp.Depth),
		gp.Path,
		int32(gp.GroupDepth),
		createdBy,
	)
}

func NewGroupPathFromRecord(record []string) (*GroupPath, error) {
	if len(record) != 5 {
		return nil, fmt.Errorf("unexpected number of fields: %v", record)
	}

	depth, err := strconv.Atoi(record[3])
	if err != nil {
		return nil, fmt.Errorf("failed to convert string to int for depth field: %v", record)
	}

	groupDepth, err := strconv.Atoi(record[4])
	if err != nil {
		return nil, fmt.Errorf("failed to convert string to int for group-depth field: %v", record)
	}

	return &GroupPath{
		Project:    record[0],
		Path:       record[1],
		Root:       record[2],
		Depth:      depth,
		GroupDepth: groupDepth,
	}, nil
}

func openMySQLFromEnv(db string) (*gorm.DB, error) {
	user := os.Getenv("GRPDIRGEN_MYSQL_USER")
	password := os.Getenv("GRPDIRGEN_MYSQL_PASSWORD")
	host := os.Getenv("GRPDIRGEN_MYSQL_HOST")
	port := os.Getenv("GRPDIRGEN_MYSQL_PORT")
	nport, err := strconv.Atoi(port)
	if err != nil {
		nport = 3306
	}

	return openMySQL(user, password, host, nport, db)
}

func openMySQL(user, password, host string, port int, db string) (*gorm.DB, error) {
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=1&loc=Local", user, password, host, port, db)
	config := &gorm.Config{
		SkipDefaultTransaction: true,
		NamingStrategy: schema.NamingStrategy{
			TablePrefix:   "t_",
			SingularTable: true,
		},
		Logger: logger.Default.LogMode(logger.Silent),
	}
	return gorm.Open(mysql.Open(dsn), config)
}
