package main

import (
	"fmt"
	"os"
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/PolygonPictures/central30-web/front/testutil"
)

func TestInsert(t *testing.T) {
	ptr := func(s string) *string {
		return &s
	}

	testutil.SetupTablesWithCleanup(t, testDB)

	oldStdin := os.Stdin
	defer func() {
		os.Stdin = oldStdin
	}()

	r, w, err := os.Pipe()
	require.Nil(t, err)
	defer r.Close()
	defer w.Close()

	os.Stdin = r
	fmt.Fprintln(w, "potoodev,shared/publish/assets/testHero,assets,4,1")
	w.Close()
	code := insert(testDB, []string{})
	os.Stdin = oldStdin

	assert.Equal(t, exitOK, code)

	var got []*model.GroupDirectory
	result := testDB.Find(&got)
	assert.Nil(t, result.Error)
	assert.Equal(t, int64(1), result.RowsAffected)

	want := []*model.GroupDirectory{
		{
			Project:    "potoodev",
			Root:       "assets",
			Depth:      4,
			Path:       "shared/publish/assets/testHero",
			GroupDepth: 1,
			Status:     "active",
			CreatedBy:  ptr(""),
			ModifiedBy: ptr(""),
		},
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(t, cmp.Diff(want, got, diffOpt))
}

func TestInsert2(t *testing.T) {
	ptr := func(s string) *string {
		return &s
	}

	tests := []struct {
		name      string
		args      []string
		input     string
		numInsert int
		want      []*model.GroupDirectory
	}{
		{
			name:      "no createdby",
			args:      []string{},
			input:     "potoodev,shared/publish/assets/testHero,assets,4,1",
			numInsert: 1,
			want: []*model.GroupDirectory{
				{
					Project:    "potoodev",
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     "active",
					CreatedBy:  ptr(""),
					ModifiedBy: ptr(""),
				},
			},
		},
		{
			name:      "createdby specified",
			args:      []string{"-createdby", "testuser"},
			input:     "potoodev,shared/publish/assets/testHero,assets,4,1",
			numInsert: 1,
			want: []*model.GroupDirectory{
				{
					Project:    "potoodev",
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     "active",
					CreatedBy:  ptr("testuser"),
					ModifiedBy: ptr("testuser"),
				},
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)

			oldStdin := os.Stdin
			defer func() {
				os.Stdin = oldStdin
			}()

			r, w, err := os.Pipe()
			require.Nil(t, err)
			defer r.Close()
			defer w.Close()

			os.Stdin = r
			fmt.Fprintln(w, test.input)
			w.Close()
			code := insert(testDB, test.args)
			os.Stdin = oldStdin

			assert.Equal(t, exitOK, code)

			var got []*model.GroupDirectory
			result := testDB.Find(&got)
			assert.Nil(t, result.Error)
			assert.Equal(t, int64(test.numInsert), result.RowsAffected)

			diffOpt := cmpopts.IgnoreFields(
				model.GroupDirectory{},
				"ID",
				"CreatedAtUTC",
				"ModifiedAtUTC",
			)

			assert.Empty(t, cmp.Diff(test.want, got, diffOpt))
		})
	}
}
