# grpdirGen: グループ階層のディレクトリ情報を取得・追加するコマンド

MySQL の `t_directory` テーブルからグループ階層のディレクトリ情報を取得し、それを `t_group_directory` テーブルに追加する作業に使用したコマンドです。

使用方法: front/server/grpdirGen ディレクトリで以下のように実行します。

```console
# MySQL への接続情報を環境変数に設定
$ export GRPDIRGEN_MYSQL_HOST=<host>
$ export GRPDIRGEN_MYSQL_PORT=<port>
$ export GRPDIRGEN_MYSQL_PASSWORD=<password>
$ export GRPDIRGEN_MYSQL_USER=<user>

# t_directory テーブルから、指定されたプロジェクトのグループ階層のディレクト
# リ情報をCSVファイルに書き出す。
$ go run . extract -project=<project> > <project>.csv

# extract コマンドが出力したグループ階層のディレクトリ情報を t_group_directory テーブルに追加する。
# デフォルトでは100件毎にコミットされ、created_by と modified_by フィールドには空文字列が設定される。
# この挙動は -batchsize および -createdby オプションで変更可能。
$ go run . insert < <project>.csv
```
