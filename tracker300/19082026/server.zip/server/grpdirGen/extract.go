package main

import (
	"cmp"
	"encoding/csv"
	"flag"
	"fmt"
	"os"
	"slices"
	"strings"

	"github.com/PolygonPictures/central30-web/front/repository/model"
	"gorm.io/gorm"
)

const (
	publishDepth = 2
	rootDepth    = 3
)

type GroupNumInfo map[[2]string]int

func newGroupNumInfo(db *gorm.DB) (GroupNumInfo, error) {
	stmt := db.Where(
		"`section_type` = ?", "project",
	).Where(
		"`key` REGEXP ?", "/ppip/roots/[a-z]+/groups",
	).Where(
		"`deleted` = ?", 0,
	)

	var prefs []*model.PreferenceEntry
	if result := stmt.Find(&prefs); result.Error != nil {
		return nil, fmt.Errorf("failed to get group num info: %w", result.Error)
	}

	info := GroupNumInfo{}
	for _, pref := range prefs {
		if pref.Value != nil {
			project := pref.SectionName
			root, _, _ := strings.Cut(strings.TrimPrefix(pref.Key, "/ppip/roots/"), "/")
			value := len(strings.Split(*pref.Value, ","))
			info.set(project, root, value)
		}
	}

	return info, nil
}

func (info GroupNumInfo) get(project, root string) int {
	key := [2]string{project, root}
	return info[key]
}

func (info GroupNumInfo) set(project, root string, num int) {
	key := [2]string{project, root}
	info[key] = num
}

func parseToGroupPaths(info GroupNumInfo, project, path string) ([]GroupPath, error) {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	depth := len(parts)

	if depth >= publishDepth && !slices.Equal(parts[:publishDepth], []string{"shared", "publish"}) {
		return nil, nil
	}

	if depth <= rootDepth {
		return nil, nil
	}

	root := parts[rootDepth-1]
	numGroups := info.get(project, root)
	if numGroups < 1 {
		return nil, fmt.Errorf("failed to get number of groups: project=%s, path=%s", project, path)
	}

	var groupPaths []GroupPath
	for i := rootDepth + 1; i <= depth && i <= rootDepth+numGroups; i++ {
		path := strings.Join(parts[:i], "/")
		groupPath := GroupPath{
			Project:    project,
			Path:       path,
			Root:       root,
			Depth:      i,
			GroupDepth: i - rootDepth,
		}
		groupPaths = append(groupPaths, groupPath)
	}

	return groupPaths, nil
}

func extract(db *gorm.DB, args []string) exitCode {
	fs := flag.NewFlagSet("extract", flag.ExitOnError)
	project := fs.String("project", "", "Project key name")
	fs.Parse(args)

	groupNumInfo, err := newGroupNumInfo(db)
	if err != nil {
		fmt.Printf("error: failed to get group number info: %s", err)
		return exitError
	}

	// est3のtest、hmのpreviz、polのlibraryはパイプライン設定にグループの設
	// 定が存在しないため既存パスから推測した値を追加する
	groupNumInfo.set("est3", "test", 2)
	groupNumInfo.set("hm", "previz", 3)
	groupNumInfo.set("pol", "library", 2)

	stmt := db
	if *project != "" {
		stmt = stmt.Where("project = ?", *project)
	}
	stmt = stmt.Where("deleted = ?", 0)

	var ms []*model.Directory
	if result := stmt.Find(&ms); result.Error != nil {
		fmt.Printf("error: failed to extract: %s", result.Error)
		return exitError
	}

	seen := make(map[GroupPath]struct{})
	for _, m := range ms {
		groupPaths, err := parseToGroupPaths(groupNumInfo, m.Project, m.Path)
		if err != nil {
			fmt.Fprintf(os.Stderr, "warning: failed to parse to group paths: %s\n", err)
			continue
		}
		for _, groupPath := range groupPaths {
			seen[groupPath] = struct{}{}
		}
	}

	groupPaths := make([]GroupPath, 0, len(seen))
	for groupPath := range seen {
		groupPaths = append(groupPaths, groupPath)
	}

	slices.SortFunc(groupPaths, func(a, b GroupPath) int {
		if n := strings.Compare(a.Project, b.Project); n != 0 {
			return n
		}
		return cmp.Compare(a.Path, b.Path)
	})

	var records [][]string
	for _, gp := range groupPaths {
		records = append(records, gp.ToRecord())
	}

	w := csv.NewWriter(os.Stdout)
	w.WriteAll(records)
	if err := w.Error(); err != nil {
		fmt.Printf("error: failed to writing csv: %s", err)
		return exitError
	}

	return exitOK
}
