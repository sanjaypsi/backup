# Publish-notifier settings command-line tool

### Create property and value of pipeline setting for publish-notifier

```bash
cd front\server\publishNotifierSetting

# run main.go directly by executing go run, without generating an executable
go run ./main.go \
  -protocol https \
  -domain <server_domain (e.g. example.co.jp)>  \
  -filepath <absolute_path_to_ssvfile (e.g. D:\example.ssv)> \
  -project <project_keyname> \
  -defaultEmailAddress <email_address> \
  -user $USERNAME \
  -keyCol 4 \
  -valueCol 3 \
  -token <decoded_token_string>
```
