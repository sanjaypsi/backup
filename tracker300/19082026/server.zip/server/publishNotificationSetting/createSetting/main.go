package main

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
)

type JSONSchema struct {
	Type    string      `json:"type"`
	Items   *JSONSchema `json:"items,omitempty"`
	Default []string    `json:"default,omitempty"`
	Pattern *string     `json:"pattern,omitempty"`
}

type Property struct {
	Key       string      `json:"key"`
	Schema    *JSONSchema `json:"schema"`
	CreatedBy string      `json:"created_by"`
}

type Value struct {
	Key       string   `json:"key"`
	Value     []string `json:"value"`
	CreatedBy string   `json:"created_by"`
}

func main() {
	// CLI args
	protocol := flag.String("protocol", "https", "[Optional] Communication protocol (e.g. https)")
	domain := flag.String(
		"domain",
		"",
		"Domain name of the server a request heads for (e.g. ppip30dev-web.polygonpictures.jp)",
	)
	filepath := flag.String("filepath", "", "Absolute path of TSV file (e.g. D:\\example.tsv)")
	project := flag.String(
		"project",
		"",
		"Name of project to be set email addresses (e.g. potoodev)",
	)
	token := flag.String("token", "", "Decoded token string")
	defaultEmailAddress := flag.String(
		"defaultEmailAddress",
		"",
		"[Optional] One or more default comma-separated email addresses (e.g. a@ppi.co.jp,b@ppi.co.jp)",
	)
	user := flag.String(
		"user",
		os.Getenv("USERNAME"),
		"[Optional] Username displayed in createdBy and modifiedBy",
	)
	keyCol := flag.String(
		"keyCol",
		"4",
		"[Optional] Column index holding key of pipeline setting",
	)
	valueCol := flag.String(
		"valueCol",
		"3",
		"[Optional] Column index holding value of pipeline setting",
	)

	// Check if arguments are entered properly
	flag.Parse()
	if *domain == "" {
		fmt.Printf("Error: -domain is required")
		return
	}
	if *filepath == "" {
		fmt.Printf("Error: -filepath is required")
		return
	}
	if *project == "" {
		fmt.Printf("Error: -project is required")
		return
	}
	if *token == "" {
		fmt.Printf("Error: -token is required")
		return
	}

	// Parse TSV file
	f, err := os.Open(*filepath)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()

	reader := csv.NewReader(f)
	reader.Comma = '\t'

	// Read TSV by line
	client := &http.Client{}
	for {
		row, err := reader.Read()
		if err != nil {
			log.Fatal(err)
		}

		// Create Property of PipelineSetting
		keyIndex, err := strconv.Atoi(*keyCol)
		if err != nil {
			panic(err)
		}
		key := row[keyIndex]
		tidyDefValues := []string{}
		for _, v := range strings.Split(*defaultEmailAddress, ",") {
			if v == "" {
				continue
			}
			tidyDefValues = append(tidyDefValues, v)
		}
		pattern := "^[a-zA-Z0-9_-]+@(ppi.co.jp|ppi-my.com)$"
		schema := JSONSchema{
			Type: "array",
			Items: &JSONSchema{
				Type:    "string",
				Pattern: &pattern,
			},
			Default: tidyDefValues,
		}
		property := Property{
			Key:       key,
			Schema:    &schema,
			CreatedBy: *user,
		}
		propertyBody, err := json.Marshal(property)
		if err != nil {
			panic(err)
		}

		// Send request to create property
		req, err := http.NewRequest(
			"POST",
			fmt.Sprintf("%s://%s/api/pipelineSetting/preference/properties", *protocol, *domain),
			bytes.NewBuffer(propertyBody),
		)
		if err != nil {
			panic(err)
		}
		req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", *token))
		req.Header.Add("Content-Type", "application/json")

		res, err := client.Do(req)
		if err != nil {
			panic(err)
		}
		defer res.Body.Close()
		if res.StatusCode != http.StatusCreated {
			log.Printf("Catch error response (%s) in creating key '%s':\n", res.Status, key)
		} else {
			log.Printf(
				"Properties for key '%s' is successfully created\n",
				key,
			)
		}

		// Create Value of PipelineSetting
		valueIndex, err := strconv.Atoi(*valueCol)
		if err != nil {
			panic(err)
		}
		tidyValues := []string{}
		for _, v := range strings.Split(row[valueIndex], ",") {
			if v == "" {
				continue
			}
			tidyValues = append(tidyValues, v)
		}
		tidyValues = append(tidyValues, tidyDefValues...)
		value := Value{
			Key:       key,
			Value:     tidyValues,
			CreatedBy: *user,
		}
		valueBody, err := json.Marshal(value)
		if err != nil {
			panic(err)
		}

		// Send request to create Value
		req, err = http.NewRequest(
			"POST",
			fmt.Sprintf(
				"%s://%s/api/pipelineSetting/preference/projects/%s/values",
				*protocol,
				*domain,
				*project,
			),
			bytes.NewBuffer(valueBody),
		)
		if err != nil {
			panic(err)
		}
		req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", *token))
		req.Header.Add("Content-Type", "application/json")

		res, err = client.Do(req)
		if err != nil {
			panic(err)
		}
		defer res.Body.Close()
		if res.StatusCode != http.StatusCreated {
			log.Printf(
				"Catch error response (%s) in creating value '%s' for key '%s':\n",
				res.Status,
				tidyValues,
				key,
			)
		} else {
			log.Printf(
				"Value '%s' for key '%s' is successfully created\n",
				tidyValues,
				key,
			)
		}
		if err == io.EOF {
			break
		}
	}

	log.Printf("Program finished")
}
