# Publish-notifier settings command-line tool

### Update property of pipeline setting for publish-notifier

```bash
cd front\server\publishNotifierSetting

# run main.go directly by executing go run, without generating an executable
go run ./main.go \
  -protocol https \
  -domain <server_domain (e.g. example.co.jp)>  \
  -defaultEmailAddress <email_address> \
  -pattern "^[a-zA-Z0-9_-]+@example.com$" \
  -token <decoded_token_string>
```
