package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
)

type JSONSchema struct {
	Type    string      `json:"type"`
	Items   *JSONSchema `json:"items,omitempty"`
	Default []string    `json:"default,omitempty"`
	Pattern *string     `json:"pattern,omitempty"`
}

type PropertyResponse struct {
	Properties []map[string]interface{} `json:"properties"`
}

type PropertyUpdateRequest struct {
	Schema   *JSONSchema `json:"schema"`
	Required bool        `json:"required"`
}

func main() {
	protocol := flag.String("protocol", "https", "[Optional] Communication protocol (e.g. https)")
	domain := flag.String(
		"domain",
		"",
		"Domain name of the server a request heads for (e.g. ppip30dev-web.polygonpictures.jp)",
	)
	defaultEmailAddress := flag.String(
		"defaultEmailAddress",
		"",
		"[Optional] One or more default comma-separated email addresses (e.g. a@ppi.co.jp,b@ppi.co.jp)",
	)
	pattern := flag.String(
		"pattern",
		"",
		"pattern for JSONSchema written in regular expressions",
	)
	token := flag.String("token", "", "Decoded token string")

	flag.Parse()
	if *domain == "" {
		fmt.Printf("Error: -domain is required")
		return
	}
	if *token == "" {
		fmt.Printf("Error: -token is required")
		return
	}

	baseURL := fmt.Sprintf("%s://%s", *protocol, *domain)
	params := url.Values{}
	params.Add("search_key", "/ppip/roots/%%/phases/%%/%%/%%/emailAddress")
	u, _ := url.ParseRequestURI(baseURL)
	u.Path = "/api/pipelineSetting/preference/properties"
	u.RawQuery = params.Encode()
	urlStr := fmt.Sprintf("%v", u)

	req, err := http.NewRequest("GET", urlStr, nil)
	if err != nil {
		panic(err)
	}
	req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", *token))
	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	b, _ := io.ReadAll(res.Body)
	fmt.Printf("%s", b)
	settingResponse := PropertyResponse{}
	if err := json.Unmarshal(b, &settingResponse); err != nil {
		panic(err)
	}
	tidyDefValues := []string{}
	for _, v := range strings.Split(*defaultEmailAddress, ",") {
		if v == "" {
			continue
		}
		tidyDefValues = append(tidyDefValues, v)
	}
	schema := JSONSchema{
		Type: "array",
		Items: &JSONSchema{
			Type:    "string",
			Pattern: pattern,
		},
		Default: tidyDefValues,
	}

	u, _ = url.ParseRequestURI(baseURL)
	for _, setting := range settingResponse.Properties {
		key, ok := setting["key"].(string)
		if !ok {
			continue
		}
		u.Path = "/api/pipelineSetting/preference/properties/" + key
		urlStr = fmt.Sprintf("%v", u)
		value := PropertyUpdateRequest{
			Schema:   &schema,
			Required: false,
		}
		valueBody, err := json.Marshal(value)
		if err != nil {
			panic(err)
		}
		req, err = http.NewRequest(
			"PATCH",
			urlStr,
			bytes.NewBuffer(valueBody),
		)
		if err != nil {
			panic(err)
		}
		req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", *token))
		req.Header.Add("Content-Type", "application/json")

		res, err = client.Do(req)
		if err != nil {
			panic(err)
		}
		defer res.Body.Close()
		fmt.Println("Success:" + key)
	}
}
