package service

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/PolygonPictures/central30-web/front/entity"
)

// CentralService represents the service of Central.
type CentralService struct {
	myRepo    entity.InfoRepository
	mongoRepo entity.DocumentRepository
}

// NewCentralService is a function that creates a new CentralService.
func NewCentralService(
	myRepo entity.InfoRepository,
	mongoRepo entity.DocumentRepository,
) *CentralService {
	return &CentralService{
		myRepo:    myRepo,
		mongoRepo: mongoRepo,
	}
}

// GetProjectByName is a method that returns the project object corresponding to the name.
func (s *CentralService) GetProjectByName(ctx context.Context, name string) (*entity.Project, error) {
	info, err := s.myRepo.GetProjectByName(ctx, name)
	if err != nil {
		return nil, fmt.Errorf("project %q not found", name)
	}
	return entity.NewProject(info, s.myRepo, s.mongoRepo), nil
}

// BeginTx is a method that creates a new Tx object.
func (s *CentralService) BeginTx(ctx context.Context, opts *sql.TxOptions) (*sql.Tx, error) {
	return s.myRepo.BeginTx(ctx, opts)
}
