from typing import Any

from ppui.PySide.QtWidgets import (
    QDialog,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .apiClient import ApiClient


class HistoryDialog(QDialog):
    def __init__(self, api: ApiClient, entityID: Any, parent: QWidget | None = None):
        super().__init__(parent)
        self._api = api
        self._entityID = entityID
        self.setWindowTitle('History')
        self.resize(800, 400)

        layout = QVBoxLayout(self)
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(['Time', 'User', 'Studio', 'Snapshot', 'Action'])
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)

        self.loadHistory()

    def loadHistory(self):
        histories = self._api.getHistory(self._entityID)
        self.table.setRowCount(len(histories))

        for i, h in enumerate(histories):
            ts = h.get('modified_at_utc', '')
            user = h.get('modified_by', '')
            studio = h.get('studio', '')
            data_summary = str(h.get('snapshot', {}).get('data', {}))

            self.table.setItem(i, 0, QTableWidgetItem(str(ts)))
            self.table.setItem(i, 1, QTableWidgetItem(user))
            self.table.setItem(i, 2, QTableWidgetItem(studio))
            self.table.setItem(i, 3, QTableWidgetItem(data_summary))

            btn = QPushButton('Rollback')
            btn.clicked.connect(lambda checked, hid=h['id']: self.doRollback(hid))
            self.table.setCellWidget(i, 4, btn)

    def doRollback(self, historyID: str):
        confirm = QMessageBox.question(
            self,
            'Confirm',
            'Revert to this state?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if confirm == QMessageBox.StandardButton.Yes:
            self._api.rollback(self._entityID, historyID)
            self.accept()
