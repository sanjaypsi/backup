# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainWindow.ui'
##
## Created by: Qt User Interface Compiler version 6.7.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QMainWindow, QMenu,
    QMenuBar, QPushButton, QSizePolicy, QSpacerItem,
    QStatusBar, QVBoxLayout, QWidget)
from . import icons_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1250, 800)
        self.centralWidget = QWidget(MainWindow)
        self.centralWidget.setObjectName(u"centralWidget")
        self.verticalLayout = QVBoxLayout(self.centralWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(5, 5, 5, 5)
        self.widget = QWidget(self.centralWidget)
        self.widget.setObjectName(u"widget")
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.refreshButton = QPushButton(self.widget)
        self.refreshButton.setObjectName(u"refreshButton")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.refreshButton.sizePolicy().hasHeightForWidth())
        self.refreshButton.setSizePolicy(sizePolicy)
        self.refreshButton.setMinimumSize(QSize(80, 0))
        icon = QIcon()
        icon.addFile(u":/refresh_w.png", QSize(), QIcon.Normal, QIcon.Off)
        self.refreshButton.setIcon(icon)

        self.horizontalLayout.addWidget(self.refreshButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.roleManagerButton = QPushButton(self.widget)
        self.roleManagerButton.setObjectName(u"roleManagerButton")
        self.roleManagerButton.setMinimumSize(QSize(120, 0))

        self.horizontalLayout.addWidget(self.roleManagerButton)

        self.columnManagerButton = QPushButton(self.widget)
        self.columnManagerButton.setObjectName(u"columnManagerButton")
        sizePolicy.setHeightForWidth(self.columnManagerButton.sizePolicy().hasHeightForWidth())
        self.columnManagerButton.setSizePolicy(sizePolicy)
        self.columnManagerButton.setMinimumSize(QSize(120, 0))

        self.horizontalLayout.addWidget(self.columnManagerButton)


        self.verticalLayout.addWidget(self.widget)

        self.selectRootWidget = QWidget(self.centralWidget)
        self.selectRootWidget.setObjectName(u"selectRootWidget")
        self.rootButtonHLayout = QHBoxLayout(self.selectRootWidget)
        self.rootButtonHLayout.setObjectName(u"rootButtonHLayout")
        self.rootButtonHLayout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout.addWidget(self.selectRootWidget)

        MainWindow.setCentralWidget(self.centralWidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1250, 21))
        self.menuHelp = QMenu(self.menubar)
        self.menuHelp.setObjectName(u"menuHelp")
        MainWindow.setMenuBar(self.menubar)

        self.menubar.addAction(self.menuHelp.menuAction())

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"PPI Tracker", None))
        self.refreshButton.setText(QCoreApplication.translate("MainWindow", u" Refresh", None))
        self.roleManagerButton.setText(QCoreApplication.translate("MainWindow", u"Role Manager", None))
        self.columnManagerButton.setText(QCoreApplication.translate("MainWindow", u"Column Manager", None))
        self.menuHelp.setTitle(QCoreApplication.translate("MainWindow", u"Help", None))
    # retranslateUi

