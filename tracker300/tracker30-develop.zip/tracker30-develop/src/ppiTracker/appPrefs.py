from typing import Any, Dict

from ppilib.utils.compat.pathlib import Path
from ppilib.utils.serialize import readJson, writeJson


class AppPrefs(object):
    __slots__ = ('_appPrefsPath', '_columnOrder')

    @classmethod
    def loadFromFile(cls, filePath: Path) -> 'AppPrefs':
        data: Dict[str, Any] = readJson(filePath) if filePath.exists() else {}
        columnOrder: dict[str, dict[str, list[str]]] = data.get('column_order', {})
        return cls(columnOrder, filePath)

    def __init__(self, columnOrder: dict[str, dict[str, list[str]]], filePath: Path) -> None:
        self._appPrefsPath = filePath
        self._columnOrder = columnOrder

    def columnOrder(self, projectKeyName: str, root: str) -> list[str]:
        if projectKeyName not in self._columnOrder or root not in self._columnOrder[projectKeyName]:
            if projectKeyName not in self._columnOrder:
                self._columnOrder[projectKeyName] = {}
            self._columnOrder[projectKeyName][root] = []
        return self._columnOrder[projectKeyName][root]

    def setColumnOrder(self, projectKeyName: str, root: str, columnKeys: list[str]) -> None:
        if projectKeyName not in self._columnOrder:
            self._columnOrder[projectKeyName] = {}
        self._columnOrder[projectKeyName][root] = columnKeys

    def asDict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self._columnOrder:
            data['column_order'] = self._columnOrder
        return data

    def saveToFile(self, filePath: Path | None = None) -> None:
        _filePath = filePath
        if _filePath is None:
            _filePath = self._appPrefsPath
        _filePath.parent.mkdir(exist_ok=True, parents=True)
        writeJson(_filePath, self.asDict())
