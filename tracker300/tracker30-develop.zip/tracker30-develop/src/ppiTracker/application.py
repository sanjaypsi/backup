from typing import Sequence

from ppui.PySide.QtWidgets import QApplication
from ppilib.core.launcher import AppInfo


class Application(QApplication):
    def __init__(self, appInfo: AppInfo, argv: Sequence[str]) -> None:
        super(Application, self).__init__(argv)
        self._appInfo = appInfo
        displayName = '%s (v%s)' % (self._appInfo.displayName(), self._appInfo.version())
        self.setApplicationDisplayName(displayName)
