from typing import Any

from ppui.PySide.QtCore import Qt, QEvent, QObject, QTimer, QPoint
from ppui.PySide.QtGui import (
    QColor,
    QMouseEvent,
    QPainter,
    QPaintEvent,
    QPen,
    QStandardItem,
    QStandardItemModel,
)
from ppui.PySide.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QListView,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QWidget,
    QVBoxLayout,
    QTextEdit,
    QSizePolicy,
)

from .apiClient import ApiClient
from .tableData import Column


class ResizableTextEdit(QTextEdit):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setMinimumHeight(60)
        self.setMaximumHeight(300)
        self._resizing = False
        self._dragStartPos = QPoint()
        self._startHeight = 0
        self.setMouseTracking(True)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            vpGeo = self.viewport().geometry()
            bottomRight = vpGeo.bottomRight()
            pos = event.position()
            isXBottomRight = pos.x() <= bottomRight.x()
            isYBottomRight = pos.y() <= bottomRight.y()

            isWidthArea = bottomRight.x() - pos.x() < 15
            isHeightArea = bottomRight.y() - pos.y() < 15
            if isWidthArea and isHeightArea and isXBottomRight and isYBottomRight:
                self._resizing = True
                self._dragStartPos = event.globalPosition().toPoint()
                self._startHeight = self.height()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._resizing:
            delta = event.globalPosition().toPoint().y() - self._dragStartPos.y()
            newHeight = max(60, min(300, self._startHeight + delta))
            self.setFixedHeight(newHeight)
            return

        super().mouseMoveEvent(event)

        vpGeo = self.viewport().geometry()
        bottomRight = vpGeo.bottomRight()
        pos = event.position()
        isXBottomRight = pos.x() <= bottomRight.x()
        isYBottomRight = pos.y() <= bottomRight.y()
        isWidthArea = bottomRight.x() - pos.x() < 15
        isHeightArea = bottomRight.y() - pos.y() < 15
        if isWidthArea and isHeightArea and isXBottomRight and isYBottomRight:
            self.viewport().setCursor(Qt.CursorShape.SizeVerCursor)
        else:
            self.viewport().setCursor(Qt.CursorShape.IBeamCursor)

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        if self._resizing:
            self._resizing = False
            return
        super().mouseReleaseEvent(event)

    def paintEvent(self, event: QPaintEvent):
        super().paintEvent(event)
        # Draw resize grip indicator (three lines)
        painter = QPainter(self.viewport())
        painter.setPen(QPen(QColor(150, 150, 150), 1))
        w = self.viewport().width()
        h = self.viewport().height()

        for i in range(1, 4):
            offset = i * 4
            painter.drawLine(w - offset, h, w, h - offset)


class EntityEditorDialog(QDialog):
    def __init__(
        self,
        api: ApiClient,
        root: str,
        group: str,
        columns: list[Column],
        entity: dict[str, Any] | None = None,
        parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self._api = api
        self._root = root
        self._group = group
        self._columns = columns
        self._entity = entity
        self.setWindowTitle(f'[{root.title()}:{group}] Edit Entity')
        self.resize(500, 600)

        self._mainLayout = QVBoxLayout(self)
        self._scrollArea = QScrollArea()
        self._scrollArea.setWidgetResizable(True)
        self._contentWidget = QWidget()

        self._layout = QFormLayout(self._contentWidget)
        self._widgets: dict[str, tuple[QWidget, str]] = {}
        self._initialData: dict[str, Any] = self._entity.get('data', {}) if self._entity else {}

        self._savedRoot = root
        self._savedGroup = group
        self._savedData = self._initialData

        for col in self._columns:
            if not col.visibled():
                continue

            key = col.key()
            dtype = col.dataType()
            display = col.displayName()
            isSys = col.isSystem()
            scope = 'project' if not col.scope() else col.scope()

            # Show scope in label
            labelText = f'{display}'
            if isSys:
                labelText += ' [System]'
            labelText += ' (Global)' if scope == 'global' else ' (Project)'

            currentVal = self._initialData.get(key)

            widget = None
            if dtype == 'array':
                # select ComboBox
                isMulti = col.config().get('multi_select', False)
                if isMulti:
                    widget = CheckableComboBox()
                else:
                    widget = QComboBox()
                    widget.addItem('')

                # Add options
                opts = col.config().get('options', [])
                widget.addItems(opts)

                # Set current values
                if currentVal is not None:
                    if isMulti:
                        vals = [val.strip() for val in currentVal.split(',')]
                        for v in vals:
                            index = widget.findText(v)
                            if index != -1:
                                widget.model().item(index).setCheckState(Qt.CheckState.Checked)
                    else:
                        widget.setCurrentText(str(currentVal))
            elif dtype == 'int':
                widget = QSpinBox()
                widget.setRange(-999999, 999999)
                if currentVal is not None:
                    try:
                        widget.setValue(int(currentVal))
                    except (ValueError, TypeError):
                        # Align initial data with the widget's fallback value to avoid
                        # overwriting existing values when parsing fails.
                        self._initialData[key] = widget.value()
            elif dtype == 'float':
                widget = QDoubleSpinBox()
                widget.setRange(-999999.99, 999999.99)
                widget.setDecimals(2)
                if currentVal is not None:
                    try:
                        widget.setValue(float(currentVal))
                    except (ValueError, TypeError):
                        # Align initial data with the widget's fallback value to avoid
                        # overwriting existing values when parsing fails.
                        self._initialData[key] = widget.value()
            elif dtype == 'bool':
                widget = QCheckBox()
                widget.setChecked(bool(currentVal))
            elif dtype == 'string':
                widget = ResizableTextEdit()
                if currentVal:
                    widget.setText(str(currentVal))

            if widget is None:
                continue
            self._layout.addRow(f'{labelText}:', widget)
            self._widgets[key] = (widget, dtype)

        self._scrollArea.setWidget(self._contentWidget)
        self._mainLayout.addWidget(self._scrollArea)

        btnSave = QPushButton('Save')
        btnSave.clicked.connect(self.save)
        self._mainLayout.addWidget(btnSave)

    def _collectData(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        for key, (widget, dtype) in self._widgets.items():
            if dtype == 'array':
                if isinstance(widget, CheckableComboBox):
                    data[key] = ', '.join(widget.getCheckedItems())
                else:
                    data[key] = widget.currentText()
            elif dtype == 'int':
                data[key] = widget.value()
            elif dtype == 'float':
                data[key] = widget.value()
            elif dtype == 'bool':
                data[key] = widget.isChecked()
            elif dtype == 'string':
                data[key] = widget.toPlainText()
        return data

    def save(self):
        currentData: dict[str, Any] = self._collectData()
        sendData: dict[str, Any] = {}
        for k, v in currentData.items():
            if v != self._initialData.get(k):
                sendData[k] = v

        if not sendData:
            self.reject()
            return

        if self._entity:
            self._api.updateEntity(self._entity['id'], self._root, self._group, sendData)
        else:
            self._api.createEntity(self._root, self._group, sendData)

        self._savedRoot = self._root
        self._savedGroup = self._group
        self._savedData = currentData
        self.accept()

    def getSavedInfo(self) -> tuple[str, str, dict[str, Any]]:
        return self._savedRoot, self._savedGroup, self._savedData


class CheckableComboBox(QComboBox):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self._model = QStandardItemModel(self)
        self.setModel(self._model)
        self.setView(QListView())
        self._model.itemChanged.connect(self.updateDisplayText)
        self.currentIndexChanged.connect(self.updateDisplayText)
        self.view().viewport().installEventFilter(self)

    def model(self) -> QStandardItemModel:
        return self._model

    def addItem(self, text: str, userData: Any = None):
        item = QStandardItem(text)
        item.setData(userData)
        item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        item.setCheckState(Qt.CheckState.Unchecked)
        self._model.appendRow(item)

    def addItems(self, texts: list[str], userData: list[Any] | None = None):
        if userData is None:
            userData = [None] * len(texts)
        for text, userData in zip(texts, userData):
            self.addItem(text, userData)

    def updateDisplayText(self, _: QStandardItem | None = None):
        def _update():
            checkedItems: list[str] = []
            for index in range(self._model.rowCount()):
                _item = self._model.item(index)
                if _item.checkState() == Qt.CheckState.Checked:
                    checkedItems.append(_item.text())
            text = ', '.join(checkedItems) if checkedItems else ''
            self.lineEdit().setText(text)
        QTimer.singleShot(0, _update)

    def getCheckedItems(self) -> list[str]:
        checkedData: list[str] = []
        for index in range(self._model.rowCount()):
            item = self._model.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                checkedData.append(item.text())
        return checkedData

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if watched == self.view().viewport():
            if event.type() == QEvent.Type.MouseButtonRelease:
                index = self.view().indexAt(event.position().toPoint())
                item = self._model.itemFromIndex(index)
                if item.checkState() == Qt.CheckState.Checked:
                    item.setCheckState(Qt.CheckState.Unchecked)
                else:
                    item.setCheckState(Qt.CheckState.Checked)
                return True
        return False
