import os

from click import (
    Context,
    group,
    option,
    pass_context,
    version_option,
)

from .__version__ import __version__
from .launch import launch


@group(invoke_without_command=True)
@version_option(__version__)
@option('--window', is_flag=True, default=False, help='Show Window.')
@option('-d', '--debug', is_flag=True, default=False, help='Enable debug mode.')
@pass_context
def cli(ctx: Context, window: bool, debug: bool) -> None:
    if ctx.invoked_subcommand is None:
        if not window:
            raise NotImplementedError("Command-line mode is not implemented.")
        result = launch()
        os._exit(result)
