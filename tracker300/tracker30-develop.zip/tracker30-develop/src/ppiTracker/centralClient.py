from enum import Enum
from logging import getLogger

import requests

_logger = getLogger(__name__)


class Groups(Enum):
    CONFIG = 'config'
    ENVIRONMENT = 'environment'
    PREFERENCE = 'preference'

    def __str__(self):
        return self.value


class Sections(Enum):
    COMMON = 'common'
    STUDIO = 'studio'
    PROJECT = 'project'
    USER = 'user'

    def __str__(self):
        return self.value


class CentralClient(object):
    __slots__ = (
        '_centralUrl',
        '_propertylistApi',
        '_preferenceApi',
    )

    def __init__(
        self,
        centralUrl: str,
        propertylistApi: str = '/propertylist',
        preferenceApi: str = '/preference',
    ):
        self._centralUrl = centralUrl
        self._propertylistApi = self._centralUrl + propertylistApi
        self._preferenceApi = self._centralUrl + preferenceApi

    def propertylistApi(self) -> str:
        return self._propertylistApi

    def preferenceApi(self) -> str:
        return self._preferenceApi

    def _buildPropertyRequestPayload(self, group: Groups, key: str) -> list[dict[str, str]]:
        keyType = str(group) + 'Key'
        return [
            dict(key=key, key_type=keyType, property='default', data=''),
            dict(key=key, key_type=keyType, property='required', data=''),
            dict(key=key, key_type=keyType, property='format', data=''),
            dict(key=key, key_type=keyType, property='splitter', data=''),
            dict(key=key, key_type=keyType, property='type', data='list'),
        ]

    def _buildPreferenceRequestPayload(
        self,
        section: Sections,
        entry: str,
        key: str,
        value: list[str],
    ) -> dict[str, str | int | None]:
        return dict(
            section_type=str(section),
            section_name=entry,
            key=key,
            value=','.join(value),
            id=None,
        )

    def property(self, group: Groups, key: str) -> list[dict[str, str | int]] | None:
        keyType = str(group)
        url = f'{self.propertylistApi()}/entries?key_type={keyType + "Key"}&key={key}'
        _logger.debug(f'Fetching property: {url}')
        res = requests.get(url)
        _logger.debug(f'Property response code: {res.status_code}')
        if not res.ok:
            res.raise_for_status()
        resJson = res.json()
        if 'propertylist_entries' not in resJson:
            return
        return resJson['propertylist_entries']

    def preference(
        self,
        section: Sections,
        entry: str,
        key: str,
    ) -> list[dict[str, str | int | None]] | None:
        url: str = (
            f'{self.preferenceApi()}/entries?section_type={section}&section_name={entry}&key={key}'
        )
        _logger.debug(f'Fetching preference: {url}')
        res = requests.get(url)
        _logger.debug(f'Preference response code: {res.status_code}')
        if not res.ok:
            res.raise_for_status()
        resJson = res.json()
        if 'preference_entries' not in resJson:
            return
        return resJson['preference_entries']

    def addProperty(self, group: Groups, key: str) -> list[dict[str, str]]:
        properties = self._buildPropertyRequestPayload(group, key)
        url = self.propertylistApi() + '/entries'
        for record in properties:
            res = requests.post(url, json=record)
            _logger.debug(f'Property response code: {res.status_code}')
            if not res.ok:
                res.raise_for_status()
        return properties

    def addPreference(
        self,
        section: Sections,
        entry: str,
        key: str,
        value: list[str],
    ) -> dict[str, str | int | None]:
        group = Groups.PREFERENCE
        prop = self.property(group, key)
        if prop is None or len(prop) == 0:
            prop = self.addProperty(group, key)

        prefRecord = self._buildPreferenceRequestPayload(section, entry, key, value)
        url = self.preferenceApi() + '/entries'
        _logger.debug(f'Adding preference: {url} with payload: {prefRecord}')
        res = requests.post(url, json=prefRecord)
        _logger.debug(f'Preference response code: {res.status_code}')
        if not res.ok:
            res.raise_for_status()
        resJson = res.json()
        if (
            'preference_entries' in resJson
            and len(resJson['preference_entries']) > 0
            and 'id' in resJson['preference_entries'][0]
        ):
            prefRecord['id'] = resJson['preference_entries'][0]['id']
        return prefRecord

    def upsertPreference(
        self,
        section: Sections,
        entry: str,
        key: str,
        value: list[str],
    ) -> dict[str, str | int | None]:
        # Add preference
        prefs = self.preference(section, entry, key)
        if prefs is None or len(prefs) == 0:
            return self.addPreference(section, entry, key, value)

        # Update preference
        pref = prefs[0]
        if 'id' not in pref:
            raise ValueError('Preference entry does not contain id')
        prefId = pref['id']
        valueStr = ','.join(value)
        jsonValue = {'value': valueStr}
        url = self.preferenceApi() + '/entries/' + str(prefId)
        _logger.debug(f'Updating preference: {url} with payload: {jsonValue}')
        res = requests.patch(url, json=jsonValue)
        _logger.debug(f'Preference update response code: {res.status_code}')
        if not res.ok:
            res.raise_for_status()
        pref['value'] = valueStr
        return pref
