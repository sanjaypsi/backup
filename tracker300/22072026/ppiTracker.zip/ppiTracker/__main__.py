# Copyright © 2025 Polygon Pictures Inc. All rights reserved.

import sys
from logging import DEBUG, INFO

from ppilib.utils.logging import initializeLogging

from .cli import cli


if __name__ == '__main__':
    debug = '--debug' in sys.argv
    initializeLogging(DEBUG if debug else INFO)
    cli(sys.argv[1:])
