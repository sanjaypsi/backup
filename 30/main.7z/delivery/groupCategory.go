package delivery

import (
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/groupCategory"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type GroupCategory struct {
	uc *usecase.GroupCategory
}

func NewGroupCategory(uc *usecase.GroupCategory) *GroupCategory {
	return &GroupCategory{
		uc: uc,
	}
}

type listGroupCategoryParams struct {
	Root          *string    `form:"root"`
	OrderBy       *string    `form:"order_by"`
	ModifiedSince *time.Time `form:"modified_since"`
	Type          *string    `form:"type"`
	PerPage       *int       `form:"per_page"`
	Page          *int       `form:"page"`
}

func (p *listGroupCategoryParams) Params(
	project string,
) *groupCategory.ListParams {
	params := &groupCategory.ListParams{
		Project: project,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}

	if p.OrderBy != nil {
		for _, orderBy := range strings.Split(*p.OrderBy, ",") {
			if strings.HasSuffix(orderBy, "modified_at") {
				orderBy += "_utc"
			}
			params.OrderBy = append(params.OrderBy, orderBy)
		}
	}

	if p.ModifiedSince != nil {
		t := groupCategory.CategoryType
		if p.Type != nil {
			switch strings.ToLower(*p.Type) {
			case "group":
				t = groupCategory.GroupType
			case "category":
				t = groupCategory.CategoryType
			}
		}
		params.SubParams = groupCategory.ListSinceSubParams{
			Type:          t,
			ModifiedSince: p.ModifiedSince,
		}
	} else {
		params.SubParams = groupCategory.ListStandardSubParams{
			Root: p.Root,
		}
	}

	return params
}

func (h *GroupCategory) List(c *gin.Context) {
	var p listGroupCategoryParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}

	params := p.Params(c.Param("project"))
	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	keyName := "categories"
	if sp, ok := params.SubParams.(groupCategory.ListSinceSubParams); ok {
		if sp.Type == groupCategory.GroupType {
			keyName = "groups"
		}
	}

	res := libs.CreateListResponse(
		keyName,
		entities,
		c.Request,
		params,
		int(total),
	)
	c.PureJSON(http.StatusOK, res)
}

func (h *GroupCategory) Get(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	params := &groupCategory.GetParams{
		Project: c.Param("project"),
		ID:      uint32(id),
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type createGroupCategoryParams struct {
	Root      string  `json:"root"`
	Path      string  `json:"path"`
	CreatedBy *string `json:"created_by"`
}

func (p *createGroupCategoryParams) Params(
	project string,
	createdBy *string,
) *groupCategory.CreateParams {
	if createdBy == nil && p.CreatedBy != nil {
		createdBy = p.CreatedBy
	}
	return &groupCategory.CreateParams{
		Project:   project,
		Root:      p.Root,
		Path:      p.Path,
		CreatedBy: createdBy,
	}
}

func (h *GroupCategory) Post(c *gin.Context) {
	var p createGroupCategoryParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	project := c.Param("project")
	params := p.Params(project, nil)
	e, err := h.uc.Create(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

type patchGroupCategoryParams struct {
	Operation  string   `json:"operation"`
	Groups     []string `json:"groups"`
	ModifiedBy *string  `json:"modified_by"`
}

func (p *patchGroupCategoryParams) Params(
	project string,
	id uint32,
	modifiedBy *string,
) *groupCategory.UpdateParams {
	if modifiedBy == nil && p.ModifiedBy != nil {
		modifiedBy = p.ModifiedBy
	}
	return &groupCategory.UpdateParams{
		GetParams: &groupCategory.GetParams{
			Project: project,
			ID:      id,
		},
		Operation:  p.Operation,
		Groups:     p.Groups,
		ModifiedBy: modifiedBy,
	}
}

func (h *GroupCategory) Patch(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	var p patchGroupCategoryParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	project := c.Param("project")
	params := p.Params(project, uint32(id), nil)
	e, err := h.uc.Update(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type deleteGroupCategoryParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deleteGroupCategoryParams) Params(
	project string,
	id uint32,
	modifiedBy *string,
) *groupCategory.DeleteParams {
	if modifiedBy == nil && p.ModifiedBy != nil {
		modifiedBy = p.ModifiedBy
	}
	return &groupCategory.DeleteParams{
		Project:    project,
		ID:         id,
		ModifiedBy: modifiedBy,
	}
}

func (h *GroupCategory) Delete(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	var p deleteGroupCategoryParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	project := c.Param("project")
	params := p.Params(project, uint32(id), nil)
	if err := h.uc.Delete(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}
