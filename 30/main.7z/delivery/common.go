package delivery

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/gin-gonic/gin"
)

func notModified(c *gin.Context, err error) {
	log.Println("INFO:", err)
	c.AbortWithStatus(http.StatusNotModified)
}

func notFound(c *gin.Context, err error) {
	log.Println("ERROR:", err)
	c.AbortWithStatus(http.StatusNotFound)
}

func badRequest(c *gin.Context, err error) {
	log.Println("ERROR:", err)
	c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"message": err.Error()})
}

func unauthorized(c *gin.Context, err error) {
	log.Println("ERROR:", err)
	c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"message": err.Error()})
}

func forbidden(c *gin.Context, err error) {
	log.Println("ERROR:", err)
	c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"message": err.Error()})
}

func internalServerError(c *gin.Context, err error) {
	log.Println("ERROR:", err)
	c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"message": err.Error()})
}

func normalizeStarParam(key string) string {
	if strings.HasPrefix(key, "/") {
		key = key[1:]
	}
	return key
}

type response struct {
	Message string `json:"message"`
}

func getStatus(err error) int {
	if errors.Is(err, entity.ErrNotModified) {
		return http.StatusNotModified
	}
	if errors.Is(err, entity.ErrBadRequest) {
		return http.StatusBadRequest
	}
	if errors.Is(err, entity.ErrUnauthorized) {
		return http.StatusUnauthorized
	}
	if errors.Is(err, entity.ErrForbidden) {
		return http.StatusForbidden
	}
	if errors.Is(err, entity.ErrRecordNotFound) {
		return http.StatusNotFound
	}
	if errors.Is(err, entity.ErrConflict) {
		return http.StatusConflict
	}
	if errors.Is(err, entity.ErrInternalServerError) {
		return http.StatusInternalServerError
	}
	if errors.Is(err, entity.ErrBadGateway) {
		return http.StatusBadGateway
	}
	return http.StatusInternalServerError
}

func jsonError(c *gin.Context, err error) {
	status := getStatus(err)
	if status == http.StatusNotModified {
		c.Status(status)
		return
	}
	c.JSON(status, &response{
		Message: err.Error(),
	})
}

// https://cloud.google.com/logging/docs/structured-logging?hl=ja
type Logger struct {
	entry map[string]interface{}
	mu    sync.Mutex
}

func NewLogger(req *http.Request) entity.Logger {
	return &Logger{
		entry: map[string]interface{}{
			"severity": entity.INFO,
			"httpRequest": &LogHTTPRequest{
				RequestMethod: req.Method,
				RequestURL:    req.RequestURI,
			},
			"created": time.Now().UTC(),
			"labels":  map[string]string{},
		},
	}
}

func (e *Logger) SetLabel(key, value string) {
	labels, ok := e.entry["labels"].(map[string]string)
	if !ok {
		labels = map[string]string{}
		e.entry["labels"] = labels
	}
	labels[key] = value
}

func (e *Logger) SetProject(p string) {
	e.entry["project"] = p
	e.SetLabel("project", p)
}

func (e *Logger) SetStudio(s string) {
	e.entry["studio"] = s
	e.SetLabel("studio", s)
}

func (e *Logger) SetSeverity(s entity.LogSeverity) {
	e.entry["severity"] = s
}

func (e *Logger) SetMessage(m string) {
	e.entry["message"] = m
}

func (e *Logger) Print(msg string) {
	e.SetMessage(msg)
	bytes, _ := json.Marshal(e.entry)
	e.mu.Lock()
	fmt.Println(string(bytes))
	e.mu.Unlock()
}

func (e *Logger) Printf(msg string, args ...interface{}) {
	e.Print(fmt.Sprintf(msg, args...))
}

func (e *Logger) Debug(msg string) {
	e.SetSeverity(entity.DEBUG)
	e.Print(msg)
}

func (e *Logger) Debugf(msg string, args ...interface{}) {
	e.SetSeverity(entity.DEBUG)
	e.Printf(msg, args...)
}

func (e *Logger) Info(msg string) {
	e.SetSeverity(entity.INFO)
	e.Print(msg)
}

func (e *Logger) Infof(msg string, args ...interface{}) {
	e.SetSeverity(entity.INFO)
	e.Printf(msg, args...)
}

func (e *Logger) Warn(msg string) {
	e.SetSeverity(entity.WARNING)
	e.Print(msg)
}

func (e *Logger) Warnf(msg string, args ...interface{}) {
	e.SetSeverity(entity.WARNING)
	e.Printf(msg, args...)
}

func (e *Logger) Error(msg string) {
	e.SetSeverity(entity.ERROR)
	e.Print(msg)
}

func (e *Logger) Errorf(msg string, args ...interface{}) {
	e.SetSeverity(entity.ERROR)
	e.Printf(msg, args...)
}

func (e *Logger) Set(key string, value interface{}) {
	e.entry[key] = value
}

// With creates a new Logger instance with an additional key-value pair added to the existing
// log entry.
func (e *Logger) With(key string, value any) entity.Logger {
	entry := make(map[string]any)
	for k, v := range e.entry {
		entry[k] = v
	}
	entry[key] = value
	return &Logger{
		entry: entry,
	}
}

type LogHTTPRequest struct {
	RequestMethod string `json:"requestMethod"`
	RequestURL    string `json:"requestUrl"`
}
