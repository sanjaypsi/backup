package delivery

import (
	"net/http"

	"github.com/PolygonPictures/central30-web/front/entity"
	dataDepEntity "github.com/PolygonPictures/central30-web/front/entity/dataDependency"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

// DataDepHandler is a handler struct that manages data dependencies.
type DataDepHandler struct {
	uc *usecase.DataDepUsecase
}

// NewDataDepHandler creates a new instance of DataDepHandler with the provided DataDependency
// repository.
//
// Parameters:
//   - uc: A DataDepUsecase instance that will be used to handle the data dependency requests.
//
// Returns:
//   - A pointer to a DataDepHandler instance.
func NewDataDepHandler(uc *usecase.DataDepUsecase) *DataDepHandler {
	return &DataDepHandler{
		uc: uc,
	}
}

// ListRoots handles the HTTP request to list root elements for a given project.
//
// URL Parameters:
//   - project: The name of the project.
//
// Responses:
//   - 200 OK: If the root data is successfully retrieved.
//   - 500 Internal Server Error: If there is an error retrieving the root data.
//   - 502 Bad Gateway: If there is an error retrieving the root data.
func (h *DataDepHandler) ListRoots(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	roots, total, err := h.uc.ListRoots(c.Request.Context(), lgr, project)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"roots": roots,
			"total": total,
		},
	)
}

// GetRoot handles the HTTP request to retrieve the root data for a given project.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//
// Responses:
//   - 200 OK: If the root data is successfully retrieved.
//   - 404 Not Found: If the root data is not found.
//   - 500 Internal Server Error: If there is an error retrieving the root data.
//   - 502 Bad Gateway: If there is an error retrieving the root data.
func (h *DataDepHandler) GetRoot(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	r, err := h.uc.GetRoot(c.Request.Context(), lgr, project, root)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, r)
}

// ListGroups handles the HTTP request to list groups for a given project and root.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//
// Responses:
//   - 200 OK: If the group data is successfully retrieved.
//   - 404 Not Found: If the root data is not found.
//   - 500 Internal Server Error: If there is an error retrieving the root data.
//   - 502 Bad Gateway: If there is an error retrieving the group data.
func (h *DataDepHandler) ListGroups(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	groups, total, err := h.uc.ListGroups(c.Request.Context(), lgr, project, root)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"groups": groups,
			"total":  total,
		},
	)
}

// GetGroup handles the HTTP request to retrieve a group based on the provided project, root, and
// group parameters from the URL.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//
// Responses:
//   - 200 OK: Returns a JSON object containing the group object.
//   - 404 Not Found: If the group is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the group data.
func (h *DataDepHandler) GetGroup(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	g, err := h.uc.GetGroup(c.Request.Context(), lgr, project, root, group)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, g)
}

// ListRelations handles the HTTP request to list relations for a given project, root, and group.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//
// Responses:
//   - 200 OK: Returns a JSON object containing the list of relations and the total count.
//   - 404 Not Found: If the group is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the relations.
func (h *DataDepHandler) ListRelations(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relations, total, err := h.uc.ListRelations(c.Request.Context(), lgr, project, root, group)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"relations": relations,
			"total":     total,
		},
	)
}

// GetRelation handles the HTTP request to retrieve a specific relation from the repository.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//
// Responses:
//   - 200 OK: If the relation is found, returns the relation data as JSON.
//   - 404 Not Found: If the relation is not found, returns an error message.
//   - 500 Internal Server Error: For any other errors, returns an error message.
//   - 502 Bad Gateway: If there is an error retrieving the relation data.
func (h *DataDepHandler) GetRelation(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	g, err := h.uc.GetRelation(c.Request.Context(), lgr, project, root, group, relation)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, g)
}

// ListPhaseDirectories handles the request to list phase directories for a given project, root,
// group, and relation.
//
// Request Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//
// Response:
//   - 200 OK: Returns a JSON object containing the list of phase directories and the total count.
//   - 404 Not Found: If the relation is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the phase directories.
func (h *DataDepHandler) ListPhaseDirectories(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phases, total, err := h.uc.ListPhaseDirectories(
		c.Request.Context(), lgr, project, root, group, relation,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"phase_directories": phases,
			"total":             total,
		},
	)
}

// GetPhaseDirectory handles the HTTP request to retrieve the phase directory data.
//
// Request Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - relation: The name of the phase.
//
// Response:
//   - 200 OK: Returns a JSON object containing the phase directory.
//   - 404 Not Found: If the phase directory is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the phase directories.
func (h *DataDepHandler) GetPhaseDirectory(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	p, err := h.uc.GetPhaseDirectory(
		c.Request.Context(), lgr, project, root, group, relation, phase,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, p)
}

// ListComponentDirectories handles the request to list component directories for a given project,
// root, group, relation, and phase.
//
// Path Parameters:
//   - project: The name of the project.
//   - root: The name of the root identifier.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//
// Responses:
//   - 200 OK: Returns a JSON object containing the list of component directories and the total
//     count.
//   - 404 Not Found: If the phase directory is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the component directories.
func (h *DataDepHandler) ListComponentDirectories(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	components, total, err := h.uc.ListComponentDirectories(
		c.Request.Context(), lgr, project, root, group, relation, phase,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"component_directories": components,
			"total":                 total,
		},
	)
}

// GetComponentDirectory handles the HTTP request to retrieve the component directory.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//
// Responses:
//   - 200 OK: Returns the component directory as a JSON response.
//   - 404 Not Found: If the component directory is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the component directory.
func (h *DataDepHandler) GetComponentDirectory(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	cd, err := h.uc.GetComponentDirectory(
		c.Request.Context(), lgr, project, root, group, relation, phase, component,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, cd)
}

// ListRevisions handles the request to list revisions of a specific component.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//
// Responses:
//   - 200 OK: Returns the revision as a JSON response.
//   - 404 Not Found: If the component directory is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an error retrieving the revisions.
func (h *DataDepHandler) ListRevisions(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revisions, total, err := h.uc.ListRevisions(
		c.Request.Context(), lgr, project, root, group, relation, phase, component,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"revisions": revisions,
			"total":     total,
		},
	)
}

// GetRevision handles the HTTP request to retrieve a specific revision of a component.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//
// Responses:
//   - 200 OK: Returns the revision as a JSON response.
//   - 404 Not Found: If the revision is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an internal server error.
func (h *DataDepHandler) GetRevision(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	r, err := h.uc.GetRevision(
		c.Request.Context(), lgr, project, root, group, relation, phase, component, revision,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, r)
}

// ListContents handles the request to list contents for a specific revision.
//
// URL Parameters:
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//
// Responses:
//   - 200 OK: Returns the content as a JSON response.
//   - 404 Not Found: If the revision is not found.
//   - 500 Internal Server Error: If there is an internal server error.
//   - 502 Bad Gateway: If there is an internal server error.
func (h *DataDepHandler) ListContents(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	contents, total, err := h.uc.ListContents(
		c.Request.Context(), lgr, project, root, group, relation, phase, component, revision,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"contents": contents,
			"total":    total,
		},
	)
}

// GetContent handles the HTTP request to retrieve content based on various parameters.
//
// URL Parameters:
//   - project: the name of the project
//   - root: the name of the root
//   - group: the name of the group
//   - relation: the name of the relation
//   - phase: the name of the phase
//   - component: the name of the component
//   - revision: the name of the revision
//   - content: the name of the content
//
// Responses:
//   - 200: OK with the content in JSON format
//   - 404: Not Found if the content is not found
//   - 500: Internal Server Error if there is an error retrieving the content
//   - 502: Bad Gateway if there is an error retrieving the content
func (h *DataDepHandler) GetContent(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	content := c.Param("content")
	lgr.Set("content", content)

	ct, err := h.uc.GetContent(
		c.Request.Context(),
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, ct)
}

// ListContentFiles handles the request to list content files for a given content.
//
// URL Parameters:
//   - project: the name of the project
//   - root: the name of the root
//   - group: the name of the group
//   - relation: the name of the relation
//   - phase: the name of the phase
//   - component: the name of the component
//   - revision: the name of the revision
//   - content: the name of the content
//
// Responses:
//   - 200: OK with the content files in JSON format
//   - 404: Not Found if the content is not found
//   - 500: Internal Server Error if there is an error retrieving the content files
//   - 502: Bad Gateway if there is an error retrieving the content files
func (h *DataDepHandler) ListContentFiles(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	content := c.Param("content")
	lgr.Set("content", content)

	files, total, err := h.uc.ListContentFiles(
		c.Request.Context(),
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"content_files": files,
			"total":         total,
		},
	)
}

// ListContentDependencies handles a request to list the dependencies of a given content.
//
// URL Parameters:
//   - project: the name of the project
//   - root: the name of the root
//   - group: the name of the group
//   - relation: the name of the relation
//   - phase: the name of the phase
//   - component: the name of the component
//   - revision: the name of the revision
//   - content: the name of the content
//
// Responses:
//   - 200: OK with the content dependencies in JSON format
//   - 404: Not Found if the content is not found
//   - 500: Internal Server Error if there is an error retrieving the content dependencies
//   - 502: Bad Gateway if there is an error retrieving the content dependencies
func (h *DataDepHandler) ListContentDependencies(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	content := c.Param("content")
	lgr.Set("content", content)

	dependendies, total, err := h.uc.ListContentDependencies(
		c.Request.Context(),
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"dependencies": dependendies,
			"total":        total,
		},
	)
}

// ListContentDependents handles the request to list content dependents.
//
// URL Parameters:
//   - project: the name of the project
//   - root: the name of the root
//   - group: the name of the group
//   - relation: the name of the relation
//   - phase: the name of the phase
//   - component: the name of the component
//   - revision: the name of the revision
//   - content: the name of the content
//
// Responses:
//   - 200: OK with the content dependents in JSON format
//   - 404: Not Found if the content is not found
//   - 500: Internal Server Error if there is an error retrieving the content dependents
//   - 502: Bad Gateway if there is an error retrieving the content dependents
func (h *DataDepHandler) ListContentDependents(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	content := c.Param("content")
	lgr.Set("content", content)

	dependents, total, err := h.uc.ListContentDependents(
		c.Request.Context(),
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(
		http.StatusOK,
		map[string]any{
			"dependents": dependents,
			"total":      total,
		},
	)
}

// AddDependencies handles adding dependencies to content.
//
// URL Parameters:
//   - project: the name of the project
//   - root: the name of the root
//   - group: the name of the group
//   - relation: the name of the relation
//   - phase: the name of the phase
//   - component: the name of the component
//   - revision: the name of the revision
//   - content: the name of the content
//
// Body Parameters:
//   - AddDependenciesParams: Add Dependencies Parameters
//
// Responses:
//   - 201: Created with content and depencies with files
//   - 400: Bad Request if the query parameters are invalid
//   - 500: Internal Server Error if there is an error adding the dependencies
//   - 502: Bad Gateway if there is an error adding the dependencies
func (h *DataDepHandler) AddDependencies(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	root := c.Param("root")
	lgr.Set("root", root)

	group := c.Param("group")
	lgr.Set("group", group)

	relation := c.Param("relation")
	lgr.Set("relation", relation)

	phase := c.Param("phase")
	lgr.Set("phase", phase)

	component := c.Param("component")
	lgr.Set("component", component)

	revision := c.Param("revision")
	lgr.Set("revision", revision)

	content := c.Param("content")
	lgr.Set("content", content)

	var p dataDepEntity.AddContentDependenciesParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		jsonError(c, retErr)
		return
	}
	lgr.Set("params", p)

	files, err := h.uc.AddContentDependencies(
		c.Request.Context(),
		lgr,
		project, root, group, relation, phase, component, revision, content, &p,
	)
	if err != nil {
		jsonError(c, err)
		return
	}
	lgr.Set("added_dependencies", files)
	lgr.Info("dependencies added successfully")
	c.PureJSON(http.StatusCreated, files)
}
