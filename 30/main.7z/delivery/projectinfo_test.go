package delivery

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/testutil"
	"github.com/PolygonPictures/central30-web/front/usecase"
)

func TestProjectInfoListReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	d := newProjectInfoDelivery(t)
	f := func(studioKeyName string) ([]*entity.ProjectInfo2, int, error) {
		router, recorder := newProjectInfoRouter(func(c *gin.Context) {
			c.Set("studio", studioKeyName)
		})
		path := "/projects"
		router.GET(path, d.List)
		req, _ := http.NewRequest("GET", path, nil)

		router.ServeHTTP(recorder, req)
		testutil.AssertInt(t, recorder.Code, http.StatusOK)

		var got struct {
			Next     *string
			Prev     *string
			Projects []*entity.ProjectInfo2
			Total    int
		}

		if err := json.Unmarshal(recorder.Body.Bytes(), &got); err != nil {
			t.Fatal(err)
		}

		return got.Projects, got.Total, nil
	}
	testutil.AssertProjectInfoList(t, testDB, f)
}

func TestProjectInfoGetReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	d := newProjectInfoDelivery(t)
	f := func(projectKeyName string) (*entity.ProjectInfo2, error) {
		router, recorder := newProjectInfoRouter(nil)
		router.GET("/projects/:project", d.Get)
		path := "/projects/" + projectKeyName
		req, _ := http.NewRequest("GET", path, nil)

		router.ServeHTTP(recorder, req)
		testutil.AssertInt(t, recorder.Code, http.StatusOK)

		var got entity.ProjectInfo2
		if err := json.Unmarshal(recorder.Body.Bytes(), &got); err != nil {
			t.Fatal(err)
		}

		return &got, nil
	}
	testutil.AssertProjectInfoGet(t, testDB, f)
}

func TestProjectInfoPostReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	d := newProjectInfoDelivery(t)
	f := func(projectKeyName string) (*entity.ProjectInfo2, error) {
		router, recorder := newProjectInfoRouter(nil)
		path := "/projects"
		router.POST(path, d.Post)
		body := fmt.Sprintf(`{"key_name": "%s"}`, projectKeyName)
		req, _ := http.NewRequest("POST", path, strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")

		router.ServeHTTP(recorder, req)
		testutil.AssertInt(t, recorder.Code, http.StatusOK)

		var got entity.ProjectInfo2
		if err := json.Unmarshal(recorder.Body.Bytes(), &got); err != nil {
			t.Fatal(err)
		}

		return &got, nil
	}
	testutil.AssertProjectInfoCreate(t, testDB, f)
}

func newProjectInfoDelivery(t *testing.T) *ProjectInfo {
	t.Helper()

	ps, err := repository.NewProjectStudioMap(testDB)
	testutil.AssertNoError(t, err)

	repo, err := repository.NewProjectInfo(testDB, ps)
	testutil.AssertNoError(t, err)

	readTimeout := 1 * time.Second
	writeTimeout := 1 * time.Second
	uc := usecase.NewProjectInfo(repo, readTimeout, writeTimeout)

	return NewProjectInfo(uc)
}

func newProjectInfoRouter(middleware func(*gin.Context)) (*gin.Engine, *httptest.ResponseRecorder) {
	recorder := httptest.NewRecorder()
	_, router := gin.CreateTestContext(recorder)
	if middleware != nil {
		router.Use(middleware)
	}
	return router, recorder
}
