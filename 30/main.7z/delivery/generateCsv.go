package delivery

import (
	"encoding/csv"
	"log"
	"net/http"
	"slices"
	"sort"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type GenerateCsv struct {
	uc *usecase.GenerateCsv
}

func NewGenerateCsv(uc *usecase.GenerateCsv) *GenerateCsv {
	return &GenerateCsv{
		uc: uc,
	}
}

func (gc *GenerateCsv) GenerateAssetsCsv(c *gin.Context) {
	params := &entity.GenerateTrackerCsvParams{
		Project: c.Param("project"),
	}

	rc := http.NewResponseController(c.Writer)
	if err := rc.SetWriteDeadline(time.Now().Add(gc.uc.ReadTimeout)); err != nil {
		log.Printf("ERROR: failed to set the deadline for the writing response: method=%s, url=%s, err=%s", c.Request.Method, c.Request.URL, err)
	}

	groupCategoryData, err := gc.uc.ListAssetsGroupCategory(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	AllBldReviewData, err := gc.uc.ListAllBldReviews(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	commentsData, err := gc.uc.ListComments(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	shotAssetsAllData, err := gc.uc.ListShotAssetsAll(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	bldDocumentData, err := gc.uc.ListBldAnmBldRendDocuments(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	publishOperationInfoData, err := gc.uc.ListPublishOperationInfos(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	latestReviewInfoData, err := gc.uc.ListLatestAssetsReviews(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	generateData := entity.GenerateData{
		ReviewInfo:            latestReviewInfoData,
		GroupCategories:       groupCategoryData,
		LatestDocuments:       bldDocumentData,
		Comments:              commentsData,
		ShotAssetsAlls:        shotAssetsAllData,
		PublishOperationInfos: publishOperationInfoData,
		ComponentReviewInfos:  AllBldReviewData,
	}

	records := generateRecords(&generateData)
	c.Writer.Header().Set("Content-Type", "text/csv")
	c.Writer.Header().Set("Content-Disposition", "attachment;filename=asset_data.csv")
	writer := csv.NewWriter(c.Writer)
	defer writer.Flush()
	if err := writer.WriteAll(records); err != nil {
		c.String(http.StatusInternalServerError, "Failed to generate CSV")
		return
	}
}

func toStrSlice(v interface{}) []string {
	if v == nil {
		return nil
	}
	switch val := v.(type) {
	case []string:
		return val
	case primitive.A: // MongoDBの配列型
		var res []string
		for _, item := range val {
			if s, ok := item.(string); ok {
				res = append(res, s)
			}
		}
		return res
	case []interface{}:
		var res []string
		for _, item := range val {
			if s, ok := item.(string); ok {
				res = append(res, s)
			}
		}
		return res
	}
	return nil
}

func toMapSlice(v interface{}) []map[string]interface{} {
	if v == nil {
		return nil
	}
	switch val := v.(type) {
	case []map[string]interface{}:
		return val
	case primitive.A:
		var res []map[string]interface{}
		for _, item := range val {
			if m, ok := item.(map[string]interface{}); ok {
				res = append(res, m)
			} else if m, ok := item.(primitive.M); ok {
				res = append(res, (map[string]interface{})(m))
			}
		}
		return res
	case []interface{}:
		var res []map[string]interface{}
		for _, item := range val {
			if m, ok := item.(map[string]interface{}); ok {
				res = append(res, m)
			}
		}
		return res
	}
	return nil
}

func toTimeStrFromInterface(v interface{}) string {
	if v == nil {
		return ""
	}
	switch val := v.(type) {
	case string:
		// 文字列の場合はそのまま返す（必要であればフォーマットチェックを入れる）
		return val
	case time.Time:
		return val.Format(time.RFC3339)
	case primitive.DateTime:
		return val.Time().Format(time.RFC3339)
	default:
		return ""
	}
}

func collectRowData(gd *entity.GenerateData) map[string]*entity.AssetRowData {
	var assetRowsData = make(map[string]*entity.AssetRowData)

	// ReviewInfo
	for _, ri := range gd.ReviewInfo {
		assetRelation := ri.Group1 + "/" + ri.Relation
		assetRowData, ok := assetRowsData[assetRelation]
		if !ok {
			assetRowData = &entity.AssetRowData{
				MdlData: &entity.PhaseRowData{},
				RigData: &entity.PhaseRowData{},
				LdvData: &entity.PhaseRowData{},
			}
			assetRowsData[assetRelation] = assetRowData
		}

		switch ri.Phase {
		case "mdl":
			assetRowData.MdlData.WorkStatus = ri.WorkStatus
			assetRowData.MdlData.ApprovalStatus = ri.ApprovalStatus
		case "rig":
			assetRowData.RigData.WorkStatus = ri.WorkStatus
			assetRowData.RigData.ApprovalStatus = ri.ApprovalStatus
		case "lookDev":
			assetRowData.LdvData.WorkStatus = ri.WorkStatus
			assetRowData.LdvData.ApprovalStatus = ri.ApprovalStatus
		}
	}

	// GroupCategory
	for _, gc := range gd.GroupCategories {
		categoryParts := strings.Split(gc.CategoryPath, "/")
		if len(categoryParts) < 2 {
			continue
		}
		for key, assetRowData := range assetRowsData {
			keyParts := strings.Split(key, "/")
			if keyParts[0] == gc.GroupPath {
				assetRowData.AssetTypes = append(assetRowData.AssetTypes, categoryParts[0])
				assetRowData.AssetGroups = append(assetRowData.AssetGroups, categoryParts[1])
			}
		}
	}

	// bld Latest Publish Operation Info
	for _, ld := range gd.LatestDocuments {
		rawGroups, okGroups := (*ld)["groups"]
		relation, okRelation := (*ld)["relation"]
		submittedAtUtc, okSubmittedAtUtc := (*ld)["submitted_at_utc"]

		groups := toStrSlice(rawGroups)

		if !okGroups || !okRelation || !okSubmittedAtUtc || len(groups) == 0 {
			continue
		}
		assetRelation := groups[0] + "/" + relation.(string)
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]

		dateStr := toTimeStrFromInterface(submittedAtUtc)
		switch (*ld)["component"].(string) {
		case "bldAnm":
			if assetRowData.BldAnmReleaseDate != "" {
				continue
			}
			assetRowData.BldAnmReleaseDate = dateStr
		case "bldRend":
			if assetRowData.BldRendReleaseDate != "" {
				continue
			}
			assetRowData.BldRendReleaseDate = dateStr
		}
	}

	// Comment
	for _, comment := range gd.Comments {
		rawGroups, okGroups := (*comment)["groups"]
		relation, okRelation := (*comment)["relation"]
		rawCommentsData, okCommentsData := (*comment)["comment_data"]
		phase, okPhase := (*comment)["phase"]

		if !okGroups || !okRelation || !okCommentsData || !okPhase {
			continue
		}

		groups := toStrSlice(rawGroups)
		commentsData := toMapSlice(rawCommentsData)

		if len(groups) == 0 || len(commentsData) == 0 {
			continue
		}

		assetRelation := groups[0] + "/" + relation.(string)
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]

		for _, cd := range commentsData {
			language, okLanguage := cd["language"]
			role, okRole := cd["responsible_person_role"]
			text, okText := cd["text"]
			if !okLanguage || !okRole || !okText {
				continue
			}
			switch phase.(string) {
			case "mdl":
				switch language.(string) {
				case "ja":
					switch role.(string) {
					case "artist":
						if assetRowData.MdlData.LatestArtistCommentJa != "" {
							continue
						}
						assetRowData.MdlData.LatestArtistCommentJa = text.(string)
					case "supervisor":
						if assetRowData.MdlData.LatestSupervisorCommentJa != "" {
							continue
						}
						assetRowData.MdlData.LatestSupervisorCommentJa = text.(string)
					case "director":
						if assetRowData.MdlData.LatestDirectorCommentJa != "" {
							continue
						}
						assetRowData.MdlData.LatestDirectorCommentJa = text.(string)
					case "client":
						if assetRowData.MdlData.LatestClientCommentJa != "" {
							continue
						}
						assetRowData.MdlData.LatestClientCommentJa = text.(string)
					}
				case "en":
					switch role.(string) {
					case "artist":
						if assetRowData.MdlData.LatestArtistCommentEn != "" {
							continue
						}
						assetRowData.MdlData.LatestArtistCommentEn = text.(string)
					case "supervisor":
						if assetRowData.MdlData.LatestSupervisorCommentEn != "" {
							continue
						}
						assetRowData.MdlData.LatestSupervisorCommentEn = text.(string)
					case "director":
						if assetRowData.MdlData.LatestDirectorCommentEn != "" {
							continue
						}
						assetRowData.MdlData.LatestDirectorCommentEn = text.(string)
					case "client":
						if assetRowData.MdlData.LatestClientCommentEn != "" {
							continue
						}
						assetRowData.MdlData.LatestClientCommentEn = text.(string)
					}
				}
			case "rig":
				switch language.(string) {
				case "ja":
					switch role.(string) {
					case "artist":
						if assetRowData.RigData.LatestArtistCommentJa != "" {
							continue
						}
						assetRowData.RigData.LatestArtistCommentJa = text.(string)
					case "supervisor":
						if assetRowData.RigData.LatestSupervisorCommentJa != "" {
							continue
						}
						assetRowData.RigData.LatestSupervisorCommentJa = text.(string)
					case "director":
						if assetRowData.RigData.LatestDirectorCommentJa != "" {
							continue
						}
						assetRowData.RigData.LatestDirectorCommentJa = text.(string)
					case "client":
						if assetRowData.RigData.LatestClientCommentJa != "" {
							continue
						}
						assetRowData.RigData.LatestClientCommentJa = text.(string)
					}
				case "en":
					switch role.(string) {
					case "artist":
						if assetRowData.RigData.LatestArtistCommentEn != "" {
							continue
						}
						assetRowData.RigData.LatestArtistCommentEn = text.(string)
					case "supervisor":
						if assetRowData.RigData.LatestSupervisorCommentEn != "" {
							continue
						}
						assetRowData.RigData.LatestSupervisorCommentEn = text.(string)
					case "director":
						if assetRowData.RigData.LatestDirectorCommentEn != "" {
							continue
						}
						assetRowData.RigData.LatestDirectorCommentEn = text.(string)
					case "client":
						if assetRowData.RigData.LatestClientCommentEn != "" {
							continue
						}
						assetRowData.RigData.LatestClientCommentEn = text.(string)
					}
				}
			case "ldv":
				switch language.(string) {
				case "ja":
					switch role.(string) {
					case "artist":
						if assetRowData.LdvData.LatestArtistCommentJa != "" {
							continue
						}
						assetRowData.LdvData.LatestArtistCommentJa = text.(string)
					case "supervisor":
						if assetRowData.LdvData.LatestSupervisorCommentJa != "" {
							continue
						}
						assetRowData.LdvData.LatestSupervisorCommentJa = text.(string)
					case "director":
						if assetRowData.LdvData.LatestDirectorCommentJa != "" {
							continue
						}
						assetRowData.LdvData.LatestDirectorCommentJa = text.(string)
					case "client":
						if assetRowData.LdvData.LatestClientCommentJa != "" {
							continue
						}
						assetRowData.LdvData.LatestClientCommentJa = text.(string)
					}
				case "en":
					switch role.(string) {
					case "artist":
						if assetRowData.LdvData.LatestArtistCommentEn != "" {
							continue
						}
						assetRowData.LdvData.LatestArtistCommentEn = text.(string)
					case "supervisor":
						if assetRowData.LdvData.LatestSupervisorCommentEn != "" {
							continue
						}
						assetRowData.LdvData.LatestSupervisorCommentEn = text.(string)
					case "director":
						if assetRowData.LdvData.LatestDirectorCommentEn != "" {
							continue
						}
						assetRowData.LdvData.LatestDirectorCommentEn = text.(string)
					case "client":
						if assetRowData.LdvData.LatestClientCommentEn != "" {
							continue
						}
						assetRowData.LdvData.LatestClientCommentEn = text.(string)
					}
				}
			}
		}
	}

	// Shot AssetsAll
	for _, sa := range gd.ShotAssetsAlls {
		rawComponentInfos, okComponentInfos := (*sa)["component_info"]
		rawGroups, okGroups := (*sa)["groups"]

		groups := toStrSlice(rawGroups)
		componentInfos := toMapSlice(rawComponentInfos)

		if !okComponentInfos || !okGroups || len(groups) == 0 {
			continue
		}
		groupsPath := strings.Join(groups, "/")
		for _, componentInfo := range componentInfos {
			rawSceneAssets, okSceneAssets := componentInfo["scene_assets"]
			if !okSceneAssets {
				continue
			}

			sceneAssets := toMapSlice(rawSceneAssets)

			for _, sceneAsset := range sceneAssets {
				group, okGroup := sceneAsset["group"]
				relation, okRelation := sceneAsset["relation"]
				if !okGroup || !okRelation {
					continue
				}
				assetRelation := group.(string) + "/" + relation.(string)
				if _, ok := assetRowsData[assetRelation]; !ok {
					continue
				}
				assetRowData := assetRowsData[assetRelation]
				assetRowData.ShotAssetsAll = append(assetRowData.ShotAssetsAll, groupsPath)
			}
		}
	}

	// PublishOperationInfo
	for _, poi := range gd.PublishOperationInfos {
		phase, okPhase := (*poi)["phase"]
		revision, okRevision := (*poi)["revision"]
		submittedUser, okSubmittedUser := (*poi)["submitted_user"]
		submittedAtUtc, okSubmittedAtUtc := (*poi)["submitted_at_utc"]
		rawGroups, okGroups := (*poi)["groups"]
		relation, okRelation := (*poi)["relation"]

		if !okPhase || !okRevision || !okSubmittedUser || !okSubmittedAtUtc || !okGroups || !okRelation {
			continue
		}

		groups := toStrSlice(rawGroups)

		if len(groups) == 0 {
			continue
		}

		assetRelation := groups[0] + "/" + relation.(string)
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]
		dateStr := toTimeStrFromInterface(submittedAtUtc)
		switch phase.(string) {
		case "mdl":
			assetRowData.MdlData.Versions = append(assetRowData.MdlData.Versions, revision.(string))
			assetRowData.MdlData.LatestPublisher = submittedUser.(string)
			assetRowData.MdlData.LatestPublishAt = dateStr
		case "rig":
			assetRowData.RigData.Versions = append(assetRowData.RigData.Versions, revision.(string))
			assetRowData.RigData.LatestPublisher = submittedUser.(string)
			assetRowData.RigData.LatestPublishAt = dateStr
		case "ldv":
			assetRowData.LdvData.Versions = append(assetRowData.LdvData.Versions, revision.(string))
			assetRowData.LdvData.LatestPublisher = submittedUser.(string)
			assetRowData.LdvData.LatestPublishAt = dateStr
		}
	}

	// bldAnm, bldRend Status
	for i := len(gd.ComponentReviewInfos) - 1; i >= 0; i-- {
		bri := gd.ComponentReviewInfos[i]
		assetRelation := bri.Group1 + "/" + bri.Relation
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]

		if slices.Contains(bri.TargetComponents, "bldAnm") {
			if assetRowData.BldAnmStatus != "" {
				continue
			}
			assetRowData.BldAnmStatus = bri.ApprovalStatus
		}
		if slices.Contains(bri.TargetComponents, "bldRend") {
			if assetRowData.BldRendStatus != "" {
				continue
			}
			assetRowData.BldRendStatus = bri.ApprovalStatus
		}
	}

	return assetRowsData
}

func generateRow(assetRelation string, gd *entity.AssetRowData) []string {
	// Build Row
	row := []string{}
	// New, Episode, Thumbnail
	row = append(row, "", "", "")
	// Asset Type, Asset Group, Asset Name
	sort.Strings(gd.AssetTypes)
	sort.Strings(gd.AssetGroups)
	row = append(row, strings.Join(gd.AssetTypes, "\n"), strings.Join(gd.AssetGroups, "\n"), assetRelation)
	// Tags, Parent Asset, Description, Asset Info Jp, Asset Info En, Dir Notes Jp, Dir Notes En, CGSV Notes Jp, CGSV Notes En
	row = append(row, "", "", "", "", "", "", "", "", "")
	// shots <-> Assets All
	sort.Strings(gd.ShotAssetsAll)
	row = append(row, strings.Join(gd.ShotAssetsAll, "\n"))
	// row = append(row, "")
	// Model Status, Model Work Status, Model submitted at, Model Published artist, Model Pipeline Step, Model Task Name, Model Versions
	sort.Strings(gd.MdlData.Versions)
	row = append(row, gd.MdlData.ApprovalStatus, gd.MdlData.WorkStatus, gd.MdlData.LatestPublishAt, gd.MdlData.LatestPublisher, "mdl", "mdl", strings.Join(gd.MdlData.Versions, "\n"))
	// Model latest_comment_artist_ja, Model latest_comment_artist_en, Model latest_comment_supervisor_ja, Model latest_comment_supervisor_en, Model latest_comment_director_ja, Model latest_comment_director_en, Model latest_comment_client_ja, Model latest_comment_client_en
	row = append(row, gd.MdlData.LatestArtistCommentJa, gd.MdlData.LatestArtistCommentEn, gd.MdlData.LatestSupervisorCommentJa, gd.MdlData.LatestSupervisorCommentEn,
		gd.MdlData.LatestDirectorCommentJa, gd.MdlData.LatestDirectorCommentEn, gd.MdlData.LatestClientCommentJa, gd.MdlData.LatestClientCommentEn)
	// Model Note, Model Start Date, Model T1 Due Date, Model Due Date, Model Description, Model Bid, Model Assigned Studio, Model Assigned To
	row = append(row, "", "", "", "", "", "", "", "")
	// to Rig Jp, to Rig En, Elements Sim
	row = append(row, "", "", "")
	// Rig Status, Rig Work Status, Rig submitted at, Rig Published artist, Rig Pipeline Step, Rig Task Name, Rig Versions
	sort.Strings(gd.RigData.Versions)
	row = append(row, gd.RigData.ApprovalStatus, gd.RigData.WorkStatus, gd.RigData.LatestPublishAt, gd.RigData.LatestPublisher, "rig", "rig", strings.Join(gd.RigData.Versions, "\n"))
	// Rig latest_comment_artist_ja, Rig latest_comment_artist_en, Rig latest_comment_supervisor_ja, Rig latest_comment_supervisor_en, Rig latest_comment_director_ja, Rig latest_comment_director_en, Rig latest_comment_client_ja, Rig latest_comment_client_en
	row = append(row, gd.RigData.LatestArtistCommentJa, gd.RigData.LatestArtistCommentEn, gd.RigData.LatestSupervisorCommentJa, gd.RigData.LatestSupervisorCommentEn,
		gd.RigData.LatestDirectorCommentJa, gd.RigData.LatestDirectorCommentEn, gd.RigData.LatestClientCommentJa, gd.RigData.LatestClientCommentEn)
	// Rig Note, Rig Start Date, Rig T1 Due Date, Rig Due Date, Rig Description, Rig Bid, Rig Assigned Studio, Rig Assigned To
	row = append(row, "", "", "", "", "", "", "", "")
	// to LookDev Jp, to LookDev En
	row = append(row, "", "")
	// LookDev Status, LookDev Work Status, LookDev submitted at, LookDev Published artist, LookDev Pipeline Step, LookDev Task Name, LookDev Versions
	sort.Strings(gd.LdvData.Versions)
	row = append(row, gd.LdvData.ApprovalStatus, gd.LdvData.WorkStatus, gd.LdvData.LatestPublishAt, gd.LdvData.LatestPublisher, "ldv", "ldv", strings.Join(gd.LdvData.Versions, "\n"))
	// LookDev latest_comment_artist_ja, LookDev latest_comment_artist_en, LookDev latest_comment_supervisor_ja, LookDev latest_comment_supervisor_en, LookDev latest_comment_director_ja, LookDev latest_comment_director_en, LookDev latest_comment_client_ja, LookDev latest_comment_client_en
	row = append(row, gd.LdvData.LatestArtistCommentJa, gd.LdvData.LatestArtistCommentEn, gd.LdvData.LatestSupervisorCommentJa, gd.LdvData.LatestSupervisorCommentEn,
		gd.LdvData.LatestDirectorCommentJa, gd.LdvData.LatestDirectorCommentEn, gd.LdvData.LatestClientCommentJa, gd.LdvData.LatestClientCommentEn)
	// to Composite Jp, to Composite En
	row = append(row, "", "")
	// buildAnim Status, buildAnim Release Date
	row = append(row, gd.BldAnmStatus, gd.BldAnmReleaseDate)
	// buildRend Status, buildRend Release Date
	row = append(row, gd.BldRendStatus, gd.BldRendReleaseDate)

	return row
}

func generateRecords(gds *entity.GenerateData) [][]string {
	records := [][]string{}

	// Header
	header := []string{
		"New", "Episode", "Thumbnail",
		"Asset Type", "Asset Group", "Asset Name",
		"Tags", "Parent Asset", "Description", "Asset Info Jp", "Asset Info En", "Dir Notes Jp", "Dir Notes En", "CGSV Notes Jp", "CGSV Notes En",
		"shots <-> Assets All",
		"Model Status", "Model Work Status", "Model submitted at", "Model Published artist", "Model Pipeline Step", "Model Task Name", "Model Versions",
		"Model latest_comment_artist_ja", "Model latest_comment_artist_en", "Model latest_comment_supervisor_ja", "Model latest_comment_supervisor_en", "Model latest_comment_director_ja", "Model latest_comment_director_en", "Model latest_comment_client_ja", "Model latest_comment_client_en",
		"Model Note", "Model Start Date", "Model T1 Due Date", "Model Due Date", "Model Description", "Model Bid", "Model Assigned Studio", "Model Assigned To",
		"to Rig Jp", "to Rig En", "Elements Sim",
		"Rig Status", "Rig Work Status", "Rig submitted at", "Rig Published artist", "Rig Pipeline Step", "Rig Task Name", "Rig Versions",
		"Rig latest_comment_artist_ja", "Rig latest_comment_artist_en", "Rig latest_comment_supervisor_ja", "Rig latest_comment_supervisor_en", "Rig latest_comment_director_ja", "Rig latest_comment_director_en", "Rig latest_comment_client_ja", "Rig latest_comment_client_en",
		"Rig Note", "Rig Start Date", "Rig T1 Due Date", "Rig Due Date", "Rig Description", "Rig Bid", "Rig Assigned Studio", "Rig Assigned To",
		"to LookDev Jp", "to LookDev En",
		"LookDev Status", "LookDev Work Status", "LookDev submitted at", "LookDev Published artist", "LookDev Pipeline Step", "LookDev Task Name", "LookDev Versions",
		"LookDev latest_comment_artist_ja", "LookDev latest_comment_artist_en", "LookDev latest_comment_supervisor_ja", "LookDev latest_comment_supervisor_en", "LookDev latest_comment_director_ja", "LookDev latest_comment_director_en", "LookDev latest_comment_client_ja", "LookDev latest_comment_client_en",
		"LookDev Note", "LookDev Start Date", "LookDev T1 Due Date", "LookDev Due Date", "LookDev Description", "LookDev Bid", "LookDev Assigned Studio", "LookDev Assigned To",
		"to Composite Jp", "to Composite En",
		"buildAnim Status", "buildAnim Release Date",
		"buildRend Status", "buildRend Release Date",
	}
	records = append(records, header)

	// Data Rows
	rowsData := collectRowData(gds)
	assetRelations := make([]string, 0, len(rowsData))
	for k := range rowsData {
		assetRelations = append(assetRelations, k)
	}
	sort.Strings(assetRelations)
	for _, assetRelation := range assetRelations {
		row := generateRow(assetRelation, rowsData[assetRelation])
		records = append(records, row)
	}

	return records
}
