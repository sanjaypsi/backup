package delivery

import (
	"errors"
	"fmt"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type Notification struct {
	uc *usecase.Notification
}

func NewNotification(uc *usecase.Notification) *Notification {
	return &Notification{
		uc: uc,
	}
}

// middleware to send notifications after each API process
func (d *Notification) SendNotification(c *gin.Context) {
	// call c.Next() to send notification after each API process
	c.Next()

	lgr := NewLogger(c.Request)
	req := c.Request
	project := c.Param("project")

	// APIs to send notification
	publish := fmt.Sprintf("/api/projects/%s/publishTransactionInfos", project)
	review := fmt.Sprintf("/api/projects/%s/reviewStatusLogs", project)
	review2 := fmt.Sprintf("/api/projects/%s/reviewStatusLogs2", project)

	path := req.URL.Path
	if req.Method != "POST" ||
		path != publish && path != review && path != review2 {
		return
	}

	if rawError, ok := c.Get("notificationErrorInfo"); ok {
		if err, ok := rawError.(*entity.ApiProcessError); ok {
			d.uc.SendApiProcessFailure(err)
			return
		}
	}

	switch path {
	case publish:
		rawinfo, ok := c.Get("publishNotificationInfo")
		if !ok {
			// send error chat
			d.uc.SendGeneralFailure(errors.New("no info is set to send publish notification"))
			return
		}
		info, ok := rawinfo.(*entity.PublishTransactionInfoNotification)
		if !ok {
			// send error chat
			d.uc.SendGeneralFailure(errors.New("conversion of PublishTransactionInfoNotification failed"))
			return
		}

		lgr.Set("publishNotificationInfo", info)
		if err := d.uc.SendPublishNotification(req.Context(), lgr, info); err != nil {
			lgr.Debug(err.Error())
		} else {
			lgr.Info("[EmailSender] send publish notification")
		}

		return
	case review, review2:
		rawinfo, ok := c.Get("reviewStatusNotificationInfo")
		if !ok {
			// send error chat
			d.uc.SendGeneralFailure(errors.New("no info is set to send review status notification"))
			return
		}
		info, ok := rawinfo.(*entity.ReviewStatusLogNotification)
		if !ok {
			// send error chat
			d.uc.SendGeneralFailure(errors.New("conversion of ReviewStatusLogNotification failed"))
			return
		}
		if !info.IsSendEmail {
			return
		}
		d.uc.SendReviewStatusNotification(req.Context(), info)
		return
	}
}
