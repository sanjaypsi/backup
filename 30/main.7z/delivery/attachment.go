package delivery

import (
	"errors"
	"net/http"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type CommentAttachment struct {
	uc *usecase.CommentAttachment
}

func NewCommentAttachment(uc *usecase.CommentAttachment) *CommentAttachment {
	return &CommentAttachment{
		uc: uc,
	}
}

func (ca *CommentAttachment) Get(c *gin.Context) {
	params := &entity.GetCommentAttachmentParams{
		CommentID:    c.Param("id"),
		Project:      c.Param("project"),
		AttachmentID: c.Param("attachment_id"),
	}
	e, err := ca.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.FileAttachment(e.DataPath, e.FileName)
}

func (ca *CommentAttachment) Post(c *gin.Context) {
	file, header, err := c.Request.FormFile("file")
	if err != nil {
		badRequest(c, errors.New("invalid file"))
		return
	}
	params := &entity.PostCommentAttachmentParams{
		CommentID: c.Param("id"),
		Project:   c.Param("project"),
		Lang:      c.Query("lang"),
		FileName:  header.Filename,
		FileData:  &file,
	}
	e, err := ca.uc.Create(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}
