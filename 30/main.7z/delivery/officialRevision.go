package delivery

import (
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type OfficialRevision struct {
	uc *usecase.OfficialRevision
}

func NewOfficialRevision(uc *usecase.OfficialRevision) *OfficialRevision {
	return &OfficialRevision{
		uc: uc,
	}
}

type listOfficialRevisionParams struct {
	PerPage       *int       `form:"per_page"`
	Page          *int       `form:"page"`
	OrderBy       *string    `form:"order_by"`
	ModifiedSince *time.Time `form:"modified_since"`
}

func (p *listOfficialRevisionParams) Params(
	project string,
) *entity.ListOfficialRevisionParams {
	params := &entity.ListOfficialRevisionParams{
		Project: project,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}

	if p.ModifiedSince != nil {
		params.ModifiedSince = p.ModifiedSince
		params.OrderBy = []string{"modified_at_utc"}
	} else if p.OrderBy != nil {
		for _, orderBy := range strings.Split(*p.OrderBy, ",") {
			if strings.HasSuffix(orderBy, "modified_at") {
				orderBy += "_utc"
			}
			params.OrderBy = append(params.OrderBy, orderBy)
		}
	}

	return params
}

func (h *OfficialRevision) List(c *gin.Context) {
	var p listOfficialRevisionParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Params(c.Param("project"))
	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		badRequest(c, err)
		return
	}

	res := libs.CreateListResponse(
		"revisions",
		entities,
		c.Request,
		params,
		total,
	)
	c.PureJSON(http.StatusOK, res)
}

type listPublishedRevisionParams struct {
	PerPage       *int    `form:"per_page"`
	Page          *int    `form:"page"`
	Root          *string `form:"root"`
	Group         *string `form:"group"`
	Relation      *string `form:"relation"`
	Phase         *string `form:"phase"`
	Component     *string `form:"component"`
	Revision      *string `form:"revision"`
	Studio        *string `form:"studio"`
	SubmittedUser *string `form:"submitted_user"`
	ExactMatch    *string `form:"exact_match"`
}

func (p *listPublishedRevisionParams) Params(
	project string,
) *entity.ListPublishedRevisionDeliveryParams {
	params := &entity.ListPublishedRevisionDeliveryParams{
		Project: project,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
		Root:          p.Root,
		Group:         p.Group,
		Relation:      p.Relation,
		Phase:         p.Phase,
		Component:     p.Component,
		Revision:      p.Revision,
		Studio:        p.Studio,
		SubmittedUser: p.SubmittedUser,
		ExactMatch:    p.ExactMatch,
	}

	return params
}

func (h *OfficialRevision) ListComposite(c *gin.Context) {
	var p listPublishedRevisionParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Params(c.Param("project"))
	entities, total, err := h.uc.ListComposite(c.Request.Context(), params)
	if err != nil {
		badRequest(c, err)
		return
	}

	res := libs.CreateListResponse(
		"revisions",
		entities,
		c.Request,
		params,
		total,
	)
	c.PureJSON(http.StatusOK, res)
}

type upsertOfficialRevisionParams struct {
	IsOfficial *bool   `json:"is_official"`
	Project    string  `json:"project"`
	Root       string  `json:"root"`
	Group      string  `json:"group"`
	Relation   string  `json:"relation"`
	Phase      string  `json:"phase"`
	Component  string  `json:"component"`
	Revision   string  `json:"revision"`
	ModifiedBy *string `json:"modified_by"`
}

func (p *upsertOfficialRevisionParams) Entity(project string) *entity.UpsertOfficialRevisionDeliveryParams {
	modifiedBy := ""
	if p.ModifiedBy != nil {
		modifiedBy = *p.ModifiedBy
	}
	return &entity.UpsertOfficialRevisionDeliveryParams{
		IsOfficial: p.IsOfficial,
		Project:    project,
		Root:       p.Root,
		Group:      p.Group,
		Relation:   p.Relation,
		Phase:      p.Phase,
		Component:  p.Component,
		Revision:   p.Revision,
		ModifiedBy: modifiedBy,
	}
}

func (h *OfficialRevision) Put(c *gin.Context) {
	var p upsertOfficialRevisionParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	prmprj := c.Param("project")
	if p.Project != prmprj {
		badRequest(c, errors.New("diffrent project names between json and url"))
		return
	}
	params := p.Entity(prmprj)
	e, err := h.uc.Upsert(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	status := http.StatusCreated
	if e.CreatedAtUTC != e.ModifiedAtUTC {
		status = http.StatusOK
	}
	c.PureJSON(status, e)
}
