package delivery

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/testutil"
	"github.com/PolygonPictures/central30-web/front/usecase"
)

func TestDirectory_SQLite(t *testing.T) {
	const studio = "ppidev"
	const project = "potoodev"
	const wantPathMySQL = "shared/publish/assets/testMySQL"
	const wantPathSQLite = "shared/publish/assets/testSQLite"

	tests := map[string]struct {
		url      string
		wantPath string
	}{
		"Use SQLite": {
			url:      "/projects/potoodev/directories?sqlite=1",
			wantPath: wantPathSQLite,
		},
		"Not Use SQLite": {
			url:      "/projects/potoodev/directories?sqlite=0",
			wantPath: wantPathMySQL,
		},
		"Default": {
			url:      "/projects/potoodev/directories",
			wantPath: wantPathMySQL,
		},
	}

	depth := func(path string) int {
		return len(strings.Split(path, ","))
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			// MySQLのt_directoryテーブルにレコードを作成
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.CreateProjectInfo(t, testDB, studio, project)
			testDB.Exec(`
			INSERT INTO t_directory (
				project, path, depth, status
			) VALUES (
				?, ?, ?, ?
			)`, project, wantPathMySQL, depth(wantPathMySQL), "active")

			// SQLiteのt_directoryテーブルにレコードを作成
			sqliteDBPathPrefix := t.TempDir()
			t.Setenv("PPI_SQLITE_PATH_PREFIX", sqliteDBPathPrefix)
			sqliteDBPath := filepath.Join(sqliteDBPathPrefix, project, ".sys/db/directory.ppidb")
			require.Nil(t, os.MkdirAll(filepath.Dir(sqliteDBPath), 0700))
			sqliteDB, err := gorm.Open(sqlite.Open(sqliteDBPath), &gorm.Config{})
			require.Nil(t, err)
			sqliteDB.Exec(`CREATE TABLE t_directory (
				id              INTEGER NOT NULL PRIMARY KEY,
				project         TEXT NOT NULL,
				path            TEXT NOT NULL,
				depth           INTEGER NOT NULL,
				status          TEXT NOT NULL,
				created_at_utc  DATETIME,
				modified_at_utc DATETIME,
				created_by      TEXT,
				modified_by     TEXT
			)`)
			sqliteDB.Exec(`INSERT INTO t_directory (
				id, project, path, depth, status
			) VALUES (
				?, ?, ?, ?, ?
			)`, 1, project, wantPathSQLite, depth(wantPathSQLite), "active")

			// テスト用のリクエストを送信
			d := newDirectoryRepositoryForTest(t, testDB)
			recorder := httptest.NewRecorder()
			_, router := gin.CreateTestContext(recorder)
			router.GET("/projects/:project/directories", d.List)
			req, err := http.NewRequest("GET", test.url, nil)
			require.Nil(t, err)
			router.ServeHTTP(recorder, req)

			// レスポンスを確認
			assert.Equal(t, recorder.Code, http.StatusOK)

			var res map[string]any
			require.Nil(t, json.Unmarshal([]byte(recorder.Body.String()), &res))

			gotTotal := int(res["total"].(float64))
			assert.Equal(t, 1, gotTotal)

			gotPath := res["directories"].([]any)[0].(map[string]any)["path"].(string)
			assert.Equal(t, test.wantPath, gotPath)
		})
	}
}

func newDirectoryRepositoryForTest(t *testing.T, db *gorm.DB) *Directory {
	t.Helper()

	gdrepo, err := repository.NewGroupDirectory(db)
	require.Nil(t, err)

	drepo, err := repository.NewDirectory(db, gdrepo)
	require.Nil(t, err)

	ddirepo, err := repository.NewDirectoryDeletionInfo(db)
	require.Nil(t, err)

	psmrepo, err := repository.NewProjectStudioMap(db)
	require.Nil(t, err)

	pjrepo, err := repository.NewProjectInfo(db, psmrepo)
	require.Nil(t, err)

	sdrepo, err := repository.NewStudioInfo(db)
	require.Nil(t, err)

	psrepo, err := repository.NewPipelineSetting(db)
	require.Nil(t, err)

	readTimeout := 1 * time.Second
	writeTimeout := 1 * time.Second
	return NewDirectory(usecase.NewDirectory(
		drepo,
		pjrepo,
		sdrepo,
		ddirepo,
		psrepo,
		readTimeout,
		writeTimeout,
	))
}
