package delivery

import (
	"net/http"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

// DataSyncClient provides PPI DataSync Client related request handlers.
type DataSyncClient struct {
	uc *usecase.DataSyncClient
}

// NewDataSyncClient returns a new DataSyncClient delivery.
func NewDataSyncClient(uc *usecase.DataSyncClient) *DataSyncClient {
	return &DataSyncClient{uc: uc}
}

// GetStatus outputs the operational status of the PPI DataSync Client in
// the project and studio specified by the URL to the HTTP response. The
// output data is entity.DataSyncClientStatus encoded as JSON.
//
// As of now, the studio name in the URL and the studio name in the access
// token need to be the same. However, in the future, it might be possible
// to allow studios with administrative privileges to retrieve the status of
// any studio project.
func (h *DataSyncClient) GetStatus(c *gin.Context) {
	project := c.Param("project")
	studio := c.Param("studio")

	studioAuthed, ok := c.Get("studio")
	if !ok {
		forbidden(c, entity.ErrForbidden)
		return
	}

	studioAuthedStr := studioAuthed.(string)
	if studioAuthedStr == "" {
		forbidden(c, entity.ErrForbidden)
		return
	}

	if studio != studioAuthedStr {
		forbidden(c, entity.ErrForbidden)
		return
	}

	e, err := h.uc.GetStatus(c.Request.Context(), project, studio)
	if err != nil {
		jsonError(c, err)
		return
	}

	c.PureJSON(http.StatusOK, e)
}
