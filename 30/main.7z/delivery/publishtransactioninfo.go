package delivery

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type listPublishTransactionInfoParams struct {
	PerPage      *int    `form:"per_page"`
	Page         *int    `form:"page"`
	RevisionPath *string `form:"revision_path"`
	Operation    *string `form:"operation"`
	Event        *string `form:"event"`
	Studio       *string `form:"studio"`
	Root         *string `form:"root"`
	Group        *string `form:"group"`
	Phase        *string `form:"phase"`
	Component    *string `form:"component"`
	User         *string `form:"user"`
	Revision     *string `form:"revision"`
	IsExact      bool    `form:"is_exact"`
}

func (p listPublishTransactionInfoParams) Entity(
	project string,
) *entity.ListPublishTransactionInfoParams {
	return &entity.ListPublishTransactionInfoParams{
		Project:      project,
		RevisionPath: p.RevisionPath,
		Operation:    p.Operation,
		Event:        p.Event,
		Studio:       p.Studio,
		Root:         p.Root,
		Group:        p.Group,
		Phase:        p.Phase,
		Component:    p.Component,
		User:         p.User,
		Revision:     p.Revision,
		IsExact:      p.IsExact,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
}

type createPublishTransactionInfoParams struct {
	LogID          string            `json:"log_id"`
	TaskID         string            `json:"task_id"`
	SubtaskID      string            `json:"subtask_id"`
	Studio         string            `json:"studio"`
	ProjectPath    string            `json:"project_path"`
	RevisionPath   string            `json:"revision_path"`
	Root           *string           `json:"root"`
	Groups         []string          `json:"groups"`
	Relation       *string           `json:"relation"`
	Phase          *string           `json:"phase"`
	Component      *string           `json:"component"`
	Revision       *string           `json:"revision"`
	NumBytes       *int64            `json:"num_bytes"`
	NumFiles       *int32            `json:"num_files"`
	ToolName       *string           `json:"tool_name"`
	ToolVersion    *string           `json:"tool_version"`
	Computer       *string           `json:"computer"`
	OS             *string           `json:"os"`
	OSVersion      *string           `json:"os_version"`
	User           *string           `json:"user"`
	TimestampUTC   *time.Time        `json:"timestamp_utc"`
	Operation      string            `json:"operation"`
	Event          string            `json:"event"`
	StackTrace     *string           `json:"stack_trace"`
	AdditionalInfo entity.JSONObject `json:"additional_info"`
}

func (p *createPublishTransactionInfoParams) Entity(
	project string,
	createdBy *string,
) *entity.CreatePublishTransactionInfoParams {
	return &entity.CreatePublishTransactionInfoParams{
		LogID:          p.LogID,
		TaskID:         p.TaskID,
		SubtaskID:      p.SubtaskID,
		Studio:         p.Studio,
		Project:        project,
		ProjectPath:    p.ProjectPath,
		RevisionPath:   p.RevisionPath,
		Root:           p.Root,
		Groups:         p.Groups,
		Relation:       p.Relation,
		Phase:          p.Phase,
		Component:      p.Component,
		Revision:       p.Revision,
		NumBytes:       p.NumBytes,
		NumFiles:       p.NumFiles,
		ToolName:       p.ToolName,
		ToolVersion:    p.ToolVersion,
		Computer:       p.Computer,
		OS:             p.OS,
		OSVersion:      p.OSVersion,
		User:           p.User,
		TimestampUTC:   p.TimestampUTC,
		Operation:      p.Operation,
		Event:          p.Event,
		StackTrace:     p.StackTrace,
		AdditionalInfo: p.AdditionalInfo,
		CreatedBy:      createdBy,
	}
}

func NewPublishTransactionInfo(
	uc *usecase.PublishTransactionInfo,
) *PublishTransactionInfo {
	return &PublishTransactionInfo{
		uc: uc,
	}
}

type PublishTransactionInfo struct {
	uc *usecase.PublishTransactionInfo
}

func (h *PublishTransactionInfo) List(c *gin.Context) {
	var p listPublishTransactionInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"))

	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse(
		"publish_transaction_infos",
		entities,
		c.Request,
		params,
		total,
	)
	c.PureJSON(http.StatusOK, res)
}

func (h *PublishTransactionInfo) Get(c *gin.Context) {
	logID := c.Param("logID")
	params := &entity.GetPublishTransactionInfoParams{
		Project: c.Param("project"),
		LogID:   logID,
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf(
				"publish transaction info with log ID %q not found", params.LogID,
			))
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *PublishTransactionInfo) Post(c *gin.Context) {
	var p createPublishTransactionInfoParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"), nil)
	e, err := h.uc.Create(c.Request.Context(), params)

	if err != nil {
		errorInfo := &entity.ApiProcessError{
			Studio:      params.Studio,
			Title:       "Error in PublishTransactionInfo Create API",
			InfoLabel:   "Revision Path",
			InfoContent: params.RevisionPath,
			Error:       err,
		}
		c.Set("notificationErrorInfo", errorInfo)

		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)

	// set info for notification process
	info := &entity.PublishTransactionInfoNotification{
		Studio:         e.Studio,
		Project:        e.Project,
		TaskID:         e.TaskID,
		SubtaskID:      e.SubtaskID,
		Root:           e.Root,
		Phase:          e.Phase,
		Component:      e.Component,
		Revision:       e.Revision,
		Operation:      e.Operation,
		Event:          e.Event,
		RevisionPath:   e.RevisionPath,
		User:           e.User,
		Computer:       e.Computer,
		ToolName:       e.ToolName,
		ToolVersion:    e.ToolVersion,
		PublishedTime:  e.TimestampUTC,
		StackTrace:     e.StackTrace,
		AdditionalInfo: e.AdditionalInfo,
	}
	c.Set("publishNotificationInfo", info)
}

func (h *PublishTransactionInfo) Delete(c *gin.Context) {
	logID, err := strconv.Atoi(c.Param("logID"))
	if err != nil {
		badRequest(c, err)
		return
	}
	params := &entity.DeletePublishTransactionInfoParams{
		Project:    c.Param("project"),
		LogID:      int32(logID),
		ModifiedBy: nil,
	}
	if err := h.uc.Delete(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf(
				"publish transaction info with log ID %q not found", params.LogID,
			))
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}
