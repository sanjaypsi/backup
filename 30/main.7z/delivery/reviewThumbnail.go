package delivery

import (
	"net/http"
	"os"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type ReviewThumbnail struct {
	uc *usecase.ReviewThumbnail
}

func NewReviewThumbnail(uc *usecase.ReviewThumbnail) *ReviewThumbnail {
	return &ReviewThumbnail{
		uc: uc,
	}
}

func (rt *ReviewThumbnail) GetAssetThumbnail(c *gin.Context) {
	params := &entity.GetAssetThumbnailParams{
		Project:  c.Param("project"),
		Asset:    c.Param("asset"),
		Relation: c.Param("relation"),
	}

	thumbnailPath, err := rt.uc.GetAssetThumbnail(params)
	if thumbnailPath == "" || err != nil {
		if err == os.ErrNotExist {
			c.Status(http.StatusNoContent)
			return
		}
		c.JSON(http.StatusBadRequest, gin.H{"error": "Thumbnail Filepath is missing"})
		return
	}
	c.File(thumbnailPath)
}

type shotThumbnailParams struct {
	Group1   string `form:"group1"`
	Group2   string `form:"group2"`
	Group3   string `form:"group3"`
	Relation string `form:"relation"`
}

func (p *shotThumbnailParams) Entity(project string) *entity.GetShotThumbnailParams {
	return &entity.GetShotThumbnailParams{
		Project:  project,
		Group1:   p.Group1,
		Group2:   p.Group2,
		Group3:   p.Group3,
		Relation: p.Relation,
	}
}

func (rt *ReviewThumbnail) GetShotThumbnail(c *gin.Context) {
	var p shotThumbnailParams
	if err := c.ShouldBindQuery(&p); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	params := p.Entity(c.Param("project"))
	thumbnailPath, err := rt.uc.GetShotThumbnail(params)
	if thumbnailPath == "" || err != nil {
		if err == os.ErrNotExist {
			c.Status(http.StatusNoContent)
			return
		}
		c.JSON(http.StatusBadRequest, gin.H{"error": "Thumbnail Filepath is missing"})
		return
	}
	c.File(thumbnailPath)
}
