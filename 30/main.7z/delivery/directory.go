package delivery

import (
	"errors"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

// Directory

type Directory struct {
	uc *usecase.Directory
}

func NewDirectory(uc *usecase.Directory) *Directory {
	return &Directory{
		uc: uc,
	}
}

type listDirectoryParams struct {
	Path          *string    `form:"path"`
	Status        *string    `form:"status"`
	Depth         *int32     `form:"depth"`
	ModifiedSince *time.Time `form:"modified_since"`
	OrderBy       *string    `form:"order_by"`
	SQLite        *int       `form:"sqlite"`
	PerPage       *int       `form:"per_page"`
	Page          *int       `form:"page"`
}

func (p *listDirectoryParams) Entity(
	project string,
) (*entity.ListDirectoryParams, error) {
	params := &entity.ListDirectoryParams{
		Project:       project,
		PathPrefix:    p.Path,
		Depth:         p.Depth,
		ModifiedSince: p.ModifiedSince,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
	if p.Status != nil {
		status, err := entity.ParseDeletionStats(*p.Status)
		if err != nil {
			return nil, err
		}
		params.Status = &status
	}
	if p.OrderBy != nil {
		for _, orderBy := range strings.Split(*p.OrderBy, ",") {
			if strings.HasSuffix(orderBy, "modified_at") {
				orderBy += "_utc"
			}
			params.OrderBy = append(params.OrderBy, orderBy)
		}
	}
	params.SQLite = p.SQLite != nil && *p.SQLite == 1
	return params, nil
}

func (h *Directory) List(c *gin.Context) {
	var p listDirectoryParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}

	params, err := p.Entity(c.Param("project"))
	if err != nil {
		badRequest(c, err)
		return
	}

	// レスポンスを返すまでのタイムアウトをusecase.Directory.ReadTimeoutに合
	// わせる。失敗してもリクエストをエラーにはしない。
	rc := http.NewResponseController(c.Writer)
	if err := rc.SetWriteDeadline(time.Now().Add(h.uc.ReadTimeout)); err != nil {
		log.Printf("ERROR: failed to set the deadline for the writing response: method=%s, url=%s, err=%s", c.Request.Method, c.Request.URL, err)
	}

	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse(
		"directories",
		entities,
		c.Request,
		params,
		total,
	)
	c.PureJSON(http.StatusOK, res)
}

func (h *Directory) Get(c *gin.Context) {
	params := &entity.GetDirectoryParams{
		Project: c.Param("project"),
		Path:    strings.Trim(c.Param("path"), "/"),
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("directory %q not found", params.Path))
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type createDirectoryParams struct {
	Path      string  `json:"path"`
	CreatedBy *string `json:"created_by,omitempty"`
}

func (p *createDirectoryParams) Entity(
	project string,
	createdBy *string,
) *entity.CreateDirectoryParams {
	var parts []string
	for _, part := range strings.Split(strings.ReplaceAll(p.Path, "\\", "/"), "/") {
		if part != "" {
			parts = append(parts, part)
		}
	}
	if createdBy == nil && p.CreatedBy != nil {
		createdBy = p.CreatedBy
	}
	return &entity.CreateDirectoryParams{
		Project:   project,
		Path:      strings.Join(parts, "/"),
		CreatedBy: createdBy,
	}
}

func (h *Directory) Post(c *gin.Context) {
	lgr := NewLogger(c.Request)

	project := c.Param("project")
	lgr.SetProject(project)

	var p createDirectoryParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		jsonError(c, retErr)
		return
	}

	lgr.Set("createDirectoryParams", p)
	params := p.Entity(project, nil)
	dirs, err := h.uc.Create(c.Request.Context(), params)
	if err != nil {
		jsonError(c, err)
		return
	}

	lgr.Set("createdDirectories", dirs)
	lgr.Info("Directory created")
	c.PureJSON(http.StatusOK, map[string]interface{}{
		"directories": dirs,
	})
}

type validateDirectoriesParams struct {
	Studio string `json:"studio"`
	Path   string `json:"path"`
}

func (h *Directory) studio(c *gin.Context) *string {
	studio, ok := c.Get("studio")
	if !ok {
		return nil
	}
	s := studio.(string)
	return &s
}

func (p *validateDirectoriesParams) Entity(
	project string,
) *entity.ValidateDirectoryParams {
	return &entity.ValidateDirectoryParams{
		Studio:  p.Studio,
		Project: project,
		Path:    p.Path,
	}
}

// Pre-testing post requests from csv input before accepting actual create requests
func (h *Directory) PostValidate(c *gin.Context) {
	var p validateDirectoriesParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"))
	dir, err := h.uc.ValidateGroup(c.Request.Context(), params)
	if err != nil {
		badRequest(c, err)
		return
	}

	c.PureJSON(http.StatusOK, map[string]interface{}{
		"directory": &dir,
	})
}

type deleteDirectoryParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deleteDirectoryParams) Entity(
	project string,
	path string,
	modifiedBy *string,
) *entity.DeleteDirectoryParams {
	if modifiedBy == nil && p.ModifiedBy != nil {
		modifiedBy = p.ModifiedBy
	}
	return &entity.DeleteDirectoryParams{
		Project:    project,
		Path:       path,
		ModifiedBy: modifiedBy,
	}
}

func (h *Directory) Delete(c *gin.Context) {
	var p deleteDirectoryParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	project := c.Param("project")
	path := strings.Trim(c.Param("path"), "/")
	params := p.Entity(project, path, nil)
	if err := h.uc.DeleteFromProject(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("directory %q not found", params.Path))
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

// Studio Directory

type deleteStudioDirectoryParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deleteStudioDirectoryParams) Entity(
	project string,
	studio string,
	path string,
	modifiedBy *string,
) *entity.DeleteDirectoryFromStudioParams {
	if modifiedBy == nil && p.ModifiedBy != nil {
		modifiedBy = p.ModifiedBy
	}
	return &entity.DeleteDirectoryFromStudioParams{
		Project:    project,
		Studio:     studio,
		Path:       path,
		ModifiedBy: modifiedBy,
	}
}

type StudioDirectory struct {
	uc *usecase.Directory
}

func NewStudioDirectory(uc *usecase.Directory) *StudioDirectory {
	return &StudioDirectory{
		uc: uc,
	}
}

func (h *StudioDirectory) Delete(c *gin.Context) {
	var p deleteStudioDirectoryParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	project := c.Param("project")
	studio := c.Param("studio")
	path := strings.Trim(c.Param("path"), "/")
	params := p.Entity(project, studio, path, nil)
	if err := h.uc.DeleteFromStudio(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("directory %q not found or not 'to_delete' status", params.Path))
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}
