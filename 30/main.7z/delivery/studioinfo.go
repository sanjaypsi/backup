package delivery

import (
	"errors"
	"net/http"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type StudioInfo struct {
	uc *usecase.StudioInfo
}

func NewStudioInfo(uc *usecase.StudioInfo) *StudioInfo {
	return &StudioInfo{
		uc: uc,
	}
}

type listStudioInfoParams struct {
	PerPage *int `form:"per_page"`
	Page    *int `form:"page"`
}

func (p *listStudioInfoParams) Entity(studio string) *entity.ListStudioInfoParams {
	return &entity.ListStudioInfoParams{
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
		Studio: studio,
	}
}

// List returns publish transaction infos.
func (h *StudioInfo) List(c *gin.Context) {
	var p listStudioInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	studio, ok := c.Get("studio")
	if !ok && !entity.SkipAuth {
		badRequest(c, entity.ErrBadRequest)
		return
	}
	if entity.SkipAuth && studio == "" {
		studio = "skipauth"
	}
	studioStr, ok := studio.(string)
	if !ok {
		badRequest(c, entity.ErrBadRequest)
		return
	}
	params := p.Entity(studioStr)

	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		badRequest(c, err)
		return
	}

	res := libs.CreateListResponse(
		"studios",
		entities,
		c.Request,
		params,
		total,
	)
	c.PureJSON(http.StatusOK, res)
}

func (h *StudioInfo) Get(c *gin.Context) {
	params := &entity.GetStudioInfoParams{
		KeyName: c.Param("studio"),
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type createStudioInfoParams struct {
	KeyName   string  `json:"key_name"`
	CreatedBy *string `json:"created_by"` // Getting the user name from the request body is a temporary measure until the login feature is implemented.
}

func (p *createStudioInfoParams) Entity(createdBy *string) *entity.CreateStudioInfoParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	return &entity.CreateStudioInfoParams{
		KeyName:   p.KeyName,
		CreatedBy: createdBy,
	}
}

func (h *StudioInfo) Post(c *gin.Context) {
	var p createStudioInfoParams
	err := c.ShouldBind(&p)
	if err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(nil)
	e, err := h.uc.Create(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type patchStudioParams struct {
	Operation  string   `json:"operation"`
	Projects   []string `json:"projects"`
	ModifiedBy *string  `json:"modified_by"`
}

func (p *patchStudioParams) Params(
	studio string,
	modifiedBy *string,
) *entity.UpdateStudioParams {
	if modifiedBy == nil && p.ModifiedBy != nil {
		modifiedBy = p.ModifiedBy
	}
	return &entity.UpdateStudioParams{
		GetStudioInfoParams: &entity.GetStudioInfoParams{
			KeyName: studio,
		},
		Operation:  p.Operation,
		Projects:   p.Projects,
		ModifiedBy: modifiedBy,
	}
}

func (h *StudioInfo) Patch(c *gin.Context) {
	var p patchStudioParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	studio := c.Param("studio")
	params := p.Params(studio, nil)
	e, err := h.uc.Update(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type deleteStudioInfoParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deleteStudioInfoParams) Params(
	studio string,
	modifiedBy *string,
) *entity.DeleteStudioInfoParams {
	if modifiedBy == nil && p.ModifiedBy != nil {
		modifiedBy = p.ModifiedBy
	}
	return &entity.DeleteStudioInfoParams{
		KeyName:    studio,
		ModifiedBy: modifiedBy,
	}
}

func (h *StudioInfo) Delete(c *gin.Context) {
	var p deleteStudioInfoParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	studio := c.Param("studio")
	params := p.Params(studio, nil)
	if err := h.uc.Delete(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}
