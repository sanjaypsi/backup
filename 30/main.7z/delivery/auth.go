package delivery

import (
	"errors"
	"net/http"
	"os"
	"strings"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type Auth struct {
	uc *usecase.Auth
}

func NewAuth(uc *usecase.Auth) *Auth {
	return &Auth{
		uc: uc,
	}
}

/********************* Token Authentication Handlers *********************/

// middleware to parse token placed in authrorization header
func (d *Auth) ParseHeaderToken(c *gin.Context) {
	req := c.Request
	if strings.HasPrefix(req.URL.Path, "/api/auth/login") ||
		strings.HasPrefix(req.URL.Path, "/api/setting/rc1") {
		return
	}
	params := &entity.StudioAuthParams{
		Project:    c.Param("project"),
		AuthHeader: req.Header.Get(entity.AuthHeader),
	}
	name, err := d.uc.ParseHeaderToken(req.Context(), params)
	if err != nil && !entity.SkipAuth {
		if errors.Is(err, entity.ErrUnauthorized) {
			unauthorized(c, err)
			return
		}
		if errors.Is(err, entity.ErrForbidden) {
			forbidden(c, err)
			return
		}
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Set("studio", name)
}

// middleware to parse token in query parameter
func (d *Auth) ParseQueryToken(c *gin.Context) {
	tokenStr := c.Query(entity.QueryToken)
	if tokenStr == "" {
		return
	}
	env := ""
	if os.Getenv(entity.RunEnv) == entity.LocalEnv {
		env = entity.Localdev
	}
	name, err := d.uc.ParseQueryToken(c.Request.Context(), tokenStr)
	if !entity.SkipAuth && err != nil {
		c.Redirect(http.StatusSeeOther, env+"/login")
	}
	newToken, err := d.uc.CreateNewToken(name)
	if err != nil {
		c.Redirect(http.StatusSeeOther, env+"/login")
	}
	c.Redirect(http.StatusSeeOther, env+c.Request.URL.Path+"?"+entity.QueryToken+"="+newToken)
}

/********************* Project/Studio Access Handler *********************/
func (d *Auth) CheckAccessPermission(c *gin.Context) {
	req := c.Request
	if entity.SkipAuth ||
		!strings.Contains(req.URL.Path, "/projects") &&
			!strings.Contains(req.URL.Path, "/studios") {
		return
	}
	name, ok := c.Get("studio")
	if !ok {
		unauthorized(c, entity.ErrUnauthorized)
		return
	}
	nameStr, ok := name.(string)
	if !ok {
		badRequest(c, entity.ErrBadRequest)
		return
	}

	// check access permission on studios
	if strings.Contains(req.URL.Path, "/studios") {

		if strings.HasPrefix(req.URL.Path, "/api/studios") {
			// StudioInfo API
			if !isAdminStudio(nameStr) {
				switch req.Method {
				case "GET":
					if req.URL.Path == "/api/studios" {
						return
					}
					if nameStr != c.Param("studio") {
						forbidden(c, entity.ErrForbidden)
					}
				default:
					forbidden(c, entity.ErrForbidden)
				}
			}
			return
		}

		// Other APIs, mainly for PipelineSetting API
		if !isAdminStudio(nameStr) && nameStr != c.Param("studio") {
			forbidden(c, entity.ErrForbidden)
			return
		}
	}

	// check access permission on projects
	if strings.Contains(req.URL.Path, "/projects") {
		switch req.URL.Path {
		case "/api/projects":
			switch req.Method {
			case "GET":
				return
			case "POST":
				if nameStr != "ppi" && nameStr != "ppidev" {
					forbidden(c, entity.ErrForbidden)
				}
				return
			default:
				return
			}
		default:
			params := &entity.ProjectAccessParams{
				Studio:  nameStr,
				Project: c.Param("project"),
			}
			if err := d.uc.CheckProjectAccess(req.Context(), params); err != nil {
				if errors.Is(err, entity.ErrUnauthorized) {
					unauthorized(c, err)
					return
				}
				if errors.Is(err, entity.ErrForbidden) {
					forbidden(c, err)
					return
				}
				if errors.Is(err, entity.ErrBadRequest) {
					badRequest(c, err)
					return
				}
				internalServerError(c, err)
				return
			}
		}
	}
}

func isAdminStudio(studio string) bool {
	return studio == "ppi" || studio == "ppidev"
}

func (d *Auth) CreateNewToken(c *gin.Context) {
	if strings.HasPrefix(c.Request.URL.Path, "/api/auth/login") ||
		strings.HasPrefix(c.Request.URL.Path, "/api/setting/rc1") {
		return
	}
	name, ok := c.Get("studio")
	if !entity.SkipAuth && !ok {
		unauthorized(c, entity.ErrUnauthorized)
		return
	}
	if entity.SkipAuth && name == "" {
		name = "skipauth"
	}
	nameStr, ok := name.(string)
	if !ok {
		badRequest(c, entity.ErrBadRequest)
	}
	token, err := d.uc.CreateNewToken(nameStr)
	if err != nil {
		internalServerError(c, err)
		return
	}
	c.Header("WWW-Authenticate", token)
	rawstudio, ok := c.Get("studio")
	if !ok {
		return
	}
	studio, ok := rawstudio.(string)
	if !ok {
		return
	}
	c.Header("Studio", studio)
}

/********************* Login Handler *********************/

type loginParams struct {
	Studio   string `json:"studio"`
	Password string `json:"pass"`
}

func (p *loginParams) Entity() *entity.LoginParams {
	return &entity.LoginParams{
		Studio:   p.Studio,
		Password: p.Password,
	}
}

// API handler for login function
func (d *Auth) Login(c *gin.Context) {
	var p loginParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity()
	name, err := d.uc.Login(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrUnauthorized) {
			unauthorized(c, err)
			return
		}
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	token, err := d.uc.CreateNewToken(name)
	if err != nil {
		internalServerError(c, err)
		return
	}
	c.Header("WWW-Authenticate", token)
}
