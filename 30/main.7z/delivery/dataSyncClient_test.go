package delivery

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"cloud.google.com/go/logging"
	"cloud.google.com/go/logging/logadmin"
	"github.com/gin-gonic/gin"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/usecase"
)

type StubCloudLoggingFinder struct {
	Entry *logging.Entry
	Err   error
}

func (f StubCloudLoggingFinder) FindOne(
	ctx context.Context,
	opts ...logadmin.EntriesOption,
) (*logging.Entry, error) {
	return f.Entry, f.Err
}

func TestDataSyncClientGetStatusOK(t *testing.T) {
	project := "potoodev"
	studio := "ppidev"

	finder := newFinder(nil)
	d := newDelivery(finder)

	router, recorder := newRouter(d, func(c *gin.Context) {
		c.Set("studio", studio)
	})
	router.GET("/projects/:project/studios/:studio/dataSyncClient/status", d.GetStatus)
	requestPath := fmt.Sprintf("/projects/%s/studios/%s/dataSyncClient/status", project, studio)
	req, _ := http.NewRequest("GET", requestPath, nil)

	router.ServeHTTP(recorder, req)

	assertCode(t, recorder.Code, http.StatusOK)

	e := &entity.DataSyncClientStatus{
		Project:     project,
		Studio:      studio,
		Status:      "healthy",
		ConfirmedAt: &finder.Entry.Timestamp,
	}
	assertBody(t, recorder.Body.String(), e)
}

func TestDataSyncClientGetStatusNoAuthedStudio(t *testing.T) {
	project := "potoodev"
	studio := "ppidev"

	d := newDelivery(newFinder(nil))
	router, recorder := newRouter(d, nil)
	router.GET("/projects/:project/studios/:studio/dataSyncClient/status", d.GetStatus)
	requestPath := fmt.Sprintf("/projects/%s/studios/%s/dataSyncClient/status", project, studio)
	req, _ := http.NewRequest("GET", requestPath, nil)
	router.ServeHTTP(recorder, req)
	assertCode(t, recorder.Code, http.StatusForbidden)
}

func TestDataSyncClientGetStatusDifferentStudio(t *testing.T) {
	project := "potoodev"
	studioAuthed := "ppidev"
	studioParam := "ppidev2"

	d := newDelivery(newFinder(nil))
	router, recorder := newRouter(d, func(c *gin.Context) {
		c.Set("studio", studioAuthed)
	})
	router.GET("/projects/:project/studios/:studio/dataSyncClient/status", d.GetStatus)
	requestPath := fmt.Sprintf("/projects/%s/studios/%s/dataSyncClient/status", project, studioParam)
	req, _ := http.NewRequest("GET", requestPath, nil)
	router.ServeHTTP(recorder, req)
	assertCode(t, recorder.Code, http.StatusForbidden)
}

func TestDataSyncClientGetStatusUnexpectedError(t *testing.T) {
	project := "potoodev"
	studio := "ppidev"

	message := "unexpected error occured"
	finder := newFinder(errors.New(message))
	d := newDelivery(finder)

	router, recorder := newRouter(d, func(c *gin.Context) {
		c.Set("studio", studio)
	})
	router.GET("/projects/:project/studios/:studio/dataSyncClient/status", d.GetStatus)
	requestPath := fmt.Sprintf("/projects/%s/studios/%s/dataSyncClient/status", project, studio)
	req, _ := http.NewRequest("GET", requestPath, nil)

	router.ServeHTTP(recorder, req)

	assertCode(t, recorder.Code, http.StatusInternalServerError)

	got := recorder.Body.String()
	want := fmt.Sprintf(`{"message":"%s"}`, message)
	if got != want {
		t.Errorf("got %q, want %q", got, want)
	}
}

func newFinder(err error) StubCloudLoggingFinder {
	return StubCloudLoggingFinder{
		Entry: &logging.Entry{Timestamp: time.Now()},
		Err:   err,
	}
}

func newDelivery(finder StubCloudLoggingFinder) *DataSyncClient {
	repo := repository.NewDataSyncClient(finder, "test_gcp_project")
	uc := usecase.NewDataSyncClient(repo, 1*time.Second)
	return NewDataSyncClient(uc)
}

func newRouter(d *DataSyncClient, middleware func(*gin.Context)) (*gin.Engine, *httptest.ResponseRecorder) {
	recorder := httptest.NewRecorder()
	_, router := gin.CreateTestContext(recorder)
	if middleware != nil {
		router.Use(middleware)
	}
	return router, recorder
}

func assertCode(t *testing.T, got, want int) {
	t.Helper()

	if got != want {
		t.Errorf("got %d, want %d", got, want)
	}
}

func assertBody(t *testing.T, got string, e *entity.DataSyncClientStatus) {
	t.Helper()

	b, err := json.Marshal(*e)
	if err != nil {
		t.Fatal(err)
	}

	want := strings.TrimSpace(string(b))
	gotTrimmed := strings.TrimSpace(got)
	if gotTrimmed != want {
		t.Errorf("got %q, want %q", gotTrimmed, want)
	}
}
