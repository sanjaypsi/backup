package delivery

import (
	"errors"
	"net/http"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type ProjectInfo struct {
	uc *usecase.ProjectInfo
}

func NewProjectInfo(uc *usecase.ProjectInfo) *ProjectInfo {
	return &ProjectInfo{
		uc: uc,
	}
}

type listProjectInfoParams struct {
	PerPage *int `form:"per_page"`
	Page    *int `form:"page"`
}

func (p *listProjectInfoParams) Entity(studio string) *entity.ListProjectInfoParams {
	return &entity.ListProjectInfoParams{
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
		Studio: studio,
	}
}

// List returns publish transaction infos.
func (h *ProjectInfo) List(c *gin.Context) {
	var p listProjectInfoParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	studio, ok := c.Get("studio")
	if !ok && !entity.SkipAuth {
		badRequest(c, entity.ErrBadRequest)
		return
	}
	if entity.SkipAuth && studio == "" {
		studio = "skipauth"
	}
	studioStr, ok := studio.(string)
	if !ok {
		badRequest(c, entity.ErrBadRequest)
		return
	}
	params := p.Entity(studioStr)

	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		badRequest(c, err)
		return
	}

	res := libs.CreateListResponse(
		"projects",
		entities,
		c.Request,
		params,
		total,
	)
	c.PureJSON(http.StatusOK, res)
}

func (h *ProjectInfo) Get(c *gin.Context) {
	params := &entity.GetProjectInfoParams{
		KeyName: c.Param("project"),
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type createProjectInfoParams struct {
	KeyName   string  `json:"key_name"`
	CreatedBy *string `json:"created_by"` // Getting the user name from the request body is a temporary measure until the login feature is implemented.
}

func (p *createProjectInfoParams) Entity(createdBy *string) *entity.CreateProjectInfoParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	return &entity.CreateProjectInfoParams{
		KeyName:   p.KeyName,
		CreatedBy: createdBy,
	}
}

func (h *ProjectInfo) Post(c *gin.Context) {
	var p createProjectInfoParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(nil)
	e, err := h.uc.Create(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type deleteProjectInfoParams struct {
	ModifiedBy *string `json:"modified_by"` // Getting the user name from the request body is a temporary measure until the login feature is implemented.
}

func (p *deleteProjectInfoParams) Entity(
	keyName string,
	modifiedBy *string,
) *entity.DeleteProjectInfoParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	return &entity.DeleteProjectInfoParams{
		KeyName:    keyName,
		ModifiedBy: modifiedBy,
	}
}

func (h *ProjectInfo) Delete(c *gin.Context) {
	var p deleteProjectInfoParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"), nil)
	if err := h.uc.Delete(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}
