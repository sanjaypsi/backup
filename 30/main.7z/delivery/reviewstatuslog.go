package delivery

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"
	"sort"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type listReviewStatusLogParams struct {
	Studio       *string `form:"studio"`
	Project      *string `form:"project"`
	UpdateID     *string `form:"update_id"`
	ReviewInfoID *int32  `form:"review_info_id"`
	StatusType   *string `form:"status_type"`
	Status       *string `form:"status"`
	PerPage      *int    `form:"per_page"`
	Page         *int    `form:"page"`
}

func (p *listReviewStatusLogParams) Entity(
	project string,
) *entity.ListReviewStatusLogParams {
	return &entity.ListReviewStatusLogParams{
		Studio:       p.Studio,
		Project:      project,
		UpdateID:     p.UpdateID,
		ReviewInfoID: p.ReviewInfoID,
		StatusType:   p.StatusType,
		Status:       p.Status,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
}

type createReviewStatusLogParams struct {
	Studio       string    `json:"studio"`
	Project      string    `json:"project"`
	UpdateID     string    `json:"update_id"`
	ReviewInfoID int32     `json:"review_info_id"`
	StatusType   string    `json:"status_type"`
	Status       string    `json:"status"`
	CreatedAtUTC time.Time `json:"created_at_utc"`
	CreatedBy    string    `json:"created_by"`
}

func (p *createReviewStatusLogParams) Entity(
	project string,
) *entity.CreateReviewStatusLogParams {
	return &entity.CreateReviewStatusLogParams{
		Studio:       p.Studio,
		Project:      project,
		UpdateID:     p.UpdateID,
		ReviewInfoID: p.ReviewInfoID,
		StatusType:   p.StatusType,
		Status:       p.Status,
		CreatedBy:    p.CreatedBy,
	}
}

func NewReviewStatusLog(
	uc *usecase.ReviewStatusLog,
	riuc *usecase.ReviewInfo,
	psuc *usecase.PipelineSetting,
) *ReviewStatusLog {
	return &ReviewStatusLog{
		uc:   uc,
		riuc: riuc,
		psuc: psuc,
	}
}

type ReviewStatusLog struct {
	uc   *usecase.ReviewStatusLog
	riuc *usecase.ReviewInfo
	psuc *usecase.PipelineSetting
}

func (h *ReviewStatusLog) List(c *gin.Context) {
	var p listReviewStatusLogParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	params := p.Entity(c.Param("project"))

	entities, total, err := h.uc.List(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse("review_statuses", entities, c.Request, params, total)
	c.PureJSON(http.StatusOK, res)
}

func (h *ReviewStatusLog) Get(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		badRequest(c, err)
		return
	}
	params := &entity.GetReviewParams{
		Project: c.Param("project"),
		ID:      int32(id),
	}
	e, err := h.uc.Get(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			badRequest(c, fmt.Errorf("review status log with ID %d not found", params.ID))
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type TakeParams struct {
	ID             int32                    `json:"id"`
	ApprovalStatus string                   `json:"approval_status"`
	WorkStatus     string                   `json:"work_status"`
	Comments       []map[string]interface{} `json:"comments"`
}

type CreateParams struct {
	Studio       string `json:"studio"`
	Project      string `json:"project"`
	ReviewInfoID int32  `json:"review_info_id"`
	StatusType   string `json:"status_type"`
	Status       string `json:"status"`
	CreatedBy    string `json:"created_by"`
}

func (h *ReviewStatusLog) Post(c *gin.Context) {
	params := &entity.GetReviewStatusesParams{
		Project:         c.Param("project"),
		Studio:          c.Query("studio"),
		MailAddresses:   c.QueryArray("mail_addresses"),
		MailCCAddresses: c.QueryArray("mail_cc_addresses"),
		MailSubject:     c.Query("mail_subject"),
		MailComment:     c.Query("mail_comment"),
		ModifiedAtUTC:   time.Now().UTC(),
		ModifiedBy:      c.Query("modified_by"),
		TakeParams:      c.QueryArray("take_params"),
		RelationList:    c.QueryArray("relation_list"),
		PhaseList:       c.QueryArray("phase_list"),
	}
	err := h.uc.CheckForReviewStatusesParams(params)
	if err != nil {
		setNotificationErrorInfo(c, params, err)
		badRequest(c, err)
		return
	}

	var createParamsList []*CreateParams
	var takeList []string
	var tableParamsList []*entity.ReviewEmailItem

	langSet := map[string]struct{}{}
	for _, s := range params.TakeParams {
		var takeParams TakeParams
		err = json.Unmarshal([]byte(s), &takeParams)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			badRequest(c, err)
			return
		}

		// get reviewInfo
		getReviewInfoParams := &entity.GetReviewParams{
			Project: c.Param("project"),
			ID:      takeParams.ID,
		}
		reviewInfo, err := h.riuc.Get(c.Request.Context(), getReviewInfoParams)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}

		group := strings.Join(reviewInfo.Groups, "/")
		tempTake := strings.Split(reviewInfo.Take, ".")
		take := tempTake[1]
		changes := ""
		approvalStatus := reviewInfo.ApprovalStatus
		workStatus := reviewInfo.WorkStatus
		var valueStr []string

		// make createParams
		if takeParams.ApprovalStatus != "" {
			if reviewInfo.ApprovalStatus != takeParams.ApprovalStatus {
				createParams := &CreateParams{
					Studio:       params.Studio,
					Project:      params.Project,
					ReviewInfoID: takeParams.ID,
					StatusType:   "approvalStatus",
					Status:       takeParams.ApprovalStatus,
					CreatedBy:    params.ModifiedBy,
				}
				createParamsList = append(createParamsList, createParams)
				changes += "Approval Status\n"
				changes += fmt.Sprintf("from %s to %s\n", reviewInfo.ApprovalStatus, takeParams.ApprovalStatus)
				approvalStatus = takeParams.ApprovalStatus
			}
		}
		if takeParams.WorkStatus != "" {
			if reviewInfo.WorkStatus != takeParams.WorkStatus {
				createParams := &CreateParams{
					Studio:       params.Studio,
					Project:      params.Project,
					ReviewInfoID: takeParams.ID,
					StatusType:   "workStatus",
					Status:       takeParams.WorkStatus,
					CreatedBy:    params.ModifiedBy,
				}
				createParamsList = append(createParamsList, createParams)
				changes += "Work Status\n"
				changes += fmt.Sprintf("from %s to %s\n", reviewInfo.WorkStatus, takeParams.WorkStatus)
				workStatus = takeParams.WorkStatus
			}
		}

		// make takeList
		takeList = append(takeList, reviewInfo.TakePath)

		// make body table
		if changes == "" {
			changes = "None"
		}

		approvalStatusNameKey := fmt.Sprintf("/ppip/reviews/approvalStatus/statuses/%s/displayName", approvalStatus)
		approvalStatusColorKey := fmt.Sprintf("/ppip/reviews/approvalStatus/statuses/%s/colorRgb", approvalStatus)
		workStatusNameKey := fmt.Sprintf("/ppip/reviews/workStatus/statuses/%s/displayName", workStatus)
		workStatusColorKey := fmt.Sprintf("/ppip/reviews/workStatus/statuses/%s/colorRgb", workStatus)

		response, err := h.GetPreferenceValue(c, params, approvalStatusNameKey)
		if err != nil {
			// Temporary function to handle error information
			// Delete after refactoring of ReviewStatusLog API
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		approvalStatusName := response.Value.(string)

		response, err = h.GetPreferenceValue(c, params, approvalStatusColorKey)
		if err != nil {
			// Temporary function to handle error information
			// Delete after refactoring of ReviewStatusLog API
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		valueStr = response.Value.([]string)
		approvalStatusColor := strings.Join(valueStr, ",")

		response, err = h.GetPreferenceValue(c, params, workStatusNameKey)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		workStatusName := response.Value.(string)

		response, err = h.GetPreferenceValue(c, params, workStatusColorKey)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		valueStr = response.Value.([]string)
		workStatusColor := strings.Join(valueStr, ",")

		comments := map[string]string{}
		for _, comment := range takeParams.Comments {
			lang, ok := comment["language"].(string)
			if !ok {
				continue
			}
			text, ok := comment["text"].(string)
			if !ok {
				continue
			}
			comments[lang] = text
			langSet[lang] = struct{}{}
		}

		tableParams := &entity.ReviewEmailItem{
			Group:               group,
			Take:                take,
			Phase:               reviewInfo.Phase,
			Component:           reviewInfo.Component,
			Changes:             changes,
			ApprovalStatus:      approvalStatusName,
			ApprovalStatusColor: approvalStatusColor,
			WorkStatus:          workStatusName,
			WorkStatusColor:     workStatusColor,
			Comments:            comments,
		}
		tableParamsList = append(tableParamsList, tableParams)
	}
	sort.SliceStable(tableParamsList, func(i, j int) bool {
		return tableParamsList[i].Group < tableParamsList[j].Group
	})

	uuidObj, err := uuid.NewRandom()
	if err != nil {
		setNotificationErrorInfo(c, params, err)
		internalServerError(c, err)
		return
	}

	// create update ID
	updateID := uuidObj.String()

	for _, createParams := range createParamsList {
		var p createReviewStatusLogParams
		p.Studio = createParams.Studio
		p.UpdateID = updateID
		p.ReviewInfoID = createParams.ReviewInfoID
		p.StatusType = createParams.StatusType
		p.Status = createParams.Status
		p.CreatedAtUTC = time.Now().UTC()
		p.CreatedBy = createParams.CreatedBy

		if err := c.ShouldBind(&p); err != nil {
			setNotificationErrorInfo(c, params, err)
			badRequest(c, err)
			return
		}

		// update status on reviewInfo
		updateReviewInfoParams := &entity.UpdateReviewInfoParams{
			Project:    c.Param("project"),
			ID:         p.ReviewInfoID,
			ModifiedBy: &p.CreatedBy,
		}
		if p.StatusType == "approvalStatus" {
			updateReviewInfoParams.ApprovalStatus = &p.Status
			updateReviewInfoParams.ApprovalStatusUpdatedUser = &p.CreatedBy
		}
		if p.StatusType == "workStatus" {
			updateReviewInfoParams.WorkStatus = &p.Status
			updateReviewInfoParams.WorkStatusUpdatedUser = &p.CreatedBy
		}

		_, err = h.riuc.Update(c.Request.Context(), updateReviewInfoParams)

		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}

		// create review status log
		createParams := p.Entity(c.Param("project"))
		_, err := h.uc.Create(c.Request.Context(), createParams)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
	}

	c.PureJSON(http.StatusOK, nil)

	isSendEmail, err := strconv.ParseBool(c.Query("is_send_email"))
	if err != nil {
		errorInfo := &entity.ApiProcessError{
			Title:       "Error in ReviewStatusLog Create API: is_send_email is invalid",
			Studio:      params.Studio,
			InfoLabel:   "Email Subject",
			InfoContent: params.MailSubject,
			Error:       err,
		}
		c.Set("notificationErrorInfo", errorInfo)
		badRequest(c, err)
		return
	}

	c.Set("reviewStatusNotificationInfo", &entity.ReviewStatusLogNotification{
		IsSendEmail:     isSendEmail,
		Project:         c.Param("project"),
		Studio:          c.Query("studio"),
		MailAddresses:   c.QueryArray("mail_addresses"),
		MailCCAddresses: c.QueryArray("mail_cc_addresses"),
		MailSubject:     c.Query("mail_subject"),
		MailComment:     c.Query("mail_comment"),
		ModifiedAtUTC:   time.Now().UTC(),
		ModifiedBy:      c.Query("modified_by"),
		RelationList:    c.QueryArray("relation_list"),
		PhaseList:       c.QueryArray("phase_list"),
		TakeList:        takeList,
		TableParamsList: tableParamsList,
		LangSet:         &langSet,
		UpdateID:        updateID,
	})
}

type storageBodyData struct {
	Studio          string   `json:"studio" binding:"required"`
	MailAddresses   []string `json:"mail_addresses" binding:"required"`
	MailCCAddresses []string `json:"mail_cc_addresses"`
	MailSubject     string   `json:"mail_subject" binding:"required"`
	MailComment     string   `json:"mail_comment"`
	ModifiedBy      string   `json:"modified_by" binding:"required"`
	TakeParams      []string `json:"take_params" binding:"required"`
	RelationList    []string `json:"relation_list" binding:"required"`
	PhaseList       []string `json:"phase_list" binding:"required"`
	IsSendEmail     bool     `json:"is_send_email"`
}

func (h *ReviewStatusLog) Post2(c *gin.Context) {
	var param storageBodyData
	err := c.ShouldBindJSON(&param)
	if err != nil {
		errorInfo := &entity.ApiProcessError{
			Title:       "Error in ReviewStatusLog Create API",
			Studio:      param.Studio,
			InfoLabel:   "Email Subject",
			InfoContent: param.MailSubject,
			Error:       err,
		}
		c.Set("notificationErrorInfo", errorInfo)
		badRequest(c, err)
		return
	}

	params := &entity.GetReviewStatusesParams{
		Project:         c.Param("project"),
		Studio:          param.Studio,
		MailAddresses:   param.MailAddresses,
		MailCCAddresses: param.MailCCAddresses,
		MailSubject:     param.MailSubject,
		MailComment:     param.MailComment,
		ModifiedAtUTC:   time.Now().UTC(),
		ModifiedBy:      param.ModifiedBy,
		TakeParams:      param.TakeParams,
		RelationList:    param.RelationList,
		PhaseList:       param.PhaseList,
	}
	err = h.uc.CheckForReviewStatusesParams(params)
	if err != nil {
		setNotificationErrorInfo(c, params, err)
		badRequest(c, err)
		return
	}

	var createParamsList []*CreateParams
	var takeList []string
	var tableParamsList []*entity.ReviewEmailItem

	langSet := map[string]struct{}{}
	for _, s := range params.TakeParams {
		var takeParams TakeParams
		err = json.Unmarshal([]byte(s), &takeParams)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			badRequest(c, err)
			return
		}

		// get reviewInfo
		getReviewInfoParams := &entity.GetReviewParams{
			Project: c.Param("project"),
			ID:      takeParams.ID,
		}
		reviewInfo, err := h.riuc.Get(c.Request.Context(), getReviewInfoParams)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}

		group := strings.Join(reviewInfo.Groups, "/")
		tempTake := strings.Split(reviewInfo.Take, ".")
		take := tempTake[1]
		changes := ""
		approvalStatus := reviewInfo.ApprovalStatus
		workStatus := reviewInfo.WorkStatus
		var valueStr []string

		// make createParams
		if takeParams.ApprovalStatus != "" {
			if reviewInfo.ApprovalStatus != takeParams.ApprovalStatus {
				createParams := &CreateParams{
					Studio:       params.Studio,
					Project:      params.Project,
					ReviewInfoID: takeParams.ID,
					StatusType:   "approvalStatus",
					Status:       takeParams.ApprovalStatus,
					CreatedBy:    params.ModifiedBy,
				}
				createParamsList = append(createParamsList, createParams)
				changes += "Approval Status\n"
				changes += fmt.Sprintf("from %s to %s\n", reviewInfo.ApprovalStatus, takeParams.ApprovalStatus)
				approvalStatus = takeParams.ApprovalStatus
			}
		}
		if takeParams.WorkStatus != "" {
			if reviewInfo.WorkStatus != takeParams.WorkStatus {
				createParams := &CreateParams{
					Studio:       params.Studio,
					Project:      params.Project,
					ReviewInfoID: takeParams.ID,
					StatusType:   "workStatus",
					Status:       takeParams.WorkStatus,
					CreatedBy:    params.ModifiedBy,
				}
				createParamsList = append(createParamsList, createParams)
				changes += "Work Status\n"
				changes += fmt.Sprintf("from %s to %s\n", reviewInfo.WorkStatus, takeParams.WorkStatus)
				workStatus = takeParams.WorkStatus
			}
		}

		// make takeList
		takeList = append(takeList, reviewInfo.TakePath)

		// make body table
		if changes == "" {
			changes = "None"
		}

		approvalStatusNameKey := fmt.Sprintf("/ppip/reviews/approvalStatus/statuses/%s/displayName", approvalStatus)
		approvalStatusColorKey := fmt.Sprintf("/ppip/reviews/approvalStatus/statuses/%s/colorRgb", approvalStatus)
		workStatusNameKey := fmt.Sprintf("/ppip/reviews/workStatus/statuses/%s/displayName", workStatus)
		workStatusColorKey := fmt.Sprintf("/ppip/reviews/workStatus/statuses/%s/colorRgb", workStatus)

		response, err := h.GetPreferenceValue(c, params, approvalStatusNameKey)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		approvalStatusName := response.Value.(string)

		response, err = h.GetPreferenceValue(c, params, approvalStatusColorKey)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		valueStr = response.Value.([]string)
		approvalStatusColor := strings.Join(valueStr, ",")

		response, err = h.GetPreferenceValue(c, params, workStatusNameKey)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		workStatusName := response.Value.(string)

		response, err = h.GetPreferenceValue(c, params, workStatusColorKey)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
		valueStr = response.Value.([]string)
		workStatusColor := strings.Join(valueStr, ",")

		comments := map[string]string{}
		for _, comment := range takeParams.Comments {
			lang, ok := comment["language"].(string)
			if !ok {
				continue
			}
			text, ok := comment["text"].(string)
			if !ok {
				continue
			}
			comments[lang] = text
			langSet[lang] = struct{}{}
		}

		tableParams := &entity.ReviewEmailItem{
			Group:               group,
			Take:                take,
			Phase:               reviewInfo.Phase,
			Component:           reviewInfo.Component,
			Changes:             changes,
			ApprovalStatus:      approvalStatusName,
			ApprovalStatusColor: approvalStatusColor,
			WorkStatus:          workStatusName,
			WorkStatusColor:     workStatusColor,
			Comments:            comments,
		}
		tableParamsList = append(tableParamsList, tableParams)
	}
	sort.SliceStable(tableParamsList, func(i, j int) bool {
		return tableParamsList[i].Group < tableParamsList[j].Group
	})

	uuidObj, err := uuid.NewRandom()
	if err != nil {
		setNotificationErrorInfo(c, params, err)
		internalServerError(c, err)
		return
	}

	// create update ID
	updateID := uuidObj.String()

	for _, createParams := range createParamsList {
		var p createReviewStatusLogParams
		p.Studio = createParams.Studio
		p.UpdateID = updateID
		p.ReviewInfoID = createParams.ReviewInfoID
		p.StatusType = createParams.StatusType
		p.Status = createParams.Status
		p.CreatedAtUTC = time.Now().UTC()
		p.CreatedBy = createParams.CreatedBy

		// update status on reviewInfo
		updateReviewInfoParams := &entity.UpdateReviewInfoParams{
			Project:    c.Param("project"),
			ID:         p.ReviewInfoID,
			ModifiedBy: &p.CreatedBy,
		}
		if p.StatusType == "approvalStatus" {
			updateReviewInfoParams.ApprovalStatus = &p.Status
			updateReviewInfoParams.ApprovalStatusUpdatedUser = &p.CreatedBy
		}
		if p.StatusType == "workStatus" {
			updateReviewInfoParams.WorkStatus = &p.Status
			updateReviewInfoParams.WorkStatusUpdatedUser = &p.CreatedBy
		}

		_, err = h.riuc.Update(c.Request.Context(), updateReviewInfoParams)

		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}

		// create review status log
		createParams := p.Entity(c.Param("project"))
		_, err := h.uc.Create(c.Request.Context(), createParams)
		if err != nil {
			setNotificationErrorInfo(c, params, err)
			internalServerError(c, err)
			return
		}
	}

	c.Set("reviewStatusNotificationInfo", &entity.ReviewStatusLogNotification{
		IsSendEmail:     param.IsSendEmail,
		Project:         c.Param("project"),
		Studio:          param.Studio,
		MailAddresses:   param.MailAddresses,
		MailCCAddresses: param.MailCCAddresses,
		MailSubject:     param.MailSubject,
		MailComment:     param.MailComment,
		ModifiedAtUTC:   time.Now().UTC(),
		ModifiedBy:      param.ModifiedBy,
		RelationList:    param.RelationList,
		PhaseList:       param.PhaseList,
		TakeList:        takeList,
		TableParamsList: tableParamsList,
		LangSet:         &langSet,
		UpdateID:        updateID,
	})
}

func (h *ReviewStatusLog) GetPreferenceValue(
	c *gin.Context,
	params *entity.GetReviewStatusesParams,
	value string,
) (*entity.PipelineSettingValue, error) {
	common := "default"
	getPipelineSettingValueParams := &entity.GetPipelineSettingValueParams{
		Group:     entity.Preference,
		Common:    &common,
		Studio:    &params.Studio,
		Project:   &params.Project,
		Key:       value,
		Composite: true,
	}
	Res, err := h.psuc.GetValue(c.Request.Context(), getPipelineSettingValueParams)
	if err != nil {
		log.Println(err)
		return nil, err
	}
	return Res, err
}

func (h *ReviewStatusLog) GetConfigValue(
	c *gin.Context,
	project *string,
	common *string,
	value string,
) (*entity.PipelineSettingValue, error) {
	getPipelineSettingValueParams := &entity.GetPipelineSettingValueParams{
		Group:     entity.Config,
		Project:   project,
		Common:    common,
		Key:       value,
		Composite: false,
	}
	Res, err := h.psuc.GetValue(c.Request.Context(), getPipelineSettingValueParams)
	if err != nil {
		log.Println(err)
		return nil, err
	}
	return Res, err
}

func setNotificationErrorInfo(
	c *gin.Context,
	params *entity.GetReviewStatusesParams,
	err error,
) {
	// Temporary function to handle error information
	// Delete after refactoring of ReviewStatusLog API
	errorInfo := &entity.ApiProcessError{
		Title:       "Error in ReviewStatusLog Create API",
		Studio:      params.Studio,
		InfoLabel:   "Email Subject",
		InfoContent: params.MailSubject,
		Error:       err,
	}
	c.Set("notificationErrorInfo", errorInfo)
	return
}
