package delivery

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/pipelineParameter"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type PipelineParameter struct {
	uc *usecase.PipelineParameter
}

func NewPipelineParameter(
	uc *usecase.PipelineParameter,
) *PipelineParameter {
	return &PipelineParameter{
		uc: uc,
	}
}

// Parameter

type listPipelineParameterParams struct {
	ModifiedSince *time.Time `json:"modified_since,omitempty" form:"modified_since"`
	OrderBy       *string    `json:"order_by,omitempty" form:"order_by"`
	PerPage       *int       `json:"per_page,omitempty" form:"per_page"`
	Page          *int       `json:"page,omitempty" form:"page"`
}

func (p *listPipelineParameterParams) Params() pipelineParameter.ListParametersParams {
	params := pipelineParameter.ListParametersParams{
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}

	if p.OrderBy != nil {
		for _, orderBy := range strings.Split(*p.OrderBy, ",") {
			if strings.HasSuffix(orderBy, "modified_at") {
				orderBy += "_utc"
			}
			params.OrderBy = append(params.OrderBy, orderBy)
		}
	}

	return params
}

func (p *listPipelineParameterParams) UpdatesParams() pipelineParameter.ListParameterUpdatesParams {
	return pipelineParameter.ListParameterUpdatesParams{
		ModifiedSince: p.ModifiedSince,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
}

func (h *PipelineParameter) ListParameters(c *gin.Context) {
	res, err := h.listParameters(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, res)
}

func (h *PipelineParameter) listParameters(c *gin.Context) (map[string]interface{}, error) {
	lgr := NewLogger(c.Request)

	var p listPipelineParameterParams
	if err := c.ShouldBindQuery(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("listPipelineParameterParams", p)

	var entities []*pipelineParameter.Parameter
	var total uint
	var err error
	var params libs.GetListParams
	ctx := c.Request.Context()
	if p.ModifiedSince == nil {
		prm := p.Params()
		entities, total, err = h.uc.ListParameters(ctx, lgr, prm)
		params = prm
	} else {
		prm := p.UpdatesParams()
		entities, total, err = h.uc.ListParameterUpdates(ctx, lgr, prm)
		params = prm
	}
	if err != nil {
		return nil, err
	}

	return libs.CreateListResponse(
		"parameters",
		entities,
		c.Request,
		params,
		int(total),
	), nil
}

func (h *PipelineParameter) GetParameter(c *gin.Context) {
	e, err := h.getParameter(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *PipelineParameter) getParameter(c *gin.Context) (*pipelineParameter.Parameter, error) {
	lgr := NewLogger(c.Request)
	parameter := c.Param("parameter")
	lgr.Set("parameter", parameter)
	params := pipelineParameter.GetParameterParams{
		KeyName: parameter,
	}
	return h.uc.GetParameter(c.Request.Context(), lgr, params)
}

type createPipelineParameterParams struct {
	KeyName     string            `json:"key_name"`
	Schema      entity.JSONObject `json:"schema"`
	DisplayName *string           `json:"display_name,omitempty"`
	Description *string           `json:"description,omitempty"`
	CreatedBy   *string           `json:"created_by,omitempty"`
}

func (p *createPipelineParameterParams) Params(
	createdBy *string,
) pipelineParameter.CreateParameterParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	return pipelineParameter.CreateParameterParams{
		KeyName:     p.KeyName,
		Schema:      p.Schema,
		DisplayName: p.DisplayName,
		Description: p.Description,
		CreatedBy:   createdBy,
	}
}

func (h *PipelineParameter) PostParameter(c *gin.Context) {
	e, err := h.postParameter(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

func (h *PipelineParameter) postParameter(c *gin.Context) (*pipelineParameter.Parameter, error) {
	lgr := NewLogger(c.Request)

	var p createPipelineParameterParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("createPipelineParameterParams", p)

	params := p.Params(nil)
	return h.uc.CreateParameter(c.Request.Context(), lgr, params)
}

type deleteParameterParams struct {
	ModifiedBy *string `json:"modified_by,omitempty"`
}

func (p *deleteParameterParams) Params(
	keyName string,
	modifiedBy *string,
) pipelineParameter.DeleteParameterParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	return pipelineParameter.DeleteParameterParams{
		KeyName:    keyName,
		ModifiedBy: modifiedBy,
	}
}

func (h *PipelineParameter) DeleteParameter(c *gin.Context) {
	if err := h.deleteParameter(c); err != nil {
		jsonError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

func (h *PipelineParameter) deleteParameter(c *gin.Context) error {
	lgr := NewLogger(c.Request)

	var p deleteParameterParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	lgr.Set("deleteParameterParams", p)
	keyName := c.Param("parameter")
	lgr.Set("parameter", keyName)

	params := p.Params(keyName, nil)
	return h.uc.DeleteParameter(c.Request.Context(), lgr, params)
}

// Location

type listPipelineParameterLocationsParams struct {
	Parameter     *string    `json:"parameter,omitempty" form:"parameter"`
	ModifiedSince *time.Time `json:"modified_since,omitempty" form:"modified_since"`
	OrderBy       *string    `json:"order_by,omitempty" form:"order_by"`
	PerPage       *int       `json:"per_page,omitempty" form:"per_page"`
	Page          *int       `json:"page,omitempty" form:"page"`
}

func (p *listPipelineParameterLocationsParams) Params(
	project string,
) pipelineParameter.ListLocationsParams {
	params := pipelineParameter.ListLocationsParams{
		Project:   project,
		Parameter: p.Parameter,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}

	if p.OrderBy != nil {
		for _, orderBy := range strings.Split(*p.OrderBy, ",") {
			if strings.HasSuffix(orderBy, "modified_at") {
				orderBy += "_utc"
			}
			params.OrderBy = append(params.OrderBy, orderBy)
		}
	}

	return params
}

func (p *listPipelineParameterLocationsParams) UpdatesParams(
	project string,
) pipelineParameter.ListLocationUpdatesParams {
	return pipelineParameter.ListLocationUpdatesParams{
		Project:       project,
		ModifiedSince: p.ModifiedSince,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
}

func (h *PipelineParameter) ListLocations(c *gin.Context) {
	res, err := h.listLocations(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, res)
}

func (h *PipelineParameter) listLocations(c *gin.Context) (map[string]interface{}, error) {
	lgr := NewLogger(c.Request)

	var p listPipelineParameterLocationsParams
	if err := c.ShouldBindQuery(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("listPipelineParameterLocationParams", p)
	project := c.Param("project")
	lgr.SetProject(project)

	var params libs.GetListParams
	var entities []*pipelineParameter.Location
	var total uint
	var err error
	ctx := c.Request.Context()
	if p.ModifiedSince == nil {
		prm := p.Params(project)
		entities, total, err = h.uc.ListLocations(ctx, lgr, prm)
		params = prm
	} else {
		prm := p.UpdatesParams(project)
		entities, total, err = h.uc.ListLocationUpdates(ctx, lgr, prm)
		params = prm
	}
	if err != nil {
		return nil, err
	}

	return libs.CreateListResponse(
		"locations",
		entities,
		c.Request,
		params,
		int(total),
	), nil
}

func (h *PipelineParameter) GetLocation(c *gin.Context) {
	e, err := h.getLocation(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *PipelineParameter) getLocation(c *gin.Context) (*pipelineParameter.Location, error) {
	lgr := NewLogger(c.Request)

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse id: %w", err)
		lgr.Warn(retErr.Error())
		return nil, err
	}

	lgr.Set("locationID", id)
	project := c.Param("project")
	lgr.SetProject(project)

	params := pipelineParameter.GetLocationParams{
		Project: project,
		ID:      uint32(id),
	}
	return h.uc.GetLocation(c.Request.Context(), lgr, params)
}

type createPipelineParameterLocationParams struct {
	Parameter string  `json:"parameter"`
	Path      string  `json:"path"`
	CreatedBy *string `json:"created_by,omitempty"`
}

func (p *createPipelineParameterLocationParams) Params(
	project string,
	createdBy *string,
) pipelineParameter.CreateLocationParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	return pipelineParameter.CreateLocationParams{
		Parameter: p.Parameter,
		Project:   project,
		Path:      p.Path,
		CreatedBy: createdBy,
	}
}

func (h *PipelineParameter) PostLocation(c *gin.Context) {
	e, err := h.postLocation(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

func (h *PipelineParameter) postLocation(c *gin.Context) (*pipelineParameter.Location, error) {
	lgr := NewLogger(c.Request)

	var p createPipelineParameterLocationParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameter: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("createPipelineParameterLocationParams", p)
	project := c.Param("project")
	lgr.SetProject(project)

	params := p.Params(project, nil)
	e, err := h.uc.CreateLocation(c.Request.Context(), lgr, params)
	if err != nil {
		return nil, err
	}

	return e, nil
}

type deletePipelineParameterLocationParams struct {
	ModifiedBy *string `json:"modified_by,omitempty"`
}

func (p *deletePipelineParameterLocationParams) Params(
	project string,
	id uint32,
	modifiedBy *string,
) pipelineParameter.DeleteLocationParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	return pipelineParameter.DeleteLocationParams{
		Project:    project,
		ID:         id,
		ModifiedBy: modifiedBy,
	}
}

func (h *PipelineParameter) DeleteLocation(c *gin.Context) {
	if err := h.deleteLocation(c); err != nil {
		jsonError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

func (h *PipelineParameter) deleteLocation(c *gin.Context) error {
	lgr := NewLogger(c.Request)

	var p deletePipelineParameterLocationParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameter: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	lgr.Set("deletePipelineParameterLocationParams", p)
	project := c.Param("project")
	lgr.SetProject(project)

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse id: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	lgr.Set("locationID", id)
	params := p.Params(project, uint32(id), nil)
	return h.uc.DeleteLocation(c.Request.Context(), lgr, params)
}

// Value

type listPipelineParameterValuesParams struct {
	Parameter       *string    `json:"parameter,omitempty" form:"parameter"`
	Studio          *string    `json:"studio,omitempty" form:"studio"`
	Project         *string    `json:"project,omitempty" form:"project"`
	Location        *string    `json:"location,omitempty" form:"location"`
	ModifiedSince   *time.Time `json:"modified_since,omitempty" form:"modified_since"`
	OrderBy         *string    `json:"order_by,omitempty" form:"order_by"`
	PerPage         *int       `json:"per_page,omitempty" form:"per_page"`
	Page            *int       `json:"page,omitempty" form:"page"`
	FilterParameter *string    `json:"filter_parameter,omitempty" form:"filter_parameter"`
	FilterStudio    *string    `json:"filter_studio,omitempty" form:"filter_studio"`
	FilterProject   *string    `json:"filter_project,omitempty" form:"filter_project"`
	FilterLocation  *string    `json:"filter_location,omitempty" form:"filter_location"`
	FilterValue     *string    `json:"filter_value,omitempty" form:"filter_value"`
}

func (p *listPipelineParameterValuesParams) Params() pipelineParameter.ListValuesParams {
	var studios []string
	if p.Studio != nil {
		studios = strings.Split(*p.Studio, ",")
	}
	var projects []string
	if p.Project != nil {
		projects = strings.Split(*p.Project, ",")
	}
	params := pipelineParameter.ListValuesParams{
		Parameter:       p.Parameter,
		Location:        p.Location,
		Studios:         studios,
		Projects:        projects,
		FilterParameter: p.FilterParameter,
		FilterLocation:  p.FilterLocation,
		FilterStudio:    p.FilterStudio,
		FilterProject:   p.FilterProject,
		FilterValue:     p.FilterValue,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}

	if p.OrderBy != nil {
		for _, orderBy := range strings.Split(*p.OrderBy, ",") {
			if strings.HasSuffix(orderBy, "modified_at") {
				orderBy += "_utc"
			}
			params.OrderBy = append(params.OrderBy, orderBy)
		}
	}

	return params
}

func (p *listPipelineParameterValuesParams) UpdatesParams() pipelineParameter.ListValueUpdatesParams {
	return pipelineParameter.ListValueUpdatesParams{
		Studio:        p.Studio,
		Project:       p.Project,
		ModifiedSince: p.ModifiedSince,
		BaseListParams: &entity.BaseListParams{
			PerPage: p.PerPage,
			Page:    p.Page,
		},
	}
}

func (h *PipelineParameter) ListValues(c *gin.Context) {
	res, err := h.listValues(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, res)
}

func (h *PipelineParameter) listValues(c *gin.Context) (map[string]interface{}, error) {
	lgr := NewLogger(c.Request)

	var p listPipelineParameterValuesParams
	if err := c.ShouldBindQuery(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("listPipelineParameterValuesParams", p)
	if p.Studio != nil {
		lgr.SetStudio(*p.Studio)
	}
	if p.Project != nil {
		lgr.SetProject(*p.Project)
	}

	var entities []*pipelineParameter.Value
	var total uint
	var err error
	var params libs.GetListParams
	ctx := c.Request.Context()
	if p.ModifiedSince == nil {
		prm := p.Params()
		entities, total, err = h.uc.ListValues(ctx, lgr, prm)
		params = prm
	} else {
		prm := p.UpdatesParams()
		entities, total, err = h.uc.ListValueUpdates(ctx, lgr, prm)
		params = prm
	}
	if err != nil {
		return nil, err
	}

	return libs.CreateListResponse(
		"values",
		entities,
		c.Request,
		params,
		int(total),
	), nil
}

func (h *PipelineParameter) GetValue(c *gin.Context) {
	e, err := h.getValue(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *PipelineParameter) getValue(c *gin.Context) (*pipelineParameter.Value, error) {
	lgr := NewLogger(c.Request)

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse id: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("valueID", id)
	params := pipelineParameter.GetValueParams{
		ID: uint32(id),
	}
	return h.uc.GetValue(c.Request.Context(), lgr, params)
}

type createPipelineParameterValueParams struct {
	Parameter string      `json:"parameter"`
	Location  string      `json:"location"`
	Project   *string     `json:"project,omitempty"`
	Studio    *string     `json:"studio,omitempty"`
	Value     interface{} `json:"value"`
	CreatedBy *string     `json:"created_by,omitempty"`
}

func (p *createPipelineParameterValueParams) Params(
	createdBy *string,
) *pipelineParameter.CreateValueParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	return &pipelineParameter.CreateValueParams{
		Parameter: p.Parameter,
		Location:  p.Location,
		Value:     p.Value,
		Project:   p.Project,
		Studio:    p.Studio,
		CreatedBy: createdBy,
	}
}

func (h *PipelineParameter) PostValue(c *gin.Context) {
	e, err := h.postValue(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

func (h *PipelineParameter) postValue(c *gin.Context) (*pipelineParameter.Value, error) {
	lgr := NewLogger(c.Request)

	var p createPipelineParameterValueParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("createPipelineParameterValueParams", p)
	if p.Studio != nil {
		lgr.SetStudio(*p.Studio)
	}
	if p.Project != nil {
		lgr.SetProject(*p.Project)
	}

	params := p.Params(nil)
	return h.uc.CreateValue(c.Request.Context(), lgr, params)
}

type updatePipelineParameterValueParams struct {
	Value      interface{} `json:"value"`
	ModifiedBy *string     `json:"modified_by,omitempty"`
}

func (p *updatePipelineParameterValueParams) Params(
	id uint32,
	modifiedBy *string,
) *pipelineParameter.UpdateValueParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	return &pipelineParameter.UpdateValueParams{
		ID:         id,
		Value:      p.Value,
		ModifiedBy: modifiedBy,
	}
}

func (h *PipelineParameter) PatchValue(c *gin.Context) {
	e, err := h.patchValue(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

func (h *PipelineParameter) patchValue(c *gin.Context) (*pipelineParameter.Value, error) {
	lgr := NewLogger(c.Request)

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse id: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("valueID", id)
	var p updatePipelineParameterValueParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("updatePipelineParameterValueParams", p)
	params := p.Params(uint32(id), nil)
	return h.uc.UpdateValue(c.Request.Context(), lgr, params)
}

type upsertPipelineParameterValueParams struct {
	Parameter  string      `json:"parameter"`
	Location   string      `json:"location"`
	Project    *string     `json:"project,omitempty"`
	Studio     *string     `json:"studio,omitempty"`
	Value      interface{} `json:"value"`
	CreatedBy  *string     `json:"created_by,omitempty"`
	ModifiedBy *string     `json:"modified_by,omitempty"`
}

func (p *upsertPipelineParameterValueParams) Params(
	createdBy *string,
	modifiedBy *string,
) *pipelineParameter.UpsertValueParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	return &pipelineParameter.UpsertValueParams{
		Parameter:  p.Parameter,
		Location:   p.Location,
		Value:      p.Value,
		Project:    p.Project,
		Studio:     p.Studio,
		CreatedBy:  createdBy,
		ModifiedBy: modifiedBy,
	}
}

func (h *PipelineParameter) PutValue(c *gin.Context) {
	e, err := h.putValue(c)
	if err != nil {
		jsonError(c, err)
		return
	}
	var status int
	if e.ModifiedAtUTC != e.CreatedAtUTC {
		status = http.StatusOK
	} else {
		status = http.StatusCreated
	}
	c.PureJSON(status, e)
}

func (h *PipelineParameter) putValue(c *gin.Context) (*pipelineParameter.Value, error) {
	lgr := NewLogger(c.Request)

	var p upsertPipelineParameterValueParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	lgr.Set("upsertPipelineParameterValueParams", p)
	if p.Studio != nil {
		lgr.SetStudio(*p.Studio)
	}
	if p.Project != nil {
		lgr.SetProject(*p.Project)
	}

	params := p.Params(nil, nil)
	return h.uc.UpsertValue(c.Request.Context(), lgr, params)
}

type deletePipelineParameterValueParams struct {
	ModifiedBy *string `json:"modified_by,omitempty"`
}

func (p *deletePipelineParameterValueParams) Params(
	id uint32,
	modifiedBy *string,
) pipelineParameter.DeleteValueParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	return pipelineParameter.DeleteValueParams{
		ID:         id,
		ModifiedBy: modifiedBy,
	}
}

func (h *PipelineParameter) DeleteValue(c *gin.Context) {
	if err := h.deleteValue(c); err != nil {
		jsonError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

func (h *PipelineParameter) deleteValue(c *gin.Context) error {
	lgr := NewLogger(c.Request)

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse id: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	lgr.Set("valueID", id)
	var p deletePipelineParameterValueParams
	if err := c.ShouldBind(&p); err != nil {
		retErr := entity.NewBadRequestErrorf("could not parse query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	lgr.Set("deletePipelineParameterValueParams", p)
	params := p.Params(uint32(id), nil)
	return h.uc.DeleteValue(c.Request.Context(), lgr, params)
}
