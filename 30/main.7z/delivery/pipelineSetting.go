package delivery

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type PipelineSetting struct {
	uc *usecase.PipelineSetting
}

func NewPipelineSetting(
	uc *usecase.PipelineSetting,
) *PipelineSetting {
	return &PipelineSetting{
		uc: uc,
	}
}

// Property

type listPipelineSettingPropertyParams struct {
	PerPage   *int    `form:"per_page"`
	Page      *int    `form:"page"`
	OrderBy   *string `form:"order_by"`
	SearchKey *string `form:"search_key"`
}

func (p *listPipelineSettingPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
) *entity.ListPipelineSettingPropertyParams {
	params := &entity.ListPipelineSettingPropertyParams{
		Group: group,
		BaseListParams: &entity.BaseListParams{
			PerPage:   p.PerPage,
			Page:      p.Page,
			OrderBy:   p.OrderBy,
			SearchKey: p.SearchKey,
		},
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) ListProperties(c *gin.Context) {
	var p listPipelineSettingPropertyParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	params := p.Entity(group, &section)

	entities, total, err := h.uc.ListProperties(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse(
		"properties",
		entities,
		c.Request,
		params,
		int(total),
	)
	c.PureJSON(http.StatusOK, res)
}

type listEnvironmentPropertyParams struct {
	PerPage   *int    `form:"per_page"`
	Page      *int    `form:"page"`
	OrderBy   *string `form:"order_by"`
	SearchKey *string `form:"search_key"`
}

func (p *listEnvironmentPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
) *entity.ListEnvironmentPropertyParams {
	params := &entity.ListEnvironmentPropertyParams{
		BaseListParams: &entity.BaseListParams{
			PerPage:   p.PerPage,
			Page:      p.Page,
			OrderBy:   p.OrderBy,
			SearchKey: p.SearchKey,
		},
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) ListEnvironmentProperties(c *gin.Context) {
	var p listEnvironmentPropertyParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Environment {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	params := p.Entity(group, &section)

	entities, total, err := h.uc.ListEnvironmentProperties(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse(
		"properties",
		entities,
		c.Request,
		params,
		int(total),
	)
	c.PureJSON(http.StatusOK, res)
}

type getPipelineSettingPropertyParams struct{}

func (p *getPipelineSettingPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	key string,
	section *entity.PipelineSettingSection,
) *entity.GetPipelineSettingPropertyParams {
	params := &entity.GetPipelineSettingPropertyParams{
		Group: group,
		Key:   key,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) GetProperty(c *gin.Context) {
	var p getPipelineSettingPropertyParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	params := p.Entity(group, key, &section)
	e, err := h.uc.GetProperty(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type getEnvironmentPropertyParams struct{}

func (p *getEnvironmentPropertyParams) Entity(
	key string,
	section *entity.PipelineSettingSection,
) *entity.GetEnvironmentPropertyParams {
	params := &entity.GetEnvironmentPropertyParams{
		Key: key,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) GetEnvironmentProperty(c *gin.Context) {
	var p getEnvironmentPropertyParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	params := p.Entity(key, &section)
	e, err := h.uc.GetEnvironmentProperty(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type createPipelineSettingPropertyParams struct {
	Section   *string     `json:"section"`
	Key       string      `json:"key"`
	Schema    interface{} `json:"schema"`
	Required  bool        `json:"required"`
	CreatedBy *string     `json:"created_by"`
}

func (p *createPipelineSettingPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
	createdBy *string,
) *entity.CreatePipelineSettingPropertyParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	params := &entity.CreatePipelineSettingPropertyParams{
		Group:     group,
		Key:       p.Key,
		Required:  p.Required,
		CreatedBy: createdBy,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) PostProperty(c *gin.Context) {
	var p createPipelineSettingPropertyParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	params := p.Entity(group, &section, nil)
	e, err := h.uc.CreateProperty(c.Request.Context(), params, p.Schema)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

type createEnvironmentPropertyParams struct {
	Section   *string     `json:"section"`
	Key       string      `json:"key"`
	Schema    interface{} `json:"schema"`
	Required  bool        `json:"required"`
	CreatedBy *string     `json:"created_by"`
}

func (p *createEnvironmentPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
	createdBy *string,
) *entity.CreateEnvironmentPropertyParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	params := &entity.CreateEnvironmentPropertyParams{
		Key:       p.Key,
		Required:  p.Required,
		CreatedBy: createdBy,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) PostEnvironmentProperty(c *gin.Context) {
	var p createEnvironmentPropertyParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Environment {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	params := p.Entity(group, &section, nil)
	e, err := h.uc.CreateEnvironmentProperty(c.Request.Context(), params, p.Schema)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

type updatePipelineSettingPropertyParams struct {
	Section    *string     `json:"section"`
	Key        string      `json:"key"`
	Schema     interface{} `json:"schema"`
	Required   bool        `json:"required"`
	ModifiedBy *string     `json:"modified_by"`
}

func (p *updatePipelineSettingPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
	key string,
	modifiedBy *string,
) *entity.UpdatePipelineSettingPropertyParams {
	params := &entity.UpdatePipelineSettingPropertyParams{
		Group:      group,
		Key:        key,
		Required:   p.Required,
		ModifiedBy: p.ModifiedBy,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) PatchProperty(c *gin.Context) {
	var p updatePipelineSettingPropertyParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}

	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	key := normalizeStarParam(c.Param("key"))
	params := p.Entity(group, &section, key, nil)

	e, err := h.uc.UpdateProperty(c.Request.Context(), params, p.Schema)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type updateEnvironmentPropertyParams struct {
	Section    *string     `json:"section"`
	Key        string      `json:"key"`
	Schema     interface{} `json:"schema"`
	Required   bool        `json:"required"`
	ModifiedBy *string     `json:"modified_by"`
}

func (p *updateEnvironmentPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
	key string,
	modifiedBy *string,
) *entity.UpdateEnvironmentPropertyParams {
	params := &entity.UpdateEnvironmentPropertyParams{
		Key:        key,
		Required:   p.Required,
		ModifiedBy: p.ModifiedBy,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) PatchEnvironmentProperty(c *gin.Context) {
	var p updateEnvironmentPropertyParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}

	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Environment {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, _ := entity.ParsePipelineSettingSection(c.Param("section"))
	key := normalizeStarParam(c.Param("key"))
	params := p.Entity(group, &section, key, nil)

	e, err := h.uc.UpdateEnvironmentProperty(c.Request.Context(), params, p.Schema)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type deletePipelineSettingPropertyParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deletePipelineSettingPropertyParams) Entity(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
	key string,
) *entity.DeletePipelineSettingPropertyParams {
	params := &entity.DeletePipelineSettingPropertyParams{
		Group:      group,
		Key:        key,
		ModifiedBy: p.ModifiedBy,
	}
	if section != nil && *section != 0 {
		params.Section = section
	}
	return params
}

func (h *PipelineSetting) DeleteProperty(c *gin.Context) {
	var p deletePipelineSettingPropertyParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	section, ok := entity.ParsePipelineSettingSection(c.Param("section"))
	if !ok && group != entity.Preference && group != entity.Environment {
		fmt.Println("section err")
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	params := p.Entity(group, &section, key)
	if err := h.uc.DeleteProperty(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

type deleteEnvironmentPropertyParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deleteEnvironmentPropertyParams) Entity(
	key string,
) *entity.DeleteEnvironmentPropertyParams {
	params := &entity.DeleteEnvironmentPropertyParams{
		Key:        key,
		ModifiedBy: p.ModifiedBy,
	}
	return params
}

func (h *PipelineSetting) DeleteEnvironmentProperty(c *gin.Context) {
	var p deleteEnvironmentPropertyParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	params := p.Entity(key)
	if err := h.uc.DeleteEnvironmentProperty(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

// Value

type listPipelineSettingValueParams struct {
	PerPage   *int    `form:"per_page"`
	Page      *int    `form:"page"`
	OrderBy   *string `form:"order_by"`
	SearchKey *string `form:"search_key"`
}

func (p *listPipelineSettingValueParams) Entity(
	group entity.PipelineSettingGroup,
	common *string,
	studio *string,
	project *string,
) *entity.ListPipelineSettingValueParams {
	params := &entity.ListPipelineSettingValueParams{
		Group: group,
		BaseListParams: &entity.BaseListParams{
			PerPage:   p.PerPage,
			Page:      p.Page,
			OrderBy:   p.OrderBy,
			SearchKey: p.SearchKey,
		},
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) ListValues(c *gin.Context) {
	var p listPipelineSettingValueParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}

	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	common := c.Param("common")
	studio := c.Param("studio")
	project := c.Param("project")
	params := p.Entity(group, &common, &studio, &project)

	entities, total, err := h.uc.ListValues(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse(
		"values",
		entities,
		c.Request,
		params,
		int(total),
	)
	c.PureJSON(http.StatusOK, res)
}

type listEnvironmentValueParams struct {
	PerPage   *int    `form:"per_page"`
	Page      *int    `form:"page"`
	OrderBy   *string `form:"order_by"`
	PropKey   *string `form:"prop_key"`
	EnvKey    *string `form:"env_key"`
	SearchKey *string `form:"search_key"`
}

func (p *listEnvironmentValueParams) Entity(
	common *string,
	studio *string,
	project *string,
) *entity.ListEnvironmentValueParams {
	params := &entity.ListEnvironmentValueParams{
		Group:   entity.Environment,
		EnvKey:  p.EnvKey,
		PropKey: p.PropKey,
		BaseListParams: &entity.BaseListParams{
			PerPage:   p.PerPage,
			Page:      p.Page,
			OrderBy:   p.OrderBy,
			SearchKey: p.SearchKey,
		},
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) ListEnvironmentValues(c *gin.Context) {
	var p listEnvironmentValueParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	common := c.Param("common")
	studio := c.Param("studio")
	project := c.Param("project")
	params := p.Entity(&common, &studio, &project)

	entities, total, err := h.uc.ListEnvironmentValues(c.Request.Context(), params)
	if err != nil {
		internalServerError(c, err)
		return
	}

	res := libs.CreateListResponse(
		"values",
		entities,
		c.Request,
		params,
		int(total),
	)
	c.PureJSON(http.StatusOK, res)
}

type getPipelineSettingValueParams struct {
	ModifiedBy *string `form:"modified_by"`
}

func (p *getPipelineSettingValueParams) Entity(
	group entity.PipelineSettingGroup,
	key string,
	common *string,
	studio *string,
	project *string,
) *entity.GetPipelineSettingValueParams {
	return &entity.GetPipelineSettingValueParams{
		Group:      group,
		Common:     common,
		Studio:     studio,
		Project:    project,
		Key:        key,
		ModifiedBy: p.ModifiedBy,
	}
}

func (h *PipelineSetting) GetValue(c *gin.Context) {
	var p getPipelineSettingValueParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	common := c.Param("common")
	project := c.Param("project")
	studio := c.Param("studio")
	params := p.Entity(group, key, &common, &studio, &project)
	e, err := h.uc.GetValue(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type getEnvironmentValueParams struct {
	EnvironmentKey *string `form:"key"`
}

func (p *getEnvironmentValueParams) Entity(
	id uint32,
	common *string,
	studio *string,
	project *string,
) *entity.GetEnvironmentValueParams {
	envParams := &entity.GetEnvironmentValueParams{
		Group:   entity.Environment,
		Common:  common,
		Studio:  studio,
		Project: project,
		ID:      id,
	}
	return envParams
}

func (h *PipelineSetting) GetEnvironmentValue(c *gin.Context) {
	var p getEnvironmentValueParams
	if err := c.ShouldBindQuery(&p); err != nil {
		badRequest(c, err)
		return
	}
	strID := c.Param("id")
	id, err := strconv.Atoi(strID)
	if err != nil {
		badRequest(c, err)
		return
	}
	common := c.Param("common")
	project := c.Param("project")
	studio := c.Param("studio")
	params := p.Entity(uint32(id), &common, &studio, &project)
	e, err := h.uc.GetEnvironmentValue(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}

type createPipelineSettingValueParams struct {
	Key       string      `json:"key"`
	Value     interface{} `json:"value"`
	Project   *string     `json:"project"`
	Studio    *string     `json:"studio"`
	Common    *string     `json:"common"`
	CreatedBy *string     `json:"created_by"`
}

func (p *createPipelineSettingValueParams) Entity(
	group entity.PipelineSettingGroup,
	common *string,
	studio *string,
	project *string,
	createdBy *string,
) *entity.CreatePipelineSettingValueParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	params := &entity.CreatePipelineSettingValueParams{
		Group:     group,
		Key:       p.Key,
		Value:     p.Value,
		CreatedBy: createdBy,
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) PostValue(c *gin.Context) {
	var p createPipelineSettingValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	common := c.Param("common")
	studio := c.Param("studio")
	project := c.Param("project")
	params := p.Entity(group, &common, &studio, &project, nil)
	var e *entity.PipelineSettingValue
	var err error
	e, err = h.uc.CreateValue(c.Request.Context(), params)

	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

type createEnvironmentValueParams struct {
	Key       string      `json:"key"`
	Value     interface{} `json:"value"`
	Project   *string     `json:"project"`
	Studio    *string     `json:"studio"`
	Common    *string     `json:"common"`
	CreatedBy *string     `json:"created_by"`
}

func (p *createEnvironmentValueParams) Entity(
	common *string,
	studio *string,
	project *string,
	createdBy *string,
) *entity.CreateEnvironmentValueParams {
	if createdBy == nil {
		createdBy = p.CreatedBy
	}
	params := &entity.CreateEnvironmentValueParams{
		PropKey:   p.Key,
		Value:     p.Value,
		CreatedBy: createdBy,
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) PostEnvironmentValue(c *gin.Context) {
	var p createEnvironmentValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	common := c.Param("common")
	studio := c.Param("studio")
	project := c.Param("project")
	params := p.Entity(&common, &studio, &project, nil)
	var e *entity.PipelineSettingValue
	var err error

	e, err = h.uc.CreateEnvironmentValue(c.Request.Context(), params)

	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusCreated, e)
}

type updatePipelineSettingValueParams struct {
	Value      interface{} `json:"value"`
	ModifiedBy *string     `json:"modified_by"`
}

func (p *updatePipelineSettingValueParams) Entity(
	group entity.PipelineSettingGroup,
	key string,
	common *string,
	studio *string,
	project *string,
	modifiedBy *string,
) *entity.UpdatePipelineSettingValueParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	params := &entity.UpdatePipelineSettingValueParams{
		Group:      group,
		Key:        key,
		Value:      p.Value,
		ModifiedBy: modifiedBy,
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) PatchValue(c *gin.Context) {
	var p updatePipelineSettingValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference && group != entity.Environment {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	common := c.Param("common")
	project := c.Param("project")
	studio := c.Param("studio")
	params := p.Entity(group, key, &common, &studio, &project, nil)
	var e *entity.PipelineSettingValue
	var err error
	e, err = h.uc.UpdateValue(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}

	c.PureJSON(http.StatusOK, e)
}

type updateEnvironmentValueParams struct {
	Value      interface{} `json:"value"`
	ModifiedBy *string     `json:"modified_by"`
}

func (p *updateEnvironmentValueParams) Entity(
	id uint32,
	common *string,
	studio *string,
	project *string,
	modifiedBy *string,
) *entity.UpdateEnvironmentValueParams {
	if modifiedBy == nil {
		modifiedBy = p.ModifiedBy
	}
	params := &entity.UpdateEnvironmentValueParams{
		ID:         id,
		Value:      p.Value,
		ModifiedBy: modifiedBy,
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) PatchEnvironmentValue(c *gin.Context) {
	var p updateEnvironmentValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	strID := c.Param("id")
	id, err := strconv.Atoi(strID)
	if err != nil {
		badRequest(c, err)
		return
	}
	common := c.Param("common")
	project := c.Param("project")
	studio := c.Param("studio")
	params := p.Entity(uint32(id), &common, &studio, &project, nil)
	e, err := h.uc.UpdateEnvironmentValue(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}

	c.PureJSON(http.StatusOK, e)
}

type deletePipelineSettingValueParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deletePipelineSettingValueParams) Entity(
	group entity.PipelineSettingGroup,
	key string,
	common *string,
	studio *string,
	project *string,
) *entity.DeletePipelineSettingValueParams {
	params := &entity.DeletePipelineSettingValueParams{
		Group:      group,
		Key:        key,
		ModifiedBy: p.ModifiedBy,
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) DeleteValue(c *gin.Context) {
	var p deletePipelineSettingValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	group, ok := entity.ParsePipelineSettingGroup(c.Param("group"))
	if !ok || group != entity.Config && group != entity.Preference && group != entity.Environment {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	common := c.Param("common")
	project := c.Param("project")
	studio := c.Param("studio")
	params := p.Entity(group, key, &common, &studio, &project)
	if err := h.uc.DeleteValue(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

type deleteEnvironmentValueParams struct {
	ModifiedBy *string `json:"modified_by"`
}

func (p *deleteEnvironmentValueParams) Entity(
	id uint32,
	common *string,
	studio *string,
	project *string,
) *entity.DeleteEnvironmentValueParams {
	params := &entity.DeleteEnvironmentValueParams{
		ID:         id,
		ModifiedBy: p.ModifiedBy,
	}
	if common != nil && *common != "" {
		params.Common = common
	}
	if studio != nil && *studio != "" {
		params.Studio = studio
	}
	if project != nil && *project != "" {
		params.Project = project
	}
	return params
}

func (h *PipelineSetting) DeleteEnvironmentValue(c *gin.Context) {
	var p deleteEnvironmentValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	strID := c.Param("id")
	id, err := strconv.Atoi(strID)
	if err != nil {
		badRequest(c, err)
		return
	}
	common := c.Param("common")
	project := c.Param("project")
	studio := c.Param("studio")
	params := p.Entity(uint32(id), &common, &studio, &project)

	if err := h.uc.DeleteEnvironmentValue(c.Request.Context(), params); err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.Status(http.StatusNoContent)
}

// Preference Composite Value

type PreferenceCompositeValue struct {
	uc *usecase.PipelineSetting
}

func NewPreferenceCompositeValue(
	uc *usecase.PipelineSetting,
) *PreferenceCompositeValue {
	return &PreferenceCompositeValue{
		uc: uc,
	}
}

type getPreferenceCompositeValueParams struct {
	Common  *string `form:"common"`
	Studio  *string `form:"studio"`
	Project *string `form:"project"`
}

func (p *getPreferenceCompositeValueParams) Entity(
	key string,
) *entity.GetPipelineSettingValueParams {
	params := &entity.GetPipelineSettingValueParams{
		Group:     entity.Preference,
		Key:       key,
		Composite: true,
	}
	if p.Common != nil && *p.Common != "" {
		params.Common = p.Common
	}
	if p.Studio != nil && *p.Studio != "" {
		params.Studio = p.Studio
	}
	if p.Project != nil && *p.Project != "" {
		params.Project = p.Project
	}
	return params
}

func (h *PipelineSetting) GetCompositeValue(c *gin.Context) {
	var p getPreferenceCompositeValueParams
	if err := c.ShouldBind(&p); err != nil {
		badRequest(c, err)
		return
	}
	key := normalizeStarParam(c.Param("key"))
	params := p.Entity(key)
	e, err := h.uc.GetValue(c.Request.Context(), params)
	if err != nil {
		if errors.Is(err, entity.ErrBadRequest) {
			badRequest(c, err)
			return
		}
		if errors.Is(err, entity.ErrRecordNotFound) {
			notFound(c, err)
			return
		}
		internalServerError(c, err)
		return
	}
	c.PureJSON(http.StatusOK, e)
}
