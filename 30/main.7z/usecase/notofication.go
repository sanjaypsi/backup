package usecase

import (
	"context"
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
)

type Notification struct {
	repo         *repository.Notification
	readTimeout  time.Duration
	writeTimeout time.Duration
}

func NewNotification(
	repo *repository.Notification,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *Notification {
	return &Notification{
		repo:         repo,
		readTimeout:  readTimeout,
		writeTimeout: writeTimeout,
	}
}

func (uc *Notification) SendPublishNotification(
	ctx context.Context,
	lgr entity.Logger,
	params *entity.PublishTransactionInfoNotification,
) error {
	if params.Root == nil {
		return errors.New("[EmailSender] root in PublishTransactionInfo is nil")
	}
	if params.Phase == nil {
		return errors.New("[EmailSender] phase in PublishTransactionInfo is nil")
	}
	if params.Component == nil {
		return errors.New("[EmailSender] component in PublishTransactionInfo is nil")
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.SendPublishNotification(db, lgr, params)
}

func (uc *Notification) SendReviewStatusNotification(
	ctx context.Context,
	params *entity.ReviewStatusLogNotification,
) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	uc.repo.SendReviewStatusNotification(db, params)
}

func (uc *Notification) SendApiProcessFailure(err *entity.ApiProcessError) {
	uc.repo.SendApiProcessFailure(err)
}

func (uc *Notification) SendGeneralFailure(err error) {
	uc.repo.SendGeneralFailure(err)
}
