package usecase

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"github.com/go-playground/validator/v10"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type CommentAttachment struct {
	repo         *repository.CommentAttachment
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewCommentAttachment(
	repo *repository.CommentAttachment,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *CommentAttachment {
	return &CommentAttachment{
		repo:         repo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *CommentAttachment) Get(
	ctx context.Context,
	params *entity.GetCommentAttachmentParams,
) (*entity.DownloadAttachment, error) {
	if _, err := primitive.ObjectIDFromHex(params.CommentID); err != nil {
		return nil, entity.ErrBadRequest
	}
	if err := binding.Validator.ValidateStruct(params); showResult(err) {
		return nil, entity.ErrBadRequest
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	var err error
	db, tx, err := uc.repo.WithContext(timeoutCtx)
	if err != nil {
		return nil, err
	}
	defer func() {
		err = cleanupTx(tx, err)
	}()
	attachment, err := uc.repo.Get(db, params)
	return attachment, err
}

func (uc *CommentAttachment) Create(
	ctx context.Context,
	params *entity.PostCommentAttachmentParams,
) (*entity.Document, error) {
	if _, err := primitive.ObjectIDFromHex(params.CommentID); err != nil {
		return nil, err
	}
	if err := binding.Validator.ValidateStruct(params); showResult(err) {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()
	var err error
	db, tx, err := uc.repo.WithContext(timeoutCtx)
	if err != nil {
		return nil, err
	}
	defer func() {
		err = cleanupTx(tx, err)
	}()
	document, err := uc.repo.Create(db, params)
	return document, err
}

func cleanupTx(tx *sql.Tx, err error) error {
	// if panic occurs during transaction
	if p := recover(); p != nil {
		if tx != nil {
			tx.Rollback()
		}
		panic(p)
	}

	// if any error occurs other than panic during transaction
	if err != nil {
		if tx != nil {
			tx.Rollback()
		}
		log.Println(err)
		return err
	}

	// if no error occurs
	if tx != nil {
		if err := tx.Commit(); err != nil {
			log.Println(err)
			return err
		}
	}
	return nil
}

func showResult(err error) bool {
	if err != nil {
		if _, ok := err.(*validator.InvalidValidationError); ok {
			fmt.Println(err)
			return true
		}
		for _, err := range err.(validator.ValidationErrors) {
			fmt.Println(err.Namespace())
			fmt.Println(err.Field())
			fmt.Println(err.StructNamespace())
			fmt.Println(err.StructField())
			fmt.Println(err.Tag())
			fmt.Println(err.ActualTag())
			fmt.Println(err.Kind())
			fmt.Println(err.Type())
			fmt.Println(err.Value())
			fmt.Println(err.Param())
			fmt.Println()
		}
		return true
	}
	return false
}
