package usecase

import (
	"context"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
)

type Auth struct {
	repo         *repository.Auth
	readTimeout  time.Duration
	writeTimeout time.Duration
}

func NewAuth(
	repo *repository.Auth,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *Auth {
	return &Auth{
		repo:         repo,
		readTimeout:  readTimeout,
		writeTimeout: writeTimeout,
	}
}

func (uc *Auth) ParseHeaderToken(
	ctx context.Context,
	params *entity.StudioAuthParams,
) (string, error) {
	tokenStr, err := uc.checkHeader(params.AuthHeader)
	if err != nil {
		return "", err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.ParseToken(db, tokenStr)
}

func (uc *Auth) ParseQueryToken(ctx context.Context, tokenStr string) (string, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.ParseToken(db, tokenStr)
}

func (uc *Auth) CheckProjectAccess(ctx context.Context, params *entity.ProjectAccessParams) error {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.CheckProjectAccess(db, params)
}

func (uc *Auth) CreateNewToken(name string) (string, error) {
	return uc.repo.CreateNewToken(name)
}

func (uc *Auth) Login(ctx context.Context, params *entity.LoginParams) (string, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.Login(db, params)
}

func (uc *Auth) checkHeader(tokenStr string) (string, error) {
	if tokenStr == "" {
		return "", entity.ErrUnauthorized
	}
	bearerToken := strings.Split(tokenStr, entity.Bearer+" ")
	if len(bearerToken) == entity.BearerLength {
		tokenStr = strings.TrimSpace(bearerToken[entity.TokenPos])
	} else {
		return "", entity.ErrUnauthorized
	}
	return tokenStr, nil
}
