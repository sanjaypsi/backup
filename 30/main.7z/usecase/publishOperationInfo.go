package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
)

type PublishOperationInfo struct {
	repo        *repository.PublishOperationInfo
	readTimeout time.Duration
}

func NewPublishOperationInfo(
	repo *repository.PublishOperationInfo,
	readTimeout time.Duration,
) *PublishOperationInfo {
	return &PublishOperationInfo{
		repo:        repo,
		readTimeout: readTimeout,
	}
}

func (uc *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	params *entity.LatestAssetComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestAssetDocuments(timeoutCtx, params)
}

func (uc *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
) ([]*entity.ShotDocument, int64, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListShots(timeoutCtx, params)
}

func (uc *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	params *entity.LatestShotComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestShotDocuments(timeoutCtx, params)
}
