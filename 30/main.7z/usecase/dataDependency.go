package usecase

import (
	"context"
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	dataDepEntity "github.com/PolygonPictures/central30-web/front/entity/dataDependency"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

// DataDepUsecase represents the use case for handling data dependencies.
type DataDepUsecase struct {
	// repo: A pointer to DataDepRepository which handles data dependency operations.
	repo *repository.DataDepRepository

	// prjRepo: A pointer to ProjectInfo which provides project-related information.
	prjRepo *repository.ProjectInfo

	// ReadTimeout: Duration for read operations timeout.
	ReadTimeout time.Duration

	// WriteTimeout: Duration for write operations timeout.
	WriteTimeout time.Duration
}

// NewDataDepUsecase creates a new instance of DataDepUsecase with the provided data dependency
// repository, project repository, read timeout, and write timeout.
//
// Parameters:
//   - repo: a pointer to DataDepRepository which handles data dependency operations.
//   - prjRepo: a pointer to ProjectInfo repository which contains project-related information.
//   - readTimeout: duration for read operations timeout.
//   - writeTimeout: duration for write operations timeout.
//
// Returns:
//   - A pointer to a newly created DataDepUsecase instance.
func NewDataDepUsecase(
	repo *repository.DataDepRepository,
	prjRepo *repository.ProjectInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *DataDepUsecase {
	return &DataDepUsecase{
		repo:         repo,
		prjRepo:      prjRepo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

// checkForProject checks if the project exists in the database.
//
// Parameters:
//   - db: A pointer to a GORM database instance.
//   - lgr: A pointer to a Logger instance.
//   - project: The name of the project.
//
// Returns:
//   - nil: If the project exists.
//   - error: If the project does not exist.
func (uc *DataDepUsecase) checkForProject(db *gorm.DB, lgr entity.Logger, project string) error {
	if project == "" {
		return nil
	}

	if _, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			retErr := entity.NewBadRequestError("project not found")
			lgr.Warnf("%v: %v", retErr, err)
			return retErr
		}
		retErr := entity.NewBadGatewayError("error getting project info")
		lgr.Errorf("%v: %v", retErr, err)
		return retErr
	}

	return nil
}

// ListRoots retrieves the root entity for the specified project.
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//
// Returns:
//   - A slice of pointers to Root entities.
//   - An integer representing the total number of root entities.
//   - An error if the operation fails.
func (uc *DataDepUsecase) ListRoots(
	ctx context.Context,
	lgr entity.Logger,
	project string,
) ([]*dataDepEntity.Root, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if err := uc.checkForProject(uc.repo.WithContext(timeoutCtx), lgr, project); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListRoots(timeoutCtx, lgr, project)
}

// GetRoot retrieves the root entity for the specified project and root.
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//
// Returns:
//   - A pointer to the Root entity.
//   - An error if the operation fails.
func (uc *DataDepUsecase) GetRoot(
	ctx context.Context,
	lgr entity.Logger,
	project, root string,
) (*dataDepEntity.Root, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetRoot(timeoutCtx, lgr, project, root)
}

// ListGroups retrieves a list of group entities for the specified project and root.
//
// Parameters:
//   - ctx: The context for the request, used for timeout and cancellation.
//   - lgr: The logger instance for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//
// Returns:
//   - A slice of Group pointers representing the groups.
//   - An integer representing the total number of groups.
//   - An error if any occurred during the operation.
func (uc *DataDepUsecase) ListGroups(
	ctx context.Context,
	lgr entity.Logger,
	project, root string,
) ([]*dataDepEntity.Group, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetRoot(timeoutCtx, lgr, project, root); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListGroups(timeoutCtx, lgr, project, root)
}

// GetGroup retrieves a group entity for the specified project, root,
// and group.
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//
// Returns:
//   - *dataDepEntity.Group: The retrieved group entity.
//   - error: An error if the operation fails.
func (uc *DataDepUsecase) GetGroup(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group string,
) (*dataDepEntity.Group, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetGroup(timeoutCtx, lgr, project, root, group)
}

// ListRelations retrieves a list of relation entities for the specifies project, root, and group.
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//
// Returns:
//   - A slice of pointers to dataDepEntity.Relation representing the relations.
//   - An integer representing the total number of relations.
//   - An error if any issue occurs during the retrieval process.
func (uc *DataDepUsecase) ListRelations(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group string,
) ([]*dataDepEntity.Relation, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetGroup(timeoutCtx, lgr, project, root, group); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListRelations(timeoutCtx, lgr, project, root, group)
}

// GetRelation retrieves the relation entity for the specified project, root, group, and relation.
//
// Parameters:
//   - ctx: The context for controlling cancellation and deadlines.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//
// Returns:
//   - *dataDepEntity.Relation: The relation data if found.
//   - error: An error if the operation fails.
func (uc *DataDepUsecase) GetRelation(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation string,
) (*dataDepEntity.Relation, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetRelation(timeoutCtx, lgr, project, root, group, relation)
}

// ListPhaseDirectories retrieves a list of phase directory entities for the specified project,
// root, group, and relation.
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The root name of the directory.
//   - group: The name of the group.
//   - relation: The name of the relation.
//
// Returns:
//   - A slice of pointers to PhaseDirectory entities.
//   - An integer representing the count of phase directories.
//   - An error if any issues occur during the retrieval process.
func (uc *DataDepUsecase) ListPhaseDirectories(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation string,
) ([]*dataDepEntity.PhaseDirectory, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetRelation(timeoutCtx, lgr, project, root, group, relation); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListPhaseDirectories(
		timeoutCtx, lgr, project, root, group, relation,
	)
}

// GetPhaseDirectory retrieves the phase directory entity for the specified project, root, group,
// relation, and phase.
//
// Parameters:
//   - ctx: The context for the request, used for cancellation and deadlines.
//   - lgr: The logger instance for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//
// Returns:
//   - *dataDepEntity.PhaseDirectory: The phase directory entity if found.
//   - error: An error if the operation fails or the phase directory is not found.
func (uc *DataDepUsecase) GetPhaseDirectory(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase string,
) (*dataDepEntity.PhaseDirectory, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetPhaseDirectory(
		timeoutCtx, lgr, project, root, group, relation, phase,
	)
}

// ListComponentDirectories retrieves a list of component directory entities for the specified
// project, root, group, relation, and phase.
//
// Parameters:
//   - ctx: The context for managing request deadlines and cancellations.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//
// Returns:
//   - A slice of pointers to ComponentDirectory entities.
//   - An integer representing the total number of component directories.
//   - An error if any issue occurs during the process.
func (uc *DataDepUsecase) ListComponentDirectories(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase string,
) ([]*dataDepEntity.ComponentDirectory, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetPhaseDirectory(
		timeoutCtx, lgr, project, root, group, relation, phase,
	); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListComponentDirectories(
		timeoutCtx, lgr, project, root, group, relation, phase,
	)
}

// GetComponentDirectory retrieves the component directory entity for the specified projet,
// root, group, relation, phase and component.
//
// Parameters:
//   - ctx: The context for the operation, used for cancellation and deadlines.
//   - lgr: The logger instance for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//
// Returns:
//   - *dataDepEntity.ComponentDirectory: The retrieved component directory.
//   - error: An error if the operation fails.
func (uc *DataDepUsecase) GetComponentDirectory(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component string,
) (*dataDepEntity.ComponentDirectory, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetComponentDirectory(
		timeoutCtx, lgr, project, root, group, relation, phase, component,
	)
}

// ListRevisions retrieves a list of revision entities for the specified component within a
// project.
//
// Parameters:
//   - ctx: The context for managing request deadlines and cancellation signals.
//   - lgr: The logger for logging information and errors.
//   - project: The name of the project.
//   - root: The root name of the project.
//   - group: The group name of the project.
//   - relation: The relation name of the group.
//   - phase: The phase name of the project.
//   - component: The specific component to list revisions for.
//
// Returns:
//   - A slice of pointers to Revision entities.
//   - An integer representing the total number of revisions.
//   - An error if any issues occur during the process.
func (uc *DataDepUsecase) ListRevisions(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component string,
) ([]*dataDepEntity.Revision, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetComponentDirectory(
		timeoutCtx, lgr, project, root, group, relation, phase, component,
	); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListRevisions(
		timeoutCtx, lgr, project, root, group, relation, phase, component,
	)
}

// GetRevision retrieves a specific revision entity for the specified component within a project.
//
// Parameters:
//   - ctx: The context for the operation, used for cancellation and deadlines.
//   - lgr: The logger instance for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//
// Returns:
//   - *dataDepEntity.Revision: The retrieved revision entity.
//   - error: An error if the operation fails.
func (uc *DataDepUsecase) GetRevision(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision string,
) (*dataDepEntity.Revision, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetRevision(
		timeoutCtx, lgr, project, root, group, relation, phase, component, revision,
	)
}

// ListContents retrieves a list of content entities for the specified component revision within a
// project.
//
// Parameters:
//   - ctx: The context for managing request deadlines and cancellations.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//
// Returns:
//   - A slice of Content pointers representing the list of contents.
//   - An integer representing the total count of contents.
//   - An error if any issue occurs during the process.
func (uc *DataDepUsecase) ListContents(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision string,
) ([]*dataDepEntity.Content, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetRevision(
		timeoutCtx, lgr, project, root, group, relation, phase, component, revision,
	); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListContents(
		timeoutCtx, lgr, project, root, group, relation, phase, component, revision,
	)
}

// GetContent retrieves the content entity for the specified component revision within a project.
//
// Parameters:
//   - ctx: The context for the request.
//   - lgr: The logger instance for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//   - content: The name of the content.
//
// Returns:
//   - *dataDepEntity.Content: The retrieved content entity.
//   - error: An error if the operation fails.
func (uc *DataDepUsecase) GetContent(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) (*dataDepEntity.Content, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	return uc.repo.GetContent(
		timeoutCtx, lgr, project, root, group, relation, phase, component, revision, content,
	)
}

// ListContentFiles retrieves a list of content file entities for the specified content within a
// project.
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//   - content: The name of the content.
//
// Returns:
//   - A slice of pointers to ContentFile entities.
//   - An integer representing the total number of content files.
//   - An error if any issue occurs during the retrieval process.
func (uc *DataDepUsecase) ListContentFiles(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) ([]*dataDepEntity.ContentFile, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetContent(
		timeoutCtx,
		lgr,
		project, root, group, relation, phase, component, revision, content,
	); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListContentFiles(
		timeoutCtx,
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
}

// ListContentDependencies retrieves a list of content dependencies for the specified content.
// (e.g.: Assets referenced in a shot scene file)
//
// Parameters:
//   - ctx: The context for controlling cancellation and timeout.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//   - content: The name of the content.
//
// Returns:
//   - A slice of pointers to ContentDependency entities.
//   - An integer representing the count of content dependencies.
//   - An error if any occurs during the process.
func (uc *DataDepUsecase) ListContentDependencies(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) ([]*dataDepEntity.ContentDependency, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetContent(
		timeoutCtx,
		lgr,
		project, root, group, relation, phase, component, revision, content,
	); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListContentDependencies(
		timeoutCtx,
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
}

// ListContentDependents retrieves a list of content dependents for the specified content.
// (e.g.: Shot scene files referencing the asset)
//
// Parameters:
//   - ctx: The context for managing request deadlines and cancellations.
//   - lgr: The logger for logging purposes.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//   - content: The name of the content.
//
// Returns:
//   - A slice of ContentDependency pointers.
//   - An integer representing the total number of dependencies.
//   - An error if any occurs during the process.
func (uc *DataDepUsecase) ListContentDependents(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) ([]*dataDepEntity.ContentDependency, int, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	if _, err := uc.repo.GetContent(
		timeoutCtx,
		lgr,
		project, root, group, relation, phase, component, revision, content,
	); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListContentDependents(
		timeoutCtx,
		lgr,
		project, root, group, relation, phase, component, revision, content,
	)
}

// AddContentDependencies adds content dependencies. (e.g: Assets referenced in a shot scene file)
//
// Parameters:
//   - ctx: The context for managing request deadlines and cancellation signals.
//   - lgr: The logger for logging warnings and errors.
//   - project: The name of the project.
//   - root: The name of the root.
//   - group: The name of the group.
//   - relation: The name of the relation.
//   - phase: The name of the phase.
//   - component: The name of the component.
//   - revision: The name of the revision.
//   - content: The name of the content.
//   - params: A list of content files and their dependencies.
//
// Returns:
//   - *dataDepEntity.ContentAndDependenciesWithFile: The added content dependencies along with
//     the file information.
//   - error: An error if the operation fails, otherwise nil.
func (uc *DataDepUsecase) AddContentDependencies(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
	params *dataDepEntity.AddContentDependenciesParams,
) (*dataDepEntity.ContentAndDependenciesWithFile, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("could not validate query parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	// Check for project
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, lgr, project); err != nil {
		return nil, err
	}

	// TODO:
	// It would be even better to check for the existence of the root.
	// To do this, we need to get the list of roots beforehand from the project preferences in
	// the pipeline settings.

	return uc.repo.AddContentDependencies(
		ctx,
		lgr,
		project, root, group, relation, phase, component, revision, content, params,
	)
}
