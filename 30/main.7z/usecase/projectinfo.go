package usecase

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type ProjectInfo struct {
	repo         *repository.ProjectInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewProjectInfo(
	repo *repository.ProjectInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *ProjectInfo {
	return &ProjectInfo{
		repo:         repo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *ProjectInfo) WithContext(ctx context.Context) *gorm.DB {
	return uc.repo.WithContext(ctx)
}

func (uc *ProjectInfo) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	return uc.repo.TransactionWithContext(ctx, fc, opts...)
}

func (uc *ProjectInfo) List(
	ctx context.Context,
	params *entity.ListProjectInfoParams,
) ([]*entity.ProjectInfo2, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.List(db, params)
}

func (uc *ProjectInfo) Get(
	ctx context.Context,
	params *entity.GetProjectInfoParams,
) (*entity.ProjectInfo2, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.Get(db, params)
}

func (uc *ProjectInfo) Create(
	ctx context.Context,
	params *entity.CreateProjectInfoParams,
) (*entity.ProjectInfo2, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.Get(db, &entity.GetProjectInfoParams{
		KeyName: params.KeyName,
	}); err == nil {
		return nil, fmt.Errorf(
			"%w: project with key name %q is already exists",
			entity.ErrBadRequest, params.KeyName,
		)
	}

	var e *entity.ProjectInfo2
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var err error
		e, err = uc.repo.Create(tx, params)
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *ProjectInfo) Delete(
	ctx context.Context,
	params *entity.DeleteProjectInfoParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.Get(db, &entity.GetProjectInfoParams{
		KeyName: params.KeyName,
	}); err != nil {
		return err
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.Delete(tx, params)
	})
}
