package usecase

import (
	"context"
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/pipelineParameter"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type PipelineParameter struct {
	repo         *repository.PipelineParameter
	pr           *repository.ProjectInfo
	sr           *repository.StudioInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewPipelineParameter(
	repo *repository.PipelineParameter,
	pr *repository.ProjectInfo,
	sr *repository.StudioInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *PipelineParameter {
	return &PipelineParameter{
		repo:         repo,
		pr:           pr,
		sr:           sr,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *PipelineParameter) checkForProject(
	db *gorm.DB,
	lgr entity.Logger,
	project string,
) error {
	if project == "" {
		return nil
	}

	if _, err := uc.pr.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			retErr := entity.NewBadRequestError("project not found")
			lgr.Warnf("%v: %v", retErr, err)
			return retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while retrieving the project")
		lgr.Errorf("%v: %v", retErr, err)
		return retErr
	}

	return nil
}

func (uc *PipelineParameter) checkForStudio(db *gorm.DB, lgr entity.Logger, studio string) error {
	if studio == "" {
		return nil
	}

	if _, err := uc.sr.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			retErr := entity.NewBadRequestError("studio not found")
			lgr.Warnf("%v: %v", retErr, err)
			return retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while retrieving the studio")
		lgr.Errorf("%v: %v", retErr, err)
		return retErr
	}

	return nil
}

// Parameter

func (uc *PipelineParameter) ListParameterUpdates(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.ListParameterUpdatesParams,
) ([]*pipelineParameter.Parameter, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, 0, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.ListParameterUpdates(db, lgr, params)
}

func (uc *PipelineParameter) ListParameters(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.ListParametersParams,
) ([]*pipelineParameter.Parameter, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, 0, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.ListParameters(db, lgr, params)
}

func (uc *PipelineParameter) GetParameter(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.GetParameterParams,
) (*pipelineParameter.Parameter, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.GetParameter(db, lgr, params)
}

func (uc *PipelineParameter) CreateParameter(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.CreateParameterParams,
) (*pipelineParameter.Parameter, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.GetParameter(db, lgr, pipelineParameter.GetParameterParams{
		KeyName: params.KeyName,
	}); err == nil {
		return nil, err
	}

	var e *pipelineParameter.Parameter
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		parameter, err := uc.repo.CreateParameter(tx, lgr, params)
		e = parameter
		return err
	}); err != nil {
		return nil, err
	}

	lgr.Set("createdParameter", e)
	lgr.Infof("a parameter created: %v", e.KeyName)
	return e, nil
}

func (uc *PipelineParameter) DeleteParameter(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.DeleteParameterParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	getParams := pipelineParameter.GetParameterParams{
		KeyName: params.KeyName,
	}
	if _, err := uc.repo.GetParameter(db, lgr, getParams); err != nil {
		return err
	}
	count, err := uc.repo.CountValues(db, lgr, getParams)
	if err != nil {
		return err
	}
	if count != 0 {
		retErr := entity.NewBadRequestErrorf(
			"the parameter has some values and cannot be deleted: parameter=%v, numberOfValues=%v",
			params.KeyName, count,
		)
		lgr.Warn(retErr.Error())
		return retErr
	}

	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteParameter(tx, lgr, params)
	}); err != nil {
		return err
	}

	lgr.Infof("the parameter deleted: %v", params.KeyName)
	return nil
}

// Location

func (uc *PipelineParameter) ListLocationUpdates(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.ListLocationUpdatesParams,
) ([]*pipelineParameter.Location, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, 0, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, lgr, params.Project); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListLocationUpdates(db, lgr, params)
}

func (uc *PipelineParameter) ListLocations(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.ListLocationsParams,
) ([]*pipelineParameter.Location, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, 0, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, lgr, params.Project); err != nil {
		return nil, 0, err
	}

	return uc.repo.ListLocations(db, lgr, params)
}

func (uc *PipelineParameter) GetLocation(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.GetLocationParams,
) (*pipelineParameter.Location, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, lgr, params.Project); err != nil {
		return nil, err
	}

	return uc.repo.GetLocation(db, lgr, params)
}

func (uc *PipelineParameter) CreateLocation(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.CreateLocationParams,
) (*pipelineParameter.Location, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, lgr, params.Project); err != nil {
		return nil, err
	}

	if _, err := uc.repo.GetParameter(db, lgr, pipelineParameter.GetParameterParams{
		KeyName: params.Parameter,
	}); err != nil {
		return nil, err
	}

	var e *pipelineParameter.Location
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		location, err := uc.repo.CreateLocation(tx, lgr, params)
		e = location
		return err
	}); err != nil {
		return nil, err
	}

	lgr.Set("createdLocation", e)
	lgr.Infof("a parameter location created: parameter=%v path=%v", e.Parameter, e.Path)
	return e, nil
}

func (uc *PipelineParameter) DeleteLocation(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.DeleteLocationParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, lgr, params.Project); err != nil {
		return err
	}
	if _, err := uc.repo.GetLocation(db, lgr, pipelineParameter.GetLocationParams{
		Project: params.Project,
		ID:      params.ID,
	}); err != nil {
		return err
	}

	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteLocation(tx, lgr, params)
	}); err != nil {
		return err
	}

	lgr.Infof("the parameter location deleted: id=%v", params.ID)
	return nil
}

// Value

func (uc *PipelineParameter) ListValueUpdates(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.ListValueUpdatesParams,
) ([]*pipelineParameter.Value, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, 0, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Project != nil {
		if err := uc.checkForProject(db, lgr, *params.Project); err != nil {
			return nil, 0, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, lgr, *params.Studio); err != nil {
			return nil, 0, err
		}
	}

	return uc.repo.ListValueUpdates(db, lgr, params)
}

func (uc *PipelineParameter) ListValues(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.ListValuesParams,
) ([]*pipelineParameter.Value, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, 0, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	for _, project := range params.Projects {
		if err := uc.checkForProject(db, lgr, project); err != nil {
			return nil, 0, err
		}
	}
	for _, studio := range params.Studios {
		if err := uc.checkForStudio(db, lgr, studio); err != nil {
			return nil, 0, err
		}
	}

	return uc.repo.ListValues(db, lgr, params)
}

func (uc *PipelineParameter) GetValue(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.GetValueParams,
) (*pipelineParameter.Value, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.GetValue(db, lgr, params)
}

func (uc *PipelineParameter) CreateValue(
	ctx context.Context,
	lgr entity.Logger,
	params *pipelineParameter.CreateValueParams,
) (*pipelineParameter.Value, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)

	if params.Project != nil {
		if err := uc.checkForProject(db, lgr, *params.Project); err != nil {
			return nil, err
		}
	}

	if params.Studio != nil {
		if err := uc.checkForStudio(db, lgr, *params.Studio); err != nil {
			return nil, err
		}
	}

	parameter, err := uc.repo.GetParameter(db, lgr, pipelineParameter.GetParameterParams{
		KeyName: params.Parameter,
	})
	if err != nil {
		return nil, err
	}

	if err := parameter.Validate(params.Value); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	var e *pipelineParameter.Value
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		value, err := uc.repo.CreateValue(tx, lgr, params)
		e = value
		return err
	}); err != nil {
		return nil, err
	}

	lgr.Set("createdValue", e)
	lgr.Infof("a parameter value created: %v=%v", e.Parameter, e.Value)
	return e, nil
}

func (uc *PipelineParameter) UpdateValue(
	ctx context.Context,
	lgr entity.Logger,
	params *pipelineParameter.UpdateValueParams,
) (*pipelineParameter.Value, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)

	if params.Parameter == "" {
		value, err := uc.GetValue(timeoutCtx, lgr, pipelineParameter.GetValueParams{
			ID: params.ID,
		})
		if err != nil {
			return nil, err
		}
		params.Parameter = value.Parameter
	}

	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	parameter, err := uc.repo.GetParameter(db, lgr, pipelineParameter.GetParameterParams{
		KeyName: params.Parameter,
	})
	if err != nil {
		return nil, err
	}

	if err := parameter.Validate(params.Value); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	var e *pipelineParameter.Value
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		value, err := uc.repo.UpdateValue(tx, lgr, params)
		e = value
		return err
	}); err != nil {
		return nil, err
	}

	lgr.Set("updatedValue", e)
	lgr.Infof("the parameter value updated: %v=%v", e.Parameter, e.Value)
	return e, nil
}

func (uc *PipelineParameter) UpsertValue(
	ctx context.Context,
	lgr entity.Logger,
	params *pipelineParameter.UpsertValueParams,
) (*pipelineParameter.Value, error) {
	var studios []string
	if params.Studio != nil {
		studios = append(studios, *params.Studio)
	}

	var projects []string
	if params.Project != nil {
		projects = append(projects, *params.Project)
	}

	entities, total, err := uc.ListValues(ctx, lgr, pipelineParameter.ListValuesParams{
		Parameter: &params.Parameter,
		Studios:   studios,
		Projects:  projects,
		Location:  &params.Location,
	})
	if err != nil {
		return nil, err
	}

	if total == 0 {
		e, err := uc.CreateValue(ctx, lgr, &pipelineParameter.CreateValueParams{
			Parameter: params.Parameter,
			Studio:    params.Studio,
			Project:   params.Project,
			Location:  params.Location,
			Value:     params.Value,
			CreatedBy: params.CreatedBy,
		})
		if err != nil {
			return nil, err
		}

		lgr.Set("createdValue", e)
		lgr.Infof("a parameter value created: %v=%v", e.Parameter, e.Value)
		return e, nil
	}

	if total == 1 {
		e := entities[0]
		e, err := uc.UpdateValue(ctx, lgr, &pipelineParameter.UpdateValueParams{
			ID:         e.ID,
			Parameter:  e.Parameter,
			Value:      params.Value,
			ModifiedBy: params.ModifiedBy,
		})
		if err != nil {
			return nil, err
		}

		lgr.Set("updated value", e)
		lgr.Infof("the parameter value updated: %v=%v", e.Parameter, e.Value)
		return e, nil
	}

	retErr := entity.NewBadRequestError(
		"there are multiple values that match the condition, and one cannot be identified",
	)
	lgr.Warn(retErr.Error())
	return nil, retErr
}

func (uc *PipelineParameter) DeleteValue(
	ctx context.Context,
	lgr entity.Logger,
	params pipelineParameter.DeleteValueParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		retErr := entity.NewBadRequestErrorf("got invalid parameters: %w", err)
		lgr.Error(retErr.Error())
		return retErr
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)

	if _, err := uc.repo.GetValue(db, lgr, pipelineParameter.GetValueParams{
		ID: params.ID,
	}); err != nil {
		return err
	}

	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteValue(tx, lgr, params)
	}); err != nil {
		return err
	}

	lgr.Infof("the parameter value deleted: id=%v", params.ID)
	return nil
}
