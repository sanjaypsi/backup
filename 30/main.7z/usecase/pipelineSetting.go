package usecase

import (
	"context"
	"errors"
	"fmt"
	"math"
	"reflect"
	"regexp"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"github.com/xeipuuv/gojsonschema"
	"gorm.io/gorm"
)

// currently define `definition` here as constant
const definition string = `{
	"$schema": "http://json-schema.org/draft-04/schema#",
	"additionalProperties": false,
	"title": "Basic Environment",
	"description": "Basic environment schema",
	"properties": {
		"key": {
			"pattern": "^[0-9A-Za-z_]+$",
			"type": "string"
		},
		"method": {
			"enum": ["set", "append", "prepend", "remove"],
			"type": "string"
		},
		"osName": {
			"enum": ["com", "win", "mac", "lnx"],
			"type": "string"
		},
		"sortOrder": {
			"type": "integer"
		},
		"usage": {
			"pattern": "^/[0-9A-Za-z]+$",
			"type": "string"
		},
		"value": {
			"pattern": "^[\\w:;/.\\{\\}?@%#&=+-]+$",
			"type": "string"
		}
	},
	"required": ["key", "method", "osName", "sortOrder", "value"],
	"type": "object"
}`

type PipelineSetting struct {
	repo         *repository.PipelineSetting
	pr           *repository.ProjectInfo
	sr           *repository.StudioInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewPipelineSetting(
	repo *repository.PipelineSetting,
	pr *repository.ProjectInfo,
	sr *repository.StudioInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *PipelineSetting {
	return &PipelineSetting{
		repo:         repo,
		pr:           pr,
		sr:           sr,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *PipelineSetting) checkForCommon(db *gorm.DB, common string) error {
	if common == "" {
		return nil
	}
	if common != "default" {
		return fmt.Errorf("%w: common %q not found", entity.ErrBadRequest, common)
	}
	return nil
}

func (uc *PipelineSetting) checkForProject(db *gorm.DB, project string) error {
	if project == "" {
		return nil
	}
	_, err := uc.pr.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	if err != nil && errors.Is(err, entity.ErrRecordNotFound) {
		return fmt.Errorf("%w: project %q not found", entity.ErrBadRequest, project)
	}
	return err
}

func (uc *PipelineSetting) checkForStudio(db *gorm.DB, studio string) error {
	if studio == "" {
		return nil
	}
	_, err := uc.sr.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	})
	if err != nil && errors.Is(err, entity.ErrRecordNotFound) {
		return fmt.Errorf("%w: studio %q not found", entity.ErrBadRequest, studio)
	}
	return err
}

// Property

func (uc *PipelineSetting) ListProperties(
	ctx context.Context,
	params *entity.ListPipelineSettingPropertyParams,
) ([]*entity.PipelineSettingProperty, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.ListProperties(db, params)
}

func (uc *PipelineSetting) ListEnvironmentProperties(
	ctx context.Context,
	params *entity.ListEnvironmentPropertyParams,
) ([]*entity.PipelineSettingProperty, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.ListEnvironmentProperties(db, params)
}

func (uc *PipelineSetting) GetProperty(
	ctx context.Context,
	params *entity.GetPipelineSettingPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.GetProperty(db, params)
}

func (uc *PipelineSetting) GetEnvironmentProperty(
	ctx context.Context,
	params *entity.GetEnvironmentPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.GetEnvironmentProperty(db, params)
}

func (uc *PipelineSetting) CreateProperty(
	ctx context.Context,
	params *entity.CreatePipelineSettingPropertyParams,
	schema interface{},
) (*entity.PipelineSettingProperty, error) {
	if params.Group != entity.Environment {
		result, err := checkRequestSchema(schema)
		if err != nil {
			return nil, err
		}
		params.Schema = *result
	} else {
		params.Schema = entity.JSONSchema{Type: "string"}
	}

	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.GetProperty(db, &entity.GetPipelineSettingPropertyParams{
		Group:   params.Group,
		Section: params.Section,
		Key:     params.Key,
	}); err == nil {
		return nil, fmt.Errorf(
			"%w: property with key %q is already exists", entity.ErrBadRequest, params.Key,
		)
	}

	var e *entity.PipelineSettingProperty
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		property, err := uc.repo.CreateProperty(tx, params)
		e = property
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) CreateEnvironmentProperty(
	ctx context.Context,
	params *entity.CreateEnvironmentPropertyParams,
	schema interface{},
) (*entity.PipelineSettingProperty, error) {
	// Currently create empty JSON for environment property
	params.Schema = entity.JSONSchema{}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.GetEnvironmentProperty(db, &entity.GetEnvironmentPropertyParams{
		Section: params.Section,
		Key:     params.Key,
	}); err == nil {
		return nil, fmt.Errorf(
			"%w: property with key %q is already exists", entity.ErrBadRequest, params.Key,
		)
	}

	var e *entity.PipelineSettingProperty
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		property, err := uc.repo.CreateEnvironmentProperty(tx, params)
		e = property
		return err

	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) UpdateProperty(
	ctx context.Context,
	params *entity.UpdatePipelineSettingPropertyParams,
	schema interface{},
) (*entity.PipelineSettingProperty, error) {
	result, err := checkRequestSchema(schema)
	if err != nil {
		return nil, err
	}
	params.Schema = *result

	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	getParams := entity.GetPipelineSettingPropertyParams{
		Group:   params.Group,
		Section: params.Section,
		Key:     params.Key,
	}
	if _, err := uc.repo.GetProperty(db, &getParams); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return nil, err
	}

	var e *entity.PipelineSettingProperty
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		property, err := uc.repo.UpdateProperty(tx, params)
		e = property
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) UpdateEnvironmentProperty(
	ctx context.Context,
	params *entity.UpdateEnvironmentPropertyParams,
	schema interface{},
) (*entity.PipelineSettingProperty, error) {
	result, err := checkRequestSchema(schema)
	if err != nil {
		return nil, err
	}
	params.Schema = *result

	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	getParams := entity.GetEnvironmentPropertyParams{
		Section: params.Section,
		Key:     params.Key,
	}

	if _, err := uc.repo.GetEnvironmentProperty(db, &getParams); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return nil, err
	}

	var e *entity.PipelineSettingProperty
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		property, err := uc.repo.UpdateEnvironmentProperty(tx, params)
		e = property
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) DeleteProperty(
	ctx context.Context,
	params *entity.DeletePipelineSettingPropertyParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	getParams := entity.GetPipelineSettingPropertyParams{
		Group:   params.Group,
		Section: params.Section,
		Key:     params.Key,
	}

	if _, err := uc.repo.GetProperty(db, &getParams); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return err
	}

	count, err := uc.repo.CountValues(db, getParams)
	if err != nil {
		return err
	}
	if count != 0 {
		return fmt.Errorf(
			"%w: property with key %q has %d values and cannot be deleted",
			entity.ErrBadRequest, params.Key, count,
		)
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteProperty(tx, params)
	})
}

func (uc *PipelineSetting) DeleteEnvironmentProperty(
	ctx context.Context,
	params *entity.DeleteEnvironmentPropertyParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	getParams := entity.GetEnvironmentPropertyParams{
		Key: params.Key,
	}

	if _, err := uc.repo.GetEnvironmentProperty(db, &getParams); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return err
	}
	count, err := uc.repo.CountEnvironmentValues(db, getParams)
	if err != nil {
		return err
	}
	if count != 0 {
		return fmt.Errorf(
			"%w: property with key %q has %d values and cannot be deleted",
			entity.ErrBadRequest, params.Key, count,
		)
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteEnvironmentProperty(tx, params)
	})
}

func checkRequestSchema(request interface{}) (*entity.JSONSchema, error) {
	schema := entity.JSONSchema{}

	schemamap, ok := request.(map[string]interface{})
	if !ok {
		return nil, fmt.Errorf(
			"invalid schema: schema must be a JSON object: got %#v",
			request,
		)
	}

	schematype, ok := schemamap[entity.JSONType]
	if !ok {
		return nil, errors.New("invalid schema: type property is required")
	}
	switch schematype {
	case entity.JSONArray, entity.JSONString, entity.JSONInteger, entity.JSONNumber, entity.JSONBoolean:
		schema.Type = schematype.(string)
	default:
		return nil, fmt.Errorf("invalid json schema: invalid type: %q", schematype)
	}

	// TODO add strict check for string arrays
	schemaenum, ok := schemamap[entity.JSONEnum]
	if ok {
		var enum []interface{}
		if schema.Type == entity.JSONString {
			v := reflect.ValueOf(schemaenum)
			if v.Kind() == reflect.Slice {
				for i := 0; i < v.Len(); i++ {
					enum = append(enum, fmt.Sprintf("%v", v.Index(i)))
				}
			}
		}
		schema.Enum = enum
	}

	// TODO add flow to the items field
	schemaitems, ok := schemamap[entity.JSONItems]
	if ok && schema.Type == entity.JSONArray {
		mapitems, ok := schemaitems.(map[string]interface{})
		if !ok {
			return nil, fmt.Errorf(
				"invalid schema: items must be a JSON object: got %#v",
				mapitems,
			)
		}
		itemtype, ok := mapitems[entity.JSONType]
		if !ok || itemtype != entity.JSONString {
			return nil, errors.New("invalid schema: type property of items must be a string")
		}
		//check JSON structure recursively
		items, err := checkRequestSchema(schemaitems)
		if err != nil {
			return nil, err
		}
		schema.Items = items
	}

	schemadefault, ok := schemamap[entity.JSONDefault]
	if ok {
		switch schema.Type {
		// TODO add strict check for string arrays
		case entity.JSONArray:
			v := reflect.ValueOf(schemadefault)
			if v.Kind() != reflect.Slice {
				return nil, entity.ErrBadRequest
			}
			var defaultarray []string
			// allow any value of valid types only if passed a valid array
			for i := 0; i < v.Len(); i++ {
				// convert any values into string
				defaultarray = append(defaultarray, fmt.Sprintf("%v", v.Index(i)))
			}
			schema.Default = defaultarray
		case entity.JSONString:
			defaultstring, ok := schemadefault.(string)
			if !ok {
				return nil, entity.ErrBadRequest
			}
			schema.Default = defaultstring
		case entity.JSONInteger:
			defaultinteger, ok := schemadefault.(float64)
			// allow float format when same to integer value (i.e. 12.0 = 12)
			if !ok || defaultinteger != math.Floor(defaultinteger) {
				return nil, entity.ErrBadRequest
			}
			schema.Default = defaultinteger
		case entity.JSONNumber:
			defaultfloat, ok := schemadefault.(float64)
			if !ok {
				return nil, entity.ErrBadRequest
			}
			schema.Default = defaultfloat
		case entity.JSONBoolean:
			defaultbool, ok := schemadefault.(bool)
			if !ok {
				return nil, entity.ErrBadRequest
			}
			schema.Default = defaultbool
		}
	}

	schemaminimum, ok := schemamap[entity.JSONMinimum]
	if ok {
		minimumfloat, ok := schemaminimum.(float64)
		switch schema.Type {
		case entity.JSONInteger:
			// allow float format when same to integer value (i.e. 12.0 = 12)
			if !ok || minimumfloat != math.Floor(minimumfloat) {
				return nil, entity.ErrBadRequest
			}
		case entity.JSONNumber:
			if !ok {
				return nil, entity.ErrBadRequest
			}
		}
		schema.Minimum = minimumfloat
	}

	schemamax, ok := schemamap[entity.JSONMaximum]
	if ok {
		maximumfloat, ok := schemamax.(float64)
		switch schema.Type {
		case entity.JSONInteger:
			// allow float format when same to integer value (i.e. 12.0 = 12)
			if !ok || maximumfloat != math.Floor(maximumfloat) {
				return nil, entity.ErrBadRequest
			}
		case entity.JSONNumber:
			if !ok {
				return nil, entity.ErrBadRequest
			}
		}
		schema.Maximum = maximumfloat
	}

	schemapattern, ok := schemamap[entity.JSONPattern]
	if ok && (schema.Type == entity.JSONString) {
		patternstring, ok := schemapattern.(string)
		if !ok {
			return nil, fmt.Errorf(
				"%w: %v must be consistent with its type %v: got %#v of type %T",
				entity.ErrBadRequest,
				entity.JSONPattern,
				schema.Type,
				schemapattern,
				schemapattern,
			)
		}
		schema.Pattern = &patternstring
	}

	// check if default has a valid value against pattern, min, and max
	if schema.Default != nil {
		switch schema.Type {
		case entity.JSONString:
			if !schema.HasPattern() {
				break
			}
			defaultstring, ok := schema.Default.(string)
			patternregexp := regexp.MustCompile(*schema.Pattern)
			if !ok || !patternregexp.MatchString(defaultstring) {
				return nil, fmt.Errorf(
					"%w: default string value must be satisfy pattern",
					entity.ErrBadRequest,
				)
			}
		case entity.JSONArray:
			if !schema.HasPattern() {
				break
			}
			defaultarray, ok := schema.Default.([]string)
			patternregexp := regexp.MustCompile(*schema.Items.Pattern)
			if !ok {
				return nil, entity.ErrBadRequest
			}
			for _, defaultarrayitem := range defaultarray {
				if !patternregexp.MatchString(defaultarrayitem) {
					return nil, fmt.Errorf(
						"%w: default string value of each item must be satisfy pattern",
						entity.ErrBadRequest,
					)
				}
			}
		case entity.JSONInteger, entity.JSONNumber:
			defaultfloat, ok := schema.Default.(float64)
			if !ok {
				return nil, entity.ErrBadRequest
			}
			if schema.Minimum != nil {
				minimumfloat, ok := schema.Minimum.(float64)
				if !ok {
					return nil, entity.ErrBadRequest
				}
				if defaultfloat < minimumfloat {
					return nil, fmt.Errorf(
						"%w: default number value must be higher than minimum",
						entity.ErrBadRequest,
					)
				}
			}
			if schema.Maximum != nil {
				maximumfloat, ok := schema.Maximum.(float64)
				if !ok {
					return nil, entity.ErrBadRequest
				}
				if maximumfloat < defaultfloat {
					return nil, fmt.Errorf(
						"%w: default number value must be lower than maximum",
						entity.ErrBadRequest,
					)
				}
			}
		}
	}

	// check minimum is lower than or equal to maximum
	if schema.Minimum != nil && schema.Maximum != nil {
		minimumfloat, ok := schema.Minimum.(float64)
		if !ok {
			return nil, entity.ErrBadRequest
		}
		maximumfloat, ok := schema.Maximum.(float64)
		if !ok {
			return nil, entity.ErrBadRequest
		}
		if maximumfloat < minimumfloat {
			return nil, fmt.Errorf(
				"%w: minimum value must be lower than or equal to maximum",
				entity.ErrBadRequest,
			)
		}
	}

	return &schema, nil
}

// Value

func (uc *PipelineSetting) ListValues(
	ctx context.Context,
	params *entity.ListPipelineSettingValueParams,
) ([]*entity.PipelineSettingValue, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if params.Common != nil {
		if err := uc.checkForCommon(db, *params.Common); err != nil {
			return nil, 0, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, 0, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, 0, err
		}
	}
	return uc.repo.ListValues(db, params)
}

func (uc *PipelineSetting) ListEnvironmentValues(
	ctx context.Context,
	params *entity.ListEnvironmentValueParams,
) ([]*entity.PipelineSettingValue, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if params.Common != nil {
		if err := uc.checkForCommon(db, *params.Common); err != nil {
			return nil, 0, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, 0, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, 0, err
		}
	}

	return uc.repo.ListEnvironmentValues(db, params)
}

func (uc *PipelineSetting) GetValue(
	ctx context.Context,
	params *entity.GetPipelineSettingValueParams,
) (*entity.PipelineSettingValue, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if params.Common != nil {
		if err := uc.checkForCommon(db, *params.Common); err != nil {
			return nil, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, err
		}
	}
	return uc.repo.GetValue(db, params)
}

func (uc *PipelineSetting) GetEnvironmentValue(
	ctx context.Context,
	params *entity.GetEnvironmentValueParams,
) (*entity.PipelineSettingValue, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if params.Common != nil {
		if err := uc.checkForCommon(db, *params.Common); err != nil {
			return nil, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, err
		}
	}

	return uc.repo.GetEnvironmentValue(db, params)
}

func (uc *PipelineSetting) CreateValue(
	ctx context.Context,
	params *entity.CreatePipelineSettingValueParams,
) (*entity.PipelineSettingValue, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Common != nil {
		if err := uc.checkForCommon(db, *params.Common); err != nil {
			return nil, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, err
		}
	}
	if _, err := uc.repo.GetValue(db, &entity.GetPipelineSettingValueParams{
		Group:   params.Group,
		Common:  params.Common,
		Studio:  params.Studio,
		Project: params.Project,
		Key:     params.Key,
	}); err == nil {
		return nil, fmt.Errorf(
			"%w: value with key %q is already exists", entity.ErrBadRequest, params.Key,
		)
	}
	section := params.Section()
	property, err := uc.repo.GetProperty(db, &entity.GetPipelineSettingPropertyParams{
		Group:   params.Group,
		Section: &section,
		Key:     params.Key,
	})
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			if params.Group == entity.Config {
				return nil, fmt.Errorf(
					"%w: property with key %q in section %q not found",
					entity.ErrBadRequest, params.Key, section,
				)
			}
			return nil, fmt.Errorf(
				"%w: property with key %q not found",
				entity.ErrBadRequest, params.Key,
			)
		}
		return nil, err
	}
	if err := property.Validate(params.Value); err != nil {
		return nil, fmt.Errorf("%w: %s", entity.ErrBadRequest, err.Error())
	}

	var e *entity.PipelineSettingValue
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		value, err := uc.repo.CreateValue(tx, params)
		e = value
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

// currently define validateEnvironmentValue() as a private function
// instead of entity.PipelineSettingProperty handler like Validate()
// since UpdateEnvironmentValue() is not passed the key of Property
func validateEnvironmentValue(value interface{}) error {
	schemaLoader := gojsonschema.NewStringLoader(definition)
	valueLoader := gojsonschema.NewGoLoader(value)
	result, err := gojsonschema.Validate(schemaLoader, valueLoader)
	if err != nil {
		return err
	}
	if !result.Valid() {
		var errStr string
		for _, err := range result.Errors() {
			errStr += ":" + err.String()
		}
		return errors.New(errStr)
	}
	return nil
}

func (uc *PipelineSetting) CreateEnvironmentValue(
	ctx context.Context,
	params *entity.CreateEnvironmentValueParams,
) (*entity.PipelineSettingValue, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Common != nil {
		if err := uc.checkForCommon(db, *params.Common); err != nil {
			return nil, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, err
		}
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, err
		}
	}

	section := params.Section()
	if _, err := uc.repo.GetEnvironmentProperty(db, &entity.GetEnvironmentPropertyParams{
		Section: &section,
		Key:     params.PropKey,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: property with key %q not found",
				entity.ErrBadRequest, params.PropKey,
			)
		}
		return nil, err
	}
	if err := validateEnvironmentValue(params.Value); err != nil {
		return nil, fmt.Errorf("%w: %s", entity.ErrBadRequest, err.Error())
	}

	var e *entity.PipelineSettingValue
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {

		value, err := uc.repo.CreateEnvironmentValue(tx, params)
		e = value
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) UpdateValue(
	ctx context.Context,
	params *entity.UpdatePipelineSettingValueParams,
) (*entity.PipelineSettingValue, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, err
		}
	}
	if _, err := uc.repo.GetValue(db, &entity.GetPipelineSettingValueParams{
		Group:   params.Group,
		Common:  params.Common,
		Studio:  params.Studio,
		Project: params.Project,
		Key:     params.Key,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: value with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return nil, err
	}
	section := params.Section()
	property, err := uc.repo.GetProperty(db, &entity.GetPipelineSettingPropertyParams{
		Group:   params.Group,
		Section: &section,
		Key:     params.Key,
	})
	if err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			if params.Group == entity.Config {
				return nil, fmt.Errorf(
					"%w: property with key %q in section %q not found",
					entity.ErrBadRequest, params.Key, section,
				)
			}
			return nil, fmt.Errorf(
				"%w: property with key %q not found",
				entity.ErrBadRequest, params.Key,
			)
		}
		return nil, err
	}
	if err := property.Validate(params.Value); err != nil {
		return nil, fmt.Errorf("%w: %s", entity.ErrBadRequest, err.Error())
	}
	var e *entity.PipelineSettingValue
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		value, err := uc.repo.UpdateValue(tx, params)
		e = value
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) UpdateEnvironmentValue(
	ctx context.Context,
	params *entity.UpdateEnvironmentValueParams,
) (*entity.PipelineSettingValue, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return nil, err
		}
	}
	envParams := &entity.GetEnvironmentValueParams{
		Group:   entity.Environment,
		Common:  params.Common,
		Studio:  params.Studio,
		Project: params.Project,
		ID:      params.ID,
	}

	// not testing Property existence in UpdateEnvironmentValue() for the reason below:
	// https://ppi-jp.backlog.com/view/RND-1473#comment-410803048

	if _, err := uc.repo.GetEnvironmentValue(db, envParams); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: value with id %q not found", entity.ErrRecordNotFound, params.ID,
			)
		}
		return nil, err
	}
	if err := validateEnvironmentValue(params.Value); err != nil {
		return nil, fmt.Errorf("%w: %s", entity.ErrBadRequest, err.Error())
	}

	var e *entity.PipelineSettingValue
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		value, err := uc.repo.UpdateEnvironmentValue(tx, params)
		e = value
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *PipelineSetting) DeleteValue(
	ctx context.Context,
	params *entity.DeletePipelineSettingValueParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return err
		}
	}
	if _, err := uc.repo.GetValue(db, &entity.GetPipelineSettingValueParams{
		Group:   params.Group,
		Common:  params.Common,
		Studio:  params.Studio,
		Project: params.Project,
		Key:     params.Key,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: value with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return err
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteValue(tx, params)
	})
}

func (uc *PipelineSetting) DeleteEnvironmentValue(
	ctx context.Context,
	params *entity.DeleteEnvironmentValueParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return err
		}
	}
	if params.Project != nil {
		if err := uc.checkForProject(db, *params.Project); err != nil {
			return err
		}
	}

	envParams := &entity.GetEnvironmentValueParams{
		Group:   entity.Environment,
		Common:  params.Common,
		Studio:  params.Studio,
		Project: params.Project,
		ID:      params.ID,
	}

	if _, err := uc.repo.GetEnvironmentValue(db, envParams); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: value with id %q not found", entity.ErrRecordNotFound, params.ID,
			)
		}
		return err
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.DeleteEnvironmentValue(tx, params)
	})
}
