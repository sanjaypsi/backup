package usecase

import (
	"testing"

	"github.com/gin-gonic/gin/binding"
	"github.com/go-playground/validator/v10"
	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/testutil"
)

const testDBName = "test_usecase"
var testDB *gorm.DB

func TestMain(m *testing.M) {
	testDB = testutil.NewTestDB(testDBName)

	if v, ok := binding.Validator.Engine().(*validator.Validate); ok {
		v.RegisterValidation("startsnotwithdigit", func(f validator.FieldLevel) bool {
			return true
		})
	}

	m.Run()
}
