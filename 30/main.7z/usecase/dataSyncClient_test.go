package usecase

import (
	"context"
	"errors"
	"reflect"
	"testing"
	"time"

	"cloud.google.com/go/logging"
	"cloud.google.com/go/logging/logadmin"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
)

var ErrTimeout = errors.New("timeout")

type StubCloudLoggingFinder struct {
	Entry *logging.Entry
	Timer *time.Timer
}

func (f StubCloudLoggingFinder) FindOne(
	ctx context.Context,
	opts ...logadmin.EntriesOption,
) (*logging.Entry, error) {
	if f.Timer == nil {
		return f.Entry, nil
	}

	select {
	case <-f.Timer.C:
		return nil, ErrTimeout
	case <-ctx.Done():
		f.Timer.Stop()
		return nil, ctx.Err()
	}
}

func TestDataSyncClientGetStatus(t *testing.T) {
	gcpProject := "test_gcp_project"
	project := "potoodev"
	studio := "ppidev"
	timestamp := time.Now()
	ctx := context.Background()
	readTimeout := 1 * time.Second

	finder := StubCloudLoggingFinder{
		Entry: &logging.Entry{Timestamp: timestamp},
	}
	repo := repository.NewDataSyncClient(finder, gcpProject)
	uc := NewDataSyncClient(repo, readTimeout)

	want := &entity.DataSyncClientStatus{
		Project:     project,
		Studio:      studio,
		Status:      "healthy",
		ConfirmedAt: &timestamp,
	}

	got, err := uc.GetStatus(ctx, project, studio)
	if err != nil {
		t.Fatal(err)
	}

	if !reflect.DeepEqual(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
}

func TestDataSyncClientGetStatusTimeout(t *testing.T) {
	gcpProject := "test_gcp_project"
	project := "potoodev"
	studio := "ppidev"
	ctx := context.Background()
	readTimeout := 1 * time.Millisecond
	timer := time.NewTimer(1 * time.Second)
	defer timer.Stop()

	finder := StubCloudLoggingFinder{
		Entry: nil,
		Timer: timer,
	}
	repo := repository.NewDataSyncClient(finder, gcpProject)
	uc := NewDataSyncClient(repo, readTimeout)

	_, err := uc.GetStatus(ctx, project, studio)
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Errorf("got %v, want %v", err, context.DeadlineExceeded)
	}
}
