package usecase

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type PublishTransactionInfo struct {
	repo         *repository.PublishTransactionInfo
	prjRepo      *repository.ProjectInfo
	stuRepo      *repository.StudioInfo
	psRepo       *repository.PipelineSetting
	docRepo      entity.DocumentRepository
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewPublishTransactionInfo(
	repo *repository.PublishTransactionInfo,
	prjRepo *repository.ProjectInfo,
	stuRepo *repository.StudioInfo,
	psRepo *repository.PipelineSetting,
	docRepo entity.DocumentRepository,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *PublishTransactionInfo {
	return &PublishTransactionInfo{
		repo:         repo,
		prjRepo:      prjRepo,
		stuRepo:      stuRepo,
		psRepo:       psRepo,
		docRepo:      docRepo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *PublishTransactionInfo) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	return err
}

func (uc *PublishTransactionInfo) checkForStudio(db *gorm.DB, studio string) error {
	_, err := uc.stuRepo.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	})
	return err
}

func (uc *PublishTransactionInfo) List(
	ctx context.Context,
	params *entity.ListPublishTransactionInfoParams,
) ([]*entity.PublishTransactionInfo, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, 0, err
	}
	return uc.repo.List(db, params)
}

func (uc *PublishTransactionInfo) Get(
	ctx context.Context,
	params *entity.GetPublishTransactionInfoParams,
) (*entity.PublishTransactionInfo, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}
	return uc.repo.Get(db, params)
}

func (uc *PublishTransactionInfo) Create(
	ctx context.Context,
	params *entity.CreatePublishTransactionInfoParams,
) (*entity.PublishTransactionInfo, error) {

	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, fmt.Errorf("%w: %s", entity.ErrBadRequest, err.Error())
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	stackTraceMaxBytes := 65535 // bytes
	ellipsisText := "\n...\n"
	var (
		begining []rune
		ending   []rune
		sum      int
	)
	if params.StackTrace != nil && len(*params.StackTrace) > stackTraceMaxBytes {
		stackTraceMaxBytes -= len(ellipsisText)
		runes := []rune(*params.StackTrace)
		for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
			b, e := runes[i], runes[j]
			if sum += len(string([]rune{b, e})); sum > stackTraceMaxBytes {
				break
			}
			begining = append(begining, b)
			ending = append([]rune{e}, ending...)
		}
		*params.StackTrace = string(begining) + ellipsisText + string(ending)
		log.Printf(
			"Since stack_trace is over %d bytes, some of it has been omitted.",
			stackTraceMaxBytes,
		)
	}

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}
	if err := uc.checkForStudio(db, params.Studio); err != nil {
		return nil, err
	}
	if _, err := uc.repo.Get(db, &entity.GetPublishTransactionInfoParams{
		Project: params.Project,
		LogID:   params.LogID,
	}); err == nil {
		return nil, fmt.Errorf(
			"%w: publish transaction info with log ID %q and project %q already exists",
			entity.ErrBadRequest, params.LogID, params.Project,
		)
	}

	var e *entity.PublishTransactionInfo
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var err error
		e, err = uc.repo.Create(tx, params)
		return err
	}); err != nil {
		return nil, err
	}

	return e, nil
}

func (uc *PublishTransactionInfo) Delete(
	ctx context.Context,
	params *entity.DeletePublishTransactionInfoParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return err
	}
	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.Delete(tx, params)
	})
}
