package usecase

import (
	"context"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/repository"
	"go.mongodb.org/mongo-driver/bson"
)

type GenerateCsv struct {
	repo                 *repository.GenerateCsv
	reviewInfoRepo       *repository.ReviewInfo
	groupCategoryRepo    *repository.GroupCategory
	pubOperationInfoRepo *repository.PublishOperationInfo
	mongoRepo            entity.DocumentRepository
	ReadTimeout          time.Duration
}

func NewGenerateCsv(
	repo *repository.GenerateCsv,
	reviewInfoRepo *repository.ReviewInfo,
	groupCategoryRepo *repository.GroupCategory,
	pubOperationInfoRepo *repository.PublishOperationInfo,
	mongoRepo entity.DocumentRepository,
	readTimeout time.Duration,
) *GenerateCsv {
	return &GenerateCsv{
		repo:                 repo,
		reviewInfoRepo:       reviewInfoRepo,
		groupCategoryRepo:    groupCategoryRepo,
		pubOperationInfoRepo: pubOperationInfoRepo,
		mongoRepo:            mongoRepo,
		ReadTimeout:          readTimeout,
	}
}

func (gc *GenerateCsv) ListAssetsGroupCategory(
	ctx context.Context,
	project string,
) ([]*entity.GroupPathInfo, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListAssetsGroupCategory(db, project)
}

func (gc *GenerateCsv) ListAllBldReviews(
	ctx context.Context,
	project string,
) ([]*entity.BldComponentReviewInfo, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListAllBldReviews(db, project)
}

func (gc *GenerateCsv) ListComments(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	filterPath := "^shared/publish/assets/[^/]+/[^/]+/(mdl|rig|ldv)/_review"
	commentParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root": "assets",
			"path": bson.M{"$regex": filterPath},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
	}
	comments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "comment", commentParam)
	if err != nil {
		return nil, fmt.Errorf("listComments query failed: %w", err)
	}
	return comments, nil
}

func (gc *GenerateCsv) ListShotAssetsAll(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	shotAssetsAllParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "shots",
			"phase":     "anm",
			"component": "anm",
		},
	}
	shotAssetsAllInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "publishOperationInfo", shotAssetsAllParam)
	if err != nil {
		return nil, fmt.Errorf("listShotAssetsAll query failed: %w", err)
	}
	return shotAssetsAllInfos, nil
}

func (gc *GenerateCsv) ListBldAnmBldRendDocuments(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	bldDocumentsParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "assets",
			"phase":     "bld",
			"component": bson.M{"$in": []string{"bldAnm", "bldRend"}},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
	}
	bldDocuments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "publishOperationInfo", bldDocumentsParam)
	if err != nil {
		return nil, fmt.Errorf("list bldAnm bldRend Documents query failed: %w", err)
	}
	return bldDocuments, nil
}

func (gc *GenerateCsv) ListPublishOperationInfos(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	publishOperationInfoParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "assets",
			"phase":     bson.M{"$in": []string{"mdl", "rig", "ldv"}},
			"component": bson.M{"$regex": "^(mdl|rig|ldv)"},
		},
	}
	publishOperationInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "publishOperationInfo", publishOperationInfoParam)
	if err != nil {
		return nil, fmt.Errorf("list PublishOperationInfos query failed: %w", err)
	}
	return publishOperationInfos, nil
}

func (gc *GenerateCsv) ListLatestAssetsReviews(
	ctx context.Context,
	project string,
) ([]*entity.AssetReviewInfoCsv, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListLatestAssetsReviews(db, project)
}
