package usecase

import (
	"context"
	"net/mail"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type ReviewStatusLog struct {
	repo         *repository.ReviewStatusLog
	prjRepo      *repository.ProjectInfo
	stuRepo      *repository.StudioInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewReviewStatusLog(
	repo *repository.ReviewStatusLog,
	pr *repository.ProjectInfo,
	sr *repository.StudioInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *ReviewStatusLog {
	return &ReviewStatusLog{
		repo:         repo,
		prjRepo:      pr,
		stuRepo:      sr,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *ReviewStatusLog) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	return err
}

func (uc *ReviewStatusLog) checkForStudio(db *gorm.DB, studio string) error {
	_, err := uc.stuRepo.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	})
	return err
}

func (uc *ReviewStatusLog) CheckForReviewStatusesParams(
	params *entity.GetReviewStatusesParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	for _, s := range params.MailAddresses {
		_, err := mail.ParseAddress(s)
		if err != nil {
			return err
		}
	}
	for _, s := range params.MailCCAddresses {
		_, err := mail.ParseAddress(s)
		if err != nil {
			return err
		}
	}
	return nil
}

func (uc *ReviewStatusLog) List(
	ctx context.Context,
	params *entity.ListReviewStatusLogParams,
) ([]*entity.ReviewStatusLog, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, 0, err
	}
	if params.Studio != nil {
		if err := uc.checkForStudio(db, *params.Studio); err != nil {
			return nil, 0, err
		}
	}
	return uc.repo.List(db, params)
}

func (uc *ReviewStatusLog) Get(
	ctx context.Context,
	params *entity.GetReviewParams,
) (*entity.ReviewStatusLog, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}
	return uc.repo.Get(db, params)
}

func (uc *ReviewStatusLog) Create(
	ctx context.Context,
	params *entity.CreateReviewStatusLogParams,
) (*entity.ReviewStatusLog, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}
	if err := uc.checkForStudio(db, params.Studio); err != nil {
		return nil, err
	}
	var e *entity.ReviewStatusLog
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var err error
		e, err = uc.repo.Create(tx, params)
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}
