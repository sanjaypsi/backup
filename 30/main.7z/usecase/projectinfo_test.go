package usecase

import (
	"context"
	"testing"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/testutil"
)

func TestProjectInfoListReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	uc := newProjectInfoUsecase(t)
	f := func(studioKeyName string) ([]*entity.ProjectInfo2, int, error) {
		ctx := context.Background()
		params := entity.ListProjectInfoParams{Studio: studioKeyName}
		return uc.List(ctx, &params)
	}
	testutil.AssertProjectInfoList(t, testDB, f)
}

func TestProjectInfoGetReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	uc := newProjectInfoUsecase(t)
	f := func(projectKeyName string) (*entity.ProjectInfo2, error) {
		ctx := context.Background()
		params := entity.GetProjectInfoParams{KeyName: projectKeyName}
		return uc.Get(ctx, &params)
	}
	testutil.AssertProjectInfoGet(t, testDB, f)
}

func TestProjectInfoCreateReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	uc := newProjectInfoUsecase(t)
	f := func(projectKeyName string) (*entity.ProjectInfo2, error) {
		ctx := context.Background()
		params := entity.CreateProjectInfoParams{KeyName: projectKeyName}
		return uc.Create(ctx, &params)
	}
	testutil.AssertProjectInfoCreate(t, testDB, f)
}

func newProjectInfoUsecase(t *testing.T) *ProjectInfo {
	t.Helper()

	ps, err := repository.NewProjectStudioMap(testDB)
	testutil.AssertNoError(t, err)

	repo, err := repository.NewProjectInfo(testDB, ps)
	testutil.AssertNoError(t, err)

	readTimeout := 1 * time.Second
	writeTimeout := 1 * time.Second
	return NewProjectInfo(repo, readTimeout, writeTimeout)
}
