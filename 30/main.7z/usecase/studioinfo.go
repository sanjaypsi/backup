package usecase

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type StudioInfo struct {
	repo         *repository.StudioInfo
	prjRepo      *repository.ProjectInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewStudioInfo(
	repo *repository.StudioInfo,
	prjRepo *repository.ProjectInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *StudioInfo {
	return &StudioInfo{
		repo:         repo,
		prjRepo:      prjRepo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *StudioInfo) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	if err != nil && errors.Is(err, entity.ErrRecordNotFound) {
		return fmt.Errorf("%w: project %q not found", entity.ErrBadRequest, project)
	}
	return err
}

func (uc *StudioInfo) List(
	ctx context.Context,
	params *entity.ListStudioInfoParams,
) ([]*entity.StudioInfo2, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.List(db, params)
}

func (uc *StudioInfo) Get(
	ctx context.Context,
	params *entity.GetStudioInfoParams,
) (*entity.StudioInfo2, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	return uc.repo.Get(db, params)
}

func (uc *StudioInfo) Create(
	ctx context.Context,
	params *entity.CreateStudioInfoParams,
) (*entity.StudioInfo2, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.Get(db, &entity.GetStudioInfoParams{
		KeyName: params.KeyName,
	}); err == nil {
		return nil, fmt.Errorf(
			"%w: studio with key name %q already exists",
			entity.ErrBadRequest, params.KeyName,
		)
	}

	var e *entity.StudioInfo2
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var err error
		e, err = uc.repo.Create(tx, params)
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *StudioInfo) Update(
	ctx context.Context,
	params *entity.UpdateStudioParams,
) (*entity.StudioInfo2, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	for _, project := range params.Projects {
		if err := uc.checkForProject(db, project); err != nil {
			return nil, err
		}
	}
	if _, err := uc.repo.Get(db, &entity.GetStudioInfoParams{
		KeyName: params.KeyName,
	}); err != nil {
		return nil, err
	}

	var e *entity.StudioInfo2
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		studio, err := uc.repo.Update(tx, params)
		e = studio
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *StudioInfo) Delete(
	ctx context.Context,
	params *entity.DeleteStudioInfoParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if _, err := uc.repo.Get(db, &entity.GetStudioInfoParams{
		KeyName: params.KeyName,
	}); err != nil {
		return err
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.Delete(tx, params)
	})
}
