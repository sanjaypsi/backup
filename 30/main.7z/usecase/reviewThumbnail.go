package usecase

import (
	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
)

type ReviewThumbnail struct {
	repo *repository.ReviewThumbnail
}

func NewReviewThumbnail(
	repo *repository.ReviewThumbnail,
) *ReviewThumbnail {
	return &ReviewThumbnail{
		repo: repo,
	}
}

func (uc *ReviewThumbnail) GetAssetThumbnail(
	params *entity.GetAssetThumbnailParams,
) (string, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return "", err
	}
	thumbnailPath, err := uc.repo.GetAssetThumbnail(params)
	return thumbnailPath, err
}

func (uc *ReviewThumbnail) GetShotThumbnail(
	params *entity.GetShotThumbnailParams,
) (string, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return "", err
	}
	thumbnailPath, err := uc.repo.GetShotThumbnail(params)
	return thumbnailPath, err
}
