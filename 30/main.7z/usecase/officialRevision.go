package usecase

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type OfficialRevision struct {
	repo         *repository.OfficialRevision
	prjRepo      *repository.ProjectInfo
	docRepo      entity.DocumentRepository
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewOfficialRevision(
	repo *repository.OfficialRevision,
	prjRepo *repository.ProjectInfo,
	docRepo entity.DocumentRepository,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *OfficialRevision {
	return &OfficialRevision{
		repo:         repo,
		prjRepo:      prjRepo,
		docRepo:      docRepo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *OfficialRevision) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	if err != nil && errors.Is(err, entity.ErrRecordNotFound) {
		return fmt.Errorf("%w: project %q not found", entity.ErrBadRequest, project)
	}
	return err
}

func (uc *OfficialRevision) List(
	ctx context.Context,
	params *entity.ListOfficialRevisionParams,
) ([]*entity.OfficialRevision, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, 0, err
	}

	entities, total, err := uc.repo.List(db, params)
	if err != nil {
		return nil, 0, err
	}
	return entities, total, nil
}

func (uc *OfficialRevision) ListComposite(
	ctx context.Context,
	params *entity.ListPublishedRevisionDeliveryParams,
) ([]*entity.PublishedRevision, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, 0, err
	}

	docparams := &entity.QueryDocumentsParam{}

	page := 1
	if params.Page != nil {
		page = *params.Page
	}
	docparams.Page = &page

	perPage := 500
	if params.PerPage != nil {
		perPage = *params.PerPage
	}
	docparams.PerPage = &perPage

	if err := docparams.ParseOrderBy("-submitted_at_utc"); err != nil {
		return nil, 0, err
	}

	filters := map[string]interface{}{}
	if params.Root != nil {
		label := "root"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.Root
	}

	if params.Group != nil {
		filters["groups"] = strings.Split(*params.Group, "/")
	}

	if params.Relation != nil {
		label := "relation"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.Relation
	}

	if params.Phase != nil {
		label := "phase"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.Phase
	}

	if params.Component != nil {
		label := "component"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.Component
	}

	if params.Revision != nil {
		label := "revision"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.Revision
	}

	if params.Studio != nil {
		label := "studio"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.Studio
	}

	if params.SubmittedUser != nil {
		label := "submitted_user"
		if params.ExactMatch != nil && strings.Contains(*params.ExactMatch, label) {
			label = label + "_exact"
		}
		filters[label] = *params.SubmittedUser
	}

	docs, total, err := uc.docRepo.GetDocumentsByOfficialRevisionFilters(
		timeoutCtx,
		params.Project,
		"publishOperationInfo",
		docparams,
		&filters,
	)
	if err != nil {
		return nil, 0, err
	}

	cmpparams := &entity.ListPublishedRevisionUsecaseParams{
		Project:      params.Project,
		PublishInfos: docs,
	}

	entities, err := uc.repo.ListComposite(db, cmpparams)
	if err != nil {
		return nil, 0, err
	}
	return entities, total, nil
}

func (uc *OfficialRevision) Upsert(
	ctx context.Context,
	params *entity.UpsertOfficialRevisionDeliveryParams,
) (*entity.OfficialRevision, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}

	filters := map[string]interface{}{
		"root":      params.Root,
		"groups":    strings.Split(params.Group, "/"),
		"relation":  params.Relation,
		"phase":     params.Phase,
		"component": params.Component,
		"revision":  params.Revision,
	}

	docparams := &entity.QueryDocumentsParam{
		Filters: filters,
	}

	docs, _, err := uc.docRepo.GetDocumentsByFields(
		timeoutCtx,
		params.Project,
		"publishOperationInfo",
		docparams,
	)
	if err != nil {
		return nil, err
	}

	if len(docs) > 1 {
		return nil, errors.New("duplicate PublishInfos are found")
	}
	if len(docs) < 1 {
		return nil, fmt.Errorf(
			"%w: no PublishInfos are found",
			entity.ErrRecordNotFound,
		)
	}

	info := docs[0]
	studio, ok := (*info)["studio"].(string)
	if !ok {
		return nil, errors.New("studio is not found")
	}

	user, ok := (*info)["submitted_user"].(string)
	if !ok {
		return nil, errors.New("submitted_user is not found")
	}

	strdate, ok := (*info)["submitted_at_utc"].(string)
	if !ok {
		return nil, errors.New("submitted_at_utc is not found")
	}
	submitdate, err := time.Parse("2006-01-02T15:04:05Z07:00", strdate)
	if err != nil {
		return nil, errors.New("failed to convert submitted_at_utc into time format")
	}

	taskid, ok := (*info)["task_id"].(string)
	if !ok {
		return nil, errors.New("task_id is not found")
	}

	subtaskid, ok := (*info)["subtask_id"].(string)
	if !ok {
		return nil, errors.New("subtask_id is not found")
	}

	ucparams := &entity.UpsertOfficialRevisionUsecaseParams{
		IsOfficial:     *params.IsOfficial,
		Project:        params.Project,
		Root:           params.Root,
		Group:          params.Group,
		Relation:       params.Relation,
		Phase:          params.Phase,
		Component:      params.Component,
		Revision:       params.Revision,
		ModifiedBy:     params.ModifiedBy,
		Studio:         studio,
		SubmittedUser:  user,
		SubmittedAtUTC: submitdate,
		TaskID:         taskid,
		SubtaskID:      subtaskid,
	}

	var e *entity.OfficialRevision
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var err error
		e, err = uc.repo.Upsert(tx, ucparams)
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}
