package usecase

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/groupCategory"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type GroupCategory struct {
	repo         *repository.GroupCategory
	prjRepo      *repository.ProjectInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewGroupCategory(
	repo *repository.GroupCategory,
	prjRepo *repository.ProjectInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *GroupCategory {
	return &GroupCategory{
		repo:         repo,
		prjRepo:      prjRepo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *GroupCategory) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	if err != nil && errors.Is(err, entity.ErrRecordNotFound) {
		return fmt.Errorf("%w: project %q not found", entity.ErrBadRequest, project)
	}
	return err
}

func (uc *GroupCategory) List(
	ctx context.Context,
	params *groupCategory.ListParams,
) ([]groupCategory.Entity, uint, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, 0, err
	}

	entities, total, err := uc.repo.List(db, params)
	if err != nil {
		return nil, 0, err
	}
	return entities, total, nil
}

func (uc *GroupCategory) Get(
	ctx context.Context,
	params *groupCategory.GetParams,
) (*groupCategory.CategoryEntity, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}

	return uc.repo.Get(db, params)
}

func (uc *GroupCategory) Create(
	ctx context.Context,
	params *groupCategory.CreateParams,
) (*groupCategory.CategoryEntity, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}

	var e *groupCategory.CategoryEntity
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		category, err := uc.repo.Create(tx, params)
		e = category
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *GroupCategory) Update(
	ctx context.Context,
	params *groupCategory.UpdateParams,
) (*groupCategory.CategoryEntity, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}

	var e *groupCategory.CategoryEntity
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		category, err := uc.repo.Update(tx, params)
		e = category
		return err
	}); err != nil {
		return nil, err
	}
	return e, nil
}

func (uc *GroupCategory) Delete(
	ctx context.Context,
	params *groupCategory.DeleteParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return err
	}
	if _, err := uc.repo.Get(db, &groupCategory.GetParams{
		Project: params.Project,
		ID:      params.ID,
	}); err != nil {
		if errors.Is(err, entity.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: category with ID %d not found", entity.ErrRecordNotFound, params.ID,
			)
		}
		return err
	}

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		return uc.repo.Delete(tx, params)
	})
}
