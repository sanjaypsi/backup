package usecase

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type Directory struct {
	repo         *repository.Directory
	prjRepo      *repository.ProjectInfo
	stuRepo      *repository.StudioInfo
	ddiRepo      *repository.DirectoryDeletionInfo
	psRepo       *repository.PipelineSetting
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewDirectory(
	repo *repository.Directory,
	prjRepo *repository.ProjectInfo,
	stuRepo *repository.StudioInfo,
	ddiRepo *repository.DirectoryDeletionInfo,
	psRepo *repository.PipelineSetting,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *Directory {
	return &Directory{
		repo:         repo,
		prjRepo:      prjRepo,
		stuRepo:      stuRepo,
		ddiRepo:      ddiRepo,
		psRepo:       psRepo,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *Directory) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	return err
}

func (uc *Directory) checkForStudio(db *gorm.DB, studio string) error {
	_, err := uc.stuRepo.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	})
	return err
}

func (uc *Directory) List(
	ctx context.Context,
	params *entity.ListDirectoryParams,
) ([]*entity.Directory, int, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, 0, err
	}
	return uc.repo.List(db, params)
}

func (uc *Directory) Get(
	ctx context.Context,
	params *entity.GetDirectoryParams,
) (*entity.Directory, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}
	return uc.repo.Get(db, params)
}

// Create will create not only the directories in the given path, but also those of their
// parents if they do not exist, and will return a list of the directories created.
func (uc *Directory) Create(
	ctx context.Context,
	params *entity.CreateDirectoryParams,
) ([]*entity.Directory, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}

	var entities []*entity.Directory
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var paths []string
		parts := strings.Split(params.Path, "/")
		for i := range parts {
			paths = append(paths, strings.Join(parts[:i+1], "/"))
		}
		dirs, _, err := uc.repo.List(tx, &entity.ListDirectoryParams{
			Project: params.Project,
			Paths:   paths,
		})
		if err != nil {
			return err
		}
		dirMap := map[string]string{}
		for _, dir := range dirs {
			dirMap[strings.ToLower(dir.Path)] = dir.Path
		}
		for _, path := range paths {
			if recordedPath, ok := dirMap[strings.ToLower(path)]; ok {
				if recordedPath != path {
					return fmt.Errorf(
						"%w: directory differing with %q only in letter case already exists for project %q",
						entity.ErrBadRequest, params.Path, params.Project,
					)
				}
				continue
			}
			e, err := uc.repo.Create(tx, params.WithPath(path))
			if err != nil {
				// Allow the parent directory to already exist
				if !errors.Is(err, entity.ErrBadRequest) {
					return err
				}
			}
			entities = append(entities, e)
		}
		return nil
	}); err != nil {
		return nil, err
	}
	if len(entities) == 0 {
		return nil, fmt.Errorf(
			"%w: directory with path %q for project %q already exists",
			entity.ErrBadRequest, params.Path, params.Project,
		)
	}
	return entities, nil
}

func getExistRoot(roots []string, target string) (*string, error) {
	for _, root := range roots {
		if root == target {
			return &root, nil
		}
	}
	return nil, entity.ErrBadRequest
}

func (uc *Directory) ValidateGroup(
	ctx context.Context,
	params *entity.ValidateDirectoryParams,
) (*string, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}

	// check if the directory already exists and if the letter case is correct
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var paths []string
		parts := []string{"shared", "publish"}
		parts = append(parts, strings.Split(params.Path, "/")...)
		for i := range parts {
			paths = append(paths, strings.Join(parts[:i+1], "/"))
		}
		dirs, _, err := uc.repo.List(tx, &entity.ListDirectoryParams{
			Project: params.Project,
			Paths:   paths,
		})
		if err != nil {
			return err
		}

		dirMap := map[string]string{}
		for _, dir := range dirs {
			dirMap[strings.ToLower(dir.Path)] = dir.Path
		}
		last := len(paths) - 1
		if _, ok := dirMap[strings.ToLower(paths[last])]; ok {
			return fmt.Errorf(
				"%w: directory with path %q already exists for project %q ",
				entity.ErrBadRequest, params.Path, params.Project,
			)
		}
		for _, path := range paths[:last] {
			if recordedPath, ok := dirMap[strings.ToLower(path)]; ok && recordedPath != path {
				return fmt.Errorf(
					"%w: directory differing with %q only in letter case already exists for project %q",
					entity.ErrBadRequest, params.Path, params.Project,
				)
			}
		}
		return nil
	}); err != nil {
		return nil, err
	}

	// get roots and their depth
	common := "default"
	rootsetting, err := uc.psRepo.GetValue(db, &entity.GetPipelineSettingValueParams{
		Group:     entity.Preference,
		Common:    &common,
		Studio:    &params.Studio,
		Project:   &params.Project,
		Key:       "/ppip/roots",
		Composite: true,
	})
	if err != nil {
		return nil, err
	}

	roots, ok := rootsetting.Value.([]string)
	if !ok {
		return nil, fmt.Errorf(
			"%w: failed to get root directories",
			entity.ErrBadRequest,
		)
	}
	directories := strings.Split(strings.ReplaceAll(params.Path, "\\", "/"), "/")
	root, err := getExistRoot(roots, directories[0])
	if err != nil {
		return nil, fmt.Errorf(
			"%w: invalid root name: %q",
			err,
			directories[0],
		)
	}

	groupsetting, err := uc.psRepo.GetValue(db, &entity.GetPipelineSettingValueParams{
		Group:     entity.Preference,
		Common:    &common,
		Studio:    &params.Studio,
		Project:   &params.Project,
		Key:       "/ppip/roots/" + *root + "/groups",
		Composite: true,
	})
	if err != nil {
		return nil, err
	}
	groups, ok := groupsetting.Value.([]string)
	if !ok {
		return nil, fmt.Errorf(
			"%w: failed to get root's depth",
			entity.ErrBadRequest,
		)
	}
	grplevel := len(groups)
	prmlevel := len(directories[1:])
	if prmlevel > grplevel {
		return nil, fmt.Errorf(
			"%w: group depth %v in request exceeds permitted depth %v",
			entity.ErrBadRequest,
			prmlevel,
			grplevel,
		)
	}

	return &params.Path, nil
}

// DeleteFromProject changes the status of a directory from active to to_delete, and also
// changes the status of any children or grandchildren whose status is active, if any.
func (uc *Directory) DeleteFromProject(
	ctx context.Context,
	params *entity.DeleteDirectoryParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		project, err := uc.prjRepo.Get(tx, &entity.GetProjectInfoParams{
			KeyName: params.Project,
		})
		if err != nil {
			return err
		}
		studios, err := project.Studios(tx)
		if err != nil {
			return err
		}

		dir, err := uc.repo.Get(tx, &entity.GetDirectoryParams{
			Project: params.Project,
			Path:    params.Path,
		})
		if err != nil {
			return entity.ErrRecordNotFound
		}
		dirIDs := []int32{dir.ID}
		pathPrefix := params.Path + "/"
		status := entity.Active
		childDirs, _, err := uc.repo.List(tx, &entity.ListDirectoryParams{
			Project:    params.Project,
			PathPrefix: &pathPrefix,
			Status:     &status,
		})
		if err != nil {
			return entity.ErrRecordNotFound
		}
		for _, child := range childDirs {
			params.ChildPaths = append(params.ChildPaths, child.Path)
			dirIDs = append(dirIDs, child.ID)
		}

		if len(studios) == 0 {
			params.SetDeleted = true
			return uc.repo.Delete(tx, params)
		}

		if err := uc.repo.Delete(tx, params); err != nil {
			return err
		}

		if _, err := uc.ddiRepo.Create(tx, &entity.CreateDirectoryDeletionInfoParams{
			Studios:      studios,
			DirectoryIDs: dirIDs,
			CreatedBy:    params.ModifiedBy,
		}); err != nil {
			return err
		}

		return nil
	})
}

func (uc *Directory) DeleteFromStudio(
	ctx context.Context,
	params *entity.DeleteDirectoryFromStudioParams,
) error {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()

	return uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		if err := uc.checkForProject(tx, params.Project); err != nil {
			return err
		}
		if err := uc.checkForStudio(tx, params.Studio); err != nil {
			return err
		}

		dir, err := uc.repo.Get(tx, &entity.GetDirectoryParams{
			Project: params.Project,
			Path:    params.Path,
		})
		if err != nil {
			return err
		}
		dirIDs := []int32{dir.ID}
		pathPrefix := params.Path + "/"
		status := entity.ToDelete
		childDirs, _, err := uc.repo.List(tx, &entity.ListDirectoryParams{
			Project:    params.Project,
			PathPrefix: &pathPrefix,
			Status:     &status,
		})
		if err != nil {
			return entity.ErrRecordNotFound
		}
		dirIDs = append(dirIDs, dir.ID)
		for _, child := range childDirs {
			dirIDs = append(dirIDs, child.ID)
		}

		if err := uc.ddiRepo.Delete(tx, &entity.DeleteDirectoryDeletionInfoParams{
			Studio:       params.Studio,
			DirectoryIDs: dirIDs,
			ModifiedBy:   params.ModifiedBy,
		}); err != nil {
			return err
		}

		infos, _, err := uc.ddiRepo.List(tx, &entity.ListDirectoryDeletionInfoParams{
			DirectoryIDs: dirIDs,
			Status:       entity.ToDelete,
		})
		if err != nil {
			return err
		}
		infoMap := map[int32]struct{}{}
		for _, info := range infos {
			infoMap[info.DirectoryID] = struct{}{}
		}
		var deletedPaths []string
		if _, ok := infoMap[dir.ID]; !ok {
			deletedPaths = append(deletedPaths, dir.Path)
		}
		for _, childDir := range childDirs {
			if _, ok := infoMap[childDir.ID]; !ok {
				deletedPaths = append(deletedPaths, childDir.Path)
			}
		}
		if len(deletedPaths) != 0 {
			uc.repo.Delete(tx, &entity.DeleteDirectoryParams{
				SetDeleted: true,
				Project:    params.Project,
				Path:       deletedPaths[0],
				ChildPaths: deletedPaths[1:],
				ModifiedBy: params.ModifiedBy,
			})
		}

		return nil
	})
}
