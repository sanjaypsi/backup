package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
)

// DataSyncClient is a representation of usecase that it related PPI
// DataSync Client.
type DataSyncClient struct {
	repo        *repository.DataSyncClient
	ReadTimeout time.Duration
}

// NewDataSyncClient returns a new DataSyncClient usecase.
func NewDataSyncClient(repo *repository.DataSyncClient, readTimeout time.Duration) *DataSyncClient {
	return &DataSyncClient{repo: repo, ReadTimeout: readTimeout}
}

// GetStatus returns a PPI DataSync Client operational status.
func (uc *DataSyncClient) GetStatus(
	ctx context.Context,
	project string,
	studio string,
) (*entity.DataSyncClientStatus, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	return uc.repo.GetStatus(timeoutCtx, project, studio)
}
