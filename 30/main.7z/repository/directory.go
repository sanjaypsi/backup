package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/glebarez/sqlite"
	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
	"gorm.io/hints"
)

// Directory

type Directory struct {
	db *gorm.DB
	gd *GroupDirectory
}

func NewDirectory(db *gorm.DB, gd *GroupDirectory) (*Directory, error) {
	if err := db.AutoMigrate(&model.Directory{}); err != nil {
		return nil, err
	}
	return &Directory{
		db: db,
		gd: gd,
	}, nil
}

func (r *Directory) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *Directory) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *Directory) setDepth1Fast(stmt *gorm.DB) *gorm.DB {
	return stmt.Clauses(
		hints.UseIndex("ix_directory_3"),
	).Where(
		"`path` IN ?", []string{".sys", "shared", "unshared"},
	)
}

func (r *Directory) setDepth2Fast(stmt *gorm.DB) *gorm.DB {
	return stmt.Clauses(
		hints.UseIndex("ix_directory_3"),
	).Where(
		"`path` IN ?", []string{"shared/publish", "shared/tools"},
	)
}

func (r *Directory) setDepth3Fast(stmt *gorm.DB, project string) (*gorm.DB, error) {
	const prefKey = "/ppip/roots"
	var pref *model.PreferenceEntry
	errNoPref := fmt.Errorf("no preference for depth=3 fast: project=%s, key=%s", project, prefKey)

	stmtPref := stmt.Session(&gorm.Session{NewDB: true}).Where(
		"`section_type` = ?", "project",
	).Where(
		"`section_name` = ?", project,
	).Where(
		"`key` = ?", prefKey,
	).Where(
		"`deleted` = ?", 0,
	)

	if result := stmtPref.Take(&pref); errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return stmt, errNoPref
	}

	if pref.Value == nil {
		return stmt, errNoPref
	}

	roots := strings.Split(*pref.Value, ",")
	if len(roots) == 0 {
		return stmt, errNoPref
	}

	rootPaths := []string{}
	for _, root := range roots {
		rootPaths = append(rootPaths, "shared/publish/"+root)
	}

	return stmt.Clauses(
		hints.UseIndex("ix_directory_3"),
	).Where(
		"`path` IN ?", rootPaths,
	), nil
}

func ListWithSQLite(params *entity.ListDirectoryParams) ([]*entity.Directory, int, error) {
	dbPathPrefix := "/mnt/ppip30-data01/datasync30/projects"
	if value, ok := os.LookupEnv("PPI_SQLITE_PATH_PREFIX"); ok {
		dbPathPrefix = value
	}

	dbPath := fmt.Sprintf("%s/%s/.sys/db/directory.ppidb", dbPathPrefix, params.Project)
	db, err := gorm.Open(sqlite.Open(dbPath), &gorm.Config{
		SkipDefaultTransaction: true,
		NamingStrategy: schema.NamingStrategy{
			TablePrefix:   "t_",
			SingularTable: true,
		},
	})
	if err != nil {
		return nil, 0, err
	}

	stmt := db

	if params.Depth != nil {
		stmt = stmt.Where("`depth` = ?", *params.Depth)
	}

	if params.Status != nil {
		stmt = stmt.Where("`status` = ?", (*params.Status).String())
	}

	if params.PathPrefix != nil {
		stmt = stmt.Where("`path` LIKE ?", *params.PathPrefix+"%")

	} else if len(params.Paths) != 0 {
		stmt = stmt.Where("`path` IN ?", params.Paths)
	}

	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
	}

	stmt = stmt.Where("`project` = ?", params.Project)

	var total int64
	if err := stmt.Model(&model.Directory{}).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.Directory
	if err := stmt.Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.Directory
	showDeleted := params.ModifiedSince != nil
	for _, m := range models {
		entities = append(entities, m.Entity(showDeleted))
	}
	return entities, int(total), nil
}

func (r *Directory) List(
	tx *gorm.DB,
	params *entity.ListDirectoryParams,
) ([]*entity.Directory, int, error) {
	if params.SQLite {
		return ListWithSQLite(params)
	}

	stmt := tx.Where(
		"`project` = ?", params.Project,
	)

	// Fast path for depth=1,2,3
	if params.Depth != nil {
		switch *params.Depth {
		case 1:
			stmt = r.setDepth1Fast(stmt)
		case 2:
			stmt = r.setDepth2Fast(stmt)
		case 3:
			var err error
			stmt, err = r.setDepth3Fast(stmt, params.Project)
			if err != nil {
				log.Println(err)
			}
		}
	}

	if params.PathPrefix != nil {
		stmt = stmt.Where("`path` LIKE ?", *params.PathPrefix+"%")

	} else if len(params.Paths) != 0 {
		stmt = stmt.Where("`path` IN ?", params.Paths)
	}

	if params.Status != nil {
		stmt = stmt.Where("`status` = ?", (*params.Status).String())
	}

	if params.Depth != nil {
		stmt = stmt.Where("`depth` = ?", *params.Depth)
	}

	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
	} else {
		stmt = stmt.Where("`deleted` = ?", 0)
	}

	var total int64
	if err := stmt.Model(&model.Directory{}).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.Directory
	if err := stmt.Find(&models).Error; err != nil {
		return nil, 0, err
	}
	var entities []*entity.Directory
	showDeleted := params.ModifiedSince != nil
	for _, m := range models {
		entities = append(entities, m.Entity(showDeleted))
	}
	return entities, int(total), nil
}

func (r *Directory) Get(
	db *gorm.DB,
	params *entity.GetDirectoryParams,
) (*entity.Directory, error) {
	var m model.Directory
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`path` = ?", params.Path,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	return m.Entity(false), nil
}

func (r *Directory) Create(
	tx *gorm.DB,
	params *entity.CreateDirectoryParams,
) (*entity.Directory, error) {
	m := model.NewDirectory(params)
	if err := tx.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: directory with path %q for project %q already exists",
				entity.ErrBadRequest, params.Path, params.Project,
			)
		}
		return nil, err
	}
	return m.Entity(false), nil
}

func (r *Directory) Delete(
	tx *gorm.DB,
	params *entity.DeleteDirectoryParams,
) error {
	now := time.Now().UTC()
	m := &model.Directory{
		Path:          params.Path,
		ModifiedAtUTC: &now,
		ModifiedBy:    params.ModifiedBy,
	}
	paths := []string{m.Path}
	paths = append(paths, params.ChildPaths...)

	conditionStatus := entity.Active
	updates := map[string]interface{}{
		"status":          entity.ToDelete.String(),
		"modified_at_utc": m.ModifiedAtUTC,
		"modified_by":     m.ModifiedBy,
	}
	if params.SetDeleted {
		conditionStatus = entity.ToDelete
		updates["status"] = entity.Deleted.String()
		updates["deleted"] = gorm.Expr("id")
	}

	result := tx.Model(m).Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`path` IN ?", paths,
	).Where(
		"`status` = ?", conditionStatus.String(),
	).Updates(updates)
	if err := result.Error; err != nil {
		return err
	}
	if result.RowsAffected == 0 {
		return entity.ErrRecordNotFound
	}
	return nil
}

// Directory Deletion Info

type DirectoryDeletionInfo struct {
	db *gorm.DB
}

func NewDirectoryDeletionInfo(db *gorm.DB) (*DirectoryDeletionInfo, error) {
	if err := db.AutoMigrate(&model.DirectoryDeletionLog{}); err != nil {
		return nil, err
	}
	return &DirectoryDeletionInfo{
		db: db,
	}, nil
}

func (r *DirectoryDeletionInfo) List(
	tx *gorm.DB,
	params *entity.ListDirectoryDeletionInfoParams,
) ([]*entity.DirectoryDeletionInfo, int, error) {
	m := &model.DirectoryDeletionLog{
		Status: params.Status.String(),
	}
	stmt := tx.Where("`status` = ?", m.Status).Where("`directory_id` IN ?", params.DirectoryIDs)
	if params.Status != entity.Deleted {
		stmt = stmt.Where("`deleted` = ?", 0)
	}

	var total int64
	if err := stmt.Model(m).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var models []*model.DirectoryDeletionLog
	if err := stmt.Find(&models).Error; err != nil {
		return nil, 0, err
	}
	var entities []*entity.DirectoryDeletionInfo
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, int(total), nil
}

func (r *DirectoryDeletionInfo) Create(
	tx *gorm.DB,
	params *entity.CreateDirectoryDeletionInfoParams,
) ([]*entity.DirectoryDeletionInfo, error) {
	models := model.NewDirectoryDeletionLogs(params)
	if err := tx.Create(models).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: directory deletion info on studios %q for IDs %q already exists",
				entity.ErrBadRequest, params.Studios, params.DirectoryIDs,
			)
		}
		return nil, err
	}
	var entities []*entity.DirectoryDeletionInfo
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, nil
}

func (r *DirectoryDeletionInfo) Delete(
	tx *gorm.DB,
	params *entity.DeleteDirectoryDeletionInfoParams,
) error {
	now := time.Now().UTC()
	m := &model.DirectoryDeletionLog{
		Studio:        params.Studio,
		Status:        entity.Deleted.String(),
		ModifiedAtUTC: &now,
		ModifiedBy:    params.ModifiedBy,
	}
	result := tx.Model(m).Where(
		"`deleted` = 0",
	).Where(
		"`directory_id` IN ?", params.DirectoryIDs,
	).Where(
		"`studio` = ?", m.Studio,
	).Where(
		"`status` = ?", entity.ToDelete.String(),
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"status":          m.Status,
		"modified_at_utc": m.ModifiedAtUTC,
		"modified_by":     m.ModifiedBy,
	})
	if err := result.Error; err != nil {
		return err
	}
	if result.RowsAffected == 0 {
		return entity.ErrRecordNotFound
	}
	return nil
}
