package repository

import (
	"errors"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"
)

type ProjectStudioMap struct {
	db *gorm.DB
}

func NewProjectStudioMap(db *gorm.DB) (*ProjectStudioMap, error) {
	if err := db.AutoMigrate(&model.ProjectStudioMap{}); err != nil {
		return nil, err
	}
	return &ProjectStudioMap{
		db: db,
	}, nil
}

func (r *ProjectStudioMap) List(
	tx *gorm.DB,
	params *entity.ListProjectStudioMapParams,
) ([]*entity.ProjectStudioMap, int, error) {
	stmt := tx.Where("`deleted` = ?", 0)
	if params.Project != nil {
		stmt = stmt.Where("`project` = ?", *params.Project)
	}
	if params.Studio != nil {
		stmt = stmt.Where("`studio` = ?", *params.Studio)
	}

	var total int64
	if err := stmt.Model(&model.ProjectStudioMap{}).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var models []*model.ProjectStudioMap
	if err := stmt.Find(&models).Error; err != nil {
		return nil, 0, err
	}
	var entities []*entity.ProjectStudioMap
	for _, m := range models {
		entities = append(entities, m.Entity())
	}

	return entities, int(total), nil
}

func (r *ProjectStudioMap) Create(
	tx *gorm.DB,
	params *entity.CreateProjectStudioMapParams,
) (*entity.ProjectStudioMap, error) {
	m := model.NewProjectStudioMap(params)
	if err := tx.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: project studio map for project %q and studio %q already exists",
				entity.ErrBadRequest, params.Project, params.Studio,
			)
		}
		return nil, err
	}
	return m.Entity(), nil
}

func (r *ProjectStudioMap) Delete(
	tx *gorm.DB,
	params *entity.DeleteProjectStudioMapParams,
) error {
	now := time.Now().UTC()
	m := &model.ProjectStudioMap{
		Project:       params.Project,
		Studio:        params.Studio,
		ModifiedAtUTC: &now,
		ModifiedBy:    params.ModifiedBy,
	}
	result := tx.Model(m).Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", m.Project,
	).Where(
		"`studio` = ?", m.Studio,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": m.ModifiedAtUTC,
		"modified_by":     m.ModifiedBy,
	})
	if err := result.Error; err != nil {
		return err
	}
	if result.RowsAffected == 0 {
		return entity.ErrRecordNotFound
	}
	return nil
}
