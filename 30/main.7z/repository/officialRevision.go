package repository

import (
	"context"
	"database/sql"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"gorm.io/gorm"
)

type OfficialRevision struct {
	db *gorm.DB
}

func NewOfficialRevision(db *gorm.DB) (*OfficialRevision, error) {
	if err := db.AutoMigrate(&model.OfficialRevision{}); err != nil {
		return nil, err
	}
	return &OfficialRevision{
		db: db,
	}, nil
}

func (r *OfficialRevision) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *OfficialRevision) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *OfficialRevision) List(
	db *gorm.DB,
	params *entity.ListOfficialRevisionParams,
) ([]*entity.OfficialRevision, int, error) {
	stmt := db.Where("`project` = ?", params.Project)
	var total int64
	var m model.OfficialRevision

	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.OfficialRevision
	if err := stmt.Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.OfficialRevision
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, int(total), nil
}

func (r *OfficialRevision) ListComposite(
	db *gorm.DB,
	params *entity.ListPublishedRevisionUsecaseParams,
) ([]*entity.PublishedRevision, error) {
	var entities []*entity.PublishedRevision
	for _, info := range params.PublishInfos {
		project, ok := (*info)["project"].(string)
		if !ok {
			continue
		}

		root, ok := (*info)["root"].(string)
		if !ok {
			continue
		}

		rawgrp, ok := (*info)["groups"].(primitive.A)
		if !ok {
			continue
		}
		var slicegrp []string
		for _, group := range []interface{}(rawgrp) {
			strgrp, ok := group.(string)
			if !ok {
				continue
			}
			slicegrp = append(slicegrp, strgrp)
		}
		group := strings.Join(slicegrp, "/")

		relation, ok := (*info)["relation"].(string)
		if !ok {
			continue
		}

		phase, ok := (*info)["phase"].(string)
		if !ok {
			continue
		}

		component, ok := (*info)["component"].(string)
		if !ok {
			continue
		}

		revision, ok := (*info)["revision"].(string)
		if !ok {
			continue
		}

		studio, ok := (*info)["studio"].(string)
		if !ok {
			continue
		}

		submituser, ok := (*info)["submitted_user"].(string)
		if !ok {
			continue
		}

		strdate, ok := (*info)["submitted_at_utc"].(string)
		if !ok {
			continue
		}

		submitdate, err := time.Parse("2006-01-02T15:04:05Z07:00", strdate)
		if err != nil {
			continue
		}

		taskid, ok := (*info)["task_id"].(string)
		if !ok {
			continue
		}

		subtaskid, ok := (*info)["subtask_id"].(string)
		if !ok {
			continue
		}

		e := &entity.PublishedRevision{
			Project:        project,
			Root:           root,
			Group:          group,
			Relation:       relation,
			Phase:          phase,
			Component:      component,
			Revision:       revision,
			Studio:         studio,
			SubmittedUser:  submituser,
			SubmittedAtUTC: submitdate,
			TaskID:         taskid,
			SubtaskID:      subtaskid,
		}
		stmt := db.Where("`project` = ?", project)
		stmt = stmt.Where("`root` = ?", root)
		stmt = stmt.Where("`group` = ?", group)
		stmt = stmt.Where("`relation` = ?", relation)
		stmt = stmt.Where("`phase` = ?", phase)
		stmt = stmt.Where("`component` = ?", component)
		stmt = stmt.Where("`revision` = ?", revision)
		var model model.OfficialRevision
		if err := stmt.Limit(1).Find(&model).Error; err != nil {
			return nil, err
		}
		// substitute zero values if no record returned (i.e. ID = 0, IsOfficial = false)
		e.ID = model.ID
		e.IsOfficial = model.IsOfficial

		e.CreatedBy = model.CreatedBy
		e.ModifiedBy = model.ModifiedBy
		entities = append(entities, e)
	}

	return entities, nil
}

func (r *OfficialRevision) Upsert(
	db *gorm.DB,
	params *entity.UpsertOfficialRevisionUsecaseParams,
) (*entity.OfficialRevision, error) {
	stmt := db.Model(&model.OfficialRevision{}).Where(
		"`project` = ?", params.Project,
	).Where(
		"`root` = ?", params.Root,
	).Where(
		"`group` = ?", params.Group,
	).Where(
		"`relation` = ?", params.Relation,
	).Where(
		"`phase` = ?", params.Phase,
	).Where(
		"`component` = ?", params.Component,
	).Where(
		"`revision` = ?", params.Revision,
	)
	updatemap := model.UpdateOfficialRevision(params)
	updated := stmt.Updates(updatemap)
	if err := updated.Error; err != nil {
		return nil, err
	}

	if updated.RowsAffected == 0 {
		m := model.InsertOfficialRevision(params)
		if err := db.Create(m).Error; err != nil {
			return nil, err
		}
	}

	var result model.OfficialRevision
	if err := stmt.First(&result).Error; err != nil {
		return nil, err
	}
	return result.Entity(), nil
}
