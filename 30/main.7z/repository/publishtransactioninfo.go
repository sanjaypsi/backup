package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"
)

// NewPublishTransactionInfo returns a new PublishTransactionInfo.
func NewPublishTransactionInfo(db *gorm.DB) (*PublishTransactionInfo, error) {
	db.AutoMigrate(&model.PublishTransactionInfo{})
	return &PublishTransactionInfo{
		db: db,
	}, nil
}

// PublishTransactionInfo represents a repository of the publish transaction infos.
type PublishTransactionInfo struct {
	db *gorm.DB
}

func (r *PublishTransactionInfo) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *PublishTransactionInfo) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *PublishTransactionInfo) List(
	stmt *gorm.DB,
	params *entity.ListPublishTransactionInfoParams,
) ([]*entity.PublishTransactionInfo, int, error) {
	if params.Operation != nil {
		stmt = stmt.Where("`operation` = ?", *params.Operation)
	}
	if params.Event != nil {
		stmt = stmt.Where("`event` = ?", *params.Event)
	}
	if params.RevisionPath != nil {
		stmt = stmt.Where("`revision_path` = ?", *params.RevisionPath)
	}

	stmt = stmt.Where("`project` = ?", params.Project).Where("`deleted` = ?", 0)

	opEq := "LIKE"
	pattern := "%%%s%%"
	if params.IsExact {
		opEq = "="
		pattern = "%s"
	}

	if params.Studio != nil {
		stmt = stmt.Where(fmt.Sprintf("`studio` %s ?", opEq), fmt.Sprintf(pattern, *params.Studio))
	}
	if params.Root != nil {
		stmt = stmt.Where(fmt.Sprintf("`root` %s ?", opEq), fmt.Sprintf(pattern, *params.Root))
	}
	if params.Group != nil {
		stmt = stmt.Where(fmt.Sprintf("`groups_path` %s ?", opEq), fmt.Sprintf(pattern, *params.Group))
	}
	if params.Phase != nil {
		stmt = stmt.Where(fmt.Sprintf("`phase` %s ?", opEq), fmt.Sprintf(pattern, *params.Phase))
	}
	if params.Component != nil {
		stmt = stmt.Where(fmt.Sprintf("`component` %s ?", opEq), fmt.Sprintf(pattern, *params.Component))
	}
	if params.User != nil {
		stmt = stmt.Where(fmt.Sprintf("`user` %s ?", opEq), fmt.Sprintf(pattern, *params.User))
	}
	if params.Revision != nil {
		stmt = stmt.Where(fmt.Sprintf("`revision` %s ?", opEq), fmt.Sprintf(pattern, *params.Revision))
	}

	var total int64
	var m model.PublishTransactionInfo
	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var models []*model.PublishTransactionInfo
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Order(
		"`id` desc",
	).Limit(perPage).Offset(offset).Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.PublishTransactionInfo
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, int(total), nil
}

func (r *PublishTransactionInfo) Get(
	db *gorm.DB,
	params *entity.GetPublishTransactionInfoParams,
) (*entity.PublishTransactionInfo, error) {
	var m model.PublishTransactionInfo
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`log_id` = ?", params.LogID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	return m.Entity(), nil
}

func (r *PublishTransactionInfo) Create(
	tx *gorm.DB,
	params *entity.CreatePublishTransactionInfoParams,
) (*entity.PublishTransactionInfo, error) {
	m := model.NewPublishTransactionInfo(params)
	if err := tx.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: publish transaction info with log ID %q for project %q already exists",
				entity.ErrBadRequest, params.LogID, params.Project,
			)
		}
		return nil, err
	}
	return m.Entity(), nil
}

func (r *PublishTransactionInfo) Delete(
	tx *gorm.DB,
	params *entity.DeletePublishTransactionInfoParams,
) error {
	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	var m model.PublishTransactionInfo
	if err := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`log_id` = ?", params.LogID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return entity.ErrRecordNotFound
		}
		return err
	}
	m.Deleted = m.ID
	m.ModifiedAtUTC = now
	m.ModifiedBy = modifiedBy
	return tx.Save(m).Error
}
