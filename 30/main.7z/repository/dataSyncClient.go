package repository

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"cloud.google.com/go/logging"
	"cloud.google.com/go/logging/logadmin"
	"google.golang.org/api/iterator"

	"github.com/PolygonPictures/central30-web/front/entity"
)

// CloudLoggingFinder find Cloud Logging log entries.
type CloudLoggingFinder interface {
	FindOne(ctx context.Context, opts ...logadmin.EntriesOption) (*logging.Entry, error)
}

// ConnectedCloudLoggingFinder implements a CloudLoggingFinder with Cloud
// Logging client.
type ConnectedCloudLoggingFinder struct {
	Client *logadmin.Client
}

// FindOne implements CloudLoggingFinder.FindOne.
func (f ConnectedCloudLoggingFinder) FindOne(
	ctx context.Context,
	opts ...logadmin.EntriesOption,
) (*logging.Entry, error) {
	entry, err := f.Client.Entries(ctx, opts...).Next()
	if err != nil && !errors.Is(err, iterator.Done) {
		return nil, err
	}

	if errors.Is(err, iterator.Done) {
		return nil, entity.ErrLogEntryNotFound
	}

	return entry, nil
}

// DataSyncClient is an object used to retrieve information about PPI
// DataSync Client.
type DataSyncClient struct {
	finder       CloudLoggingFinder
	gcpProjectID string
}

// NewDataSyncClient allocates and returns a new DataSyncClient repository.
func NewDataSyncClient(finder CloudLoggingFinder, gcpProjectID string) *DataSyncClient {
	return &DataSyncClient{finder: finder, gcpProjectID: gcpProjectID}
}

// GetStatus returns a PPI DataSync Client operational status. If the PPI
// DataSync Client is running, the entity.DataSyncClientStatus.Status is
// "healthy", otherwise it is "unhealthy". The value of the
// entity.DataSyncClientStatus.ConfirmedAt is the date and time the status
// was checked.
//
// Operational status is determined by the log of the
// DirectoryDatabaseDownload job for the last hour. Since this job is
// normally executed every minute, it is considered "healthy" if the log is
// output, and "unhealthy" if it is not.
func (r *DataSyncClient) GetStatus(
	ctx context.Context,
	project string,
	studio string,
) (*entity.DataSyncClientStatus, error) {
	conditions := []string{
		fmt.Sprintf(`logName = "projects/%s/logs/ppiDataSyncClient"`, r.gcpProjectID),
		// Search logs for the last hour
		fmt.Sprintf("timestamp >= %q", time.Now().Add(-1*time.Hour).UTC().Format(time.RFC3339)),
		fmt.Sprintf("labels.project=%q", project),
		fmt.Sprintf("labels.studio=%q", studio),
		`labels.job="DirectoryDatabaseDownload"`,
		`jsonPayload.message: "Task done"`,
	}

	filter := logadmin.Filter(strings.Join(conditions, " AND "))
	entry, err := r.finder.FindOne(ctx, filter, logadmin.NewestFirst())
	if err != nil && !errors.Is(err, entity.ErrLogEntryNotFound) {
		return nil, err
	}

	s := &entity.DataSyncClientStatus{Project: project, Studio: studio}

	if errors.Is(err, entity.ErrLogEntryNotFound) {
		s.Status = "unhealthy"
	} else {
		s.Status = "healthy"
		s.ConfirmedAt = &entry.Timestamp
	}

	return s, nil
}
