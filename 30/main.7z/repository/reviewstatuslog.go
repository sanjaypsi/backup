package repository

import (
	"context"
	"database/sql"
	"errors"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"gorm.io/gorm"
)

type ReviewStatusLog struct {
	db *gorm.DB
}

func NewReviewStatusLog(db *gorm.DB) (*ReviewStatusLog, error) {
	statusLog := model.ReviewStatusLog{}

	if err := db.AutoMigrate(&statusLog); err != nil {
		return nil, err
	}

	return &ReviewStatusLog{
		db: db,
	}, nil
}

func (r *ReviewStatusLog) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *ReviewStatusLog) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *ReviewStatusLog) List(
	db *gorm.DB,
	params *entity.ListReviewStatusLogParams,
) ([]*entity.ReviewStatusLog, int, error) {
	stmt := db.Where("`project` = ?", params.Project)
	if params.Studio != nil {
		stmt = stmt.Where("`studio` = ?", *params.Studio)
	}
	if params.UpdateID != nil {
		stmt = stmt.Where("`update_id` = ?", *params.UpdateID)
	}
	if params.ReviewInfoID != nil {
		stmt = stmt.Where("`review_info_id` = ?", *params.ReviewInfoID)
	}
	if params.StatusType != nil {
		stmt = stmt.Where("`status_type` = ?", *params.StatusType)
	}
	for params.Status != nil {
		stmt = stmt.Where("`status` = ?", *params.Status)
	}

	var total int64
	var m model.ReviewStatusLog
	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var models []*model.ReviewStatusLog
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Order(
		"`id` desc",
	).Limit(perPage).Offset(offset).Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.ReviewStatusLog
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, int(total), nil
}

func (r *ReviewStatusLog) Get(
	db *gorm.DB,
	params *entity.GetReviewParams,
) (*entity.ReviewStatusLog, error) {
	var m model.ReviewStatusLog
	if err := db.Where(
		"`project` = ?", params.Project,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	return m.Entity(), nil
}

func (r *ReviewStatusLog) Create(
	tx *gorm.DB,
	params *entity.CreateReviewStatusLogParams,
) (*entity.ReviewStatusLog, error) {
	m := model.NewReviewStatusLog(params)
	if err := tx.Create(m).Error; err != nil {
		return nil, err
	}
	return m.Entity(), nil
}
