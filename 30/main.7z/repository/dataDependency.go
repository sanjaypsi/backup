package repository

import (
	"context"

	"github.com/PolygonPictures/central30-web/front/entity"
	dataDepEntity "github.com/PolygonPictures/central30-web/front/entity/dataDependency"
	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
	"gorm.io/gorm"
)

// DataDepRepository is a repository that manages data dependencies using a Neo4j driver.
type DataDepRepository struct {
	driver neo4j.DriverWithContext
	gormDB *gorm.DB
}

// NewDataDepRepository creates a new instance of DataDepRepository with the provided Neo4j driver.
//
// Parameters:
//   - driver: An instance of neo4j.DriverWithContext to interact with the Neo4j database.
//   - gormDB: An instance of gorm.DB to interact with the MySQL database.
//
// Returns:
//   - A pointer to a newly created DataDepRepository instance.
func NewDataDepRepository(driver neo4j.DriverWithContext, gormDB *gorm.DB) *DataDepRepository {
	return &DataDepRepository{driver: driver, gormDB: gormDB}
}

// WithContext returns a new instance of DataDepRepository with the provided context.
//
// Parameters:
//   - ctx: The context to be used in the new instance.
//
// Returns:
//   - *gorm.DB: A new instance of DataDepRepository with the provided context.
func (r *DataDepRepository) WithContext(ctx context.Context) *gorm.DB {
	return r.gormDB.WithContext(ctx)
}

// executeQuery executes a Neo4j query with the provided parameters and context.
//
// Parameters:
//   - ctx: The context for the query execution.
//   - query: The Cypher query string to be executed.
//   - parameters: A map of parameters to be used in the query.
//
// Returns:
//   - *neo4j.EagerResult: The result of the query execution.
//   - error: An error if the query execution fails.
func (r *DataDepRepository) executeQuery(
	ctx context.Context,
	query string,
	parameters map[string]any,
) (*neo4j.EagerResult, error) {
	return neo4j.ExecuteQuery(
		ctx,
		r.driver,
		query,
		parameters,
		neo4j.EagerResultTransformer,
		neo4j.ExecuteQueryWithDatabase("neo4j"),
	)
}

// ListRoots retrieves the list of root nodes associated with a given project.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project for which to list root nodes.
//
// Returns:
//   - []*dataDepEntity.Root: A slice of root nodes associated with the project.
//   - int: The count of root nodes found.
//   - error: An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListRoots(
	ctx context.Context, lgr entity.Logger, project string,
) ([]*dataDepEntity.Root, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root)
RETURN
	pj.keyName AS project,
	rt.keyName AS keyName,
	rt.createdAt AS createdAt,
	rt.createdBy AS createdBy
`
	result, err := r.executeQuery(ctx, query, map[string]any{
		"project": project,
	})
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a list of roots")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	roots := []*dataDepEntity.Root{}
	for _, record := range result.Records {
		roots = append(roots, dataDepEntity.NewRootFromRecord(record))
	}
	return roots, len(result.Records), nil
}

// GetRoot retrieves the root node associated with a given project and root key name from the
// database.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project to match.
//   - root: The key name of the root to match.
//
// Returns:
//   - A pointer to a dataDepEntity.Root struct containing the root node details if found.
//   - An error if the query execution fails or if no matching root node is found.
func (r *DataDepRepository) GetRoot(
	ctx context.Context, lgr entity.Logger, project, root string,
) (*dataDepEntity.Root, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})
RETURN
	pj.keyName AS project,
	rt.keyName AS keyName,
	rt.createdAt AS createdAt,
	rt.createdBy AS createdBy
LIMIT
	1
`
	parameters := map[string]any{
		"project": project,
		"root":    root,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a root")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewRootFromRecord(result.Records[0]), nil
}

// ListGroups retrieves a list of groups associated with a specific project and root.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project to filter groups.
//   - root: The key name of the root to filter groups.
//
// Returns:
//   - []*dataDepEntity.Group: A slice of Group objects representing the matched groups.
//   - int: The count of matched groups.
//   - error: An error object if an error occurred during the query execution.
func (r *DataDepRepository) ListGroups(
	ctx context.Context, lgr entity.Logger, project, root string,
) ([]*dataDepEntity.Group, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS keyName,
	gp.createdAt AS createdAt,
	gp.createdBy AS createdBy
`
	parameters := map[string]any{
		"project": project,
		"root":    root,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a list of groups")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	groups := []*dataDepEntity.Group{}
	for _, record := range result.Records {
		groups = append(groups, dataDepEntity.NewGroupFromRecord(record))
	}
	return groups, len(result.Records), nil
}

// GetGroup retrieves a group from the database based on the provided project, root, and group keys.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//
// Returns:
//   - *dataDepEntity.Group: The group object if found.
//   - error: An error if the query fails or if the group is not found.
func (r *DataDepRepository) GetGroup(
	ctx context.Context, lgr entity.Logger, project, root, group string,
) (*dataDepEntity.Group, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS keyName,
	gp.createdAt AS createdAt,
	gp.createdBy AS createdBy
LIMIT
	1
`
	parameters := map[string]any{
		"project": project,
		"root":    root,
		"group":   group,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a group")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewGroupFromRecord(result.Records[0]), nil
}

// ListRelations retrieves a list of relations for a given project, root, and group.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project to filter relations.
//   - root: The key name of the root to filter relations.
//   - group: The key name of the group to filter relations.
//
// Returns:
//   - A slice of pointers to dataDepEntity.Relation representing the matched relations.
//   - An integer representing the count of records found.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListRelations(
	ctx context.Context, lgr entity.Logger, project, root, group string,
) ([]*dataDepEntity.Relation, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS keyName,
	rl.createdAt AS createdAt,
	rl.createdBy AS createdBy
`
	parameters := map[string]any{
		"project": project,
		"root":    root,
		"group":   group,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a list of relations")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	relations := []*dataDepEntity.Relation{}
	for _, record := range result.Records {
		relations = append(relations, dataDepEntity.NewRelationFromRecord(record))
	}
	return relations, len(result.Records), nil
}

// GetRelation retrieves a relation from the database based on the provided project, root, group,
// and relation keys.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//
// Returns:
//   - *dataDepEntity.Relation: The relation object if found.
//   - error: An error if the query execution fails or if no matching record is found.
func (r *DataDepRepository) GetRelation(
	ctx context.Context, lgr entity.Logger, project, root, group, relation string,
) (*dataDepEntity.Relation, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS keyName,
	rl.createdAt AS createdAt,
	rl.createdBy AS createdBy
LIMIT
	1
`
	parameters := map[string]any{
		"project":  project,
		"root":     root,
		"group":    group,
		"relation": relation,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a relation")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewRelationFromRecord(result.Records[0]), nil
}

// ListPhaseDirectories retrieves a list of phase directories based on the provided project, root,
// group, and relation.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project node to match.
//   - root: The key name of the root node to match.
//   - group: The key name of the group node to match.
//   - relation: The key name of the relation node to match.
//
// Returns:
//   - A slice of pointers to PhaseDirectory objects that match the query.
//   - The number of records returned by the query.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListPhaseDirectories(
	ctx context.Context, lgr entity.Logger, project, root, group, relation string,
) ([]*dataDepEntity.PhaseDirectory, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS keyName,
	pd.createdAt AS createdAt,
	pd.createdBy AS createdBy
`
	parameters := map[string]any{
		"project":  project,
		"root":     root,
		"group":    group,
		"relation": relation,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of phase directories",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	phases := []*dataDepEntity.PhaseDirectory{}
	for _, record := range result.Records {
		phases = append(phases, dataDepEntity.NewPhaseDirectoryFromRecord(record))
	}
	return phases, len(result.Records), nil
}

// GetPhaseDirectory retrieves a PhaseDirectory node from the database based on the provided
// project, root, group, relation, and phase keys.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project node.
//   - root: The key name of the root node.
//   - group: The key name of the group node.
//   - relation: The key name of the relation node.
//   - phase: The key name of the phase directory node.
//
// Returns:
//   - A pointer to a PhaseDirectory object if found.
//   - An error if the query fails or no matching record is found.
func (r *DataDepRepository) GetPhaseDirectory(
	ctx context.Context, lgr entity.Logger, project, root, group, relation, phase string,
) (*dataDepEntity.PhaseDirectory, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS keyName,
	pd.createdAt AS createdAt,
	pd.createdBy AS createdBy
LIMIT
	1
`
	parameters := map[string]any{
		"project":  project,
		"root":     root,
		"group":    group,
		"relation": relation,
		"phase":    phase,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a phase directory")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewPhaseDirectoryFromRecord(result.Records[0]), nil
}

// ListComponentDirectories retrieves a list of component directories based on the provided
// project, root, group, relation, and phase.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase.
//
// Returns:
//   - A slice of pointers to ComponentDirectory objects.
//   - The number of component directories found.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListComponentDirectories(
	ctx context.Context, lgr entity.Logger, project, root, group, relation, phase string,
) ([]*dataDepEntity.ComponentDirectory, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS keyName,
	cd.createdAt AS createdAt,
	cd.createdBy AS createdBy
`
	parameters := map[string]any{
		"project":  project,
		"root":     root,
		"group":    group,
		"relation": relation,
		"phase":    phase,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of component directories",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	components := []*dataDepEntity.ComponentDirectory{}
	for _, record := range result.Records {
		components = append(components, dataDepEntity.NewComponentDirectoryFromRecord(record))
	}
	return components, len(result.Records), nil
}

// GetComponentDirectory retrieves a ComponentDirectory from the database based on the provided
// project, root, group, relation, phase and component.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase.
//   - component: The key name of the component.
//
// Returns:
//   - *dataDepEntity.ComponentDirectory: The retrieved ComponentDirectory object.
//   - error: An error if the query fails or no matching record is found.
func (r *DataDepRepository) GetComponentDirectory(
	ctx context.Context, lgr entity.Logger, project, root, group, relation, phase, component string,
) (*dataDepEntity.ComponentDirectory, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory {keyName: $component})
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS keyName,
	cd.createdAt AS createdAt,
	cd.createdBy AS createdBy
LIMIT
	1
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a component directory",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewComponentDirectoryFromRecord(result.Records[0]), nil
}

// ListRevisions retrieves a list of revisions based on the provided project, root, group,
// relation, phase and component.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase.
//   - component: The key name of the component.
//
// Returns:
//   - A slice of pointers to dataDepEntity.Revision objects that match the query.
//   - The total number of revisions found.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListRevisions(
	ctx context.Context, lgr entity.Logger, project, root, group, relation, phase, component string,
) ([]*dataDepEntity.Revision, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(rv:Revision)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS keyName,
	rv.createdAt AS createdAt,
	rv.createdBy AS createdBy
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of revisions",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	revisions := []*dataDepEntity.Revision{}
	for _, record := range result.Records {
		revisions = append(revisions, dataDepEntity.NewRevisionFromRecord(record))
	}
	return revisions, len(result.Records), nil
}

// GetRevision retrieves a specific revision of a component within a project hierarchy.
// The hierarchy is defined by project, root, group, relation, phase, component, and revision keys.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase directory.
//   - component: The key name of the component directory.
//   - revision: The key name of the revision.
//
// Returns:
//   - *dataDepEntity.Revision: The retrieved revision object.
//   - error: An error if the operation fails or if the revision is not found.
func (r *DataDepRepository) GetRevision(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision string,
) (*dataDepEntity.Revision, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(rv:Revision {keyName: $revision})
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS keyName,
	rv.createdAt AS createdAt,
	rv.createdBy AS createdBy
LIMIT
	1
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving a revision")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewRevisionFromRecord(result.Records[0]), nil
}

// ListContents retrieves a list of content items based on the specified project, root, group,
// relation, phase, component, and revision.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase directory.
//   - component: The key name of the component directory.
//   - revision: The key name of the revision.
//
// Returns:
//   - A slice of pointers to dataDepEntity.Content representing the matched content items.
//   - An integer representing the number of matched content items.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListContents(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision string,
) ([]*dataDepEntity.Content, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(rv:Revision {keyName: $revision})-[:HAS_CONTENT]->(ct:Content)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS fileName,
	ct.createdAt AS createdAt,
	ct.createdBy AS createdBy
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of content items",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	contents := []*dataDepEntity.Content{}
	for _, record := range result.Records {
		contents = append(contents, dataDepEntity.NewContentFromRecord(record))
	}
	return contents, len(result.Records), nil
}

// GetContent retrieves content information from the database based on the provided project, root,
// group, relation,
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase.
//   - component: The key name of the component.
//   - revision: The key name of the revision.
//   - content: The file name of the content.
//
// Returns:
//   - *dataDepEntity.Content: The content information if found.
//   - error: An error if the query fails or no matching record is found.
func (r *DataDepRepository) GetContent(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) (*dataDepEntity.Content, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory)-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory)-[:HAS_REVISION]->(rv:Revision {keyName: $revision})-[:HAS_CONTENT]->(ct:Content {fileName: $content})
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS fileName,
	ct.createdAt AS createdAt,
	ct.createdBy AS createdBy
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
		"content":   content,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while retrieving content")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(result.Records) == 0 {
		return nil, entity.ErrRecordNotFound
	}
	return dataDepEntity.NewContentFromRecord(result.Records[0]), nil
}

// ListContentFiles retrieves a list of content files based on the provided project, root, group,
// relation, phase, component, revision, and content.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase directory.
//   - component: The key name of the component directory.
//   - revision: The key name of the revision.
//   - content: The file name of the content.
//
// Returns:
//   - A slice of pointers to ContentFile objects that match the query.
//   - The total number of records found.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListContentFiles(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) ([]*dataDepEntity.ContentFile, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(rv:Revision {keyName: $revision})-[:HAS_CONTENT]->(ct:Content {fileName: $content})-[:HAS_CONTENT_FILE]->(cf:ContentFile)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS content,
	cf.filePath AS filePath,
	cf.storageSection AS storageSection,
	cf.createdAt AS createdAt,
	cf.createdBy AS createdBy
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
		"content":   content,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of content files",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	files := []*dataDepEntity.ContentFile{}
	for _, record := range result.Records {
		files = append(files, dataDepEntity.NewContentFileFromRecord(record))
	}
	return files, len(result.Records), nil
}

// ListContentDependencies retrieves a list of content dependencies based on the provided
// parameters.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase directory.
//   - component: The key name of the component directory.
//   - revision: The key name of the revision.
//   - content: The file name of the content.
//
// Returns:
//   - A slice of ContentDependency pointers representing the content dependencies.
//   - An integer representing the number of content dependencies found.
//   - An error if the query execution fails or any other issue occurs.
func (r *DataDepRepository) ListContentDependencies(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) ([]*dataDepEntity.ContentDependency, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(:Root {keyName: $root})-[:HAS_GROUP]->(:Group {keyName: $group})-[:HAS_RELATION]->(:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(:Revision {keyName: $revision})-[:HAS_CONTENT]->(:Content {fileName: $content})-[hd:HAS_DEPENDENCY]->(ct:Content)<-[:HAS_CONTENT]-(rv:Revision)<-[:HAS_REVISION]-(cd:ComponentDirectory)<-[:HAS_COMPONENT_DIRECTORY]-(pd:PhaseDirectory)<-[:HAS_PHASE_DIRECTORY]-(rl:Relation)<-[:HAS_RELATION]-(gp:Group)<-[:HAS_GROUP]-(rt:Root)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS fileName,
	ct.createdAt AS createdAt,
	ct.createdBy AS createdBy,
	hd.strength AS strength
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
		"content":   content,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of content dependencies",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	dependencies := []*dataDepEntity.ContentDependency{}
	for _, record := range result.Records {
		dependencies = append(dependencies, dataDepEntity.NewContentDependencyFromRecord(record))
	}
	return dependencies, len(result.Records), nil
}

// ListContentDependents retrieves a list of content dependencies for a given project, root, group,
// relation, phase, component, revision, and content.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase directory.
//   - component: The key name of the component directory.
//   - revision: The key name of the revision.
//   - content: The file name of the content.
//
// Returns:
//   - A slice of ContentDependency pointers representing the content dependencies.
//   - An integer representing the count of the content dependencies.
//   - An error if any occurs during the query execution.
func (r *DataDepRepository) ListContentDependents(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
) ([]*dataDepEntity.ContentDependency, int, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(:Root {keyName: $root})-[:HAS_GROUP]->(:Group {keyName: $group})-[:HAS_RELATION]->(:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(:Revision {keyName: $revision})-[:HAS_CONTENT]->(:Content {fileName: $content})<-[hd:HAS_DEPENDENCY]-(ct:Content)<-[:HAS_CONTENT]-(rv:Revision)<-[:HAS_REVISION]-(cd:ComponentDirectory)<-[:HAS_COMPONENT_DIRECTORY]-(pd:PhaseDirectory)<-[:HAS_PHASE_DIRECTORY]-(rl:Relation)<-[:HAS_RELATION]-(gp:Group)<-[:HAS_GROUP]-(rt:Root)
RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS fileName,
	ct.createdAt AS createdAt,
	ct.createdBy AS createdBy,
	hd.strength AS strength
`
	parameters := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
		"content":   content,
	}
	result, err := r.executeQuery(ctx, query, parameters)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of content dependents",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, 0, retErr
	}
	dependents := []*dataDepEntity.ContentDependency{}
	for _, record := range result.Records {
		dependents = append(dependents, dataDepEntity.NewContentDependencyFromRecord(record))
	}
	return dependents, len(result.Records), nil
}

// AddContentDependencies adds content and its dependencies to the repository.
// It creates or retrieves the content and then iterates over the provided dependencies, adding
// each one to the repository.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The project identifier.
//   - root: The root identifier.
//   - group: The group identifier.
//   - relation: The relation identifier.
//   - phase: The phase identifier.
//   - component: The component identifier.
//   - revision: The revision identifier.
//   - content: The content to be added.
//   - p: The parameters for adding dependencies, including the dependencies and the user who
//     created them.
//
// Returns:
//   - *ContentAndDependenciesWithFile: The content and its dependencies with associated files.
//   - error: An error if the operation fails.
func (r *DataDepRepository) AddContentDependencies(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
	p *dataDepEntity.AddContentDependenciesParams,
) (*dataDepEntity.ContentAndDependenciesWithFile, error) {
	dependencies := []*dataDepEntity.ContentDependencyWithFile{}
	ct, err := r.createContent(
		ctx, lgr, project, root, group, relation, phase, component, revision, content, p.CreatedBy,
	)
	if err != nil {
		return nil, err
	}
	for _, dep := range p.Dependencies {
		cd, cf, err := r.addDependency(
			ctx, lgr, project, root, group, relation, phase, component, revision, content, dep, p.CreatedBy,
		)
		if err != nil {
			return nil, err
		}
		dependencies = append(dependencies, &dataDepEntity.ContentDependencyWithFile{
			ContentDependency: cd,
			ContentFile:       cf,
		})
	}
	return &dataDepEntity.ContentAndDependenciesWithFile{
		Content:      ct,
		Dependencies: dependencies,
	}, nil
}

// createContent creates a new content node in the database with the provided parameters.
// If any of these nodes do not exist, they are created.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The key name of the project.
//   - root: The key name of the root.
//   - group: The key name of the group.
//   - relation: The key name of the relation.
//   - phase: The key name of the phase directory.
//   - component: The key name of the component directory.
//   - revision: The key name of the revision.
//   - content: The file name of the content.
//   - createdBy: The user who created the content.
//
// Returns:
//   - *dataDepEntity.Content: The created content.
//   - error: An error if the operation fails.
func (r *DataDepRepository) createContent(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
	createdBy *string,
) (*dataDepEntity.Content, error) {
	query := `
// Project

MERGE
	(pj:Project {keyName: $project})
ON CREATE
	SET
		pj.createdAt = datetime(),
		pj.createdBy = $createdBy

// Root

MERGE
	(rt:Root {keyName: $root, projectID: id(pj)})
ON CREATE
    SET
		rt.createdAt = datetime(),
		rt.createdBy = $createdBy
MERGE
	(pj)-[:HAS_ROOT]->(rt)

// Group

MERGE
	(gp:Group {keyName: $group, rootID: id(rt)})
ON CREATE
	SET
		gp.createdAt = datetime(),
		gp.createdBy = $createdBy
MERGE
	(rt)-[:HAS_GROUP]->(gp)

// Relation

MERGE
	(rl:Relation {keyName: $relation, groupID: id(gp)})
ON CREATE
	SET
		rl.createdAt = datetime(),
		rl.createdBy = $createdBy
MERGE
	(gp)-[:HAS_RELATION]->(rl)

// PhaseDirectory

MERGE
	(pd:PhaseDirectory {keyName: $phase, relationID: id(rl)})
ON CREATE
	SET
		pd.createdAt = datetime(),
		pd.createdBy = $createdBy
MERGE
	(rl)-[:HAS_PHASE_DIRECTORY]->(pd)

// ComponentDirectory

MERGE
	(cd:ComponentDirectory {keyName: $component, phaseDirectoryID: id(pd)})
ON CREATE
	SET
		cd.createdAt = datetime(),
		cd.createdBy = $createdBy
MERGE
	(pd)-[:HAS_COMPONENT_DIRECTORY]->(cd)

// Revision

MERGE
	(rv:Revision {keyName: $revision, componentDirectoryID: id(cd)})
ON CREATE
	SET
		rv.createdAt = datetime(),
		rv.createdBy = $createdBy
MERGE
	(cd)-[:HAS_REVISION]->(rv)

// Content

MERGE
	(ct:Content {fileName: $content, revisionID: id(rv)})
ON CREATE
	SET
		ct.createdAt = datetime(),
		ct.createdBy = $createdBy
MERGE
	(rv)-[:HAS_CONTENT]->(ct)

// Return

RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS fileName,
	ct.createdAt AS createdAt,
	ct.createdBy AS createdBy
`
	args := map[string]any{
		"project":   project,
		"root":      root,
		"group":     group,
		"relation":  relation,
		"phase":     phase,
		"component": component,
		"revision":  revision,
		"content":   content,
		"createdBy": createdBy,
	}

	res, err := r.executeQuery(ctx, query, args)

	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while creating content")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}

	if len(res.Records) == 0 {
		retErr := entity.NewInternalServerError("failed to create content")
		lgr.Error(retErr.Error())
		return nil, retErr
	}

	rec := res.Records[0]
	return dataDepEntity.NewContentFromRecord(rec), nil
}

// addDependency adds a new dependency to the repository.
// It creates a dependency content and a content file.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The project identifier.
//   - root: The root identifier.
//   - group: The group identifier.
//   - relation: The relation identifier.
//   - phase: The phase identifier.
//   - component: The component identifier.
//   - revision: The revision identifier.
//   - content: The content of the dependency.
//   - dep: The dependency object to be added.
//   - createdBy: The identifier of the user who created the dependency.
//
// Returns:
//   - *dataDepEntity.ContentDependency: The created dependency content.
//   - *dataDepEntity.ContentFile: The created content file.
//   - error: Any error encountered during the operation.
func (r *DataDepRepository) addDependency(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
	dep *dataDepEntity.Dependency,
	createdBy *string,
) (*dataDepEntity.ContentDependency, *dataDepEntity.ContentFile, error) {
	dc, err := r.createDependencyContent(
		ctx, lgr, project, root, group, relation, phase, component, revision, content, dep, createdBy,
	)
	if err != nil {
		return nil, nil, err
	}
	file, err := r.createContentFile(ctx, lgr, project, dep, createdBy)
	if err != nil {
		return nil, nil, err
	}
	return dc, file, nil
}

// createContentFile creates a new content file based on the provided project and data dependency
// details.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The project key name.
//   - dep: A pointer to a dataDepEntity.Dependency struct containing dependency details.
//   - createdBy: A pointer to a string representing the user who created the content file.
//
// Returns:
//   - A pointer to a dataDepEntity.ContentFile struct representing the created content file.
//   - An error if the operation fails.
func (r *DataDepRepository) createContentFile(
	ctx context.Context,
	lgr entity.Logger,
	project string,
	dep *dataDepEntity.Dependency,
	createdBy *string,
) (*dataDepEntity.ContentFile, error) {
	query := `
MATCH
	(pj:Project {keyName: $project})-[:HAS_ROOT]->(rt:Root {keyName: $root})-[:HAS_GROUP]->(gp:Group {keyName: $group})-[:HAS_RELATION]->(rl:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(pd:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(cd:ComponentDirectory)-[:HAS_REVISION]->(rv:Revision {keyName: $revision})-[:HAS_CONTENT]->(ct:Content {fileName: $content})

// ContentFile

MERGE
	(cf:ContentFile {filePath: $filePath, contentID: id(ct)})
ON CREATE
	SET
		cf.createdAt = datetime(),
		cf.createdBy = $createdBy,
		cf.storageSection = $storageSection
MERGE
	(ct)-[:HAS_CONTENT_FILE]->(cf)

// Return

RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	ct.fileName AS content,
	cf.filePath AS filePath,
	cf.storageSection AS storageSection,
	cf.createdAt AS createdAt,
	cf.createdBy AS createdBy
`
	args := map[string]any{
		"project":        project,
		"root":           dep.Root,
		"group":          dep.Group,
		"relation":       dep.Relation,
		"phase":          dep.Phase,
		"component":      dep.Component,
		"revision":       dep.Revision,
		"content":        dep.FileName,
		"filePath":       dep.FilePath,
		"storageSection": dep.StorageSection,
		"createdBy":      createdBy,
	}
	res, err := r.executeQuery(ctx, query, args)
	if err != nil {
		retErr := entity.NewBadGatewayError("a problem occurred while creating a content file")
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(res.Records) == 0 {
		retErr := entity.NewInternalServerError("failed to create content file")
		lgr.Error(retErr.Error())
		return nil, retErr
	}
	rec := res.Records[0]
	return dataDepEntity.NewContentFileFromRecord(rec), nil
}

// createDependencyContent creates a new content dependency in the database.
//
// Parameters:
//   - ctx: The context for controlling the request lifetime.
//   - lgr: The logger for logging errors and other messages.
//   - project: The project key name.
//   - root: The root key name.
//   - group: The group key name.
//   - relation: The relation key name.
//   - phase: The phase directory key name.
//   - component: The component directory key name.
//   - revision: The revision key name.
//   - content: The content file name.
//   - dep: A pointer to a dataDepEntity.Dependency struct containing the dependency details.
//   - createdBy: A pointer to a string representing the creator of the dependency.
//
// Returns:
//   - A pointer to a dataDepEntity.ContentDependency struct.
//   - An error if any occurred during the operation.
func (r *DataDepRepository) createDependencyContent(
	ctx context.Context,
	lgr entity.Logger,
	project, root, group, relation, phase, component, revision, content string,
	dep *dataDepEntity.Dependency,
	createdBy *string,
) (*dataDepEntity.ContentDependency, error) {
	query := `
// Dependent Content

MATCH
	(:Project {keyName: $project})-[:HAS_ROOT]->(:Root {keyName: $root})-[:HAS_GROUP]->(:Group {keyName: $group})-[:HAS_RELATION]->(:Relation {keyName: $relation})-[:HAS_PHASE_DIRECTORY]->(:PhaseDirectory {keyName: $phase})-[:HAS_COMPONENT_DIRECTORY]->(:ComponentDirectory {keyName: $component})-[:HAS_REVISION]->(:Revision {keyName: $revision})-[:HAS_CONTENT]->(ct:Content {fileName: $content})

// Project

MERGE
	(pj:Project {keyName: $project})
ON CREATE
	SET
		pj.createdAt = datetime(),
		pj.createdBy = $createdBy

// Root

MERGE
	(rt:Root {keyName: $depRoot, projectID: id(pj)})
ON CREATE
    SET
		rt.createdAt = datetime(),
		rt.createdBy = $createdBy
MERGE
	(pj)-[:HAS_ROOT]->(rt)

// Group

MERGE
	(gp:Group {keyName: $depGroup, rootID: id(rt)})
ON CREATE
	SET
		gp.createdAt = datetime(),
		gp.createdBy = $createdBy
MERGE
	(rt)-[:HAS_GROUP]->(gp)

// Relation

MERGE
	(rl:Relation {keyName: $depRelation, groupID: id(gp)})
ON CREATE
	SET
		rl.createdAt = datetime(),
		rl.createdBy = $createdBy
MERGE
	(gp)-[:HAS_RELATION]->(rl)

// PhaseDirectory

MERGE
	(pd:PhaseDirectory {keyName: $depPhase, relationID: id(rl)})
ON CREATE
	SET
		pd.createdAt = datetime(),
		pd.createdBy = $createdBy
MERGE
	(rl)-[:HAS_PHASE_DIRECTORY]->(pd)

// ComponentDirectory

MERGE
	(cd:ComponentDirectory {keyName: $depComponent, phaseID: id(pd)})
ON CREATE
	SET
		cd.createdAt = datetime(),
		cd.createdBy = $createdBy
MERGE
	(pd)-[:HAS_COMPONENT_DIRECTORY]->(cd)

// Revision

MERGE
	(rv:Revision {keyName: $depRevision, componentID: id(cd)})
ON CREATE
	SET
		rv.createdAt = datetime(),
		rv.createdBy = $createdBy
MERGE
	(cd)-[:HAS_REVISION]->(rv)

// Dependency Content

MERGE
	(dc:Content {fileName: $depContent, revisionID: id(rv)})
ON CREATE
	SET
		dc.createdAt = datetime(),
		dc.createdBy = $createdBy
MERGE
	(rv)-[:HAS_CONTENT]->(dc)

// Dependency Association

MERGE
	(ct)-[hd:HAS_DEPENDENCY]->(dc)
ON CREATE
	SET
		hd.strength = $strength

// Return

RETURN
	pj.keyName AS project,
	rt.keyName AS root,
	gp.keyName AS group,
	rl.keyName AS relation,
	pd.keyName AS phase,
	cd.keyName AS component,
	rv.keyName AS revision,
	dc.fileName AS fileName,
	dc.createdAt AS createdAt,
	dc.createdBy AS createdBy,
	hd.strength AS strength
`
	args := map[string]any{
		"project":      project,
		"root":         root,
		"group":        group,
		"relation":     relation,
		"phase":        phase,
		"component":    component,
		"revision":     revision,
		"content":      content,
		"depRoot":      dep.Root,
		"depGroup":     dep.Group,
		"depRelation":  dep.Relation,
		"depPhase":     dep.Phase,
		"depComponent": dep.Component,
		"depRevision":  dep.Revision,
		"depContent":   dep.FileName,
		"strength":     dep.Strength,
		"createdBy":    createdBy,
	}
	// log.Println(query, args)
	res, err := r.executeQuery(ctx, query, args)
	if err != nil {
		retErr := entity.NewBadGatewayError(
			"a problem occurred while creating a dependency content",
		)
		lgr.Errorf("%v:%v", retErr, err)
		return nil, retErr
	}
	if len(res.Records) == 0 {
		retErr := entity.NewInternalServerError("failed to create dependency content")
		lgr.Error(retErr.Error())
		return nil, retErr
	}
	rec := res.Records[0]
	return dataDepEntity.NewContentDependencyFromRecord(rec), nil
}
