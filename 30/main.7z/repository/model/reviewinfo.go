package model

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
)

type Comments []*libs.CommentInfo

func (Comments) GormDataType() string {
	return "json"
}

func (c Comments) Value() (driver.Value, error) {
	return json.Marshal(c)
}

func (c *Comments) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("failed to scan Comments: %v", value)
	}
	return json.Unmarshal(bytes, c)
}

type Groups []string

func (Groups) GormDataType() string {
	return "json"
}

func (g Groups) Value() (driver.Value, error) {
	return json.Marshal(g)
}

func (g *Groups) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("failed to scan Groups: %v", value)
	}
	return json.Unmarshal(bytes, g)
}

type Contents []*libs.Content

func (Contents) GormDataType() string {
	return "json"
}

func (c Contents) Value() (driver.Value, error) {
	return json.Marshal(c)
}

func (c *Contents) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("failed to scan Contents: %v", value)
	}
	return json.Unmarshal(bytes, c)
}

type Files []*libs.File

func (Files) GormDataType() string {
	return "json"
}

func (a Files) Value() (driver.Value, error) {
	return json.Marshal(a)
}

func (a *Files) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("failed to scan Files: %v", value)
	}
	return json.Unmarshal(bytes, a)
}

type Components []string

func (Components) GormDataType() string {
	return "json"
}

func (c Components) Value() (driver.Value, error) {
	return json.Marshal(c)
}

func (c *Components) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("failed to scan Components: %v", value)
	}
	return json.Unmarshal(bytes, c)
}

// https://docs.google.com/spreadsheets/d/1TNE-T0G45t9G8dM6dduuYx_T07B0TePh9OqdqzRTEPg/edit?usp=sharing
// Specification change: https://jira.ppi.co.jp/browse/POTOO-2406
// Specification change: https://jira.ppi.co.jp/browse/POTOO-2594
// Specification change: https://jira.ppi.co.jp/browse/POTOO-2666
type ReviewInfo struct {
	TaskID                     string     `gorm:"size:36;not null;index:ix_review_info_4"`
	SubtaskID                  string     `gorm:"size:36;not null;index:ix_review_info_3"`
	Studio                     string     `gorm:"size:30;not null"`
	Project                    string     `gorm:"size:30;not null;index:ix_review_info_1;index:ix_review_info_2;index:ix_review_info_3;index:ix_review_info_4;index:ix_review_info_5"`
	ProjectPath                string     `gorm:"size:1000"`
	ReviewComments             Comments   `gorm:"not null"`
	TakePath                   string     `gorm:"size:1000;not null;index:ix_review_info_2,length:255"`
	Root                       string     `gorm:"size:30;not null;index:ix_review_info_1"`
	Groups                     Groups     `gorm:"not null"`
	Group1                     string     "gorm:\"column:group_1;->;-:migration;type:VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`groups`, '$[0]')));default:(-);index:ix_review_info_1\""
	Group2                     string     "gorm:\"column:group_2;->;-:migration;type:VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`groups`, '$[1]')));default:(-);\""
	Group3                     string     "gorm:\"column:group_3;->;-:migration;type:VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`groups`, '$[2]')));default:(-);\""
	Group4                     string     "gorm:\"column:group_4;->;-:migration;type:VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`groups`, '$[3]')));default:(-);\""
	Group5                     string     "gorm:\"column:group_5;->;-:migration;type:VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`groups`, '$[4]')));default:(-);\""
	Relation                   string     `gorm:"size:100;not null;index:ix_review_info_1"`
	Phase                      string     `gorm:"size:100;not null;index:ix_review_info_1"`
	Component                  string     `gorm:"size:100;not null"`
	Take                       string     `gorm:"size:30;not null"`
	ApprovalStatus             string     `gorm:"size:20;not null"`
	ApprovalStatusUpdatedUser  string     `gorm:"size:100;not null"`
	ApprovalStatusUpdatedAtUtc time.Time  `gorm:"type:datetime(6);not null"`
	WorkStatus                 string     `gorm:"size:20;not null"`
	WorkStatusUpdatedUser      string     `gorm:"size:100;not null"`
	WorkStatusUpdatedAtUtc     time.Time  `gorm:"type:datetime(6);not null"`
	ReviewTarget               Contents   `gorm:"not null"`
	ReviewData                 Contents   `gorm:"not null"`
	OutputContents             Contents   ``
	SubmittedAtUtc             time.Time  `gorm:"type:datetime(6);not null"`
	SubmittedComputer          string     `gorm:"size:30;not null"`
	SubmittedOS                string     `gorm:"size:3;not null"`
	SubmittedOSVersion         string     `gorm:"size:1000;not null"`
	SubmittedUser              string     `gorm:"size:100;not null"`
	ExecutedAtUtc              time.Time  `gorm:"type:datetime(6);not null"`
	ExecutedComputer           string     `gorm:"size:30;not null"`
	ExecutedOS                 string     `gorm:"size:3;not null"`
	ExecutedOSVersion          string     `gorm:"size:1000;not null"`
	ExecutedUser               string     `gorm:"size:100;not null"`
	AllFiles                   Files      ``
	NumAllFiles                uint32     `gorm:"not null;default:0"`
	SizeAllFiles               uint64     `gorm:"not null;default:0"`
	TargetComponents           Components ``

	Duration                    *int32  ``
	DurationTimeline            *string `gorm:"size:100"`
	ExportShotsVersions         *bool   ``
	ExportShotsVersionsRevision *string `gorm:"size:100"`
	ExportShotsVersionsPath     *string `gorm:"size:1000"`

	CreatedAtUTC  time.Time `gorm:"type:datetime(6) not null"`
	ModifiedAtUTC time.Time `gorm:"type:datetime(6) not null;index:ix_review_info_5"`
	Deleted       int32     `gorm:"not null;default:0;index:ix_review_info_1;index:ix_review_info_2;index:ix_review_info_3;index:ix_review_info_4"`
	ModifiedBy    string    `gorm:"size:100;not null"`
	CreatedBy     string    `gorm:"size:100;not null"`
	ID            int32     `gorm:"primaryKey;autoIncrement;not null"`
}

func NewReviewInfo(
	p *entity.CreateReviewInfoParams,
) *ReviewInfo {
	now := time.Now().UTC()
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	return &ReviewInfo{
		TaskID:                     p.TaskID,
		SubtaskID:                  p.SubtaskID,
		Studio:                     p.Studio,
		Project:                    p.Project,
		ProjectPath:                p.ProjectPath,
		ReviewComments:             p.ReviewComments,
		TakePath:                   p.TakePath,
		Root:                       p.Root,
		Groups:                     p.Groups,
		Relation:                   p.Relation,
		Phase:                      p.Phase,
		Component:                  p.Component,
		Take:                       p.Take,
		ApprovalStatus:             p.ApprovalStatus,
		ApprovalStatusUpdatedUser:  p.ApprovalStatusUpdatedUser,
		ApprovalStatusUpdatedAtUtc: now,
		WorkStatus:                 p.WorkStatus,
		WorkStatusUpdatedUser:      p.WorkStatusUpdatedUser,
		WorkStatusUpdatedAtUtc:     now,
		ReviewTarget:               p.ReviewTarget,
		ReviewData:                 p.ReviewData,
		OutputContents:             p.OutputContents,
		SubmittedAtUtc:             p.SubmittedAtUtc,
		SubmittedComputer:          p.SubmittedComputer,
		SubmittedOS:                p.SubmittedOS,
		SubmittedOSVersion:         p.SubmittedOSVersion,
		SubmittedUser:              p.SubmittedUser,
		ExecutedAtUtc:              p.ExecutedAtUtc,
		ExecutedComputer:           p.ExecutedComputer,
		ExecutedOS:                 p.ExecutedOS,
		ExecutedOSVersion:          p.ExecutedOSVersion,
		ExecutedUser:               p.ExecutedUser,
		AllFiles:                   p.AllFiles,
		NumAllFiles:                p.NumAllFiles,
		SizeAllFiles:               p.SizeAllFiles,
		TargetComponents:           p.TargetComponents,

		Duration:                    p.Duration,
		DurationTimeline:            p.DurationTimeline,
		ExportShotsVersions:         p.ExportShotsVersions,
		ExportShotsVersionsRevision: p.ExportShotsVersionsRevision,
		ExportShotsVersionsPath:     p.ExportShotsVersionsPath,

		CreatedAtUTC:  now,
		ModifiedAtUTC: now,
		ModifiedBy:    createdBy,
		CreatedBy:     createdBy,
	}
}

func (m *ReviewInfo) Entity(showDeleted bool) *entity.ReviewInfo {
	e := &entity.ReviewInfo{
		TaskID:                     m.TaskID,
		SubtaskID:                  m.SubtaskID,
		Studio:                     m.Studio,
		Project:                    m.Project,
		ProjectPath:                m.ProjectPath,
		ReviewComments:             m.ReviewComments,
		Path:                       m.TakePath, // TODO: Remove the "Path" property after the tool migration is complete
		TakePath:                   m.TakePath,
		Root:                       m.Root,
		Groups:                     m.Groups,
		Relation:                   m.Relation,
		Phase:                      m.Phase,
		Component:                  m.Component,
		Take:                       m.Take,
		ApprovalStatus:             m.ApprovalStatus,
		ApprovalStatusUpdatedUser:  m.ApprovalStatusUpdatedUser,
		ApprovalStatusUpdatedAtUtc: m.ApprovalStatusUpdatedAtUtc,
		WorkStatus:                 m.WorkStatus,
		WorkStatusUpdatedUser:      m.WorkStatusUpdatedUser,
		WorkStatusUpdatedAtUtc:     m.WorkStatusUpdatedAtUtc,
		ReviewTarget:               []*libs.Content(m.ReviewTarget),
		ReviewData:                 []*libs.Content(m.ReviewData),
		OutputContents:             []*libs.Content(m.OutputContents),
		SubmittedAtUtc:             m.SubmittedAtUtc,
		SubmittedComputer:          m.SubmittedComputer,
		SubmittedOS:                m.SubmittedOS,
		SubmittedOSVersion:         m.SubmittedOSVersion,
		SubmittedUser:              m.SubmittedUser,
		ExecutedAtUtc:              m.ExecutedAtUtc,
		ExecutedComputer:           m.ExecutedComputer,
		ExecutedOS:                 m.ExecutedOS,
		ExecutedOSVersion:          m.ExecutedOSVersion,
		ExecutedUser:               m.ExecutedUser,
		AllFiles:                   []*libs.File(m.AllFiles),
		NumAllFiles:                m.NumAllFiles,
		SizeAllFiles:               m.SizeAllFiles,
		TargetComponents:           []string(m.TargetComponents),

		Duration:                    m.Duration,
		DurationTimeline:            m.DurationTimeline,
		ExportShotsVersions:         m.ExportShotsVersions,
		ExportShotsVersionsRevision: m.ExportShotsVersionsRevision,
		ExportShotsVersionsPath:     m.ExportShotsVersionsPath,

		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		CreatedBy:     m.CreatedBy,
		ID:            m.ID,
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}

	return e
}
