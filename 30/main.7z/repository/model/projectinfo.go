package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type ProjectInfo struct {
	KeyName       string     `gorm:"column:name;size:30;not null;uniqueIndex:uix_project_info_1"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:uix_project_info_1"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey;not null;autoIncrement"`
}

func NewProjectInfo(p *entity.CreateProjectInfoParams) *ProjectInfo {
	now := time.Now().UTC()
	return &ProjectInfo{
		KeyName:       p.KeyName,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    p.CreatedBy,
		CreatedBy:     p.CreatedBy,
	}
}

func (m *ProjectInfo) Entity(
	repo entity.ProjectStudioMapRepository,
) *entity.ProjectInfo2 {
	return &entity.ProjectInfo2{
		KeyName:       m.KeyName,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		CreatedBy:     m.CreatedBy,
		ID:            m.ID,
		Repo:          repo,
	}
}
