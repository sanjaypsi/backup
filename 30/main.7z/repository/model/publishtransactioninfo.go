package model

import (
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

// PublishTransactionInfo represents a publish transaction info record.
// https://docs.google.com/spreadsheets/d/1e1sRqDbdOddLhShjrdwxNO_CDrgeCS1ZDTbfrHiXroc/edit?usp=sharing
type PublishTransactionInfo struct {
	LogID          string         `gorm:"size:36;not null;uniqueIndex:uix_publish_transaction_info_1"`
	TaskID         string         `gorm:"size:36;not null;index:ix_publish_transaction_info_3"`
	SubtaskID      string         `gorm:"size:36;not null;index:ix_publish_transaction_info_4"`
	Operation      string         `gorm:"size:30;not null;index:ix_publish_transaction_info_2;index:ix_publish_transaction_info_studio;index:ix_publish_transaction_info_root;index:ix_publish_transaction_info_groups;index:ix_publish_transaction_info_phase;index:ix_publish_transaction_info_component;index:ix_publish_transaction_info_revision;index:ix_publish_transaction_info_user;"`
	Event          string         `gorm:"size:30;not null;index:ix_publish_transaction_info_2;index:ix_publish_transaction_info_studio;index:ix_publish_transaction_info_root;index:ix_publish_transaction_info_groups;index:ix_publish_transaction_info_phase;index:ix_publish_transaction_info_component;index:ix_publish_transaction_info_revision;index:ix_publish_transaction_info_user;"`
	Studio         string         `gorm:"size:30;not null;index:ix_publish_transaction_info_studio,priority:11;"`
	Project        string         `gorm:"size:30;not null;uniqueIndex:uix_publish_transaction_info_1;index:ix_publish_transaction_info_2;index:ix_publish_transaction_info_3;index:ix_publish_transaction_info_4;index:ix_publish_transaction_info_5;index:ix_publish_transaction_info_studio;index:ix_publish_transaction_info_root;index:ix_publish_transaction_info_groups;index:ix_publish_transaction_info_phase;index:ix_publish_transaction_info_component;index:ix_publish_transaction_info_revision;index:ix_publish_transaction_info_user;"`
	ProjectPath    string         `gorm:"size:1000;not null"`
	RevisionPath   string         `gorm:"size:1000;not null;index:ix_publish_transaction_info_5,length:255;"`
	Root           *string        `gorm:"size:30;index:ix_publish_transaction_info_root,priority:11;"`
	GroupsPath     *string        `gorm:"size:1000;index:ix_publish_transaction_info_groups,length:255,priority:11;"`
	Relation       *string        `gorm:"size:100;"`
	Phase          *string        `gorm:"size:100;index:ix_publish_transaction_info_phase,priority:11;"`
	Component      *string        `gorm:"size:100;index:ix_publish_transaction_info_component,priority:11;"`
	Revision       *string        `gorm:"size:30;index:ix_publish_transaction_info_revision,priority:11;"`
	NumBytes       *int64         ``
	NumFiles       *int32         ``
	ToolName       *string        `gorm:"size:50"`
	ToolVersion    *string        `gorm:"size:30"`
	Computer       *string        `gorm:"size:30"`
	OS             *string        `gorm:"size:3"`
	OSVersion      *string        `gorm:"size:1000"`
	User           *string        `gorm:"size:100;index:ix_publish_transaction_info_user,priority:11;"`
	TimestampUTC   *time.Time     `gorm:"type:datetime(6)"`
	StackTrace     *string        `gorm:"type:text"`
	AdditionalInfo GormJSONObject ``
	CreatedAtUTC   time.Time      `gorm:"type:datetime(6) not null"`
	ModifiedAtUTC  time.Time      `gorm:"type:datetime(6) not null"`
	Deleted        int32          `gorm:"not null;default:0;uniqueIndex:uix_publish_transaction_info_1;index:ix_publish_transaction_info_2;index:ix_publish_transaction_info_3;index:ix_publish_transaction_info_4;index:ix_publish_transaction_info_5;index:ix_publish_transaction_info_studio;index:ix_publish_transaction_info_root;index:ix_publish_transaction_info_groups;index:ix_publish_transaction_info_phase;index:ix_publish_transaction_info_component;index:ix_publish_transaction_info_revision;index:ix_publish_transaction_info_user;"`
	ModifiedBy     string         `gorm:"size:100;not null"`
	CreatedBy      string         `gorm:"size:100;not null"`
	ID             int32          `gorm:"primaryKey;autoIncrement;not null"`
}

func NewPublishTransactionInfo(
	p *entity.CreatePublishTransactionInfoParams,
) *PublishTransactionInfo {
	now := time.Now().UTC()
	var groupsPath string
	if len(p.Groups) != 0 {
		groupsPath = strings.Join(p.Groups, "/")
	}
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	return &PublishTransactionInfo{
		LogID:          p.LogID,
		TaskID:         p.TaskID,
		SubtaskID:      p.SubtaskID,
		Studio:         p.Studio,
		Project:        p.Project,
		ProjectPath:    p.ProjectPath,
		RevisionPath:   p.RevisionPath,
		Root:           p.Root,
		GroupsPath:     &groupsPath,
		Relation:       p.Relation,
		Phase:          p.Phase,
		Component:      p.Component,
		Revision:       p.Revision,
		NumBytes:       p.NumBytes,
		NumFiles:       p.NumFiles,
		ToolName:       p.ToolName,
		ToolVersion:    p.ToolVersion,
		Computer:       p.Computer,
		OS:             p.OS,
		OSVersion:      p.OSVersion,
		User:           p.User,
		TimestampUTC:   p.TimestampUTC,
		Operation:      p.Operation,
		Event:          p.Event,
		StackTrace:     p.StackTrace,
		AdditionalInfo: GormJSONObject(p.AdditionalInfo),
		CreatedAtUTC:   now,
		ModifiedAtUTC:  now,
		ModifiedBy:     createdBy,
		CreatedBy:      createdBy,
	}
}

func (m *PublishTransactionInfo) Entity() *entity.PublishTransactionInfo {
	groups := []string{}
	if m.GroupsPath != nil {
		groups = strings.Split(*m.GroupsPath, "/")
	}
	return &entity.PublishTransactionInfo{
		LogID:          m.LogID,
		TaskID:         m.TaskID,
		SubtaskID:      m.SubtaskID,
		Studio:         m.Studio,
		Project:        m.Project,
		ProjectPath:    m.ProjectPath,
		RevisionPath:   m.RevisionPath,
		Root:           m.Root,
		Groups:         groups,
		Relation:       m.Relation,
		Phase:          m.Phase,
		Component:      m.Component,
		Revision:       m.Revision,
		NumBytes:       m.NumBytes,
		NumFiles:       m.NumFiles,
		ToolName:       m.ToolName,
		ToolVersion:    m.ToolVersion,
		Computer:       m.Computer,
		OS:             m.OS,
		OSVersion:      m.OSVersion,
		User:           m.User,
		TimestampUTC:   m.TimestampUTC,
		Operation:      m.Operation,
		Event:          m.Event,
		StackTrace:     m.StackTrace,
		AdditionalInfo: entity.JSONObject(m.AdditionalInfo),
		CreatedAtUTC:   m.CreatedAtUTC,
		ModifiedAtUTC:  m.ModifiedAtUTC,
		ModifiedBy:     m.ModifiedBy,
		CreatedBy:      m.CreatedBy,
		ID:             m.ID,
	}
}
