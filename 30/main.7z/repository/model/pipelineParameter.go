package model

import (
	"encoding/json"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/pipelineParameter"
)

// Paraneter

type PipelineParameter struct {
	ID            uint32         `gorm:"primaryKey"`
	KeyName       string         `gorm:"size:50;not null;uniqueIndex:uix_pipeline_parameter_1"`
	Schema        GormJSONObject `gorm:"not null"`
	DisplayName   *string        `gorm:"size:50"`
	Description   *string        `gorm:"type:text"`
	Deleted       uint32         `gorm:"not null;default:0;uniqueIndex:uix_pipeline_parameter_1;index:ix_pipeline_parameter_2"`
	CreatedBy     string         `gorm:"size:100;not null"`
	CreatedAtUTC  time.Time      `gorm:"type:datetime(6);not null"`
	ModifiedBy    string         `gorm:"size:100;not null"`
	ModifiedAtUTC time.Time      `gorm:"type:datetime(6);not null;index:ix_pipeline_parameter_3"`
}

func NewPipelineParameter(
	p pipelineParameter.CreateParameterParams,
) PipelineParameter {
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	now := time.Now().UTC()
	return PipelineParameter{
		KeyName:       p.KeyName,
		Schema:        GormJSONObject(p.Schema),
		DisplayName:   p.DisplayName,
		Description:   p.Description,
		CreatedBy:     createdBy,
		CreatedAtUTC:  now,
		ModifiedBy:    createdBy,
		ModifiedAtUTC: now,
	}
}

func (m *PipelineParameter) Entity(showDeleted bool) *pipelineParameter.Parameter {
	e := &pipelineParameter.Parameter{
		ID:          m.ID,
		KeyName:     m.KeyName,
		Schema:      entity.JSONObject(m.Schema),
		DisplayName: m.DisplayName,
		Description: m.Description,
		BaseEntity: &entity.BaseEntity{
			CreatedBy:     m.CreatedBy,
			CreatedAtUTC:  m.CreatedAtUTC,
			ModifiedBy:    m.ModifiedBy,
			ModifiedAtUTC: m.ModifiedAtUTC,
		},
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}
	return e
}

// Location

type PipelineParameterLocation struct {
	ID            uint32    `gorm:"primaryKey"`
	Project       string    `gorm:"size:30;not null;uniqueIndex:uix_pipeline_parameter_location_1;index:ix_pipeline_parameter_location_2;index:ix_pipeline_parameter_location_3"`
	Parameter     string    `gorm:"size:50;not null;uniqueIndex:uix_pipeline_parameter_location_1;index:ix_pipeline_parameter_location_3"`
	Path          string    `gorm:"size:500;not null;uniqueIndex:uix_pipeline_parameter_location_1,length:255"`
	Depth         uint8     `gorm:"not null"`
	Deleted       uint32    `gorm:"not null;default:0;uniqueIndex:uix_pipeline_parameter_location_1;index:ix_pipeline_parameter_location_3"`
	CreatedBy     string    `gorm:"size:100;not null"`
	CreatedAtUTC  time.Time `gorm:"type:datetime(6);not null"`
	ModifiedBy    string    `gorm:"size:100;not null"`
	ModifiedAtUTC time.Time `gorm:"type:datetime(6);not null;index:ix_pipeline_parameter_location_2"`
}

func NewPipelineParameterLocation(
	p pipelineParameter.CreateLocationParams,
) *PipelineParameterLocation {
	var depth int
	if p.Path != "" {
		depth = strings.Count(p.Path, "/") + 1
	}
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	now := time.Now().UTC()
	return &PipelineParameterLocation{
		Project:       p.Project,
		Parameter:     p.Parameter,
		Path:          p.Path,
		Depth:         uint8(depth),
		CreatedBy:     createdBy,
		CreatedAtUTC:  now,
		ModifiedBy:    createdBy,
		ModifiedAtUTC: now,
	}
}

func (m *PipelineParameterLocation) Entity(showDeleted bool) *pipelineParameter.Location {
	e := &pipelineParameter.Location{
		ID:        m.ID,
		Project:   m.Project,
		Parameter: m.Parameter,
		Path:      m.Path,
		Depth:     m.Depth,
		BaseEntity: &entity.BaseEntity{
			CreatedBy:     m.CreatedBy,
			CreatedAtUTC:  m.CreatedAtUTC,
			ModifiedBy:    m.ModifiedBy,
			ModifiedAtUTC: m.ModifiedAtUTC,
		},
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}
	return e
}

// Value

type PipelineParameterValue struct {
	ID            uint32    `gorm:"primaryKey"`
	Project       string    `gorm:"size:30;not null;uniqueIndex:uix_pipeline_parameter_value_1;index:ix_pipeline_parameter_value_2;index:ix_pipeline_parameter_value_3"`
	Studio        string    `gorm:"size:30;not null;uniqueIndex:uix_pipeline_parameter_value_1;index:ix_pipeline_parameter_value_2;index:ix_pipeline_parameter_value_3"`
	Parameter     string    `gorm:"size:50;not null;uniqueIndex:uix_pipeline_parameter_value_1"`
	Location      string    `gorm:"size:500;not null;uniqueIndex:uix_pipeline_parameter_value_1,length:255"`
	Depth         uint8     `gorm:"not null"`
	Value         JSON      `gorm:"type:json;not null"`
	Deleted       uint32    `gorm:"not null;default:0;uniqueIndex:uix_pipeline_parameter_value_1;index:ix_pipeline_parameter_value_3"`
	CreatedBy     string    `gorm:"size:100;not null"`
	CreatedAtUTC  time.Time `gorm:"type:datetime(6);not null"`
	ModifiedBy    string    `gorm:"size:100;not null"`
	ModifiedAtUTC time.Time `gorm:"type:datetime(6);not null;index:ix_pipeline_parameter_value_2"`
}

func NewPipelineParameterValue(
	lgr entity.Logger,
	p *pipelineParameter.CreateValueParams,
) (*PipelineParameterValue, error) {
	var project string
	if p.Project != nil {
		project = *p.Project
	}
	var studio string
	if p.Studio != nil {
		studio = *p.Studio
	}
	var depth int
	if p.Location != "" {
		depth = strings.Count(p.Location, "/") + 1
	}
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}

	now := time.Now().UTC()
	bytes, err := json.Marshal(p.Value)
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not marshal json value: %v", p.Value)
		lgr.Warnf("%v: %v", retErr, err)
		return nil, retErr
	}

	return &PipelineParameterValue{
		Parameter:     p.Parameter,
		Project:       project,
		Studio:        studio,
		Location:      p.Location,
		Depth:         uint8(depth),
		Value:         bytes,
		CreatedBy:     createdBy,
		CreatedAtUTC:  now,
		ModifiedBy:    createdBy,
		ModifiedAtUTC: now,
	}, nil
}

func (m *PipelineParameterValue) Entity(showDeleted bool) *pipelineParameter.Value {
	var project string
	if m.Project != "" {
		project = m.Project
	}
	var studio string
	if m.Studio != "" {
		studio = m.Studio
	}
	var value interface{}
	json.Unmarshal(m.Value, &value)
	e := &pipelineParameter.Value{
		ID:        m.ID,
		Parameter: m.Parameter,
		Location:  m.Location,
		Depth:     m.Depth,
		Value:     value,
		Project:   &project,
		Studio:    &studio,
		BaseEntity: &entity.BaseEntity{
			CreatedBy:     m.CreatedBy,
			CreatedAtUTC:  m.CreatedAtUTC,
			ModifiedBy:    m.ModifiedBy,
			ModifiedAtUTC: m.ModifiedAtUTC,
		},
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}
	return e
}
