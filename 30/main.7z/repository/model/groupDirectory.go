package model

import "time"

// GroupDirectory represents a group directory information record.
type GroupDirectory struct {
	Project       string     `gorm:"size:30;not null;uniqueIndex:uix_directory_1;index:ix_directory_2;index:ix_directory_3"`
	Root          string     `gorm:"size:30;not null;index:ix_directory_3"`
	Depth         int32      `gorm:"not null;index:ix_directory_3"`
	Path          string     `gorm:"size:1000;not null;uniqueIndex:uix_directory_1,length:255;index:ix_directory_3,length:255"`
	GroupDepth    int32      `gorm:"not null"`
	Status        string     `gorm:"size:10;not null;index:ix_directory_3"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6);index:ix_directory_2"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:uix_directory_1;index:ix_directory_2;index:ix_directory_3"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}
