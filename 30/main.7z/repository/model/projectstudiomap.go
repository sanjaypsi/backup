package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type ProjectStudioMap struct {
	Project       string     `gorm:"size:30;not null;uniqueIndex:ix_project_studio_map"`
	Studio        string     `gorm:"size:30;not null;uniqueIndex:ix_project_studio_map"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:ix_project_studio_map"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

func NewProjectStudioMap(p *entity.CreateProjectStudioMapParams) *ProjectStudioMap {
	now := time.Now().UTC()
	return &ProjectStudioMap{
		Project:       p.Project,
		Studio:        p.Studio,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    p.CreatedBy,
		CreatedBy:     p.CreatedBy,
	}
}

func (m *ProjectStudioMap) Entity() *entity.ProjectStudioMap {
	return &entity.ProjectStudioMap{
		Project:       m.Project,
		Studio:        m.Studio,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		CreatedBy:     m.CreatedBy,
		ModifiedBy:    m.ModifiedBy,
	}
}
