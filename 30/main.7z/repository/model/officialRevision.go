package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type OfficialRevision struct {
	ID             uint32    `gorm:"primaryKey;not null;autoIncrement"`
	IsOfficial     bool      `gorm:"not null"`
	Project        string    `gorm:"size:30;not null;uniqueIndex:uix_official_revision_1;index:ix_official_revision_2"`
	Root           string    `gorm:"size:30;not null;uniqueIndex:uix_official_revision_1"`
	Group          string    `gorm:"size:100;not null;uniqueIndex:uix_official_revision_1"`
	Relation       string    `gorm:"size:100;not null;uniqueIndex:uix_official_revision_1"`
	Phase          string    `gorm:"size:100;not null;uniqueIndex:uix_official_revision_1"`
	Component      string    `gorm:"size:100;not null;uniqueIndex:uix_official_revision_1"`
	Revision       string    `gorm:"size:30;not null;uniqueIndex:uix_official_revision_1"`
	Studio         string    `gorm:"size:30;not null"`
	SubmittedUser  string    `gorm:"size:100;not null;index:ix_official_revision_3"`
	SubmittedAtUTC time.Time `gorm:"type:datetime(6);not null"`
	TaskID         string    `gorm:"size:36;not null"`
	SubtaskID      string    `gorm:"size:36;not null"`
	CreatedBy      string    `gorm:"size:100;not null"`
	CreatedAtUTC   time.Time `gorm:"type:datetime(6);not null"`
	ModifiedBy     string    `gorm:"size:100;not null"`
	ModifiedAtUTC  time.Time `gorm:"type:datetime(6);not null;index:ix_official_revision_2"`
}

func InsertOfficialRevision(
	p *entity.UpsertOfficialRevisionUsecaseParams,
) *OfficialRevision {
	now := time.Now().UTC()

	return &OfficialRevision{
		IsOfficial:     p.IsOfficial,
		Project:        p.Project,
		Root:           p.Root,
		Group:          p.Group,
		Relation:       p.Relation,
		Phase:          p.Phase,
		Component:      p.Component,
		Revision:       p.Revision,
		Studio:         p.Studio,
		SubmittedUser:  p.SubmittedUser,
		SubmittedAtUTC: p.SubmittedAtUTC,
		TaskID:         p.TaskID,
		SubtaskID:      p.SubtaskID,
		CreatedBy:      p.ModifiedBy,
		CreatedAtUTC:   now,
		ModifiedBy:     p.ModifiedBy,
		ModifiedAtUTC:  now,
	}
}

func UpdateOfficialRevision(
	p *entity.UpsertOfficialRevisionUsecaseParams,
) *map[string]interface{} {
	now := time.Now().UTC()

	// returning &map[string]interface{} instead of &entity.OfficialRevision
	// in order to update bool value of IsOfficial true to false
	return &map[string]interface{}{
		"is_official":     p.IsOfficial,
		"modified_by":     p.ModifiedBy,
		"modified_at_utc": now,
	}
}

func (m *OfficialRevision) Entity() *entity.OfficialRevision {
	return &entity.OfficialRevision{
		ID:             m.ID,
		IsOfficial:     m.IsOfficial,
		Project:        m.Project,
		Root:           m.Root,
		Group:          m.Group,
		Relation:       m.Relation,
		Phase:          m.Phase,
		Component:      m.Component,
		Revision:       m.Revision,
		Studio:         m.Studio,
		SubmittedUser:  m.SubmittedUser,
		SubmittedAtUTC: m.SubmittedAtUTC,
		TaskID:         m.TaskID,
		SubtaskID:      m.SubtaskID,
		CreatedBy:      m.CreatedBy,
		CreatedAtUTC:   m.CreatedAtUTC,
		ModifiedBy:     m.ModifiedBy,
		ModifiedAtUTC:  m.ModifiedAtUTC,
	}
}
