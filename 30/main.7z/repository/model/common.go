package model

import (
	"database/sql/driver"
	"encoding/json"
	"errors"
	"fmt"
)

// GormJSONObject represents a json object type.
type GormJSONObject map[string]interface{}

// Scan scan value into Jsonb, implements sql.Scanner interface
func (j *GormJSONObject) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return errors.New(fmt.Sprint("Failed to unmarshal JSONB value:", value))
	}
	var result map[string]interface{}
	if err := json.Unmarshal(bytes, &result); err != nil {
		return err
	}
	*j = GormJSONObject(result)
	return nil
}

// Value return json value, implement driver.Valuer interface
func (j GormJSONObject) Value() (driver.Value, error) {
	if len(j) == 0 {
		return nil, nil
	}
	var value map[string]interface{} = j
	return json.Marshal(value)
}

func (GormJSONObject) GormDataType() string {
	return "json"
}

// JSON Value

type JSON json.RawMessage

func (j *JSON) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("failed to unmarshal JSONB value: %v", value)
	}
	var result json.RawMessage
	if err := json.Unmarshal(bytes, &result); err != nil {
		return err
	}
	*j = JSON(result)
	return nil
}

func (j JSON) Value() (driver.Value, error) {
	if len(j) == 0 {
		return nil, nil
	}
	return json.RawMessage(j).MarshalJSON()
}

func (JSON) GormDataType() string {
	return "json"
}
