package model

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"gorm.io/gorm"
)

// Propertylist property enum
const (
	DBDefault  string = "default"
	DBRequired string = "required"
	DBFormat   string = "format"
	DBItems    string = "items"
	DBMaximum  string = "maximum"
	DBMinimum  string = "minimum"
	DBType     string = "type"
)

// Propertylist type enum
const (
	DBBool    string = "bool"
	DBEnum    string = "enum"
	DBFloat   string = "float"
	DBInt     string = "int"
	DBList    string = "list"
	DBUnicode string = "unicode"
)

// KeyType

func KeyType(
	group entity.PipelineSettingGroup,
	section *entity.PipelineSettingSection,
) (string, error) {
	switch group {
	case entity.Config:
		if section != nil && *section != 0 {
			return (*section).String() + "configKey", nil
		}
	case entity.Preference:
		return "preferenceKey", nil
	case entity.Environment:
		return "environmentKey", nil
	}
	var sec string
	if section != nil && *section != 0 {
		sec = (*section).String()
	}
	return "", fmt.Errorf("unable to detect key type: group %q: section: %q", group, sec)
}

func ParseKeyType(keyType string) (
	entity.PipelineSettingGroup,
	entity.PipelineSettingSection,
	error,
) {
	switch keyType {
	case "commonconfigKey":
		return entity.Config, entity.CommonSection, nil
	case "studioconfigKey":
		return entity.Config, entity.StudioSection, nil
	case "projectconfigKey":
		return entity.Config, entity.ProjectSection, nil
	case "preferenceKey":
		return entity.Preference, 0, nil
	case "environmentKey":
		return entity.Environment, 0, nil
	}
	return 0, 0, fmt.Errorf("unknown key type %q", keyType)
}

// Propertylist Entry

type PropertylistEntry struct {
	KeyType       string     `gorm:"size:50;not null;index:index_propertylist_entry_1"`
	Key           string     `gorm:"size:255;not null;index:index_propertylist_entry_1"`
	Property      string     `gorm:"size:30;not null;index:index_propertylist_entry_1"`
	Data          *string    `gorm:"type:text"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_propertylist_entry_1"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

func NewPropertylistEntry(
	keyType string,
	key string,
	property string,
	data *string,
	createdAtUTC *time.Time,
	createdBy *string,
) *PropertylistEntry {
	return &PropertylistEntry{
		KeyType:       keyType,
		Key:           key,
		Property:      property,
		Data:          data,
		CreatedAtUTC:  createdAtUTC,
		ModifiedAtUTC: createdAtUTC,
		ModifiedBy:    createdBy,
		CreatedBy:     createdBy,
	}
}

func concatSchemaSlice(s []interface{}) string {
	var enum []string
	v := reflect.ValueOf(s)
	if v.Kind() == reflect.Slice {
		for i := 0; i < v.Len(); i++ {
			enum = append(enum, fmt.Sprintf("%v", v.Index(i)))
		}
	}
	return strings.Join(enum, ",")
}

func NewPropertylistEntries(
	p *entity.CreatePipelineSettingPropertyParams,
) (*PropertylistEntry, []*PropertylistEntry) {
	keyType, _ := KeyType(p.Group, p.Section)
	now := time.Now().UTC()

	var data string
	switch p.Schema.Type {
	case entity.JSONArray:
		data = DBList
	case entity.JSONString:
		if p.Schema.Enum != nil {
			data = DBEnum
		} else {
			data = DBUnicode
		}
	case entity.JSONInteger:
		data = DBInt
	case entity.JSONNumber:
		data = DBFloat
	case entity.JSONBoolean:
		data = DBBool
	}
	typePropertyEntry := &PropertylistEntry{
		KeyType:       keyType,
		Key:           p.Key,
		Property:      DBType,
		Data:          &data,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    p.CreatedBy,
		CreatedBy:     p.CreatedBy,
	}

	var otherPropertyEntries []*PropertylistEntry
	if p.Schema.Enum != nil {
		data := concatSchemaSlice(p.Schema.Enum)
		itemsPropertyEntry := typePropertyEntry.WithProperty(DBItems, &data)
		otherPropertyEntries = append(otherPropertyEntries, itemsPropertyEntry)
	}
	if p.Schema.Default != nil {
		var strdefault string
		switch p.Schema.Type {
		case entity.JSONArray:
			if arraydefault, ok := p.Schema.Default.([]string); ok {
				strdefault = strings.Join(arraydefault, ",")
			}
		case entity.JSONString:
			if s, ok := p.Schema.Default.(string); ok {
				strdefault = s
			}
		case entity.JSONInteger:
			if floatdefault, ok := p.Schema.Default.(float64); ok {
				strdefault = strconv.Itoa(int(floatdefault))
			}
		case entity.JSONNumber:
			if floatdefault, ok := p.Schema.Default.(float64); ok {
				strdefault = fmt.Sprintf("%f", floatdefault)
			}
		case entity.JSONBoolean:
			if booldefault, ok := p.Schema.Default.(bool); ok {
				strdefault = strings.Title(strconv.FormatBool(booldefault))
			}
		}
		defaultPropertyEntry := typePropertyEntry.WithProperty(DBDefault, &strdefault)
		otherPropertyEntries = append(otherPropertyEntries, defaultPropertyEntry)
	}
	if p.Schema.Minimum != nil {
		var strmin string
		switch p.Schema.Type {
		case entity.JSONInteger:
			if minimum, ok := p.Schema.Minimum.(float64); ok {
				strmin = strconv.Itoa(int(minimum))
			}
		case entity.JSONNumber:
			if minimum, ok := p.Schema.Minimum.(float64); ok {
				strmin = fmt.Sprintf("%f", minimum)
			}
		}
		minimumPropertyEntry := typePropertyEntry.WithProperty(DBMinimum, &strmin)
		otherPropertyEntries = append(otherPropertyEntries, minimumPropertyEntry)
	}
	if p.Schema.Maximum != nil {
		var strmax string
		switch p.Schema.Type {
		case entity.JSONInteger:
			if maximum, ok := p.Schema.Maximum.(float64); ok {
				strmax = strconv.Itoa(int(maximum))
			}
		case entity.JSONNumber:
			if maximum, ok := p.Schema.Maximum.(float64); ok {
				strmax = fmt.Sprintf("%f", maximum)
			}
		}
		maximumPropertyEntry := typePropertyEntry.WithProperty(DBMaximum, &strmax)
		otherPropertyEntries = append(otherPropertyEntries, maximumPropertyEntry)
	}

	if p.Schema.HasPattern() {
		var pattern *string
		switch p.Schema.Type {
		case entity.JSONArray:
			pattern = p.Schema.Items.Pattern
		case entity.JSONString:
			pattern = p.Schema.Pattern
		}
		patternPropertyEntry := typePropertyEntry.WithProperty(DBFormat, pattern)
		otherPropertyEntries = append(otherPropertyEntries, patternPropertyEntry)
	}

	strrequired := strings.Title(strconv.FormatBool(p.Required))
	requiredPropertyEntry := typePropertyEntry.WithProperty(DBRequired, &strrequired)
	otherPropertyEntries = append(otherPropertyEntries, requiredPropertyEntry)

	return typePropertyEntry, otherPropertyEntries
}

func (m *PropertylistEntry) Entity(
	propModels []*PropertylistEntry,
) (*entity.PipelineSettingProperty, error) {
	group, section, _ := ParseKeyType(m.KeyType)

	schema := &entity.JSONSchema{}
	if m.Data != nil {
		switch *m.Data {
		case DBList:
			schema.Type = entity.JSONArray
			schema.Items = &entity.JSONSchema{
				Type: entity.JSONString,
			}
		case DBEnum:
			schema.Type = entity.JSONString
		case DBUnicode:
			schema.Type = entity.JSONString
		case DBInt:
			schema.Type = entity.JSONInteger
		case DBFloat:
			schema.Type = entity.JSONNumber
		case DBBool:
			schema.Type = entity.JSONBoolean
		default:
			return nil, fmt.Errorf("unknown type %q", *m.Data)
		}
	}

	var required bool
	for _, propModel := range propModels {
		if propModel.Data == nil || *propModel.Data == "" {
			continue
		}
		switch propModel.Property {
		case DBItems:
			var enum []interface{}
			for _, s := range strings.Split(*propModel.Data, ",") {
				enum = append(enum, s)
			}
			schema.Enum = enum
		case DBDefault:
			switch schema.Type {
			case entity.JSONArray:
				defaultarray := append([]string{}, strings.Split(*propModel.Data, ",")...)
				schema.Default = defaultarray
			case entity.JSONString:
				schema.Default = *propModel.Data
			case entity.JSONInteger:
				defaultf, err := strconv.ParseFloat(*propModel.Data, 64)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Default = int(defaultf)
			case entity.JSONNumber:
				defaultf, err := strconv.ParseFloat(*propModel.Data, 64)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Default = defaultf
			case entity.JSONBoolean:
				defaultbool, err := strconv.ParseBool(*propModel.Data)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Default = defaultbool
			}
		case DBMinimum:
			switch schema.Type {
			case entity.JSONInteger:
				minf, err := strconv.ParseFloat(*propModel.Data, 64)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Minimum = int(minf)
			case entity.JSONNumber:
				minf, err := strconv.ParseFloat(*propModel.Data, 64)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Minimum = minf
			}
		case DBMaximum:
			switch schema.Type {
			case entity.JSONInteger:
				maxf, err := strconv.ParseFloat(*propModel.Data, 64)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Maximum = int(maxf)
			case entity.JSONNumber:
				maxf, err := strconv.ParseFloat(*propModel.Data, 64)
				if err != nil {
					return nil, fmt.Errorf("data conversion error: %w", err)
				}
				schema.Maximum = maxf
			}
		case DBFormat:
			switch schema.Type {
			case entity.JSONArray:
				schema.Items.Pattern = propModel.Data
			default:
				schema.Pattern = propModel.Data
			}
		case DBRequired:
			requiredbool, err := strconv.ParseBool(*propModel.Data)
			if err != nil {
				return nil, fmt.Errorf("data conversion error: %w", err)
			}
			required = requiredbool
		}
	}

	property := &entity.PipelineSettingProperty{
		ID:            uint32(m.ID),
		Group:         group,
		Key:           m.Key,
		Schema:        schema,
		Required:      required,
		CreatedBy:     m.CreatedBy,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		ModifiedAtUTC: m.ModifiedAtUTC,
	}
	if section != 0 {
		property.Section = &section
	}

	return property, nil
}

func (f *PropertylistEntry) WithProperty(
	property string,
	data *string,
) *PropertylistEntry {
	return NewPropertylistEntry(
		f.KeyType,
		f.Key,
		property,
		data,
		f.CreatedAtUTC,
		f.CreatedBy,
	)
}

func ModifiedPropertylistEntries(
	p *entity.UpdatePipelineSettingPropertyParams,
) (*PropertylistEntry, []*PropertylistEntry, []*PropertylistEntry) {
	keyType, _ := KeyType(p.Group, p.Section)
	now := time.Now().UTC()
	var data string
	switch p.Schema.Type {
	case entity.JSONArray:
		data = DBList
	case entity.JSONString:
		if p.Schema.Enum != nil {
			data = DBEnum
		} else {
			data = DBUnicode
		}
	case entity.JSONInteger:
		data = DBInt
	case entity.JSONNumber:
		data = DBFloat
	case entity.JSONBoolean:
		data = DBBool
	}
	typePropertyEntry := &PropertylistEntry{
		KeyType:       keyType,
		Key:           p.Key,
		Property:      DBType,
		Data:          &data,
		ModifiedAtUTC: &now,
		ModifiedBy:    p.ModifiedBy,
	}

	var otherPropertyEntries []*PropertylistEntry
	var deletePropertyEntries []*PropertylistEntry
	if p.Schema.Enum != nil {
		data := concatSchemaSlice(p.Schema.Enum)
		itemsPropertyEntry := typePropertyEntry.WithModifiedProperty(DBItems, &data)
		otherPropertyEntries = append(otherPropertyEntries, itemsPropertyEntry)
	} else {
		deleteEntry := typePropertyEntry.WithModifiedProperty(DBItems, nil)
		deletePropertyEntries = append(deletePropertyEntries, deleteEntry)
	}
	if p.Schema.Default != nil {
		var strdefault string
		switch p.Schema.Type {
		case entity.JSONArray:
			if arraydefault, ok := p.Schema.Default.([]string); ok {
				strdefault = strings.Join(arraydefault, ",")
			}
		case entity.JSONString:
			if s, ok := p.Schema.Default.(string); ok {
				strdefault = s
			}
		case entity.JSONInteger:
			if floatdefault, ok := p.Schema.Default.(float64); ok {
				strdefault = strconv.Itoa(int(floatdefault))
			}
		case entity.JSONNumber:
			if floatdefault, ok := p.Schema.Default.(float64); ok {
				strdefault = fmt.Sprintf("%f", floatdefault)
			}
		case entity.JSONBoolean:
			if booldefault, ok := p.Schema.Default.(bool); ok {
				strdefault = strings.Title(strconv.FormatBool(booldefault))
			}
		}
		defaultPropertyEntry := typePropertyEntry.WithModifiedProperty(DBDefault, &strdefault)
		otherPropertyEntries = append(otherPropertyEntries, defaultPropertyEntry)
	} else {
		deleteEntry := typePropertyEntry.WithModifiedProperty(DBDefault, nil)
		deletePropertyEntries = append(deletePropertyEntries, deleteEntry)
	}
	if p.Schema.Minimum != nil {
		var strmin string
		switch p.Schema.Type {
		case entity.JSONInteger:
			if minimum, ok := p.Schema.Minimum.(float64); ok {
				strmin = strconv.Itoa(int(minimum))
			}
		case entity.JSONNumber:
			if minimum, ok := p.Schema.Minimum.(float64); ok {
				strmin = fmt.Sprintf("%f", minimum)
			}
		}
		minimumPropertyEntry := typePropertyEntry.WithModifiedProperty(DBMinimum, &strmin)
		otherPropertyEntries = append(otherPropertyEntries, minimumPropertyEntry)
	} else {
		deleteEntry := typePropertyEntry.WithModifiedProperty(DBMinimum, nil)
		deletePropertyEntries = append(deletePropertyEntries, deleteEntry)
	}
	if p.Schema.Maximum != nil {
		var strmax string
		switch p.Schema.Type {
		case entity.JSONInteger:
			if maximum, ok := p.Schema.Maximum.(float64); ok {
				strmax = strconv.Itoa(int(maximum))
			}
		case entity.JSONNumber:
			if maximum, ok := p.Schema.Maximum.(float64); ok {
				strmax = fmt.Sprintf("%f", maximum)
			}
		}
		maximumPropertyEntry := typePropertyEntry.WithModifiedProperty(DBMaximum, &strmax)
		otherPropertyEntries = append(otherPropertyEntries, maximumPropertyEntry)
	} else {
		deleteEntry := typePropertyEntry.WithModifiedProperty(DBMaximum, nil)
		deletePropertyEntries = append(deletePropertyEntries, deleteEntry)
	}
	if p.Schema.HasPattern() {
		var pattern *string
		switch p.Schema.Type {
		case entity.JSONArray:
			pattern = p.Schema.Items.Pattern
		case entity.JSONString:
			pattern = p.Schema.Pattern
		}
		patternPropertyEntry := typePropertyEntry.WithModifiedProperty(DBFormat, pattern)
		otherPropertyEntries = append(otherPropertyEntries, patternPropertyEntry)
	} else {
		deleteEntry := typePropertyEntry.WithModifiedProperty(DBFormat, nil)
		deletePropertyEntries = append(deletePropertyEntries, deleteEntry)
	}
	strrequired := strings.Title(strconv.FormatBool(p.Required))
	requiredPropertyEntry := typePropertyEntry.WithProperty(DBRequired, &strrequired)
	otherPropertyEntries = append(otherPropertyEntries, requiredPropertyEntry)

	return typePropertyEntry, otherPropertyEntries, deletePropertyEntries
}

func (f *PropertylistEntry) WithModifiedProperty(
	property string,
	data *string,
) *PropertylistEntry {
	return ModifiedPropertylistEntry(
		f.KeyType,
		f.Key,
		property,
		data,
		f.ModifiedAtUTC,
		f.ModifiedBy,
	)
}

func ModifiedPropertylistEntry(
	keyType string,
	key string,
	property string,
	data *string,
	modifiedAtUTC *time.Time,
	modifiedBy *string,
) *PropertylistEntry {
	return &PropertylistEntry{
		KeyType:       keyType,
		Key:           key,
		Property:      property,
		Data:          data,
		CreatedAtUTC:  modifiedAtUTC,
		ModifiedAtUTC: modifiedAtUTC,
		CreatedBy:     modifiedBy,
		ModifiedBy:    modifiedBy,
	}
}

// Pipeline Setting Value Entry (Config Entry | Preference Entry)

type ConfigEntry struct {
	SectionType   string     `gorm:"size:20;not null;index:index_config_entry_1"`
	SectionName   string     `gorm:"size:50;not null;index:index_config_entry_1"`
	Key           string     `gorm:"size:255;not null;index:index_config_entry_1"`
	Value         *string    `gorm:"type:text"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_config_entry_1"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

type PreferenceEntry struct {
	SectionType   string     `gorm:"size:20;not null;index:index_preference_entry_1"`
	SectionName   string     `gorm:"size:50;not null;index:index_preference_entry_1"`
	Key           string     `gorm:"size:255;not null;index:index_preference_entry_1"`
	Value         *string    `gorm:"type:text"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_preference_entry_1"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

type PipelineSettingValueEntry struct {
	SectionType   string
	SectionName   string
	Key           string
	Value         *string
	CreatedAtUTC  *time.Time
	ModifiedAtUTC *time.Time
	Deleted       int32
	ModifiedBy    *string
	CreatedBy     *string
	ID            int32
}

func (m PipelineSettingValueEntry) StmtWithGroup(
	db *gorm.DB,
	group entity.PipelineSettingGroup,
) (*gorm.DB, error) {
	switch group {
	case entity.Config:
		return db.Model(&ConfigEntry{}), nil
	case entity.Preference:
		return db.Model(&PreferenceEntry{}), nil
	case entity.Environment:
		return db.Model(&PipelineSettingEnvironment{}), nil
	default:
		return nil, fmt.Errorf("group %q is not supported", group)
	}
}

func NewPipelineSettingValue(
	p *entity.CreatePipelineSettingValueParams,
) *PipelineSettingValueEntry {
	var sectionType string
	var sectionName string
	if p.Project != nil {
		sectionType = "project"
		sectionName = *p.Project
	} else if p.Studio != nil {
		sectionType = "studio"
		sectionName = *p.Studio
	} else if p.Common != nil {
		sectionType = "common"
		sectionName = *p.Common
	}

	now := time.Now().UTC()

	m := &PipelineSettingValueEntry{
		SectionType:   sectionType,
		SectionName:   sectionName,
		Key:           p.Key,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    p.CreatedBy,
		CreatedBy:     p.CreatedBy,
	}

	if strvalue := StringifyValue(p.Value); strvalue != "" {
		m.Value = &strvalue
	}

	return m
}

func StringifyValue(value interface{}) string {
	var strvalue string
	v := reflect.ValueOf(value)
	switch v.Kind() {
	case reflect.Bool:
		if v.Bool() {
			strvalue = "True"
		} else {
			strvalue = "False"
		}
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		strvalue = strconv.FormatInt(v.Int(), 10)
	case reflect.Float32, reflect.Float64:
		strvalue = strconv.FormatFloat(v.Float(), 'f', -1, 64)
	case reflect.String:
		strvalue = v.String()
	case reflect.Slice:
		var ss []string
		for i := 0; i < v.Len(); i++ {
			ss = append(ss, fmt.Sprintf("%v", v.Index(i)))
		}
		strvalue = strings.Join(ss, ",")
	}
	return strvalue
}

func (m *PipelineSettingValueEntry) Entity(
	group entity.PipelineSettingGroup,
	schema *entity.JSONSchema,
) (*entity.PipelineSettingValue, error) {
	value := &entity.PipelineSettingValue{
		ID:            uint32(m.ID),
		Group:         group,
		Key:           m.Key,
		CreatedBy:     m.CreatedBy,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		ModifiedAtUTC: m.ModifiedAtUTC,
	}

	value.Section = m.SectionType
	value.Entry = m.SectionName

	if m.Value != nil {
		value.Value = *m.Value

		if schema != nil {
			switch (*schema).Type {
			case "array":
				value.Value = strings.Split(*m.Value, ",")
			case "string":
				value.Value = *m.Value
			case "integer":
				i, err := strconv.Atoi(*m.Value)
				if err != nil {
					return nil, err
				}
				value.Value = i
			case "boolean":
				switch strings.ToLower(*m.Value) {
				case "true", "yes", "on", "1", "y":
					value.Value = true
				default:
					value.Value = false
				}
			case "number":
				f, err := strconv.ParseFloat(*m.Value, 64)
				if err != nil {
					return nil, err
				}
				value.Value = f
			}
		}
	}

	return value, nil
}

// new tables with JSON value
type PipelineSettingProperty struct {
	ID            int32  `gorm:"primaryKey"`
	KeyType       string `gorm:"size:50;not null;index:index_pipeline_setting_property_1"`
	Key           string `gorm:"size:255;not null;index:index_pipeline_setting_property_1"`
	Property      JSON   `gorm:"type:json;not null"`
	Required      bool
	CreatedBy     *string    `gorm:"size:100"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedBy    *string    `gorm:"size:100"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_pipeline_setting_property_1"`
}

func (p *PipelineSettingProperty) Entity() (*entity.PipelineSettingProperty, error) {
	group, section, _ := ParseKeyType(p.KeyType)
	var s *entity.JSONSchema = &entity.JSONSchema{}
	if group != entity.Environment {
		json.Unmarshal(p.Property, s)
	}

	property := &entity.PipelineSettingProperty{
		ID:            uint32(p.ID),
		Group:         group,
		Key:           p.Key,
		Schema:        s,
		Required:      p.Required,
		CreatedBy:     p.CreatedBy,
		CreatedAtUTC:  p.CreatedAtUTC,
		ModifiedBy:    p.ModifiedBy,
		ModifiedAtUTC: p.ModifiedAtUTC,
	}
	if section != 0 {
		property.Section = &section
	}

	return property, nil
}

type PipelineSettingConfig struct {
	ID            int32      `gorm:"primaryKey"`
	SectionType   string     `gorm:"size:20;not null;index:index_pipeline_setting_config_1"`
	SectionName   string     `gorm:"size:50;not null;index:index_pipeline_setting_config_1"`
	Key           string     `gorm:"size:255;not null;index:index_pipeline_setting_config_1"`
	Value         JSON       `gorm:"type:json;not null"`
	CreatedBy     *string    `gorm:"size:100"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedBy    *string    `gorm:"size:100"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_pipeline_setting_config_1"`
}

type PipelineSettingPreference struct {
	ID            int32      `gorm:"primaryKey"`
	SectionType   string     `gorm:"size:20;not null;index:index_pipeline_setting_preference_1"`
	SectionName   string     `gorm:"size:50;not null;index:index_pipeline_setting_preference_1"`
	Key           string     `gorm:"size:255;not null;index:index_pipeline_setting_preference_1"`
	Value         JSON       `gorm:"type:json;not null"`
	CreatedBy     *string    `gorm:"size:100"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedBy    *string    `gorm:"size:100"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_pipeline_setting_preference_1"`
}

type PipelineSettingEnvironment struct {
	ID            int32      `gorm:"primaryKey"`
	SectionType   string     `gorm:"size:20;not null;index:index_pipeline_setting_environment_1"`
	SectionName   string     `gorm:"size:50;not null;index:index_pipeline_setting_environment_1"`
	PropKey       string     `gorm:"size:255;not null;index:index_pipeline_setting_environment_1"`
	Value         JSON       `gorm:"type:json;not null"`
	EnvKey        string     "gorm:\"column:env_key;->;type:VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`value`, '$.key')));default:(-);index:index_pipeline_setting_environment_1\""
	CreatedBy     *string    `gorm:"size:100"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedBy    *string    `gorm:"size:100"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;index:index_pipeline_setting_environment_1"`
}

func (m *PipelineSettingEnvironment) Entity(
	group entity.PipelineSettingGroup,
	schema *entity.JSONSchema,
) (*entity.PipelineSettingValue, error) {
	value := &entity.PipelineSettingValue{
		ID:            uint32(m.ID),
		Group:         group,
		Key:           m.PropKey,
		CreatedBy:     m.CreatedBy,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		ModifiedAtUTC: m.ModifiedAtUTC,
	}

	value.Section = m.SectionType
	value.Entry = m.SectionName

	var v interface{}
	json.Unmarshal(m.Value, &v)
	value.Value = v

	return value, nil
}
