package model

import (
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/groupCategory"
)

// Category

type GroupCategory struct {
	ID            uint32    `gorm:"primaryKey"`
	Project       string    `gorm:"size:30;not null;uniqueIndex:uix_group_category_1;index:ix_group_category_2;index:ix_group_category_3"`
	Root          string    `gorm:"size:30;not null;uniqueIndex:uix_group_category_1"`
	Path          string    `gorm:"size:150;not null;uniqueIndex:uix_group_category_1"`
	Depth         uint8     `gorm:"not null"`
	CreatedBy     string    `gorm:"size:100;not null"`
	CreatedAtUTC  time.Time `gorm:"type:datetime(6);not null"`
	ModifiedBy    string    `gorm:"size:100;not null"`
	ModifiedAtUTC time.Time `gorm:"type:datetime(6);not null;index:ix_group_category_2"`
	Deleted       uint32    `gorm:"not null;default:0;uniqueIndex:uix_group_category_1;index:ix_group_category_3"`

	Groups []*GroupCategoryGroup
}

func NewGroupCategory(p *groupCategory.CreateParams) *GroupCategory {
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	depth := strings.Count(p.Path, "/") + 1
	now := time.Now().UTC()
	return &GroupCategory{
		Project:       p.Project,
		Root:          p.Root,
		Path:          p.Path,
		Depth:         uint8(depth),
		CreatedAtUTC:  now,
		CreatedBy:     createdBy,
		ModifiedAtUTC: now,
		ModifiedBy:    createdBy,
	}
}

func (m *GroupCategory) Entity(showDeleted bool) *groupCategory.CategoryEntity {
	e := &groupCategory.CategoryEntity{
		ID:      m.ID,
		Project: m.Project,
		Root:    m.Root,
		Path:    m.Path,
		Depth:   m.Depth,
		BaseEntity: &entity.BaseEntity{
			CreatedAtUTC:  m.CreatedAtUTC,
			CreatedBy:     m.CreatedBy,
			ModifiedAtUTC: m.ModifiedAtUTC,
			ModifiedBy:    m.ModifiedBy,
		},
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	} else {
		e.Groups = make([]string, len(m.Groups))
		for i, group := range m.Groups {
			e.Groups[i] = group.Path
		}
	}
	return e
}

// Group

type GroupCategoryGroup struct {
	ID              uint32    `gorm:"primaryKey"`
	GroupCategoryID uint32    `gorm:"not null;uniqueIndex:uix_group_category_group_1"`
	Path            string    `gorm:"size:150;not null;uniqueIndex:uix_group_category_group_1"`
	Project         string    `gorm:"size:30;not null;index:ix_group_category_group_2;index:ix_group_category_group_3"`
	CreatedBy       string    `gorm:"size:100;not null"`
	CreatedAtUTC    time.Time `gorm:"type:datetime(6);not null"`
	ModifiedBy      string    `gorm:"size:100;not null"`
	ModifiedAtUTC   time.Time `gorm:"type:datetime(6);not null;index:ix_group_category_group_2"`
	Deleted         uint32    `gorm:"not null;default:0;uniqueIndex:uix_group_category_group_1;index:ix_group_category_group_3"`
}

func NewGroupCategoryGroup(p *groupCategory.CreateGroupParams) *GroupCategoryGroup {
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	now := time.Now().UTC()
	return &GroupCategoryGroup{
		GroupCategoryID: p.GroupCategoryID,
		Path:            p.Path,
		Project:         p.Project,
		CreatedAtUTC:    now,
		CreatedBy:       createdBy,
		ModifiedAtUTC:   now,
		ModifiedBy:      createdBy,
	}
}

func (m *GroupCategoryGroup) Entity(showDeleted bool) *groupCategory.GroupEntity {
	e := &groupCategory.GroupEntity{
		ID:              m.ID,
		Project:         m.Project,
		GroupCategoryID: m.GroupCategoryID,
		Path:            m.Path,
		BaseEntity: &entity.BaseEntity{
			CreatedAtUTC:  m.CreatedAtUTC,
			CreatedBy:     m.CreatedBy,
			ModifiedAtUTC: m.ModifiedAtUTC,
			ModifiedBy:    m.ModifiedBy,
		},
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}
	return e
}
