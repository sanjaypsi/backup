package model

import (
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type Directory struct {
	Project       string     `gorm:"size:30;not null;uniqueIndex:uix_directory_1;index:ix_directory_2;index:ix_directory_3"`
	Path          string     `gorm:"size:1000;not null;uniqueIndex:uix_directory_1,length:255;index:ix_directory_3,length:255"`
	Depth         int32      `gorm:"not null;index:ix_directory_3"`
	Status        string     `gorm:"size:10;not null;index:ix_directory_3"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6);index:ix_directory_2"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:uix_directory_1;index:ix_directory_2;index:ix_directory_3"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

func NewDirectory(p *entity.CreateDirectoryParams) *Directory {
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	now := time.Now().UTC()
	return &Directory{
		Project:       p.Project,
		Path:          p.Path,
		Depth:         int32(strings.Count(p.Path, "/") + 1),
		Status:        entity.Active.String(),
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    &createdBy,
		CreatedBy:     &createdBy,
	}
}

func (m *Directory) Entity(showDeleted bool) *entity.Directory {
	status, _ := entity.ParseDeletionStats(m.Status)
	e := &entity.Directory{
		Project:       m.Project,
		Path:          m.Path,
		Depth:         m.Depth,
		Status:        status,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		CreatedBy:     m.CreatedBy,
		ModifiedBy:    m.ModifiedBy,
		ID:            m.ID,
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}
	return e
}

type DirectoryDeletionLog struct {
	DirectoryID   int32      `gorm:"not null;uniqueIndex:uix_directory_deleteion_log_1"`
	Studio        string     `gorm:"size:30;not null;uniqueIndex:uix_directory_deleteion_log_1"`
	Status        string     `gorm:"size:10;not null"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:uix_directory_deleteion_log_1"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

func NewDirectoryDeletionLogs(
	p *entity.CreateDirectoryDeletionInfoParams,
) []*DirectoryDeletionLog {
	now := time.Now().UTC()
	var logs []*DirectoryDeletionLog
	for _, studio := range p.Studios {
		for _, directoryID := range p.DirectoryIDs {
			logs = append(logs, &DirectoryDeletionLog{
				DirectoryID:   directoryID,
				Studio:        studio,
				Status:        entity.ToDelete.String(),
				CreatedAtUTC:  &now,
				ModifiedAtUTC: &now,
				CreatedBy:     p.CreatedBy,
				ModifiedBy:    p.CreatedBy,
			})
		}
	}
	return logs
}

func (m *DirectoryDeletionLog) Entity() *entity.DirectoryDeletionInfo {
	status, _ := entity.ParseDeletionStats(m.Status)
	return &entity.DirectoryDeletionInfo{
		DirectoryID:   m.DirectoryID,
		Studio:        m.Studio,
		Status:        status,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		CreatedBy:     m.CreatedBy,
		ModifiedBy:    m.ModifiedBy,
	}
}
