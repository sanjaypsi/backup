package model

import "time"

type StudioAuth struct {
	ID            uint32     `gorm:"primaryKey"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       uint32     `gorm:"not null;default:0"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	Studio        string     `gorm:"size:100;not null"`
	Password      string     `gorm:"size:100;not null"`
	Salt          string     `gorm:"size:16;not null"`
}
