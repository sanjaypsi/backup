package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type ReviewStatusLog struct {
	Studio       string `gorm:"size:30;not null"`
	Project      string `gorm:"size:30;not null;index:ix_review_status_1;index:ix_review_status_2;index:ix_review_status_3"`
	UpdateID     string `gorm:"size:36;index:ix_review_status_2;index:ix_review_status_3"`
	ReviewInfoID int32  `gorm:"not null;index:ix_review_status_3"`
	StatusType   string `gorm:"size:20;not null"`
	Status       string `gorm:"size:20;not null"`

	CreatedAtUTC time.Time `gorm:"type:datetime(6) not null;index:ix_review_status_1;index:ix_review_status_2;index:ix_review_status_3"`
	CreatedBy    string    `gorm:"size:100;not null"`
	ID           int32     `gorm:"primaryKey;autoIncrement;not null"`
}

func NewReviewStatusLog(
	p *entity.CreateReviewStatusLogParams,
) *ReviewStatusLog {
	now := time.Now().UTC()
	return &ReviewStatusLog{
		Studio:       p.Studio,
		Project:      p.Project,
		UpdateID:     p.UpdateID,
		ReviewInfoID: p.ReviewInfoID,
		StatusType:   p.StatusType,
		Status:       p.Status,

		CreatedAtUTC: now,
		CreatedBy:    p.CreatedBy,
	}
}

func (m *ReviewStatusLog) Entity() *entity.ReviewStatusLog {
	return &entity.ReviewStatusLog{
		Studio:       m.Studio,
		Project:      m.Project,
		UpdateID:     m.UpdateID,
		ReviewInfoID: m.ReviewInfoID,
		StatusType:   m.StatusType,
		Status:       m.Status,

		CreatedAtUTC: m.CreatedAtUTC,
		CreatedBy:    m.CreatedBy,
		ID:           m.ID,
	}
}
