package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type StudioInfo struct {
	KeyName  string              `gorm:"column:name;size:30;not null;uniqueIndex:uix_studio_info_1"`
	Projects []*ProjectStudioMap `gorm:"foreignKey:Studio;references:KeyName"`

	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6)"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:uix_studio_info_1"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey;not null;autoIncrement"`
}

func NewStudioInfo(p *entity.CreateStudioInfoParams) *StudioInfo {
	now := time.Now().UTC()
	return &StudioInfo{
		KeyName:       p.KeyName,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    p.CreatedBy,
		CreatedBy:     p.CreatedBy,
	}
}

func (m *StudioInfo) Entity() *entity.StudioInfo2 {
	var projects []string = []string{}
	for _, p := range m.Projects {
		projects = append(projects, p.Project)
	}
	return &entity.StudioInfo2{
		KeyName:       m.KeyName,
		Projects:      projects,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		CreatedBy:     m.CreatedBy,
		ID:            m.ID,
	}
}
