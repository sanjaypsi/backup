package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/service"
	"github.com/google/uuid"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type CommentAttachment struct {
	cs *service.CentralService
}

func NewCommentAttachment(cs *service.CentralService) *CommentAttachment {
	return &CommentAttachment{
		cs: cs,
	}
}

func (ca *CommentAttachment) Get(
	db context.Context,
	params *entity.GetCommentAttachmentParams,
) (*entity.DownloadAttachment, error) {
	project, err := ca.cs.GetProjectByName(db, params.Project)
	if err != nil {
		return nil, err
	}
	document, err := project.GetDocumentByID(db, "comment", params.CommentID)
	if err != nil {
		return nil, err
	}
	filename, err := ca.findAttachmentFilename(*document.DocumentInfo, params.AttachmentID)
	if err != nil {
		filename = params.AttachmentID
	}
	fmt.Println(filename)

	downloadDir :=
		"/mnt/ppip30-data02/comment/projects/" +
			params.Project + "/" + params.CommentID
	if _, err = os.Stat(downloadDir); os.IsNotExist(err) {
		return nil, err
	}

	datapath := filepath.Join(downloadDir, params.AttachmentID)
	if _, err = os.Stat(datapath); errors.Is(err, os.ErrNotExist) {
		return nil, err
	}
	attachment := &entity.DownloadAttachment{
		DataPath: datapath,
		FileName: filename,
	}
	return attachment, nil
}

func (ca *CommentAttachment) Create(
	db context.Context,
	params *entity.PostCommentAttachmentParams,
) (*entity.Document, error) {
	// get project
	project, err := ca.cs.GetProjectByName(db, params.Project)
	if err != nil {
		return nil, err
	}

	// get comment
	document, err := project.GetDocumentByID(db, "comment", params.CommentID)
	if err != nil {
		return nil, err
	}
	comment := *document.DocumentInfo
	fmt.Println(comment)

	uploadDir :=
		"/mnt/ppip30-data02/comment/projects/" +
			params.Project + "/" + params.CommentID
	if err = os.MkdirAll(uploadDir, 0755); err != nil {
		return nil, err
	}

	uuidObj, err := uuid.NewRandom()
	if err != nil {
		return nil, err
	}

	// create attachment ID
	attachmentID := uuidObj.String()

	out, err := os.Create(uploadDir + "/" + attachmentID)
	if err != nil {
		return nil, err
	}

	defer out.Close()
	_, err = io.Copy(out, *params.FileData)
	if err != nil {
		return nil, err
	}
	fileinfo, _ := out.Stat()
	filesize := fileinfo.Size()

	// make update params
	var attachmentDataParams = map[string]interface{}{
		"id":       attachmentID,
		"filename": params.FileName,
		"size":     filesize,
	}

	attachments, ok := comment["attachments"]
	if !ok {
		attachments = primitive.M{}
	}
	attachmentList, ok := attachments.(primitive.A)
	if !ok {
		attachmentList = primitive.A{}
	}
	attachmentList = append(attachmentList, attachmentDataParams)

	comment["attachments"] = attachmentList

	commentData, ok := comment["comment_data"]
	if !ok {
		commentData = primitive.M{}
	}
	commentDataList, ok := commentData.(primitive.A)
	if !ok {
		commentDataList = primitive.A{}
	}
	langs := strings.Split(params.Lang, ",")
	for _, lang := range langs {
		var langDataMap primitive.M = nil

		for _, commentData := range commentDataList {
			commentDataMap, ok := commentData.(primitive.M)
			if !ok {
				continue
			}
			language, ok := commentDataMap["language"]
			if ok && language == lang {
				langDataMap = commentDataMap
				break
			}
		}
		if langDataMap == nil {
			langDataMap = primitive.M{
				"language": lang,
			}
			commentDataList = append(commentDataList, langDataMap)
		}

		// attachments
		attachments, ok := langDataMap["attachments"]
		if !ok {
			attachments = primitive.A{}
		}
		attachmentList, ok := attachments.(primitive.A)
		if !ok {
			attachmentList = primitive.A{}
		}
		attachmentList = append(attachmentList, attachmentID)
		langDataMap["attachments"] = attachmentList
	}

	comment["comment_data"] = commentDataList

	// update comment
	document, err = project.UpdateDocument(db, "comment", params.CommentID, comment)
	if err != nil {
		return nil, err
	}

	return document, nil
}

func (ca *CommentAttachment) WithContext(ctx context.Context) (context.Context, *sql.Tx, error) {
	// TODO: Once the authentication mechanism is in place, get the authenticated user name
	var user string
	ctx = context.WithValue(ctx, entity.KeyUser, user)
	tx, err := ca.cs.BeginTx(ctx, &sql.TxOptions{})
	if err != nil {
		return nil, nil, err
	}
	ctx = context.WithValue(ctx, entity.KeyTx, tx)
	return ctx, tx, nil
}

func (ca *CommentAttachment) findAttachmentFilename(comment entity.DocumentInfo, attachmentID string) (string, error) {
	if attachments, ok := comment["attachments"]; !ok {
		return "", entity.ErrRecordNotFound
	} else if attachments, ok := attachments.(primitive.A); !ok {
		return "", entity.ErrRecordNotFound
	} else {
		for _, attachment := range attachments {
			if attachment, ok := attachment.(primitive.M); !ok {
				continue
			} else if aid, ok := attachment["id"]; !ok {
				continue
			} else if aid, ok := aid.(string); !ok {
				continue
			} else if aid != attachmentID {
				continue
			} else if filename, ok := attachment["filename"]; !ok {
				continue
			} else if filename, ok := filename.(string); !ok {
				continue
			} else {
				return filename, nil
			}
		}
		return "", entity.ErrRecordNotFound
	}
}
