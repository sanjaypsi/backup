package repository

import (
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/service"
)

type ReviewThumbnail struct {
	cs *service.CentralService
}

func NewReviewThumbnail(cs *service.CentralService) *ReviewThumbnail {
	return &ReviewThumbnail{
		cs: cs,
	}
}

func (rt *ReviewThumbnail) GetAssetThumbnail(
	params *entity.GetAssetThumbnailParams,
) (string, error) {
	var thumbnailDirs []string
	for _, phase := range []string{"mdl", "rig", "bld", "dsn", "ldv"} {
		matches, err := filepath.Glob(filepath.Join(
			"/mnt/ppip30-data01/datasync30/projects",
			params.Project,
			"shared/publish/assets",
			params.Asset,
			params.Relation,
			phase,
			"_tmb/20*.s???r????/thumbnail",
		))
		if err != nil {
			return "", err
		}
		thumbnailDirs = append(thumbnailDirs, matches...)
	}

	// リビジョン名の日付部分で降順ソート
	timestamp := func(thumbnailDir string) string {
		return strings.Split(filepath.Base(filepath.Dir(thumbnailDir)), ".")[0]
	}
	sort.Slice(thumbnailDirs, func(i, j int) bool {
		return timestamp(thumbnailDirs[j]) < timestamp(thumbnailDirs[i])
	})

	names := []string{"thumbnail_s.png", "thumbnail_m.png", "thumbnail_l.png", "animated.gif"}
	for _, thumbnailDir := range thumbnailDirs {
		for _, name := range names {
			thumbnailPath := filepath.Join(thumbnailDir, name)
			if f, err := os.Stat(thumbnailPath); err == nil && f.Mode().IsRegular() {
				return thumbnailPath, nil
			}
		}
	}

	return "", os.ErrNotExist
}

func (rt *ReviewThumbnail) GetShotThumbnail(
	params *entity.GetShotThumbnailParams,
) (string, error) {
	var thumbnailDirs []string
	for _, phase := range []string{"lay", "anm", "gnz", "mat", "cmp"} {
		matches, err := filepath.Glob(filepath.Join(
			"/mnt/ppip30-data01/datasync30/projects",
			params.Project,
			"shared/publish/shots",
			params.Group1,
			params.Group2,
			params.Group3,
			params.Relation,
			phase,
			"_tmb/20*.s???r????/thumbnail",
		))
		if err != nil {
			return "", err
		}
		thumbnailDirs = append(thumbnailDirs, matches...)
	}

	// リビジョン名の日付部分で降順ソート
	timestamp := func(thumbnailDir string) string {
		return strings.Split(filepath.Base(filepath.Dir(thumbnailDir)), ".")[0]
	}
	sort.Slice(thumbnailDirs, func(i, j int) bool {
		return timestamp(thumbnailDirs[j]) < timestamp(thumbnailDirs[i])
	})

	names := []string{"thumbnail_s.png", "thumbnail_m.png", "thumbnail_l.png", "animated.gif"}
	for _, thumbnailDir := range thumbnailDirs {
		for _, name := range names {
			thumbnailPath := filepath.Join(thumbnailDir, name)
			if f, err := os.Stat(thumbnailPath); err == nil && f.Mode().IsRegular() {
				return thumbnailPath, nil
			}
		}
	}

	return "", os.ErrNotExist
}
