package repository

import (
	"bytes"
	"fmt"
	"log"
	"regexp"
	"strings"
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/PolygonPictures/central30-web/front/testutil"
)

func TestDirectoryListDepth1Fast(t *testing.T) {
	project := "potoodev"
	wantUseIndex := "USE INDEX (`ix_directory_3`)"
	wantWhere := fmt.Sprintf("WHERE `project` = '%s' AND `path` IN ('.sys','shared','unshared')", project)
	diffOpts := cmpopts.IgnoreFields(entity.Directory{}, "ID")

	tests := []struct {
		name       string
		path       string
		depth      int32
		wantEntity *entity.Directory
	}{
		{
			name:  "List depth=1 Fast .sys",
			path:  ".sys",
			depth: 1,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    ".sys",
				Depth:   1,
				Status:  entity.Active,
			},
		},
		{
			name:  "List depth=1 Fast shared",
			path:  "shared",
			depth: 1,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    "shared",
				Depth:   1,
				Status:  entity.Active,
			},
		},
		{
			name:  "List depth=1 Fast unshared",
			path:  "unshared",
			depth: 1,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    "unshared",
				Depth:   1,
				Status:  entity.Active,
			},
		},
	}

	repo := newDirectoryRepository(t)

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			testDB.Create(&model.Directory{
				Project: project,
				Path:    test.path,
				Depth:   test.depth,
				Status:  entity.Active.String(),
			})

			params := &entity.ListDirectoryParams{Project: project, Depth: &test.depth}
			buf := captureGORMLog(t, testDB)
			entities, total, err := repo.List(testDB, params)
			require.Nil(t, err)
			require.Equal(t, 1, total)

			diff := cmp.Diff(test.wantEntity, entities[0], diffOpts)
			assert.Emptyf(t, diff, "directory entity mismatch (-want +got):\n%s", diff)

			assertDirectoryListFastSQL(t, buf.String(), wantUseIndex, wantWhere)
		})
	}
}

func TestDirectoryListDepth2Fast(t *testing.T) {
	project := "potoodev"
	wantUseIndex := "USE INDEX (`ix_directory_3`)"
	wantWhere := fmt.Sprintf("WHERE `project` = '%s' AND `path` IN ('shared/publish','shared/tools')", project)
	diffOpts := cmpopts.IgnoreFields(entity.Directory{}, "ID")

	tests := []struct {
		name       string
		path       string
		pathPrefix string
		depth      int32
		wantEntity *entity.Directory
	}{
		{
			name:       "List depth=2 Fast shared/publish",
			path:       "shared/publish",
			pathPrefix: "shared/",
			depth:      2,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    "shared/publish",
				Depth:   2,
				Status:  entity.Active,
			},
		},
		{
			name:       "List depth=2 Fast shared/tools",
			path:       "shared/tools",
			pathPrefix: "shared/",
			depth:      2,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    "shared/tools",
				Depth:   2,
				Status:  entity.Active,
			},
		},
	}

	repo := newDirectoryRepository(t)

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			testDB.Create(&model.Directory{
				Project: project,
				Path:    test.path,
				Depth:   test.depth,
				Status:  entity.Active.String(),
			})

			params := &entity.ListDirectoryParams{
				Project:    project,
				Depth:      &test.depth,
				PathPrefix: &test.pathPrefix,
			}
			buf := captureGORMLog(t, testDB)
			entities, total, err := repo.List(testDB, params)
			require.Nil(t, err)
			require.Equal(t, 1, total)

			diff := cmp.Diff(test.wantEntity, entities[0], diffOpts)
			assert.Emptyf(t, diff, "directory entity mismatch (-want +got):\n%s", diff)

			assertDirectoryListFastSQL(t, buf.String(), wantUseIndex, wantWhere)
		})
	}
}

func TestDirectoryListDepth3Fast(t *testing.T) {
	project := "potoodev"
	roots := []string{"assets", "shots"}
	quotedPaths := []string{}
	for _, root := range roots {
		quotedPaths = append(quotedPaths, fmt.Sprintf("'shared/publish/%s'", root))
	}
	rootsString := strings.Join(roots, ",")
	wantUseIndex := "USE INDEX (`ix_directory_3`)"
	wantWhere := fmt.Sprintf("WHERE `project` = '%s' AND `path` IN (%s)", project, strings.Join(quotedPaths, ","))
	diffOpts := cmpopts.IgnoreFields(entity.Directory{}, "ID")

	tests := []struct {
		name       string
		path       string
		pathPrefix string
		depth      int32
		wantEntity *entity.Directory
	}{
		{
			name:       "List depth=3 Fast shared/publish/assets",
			path:       "shared/publish/assets",
			pathPrefix: "shared/publish/",
			depth:      3,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    "shared/publish/assets",
				Depth:   3,
				Status:  entity.Active,
			},
		},
		{
			name:       "List depth=3 Fast shared/publish/shots",
			path:       "shared/publish/shots",
			pathPrefix: "shared/publish/",
			depth:      3,
			wantEntity: &entity.Directory{
				Project: project,
				Path:    "shared/publish/shots",
				Depth:   3,
				Status:  entity.Active,
			},
		},
	}

	repo := newDirectoryRepository(t)

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			testDB.Create(&model.PreferenceEntry{
				SectionType: "project",
				SectionName: project,
				Key:         "/ppip/roots",
				Value:       &rootsString,
			})
			testDB.Create(&model.Directory{
				Project: project,
				Path:    test.path,
				Depth:   test.depth,
				Status:  entity.Active.String(),
			})

			params := &entity.ListDirectoryParams{
				Project:    project,
				Depth:      &test.depth,
				PathPrefix: &test.pathPrefix,
			}
			buf := captureGORMLog(t, testDB)
			entities, total, err := repo.List(testDB, params)
			require.Nil(t, err)
			require.Equal(t, 1, total)

			diff := cmp.Diff(test.wantEntity, entities[0], diffOpts)
			assert.Emptyf(t, diff, "directory entity mismatch (-want +got):\n%s", diff)

			assertDirectoryListFastSQL(t, buf.String(), wantUseIndex, wantWhere)
		})
	}
}

func captureGORMLog(t *testing.T, db *gorm.DB) *bytes.Buffer {
	t.Helper()

	var buf bytes.Buffer
	newLogger := logger.New(
		log.New(&buf, "\r\n", 0),
		logger.Config{LogLevel: logger.Info},
	)

	origLogger := db.Logger
	t.Cleanup(func() {
		db.Logger = origLogger
	})
	db.Logger = newLogger
	return &buf
}

func assertDirectoryListFastSQL(t *testing.T, gormLog, wantUseIndex, wantWhere string) {
	t.Helper()

	re := regexp.MustCompile("(?m)SELECT \\* FROM `t_directory` .*$")
	sql := re.FindString(gormLog)
	require.NotEmpty(t, sql, "no sql in log: sql=%v, log=%q", re, gormLog)
	assert.Containsf(t, sql, wantUseIndex, "no %q in %q", wantUseIndex, sql)
	assert.Containsf(t, sql, wantWhere, "no %q in %q", wantWhere, sql)
}

func newDirectoryRepository(t *testing.T) *Directory {
	t.Helper()

	gd, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	repo, err := NewDirectory(testDB, gd)
	require.Nil(t, err)

	return repo
}
