package repository

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"
)

type PipelineSetting struct {
	db *gorm.DB
}

func NewPipelineSetting(db *gorm.DB) (*PipelineSetting, error) {
	if err := db.AutoMigrate(
		&model.PropertylistEntry{},
		&model.ConfigEntry{},
		&model.PreferenceEntry{},
		&model.PipelineSettingProperty{},
		&model.PipelineSettingConfig{},
		&model.PipelineSettingPreference{},
		// &model.PipelineSettingEnvironment{},
	); err != nil {
		return nil, err
	}
	return &PipelineSetting{
		db: db,
	}, nil
}

func (r *PipelineSetting) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *PipelineSetting) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

// Property

func (r *PipelineSetting) ListProperties(
	tx *gorm.DB,
	params *entity.ListPipelineSettingPropertyParams,
) ([]*entity.PipelineSettingProperty, uint, error) {
	if params.Group == entity.Environment {
		return nil, 0, fmt.Errorf("group %q is not implemented", params.Group)
	}
	keyType, err := model.KeyType(params.Group, params.Section)
	if err != nil {
		return nil, 0, err
	}

	stmt := tx.Where("`deleted` = ?", 0).Where("`key_type` = ?", keyType)

	typeStmt := tx.Where(stmt).Where("`property` = ?", "type")

	if params.SearchKey != nil {
		typeStmt.Where("`key` LIKE CONCAT('%', ?, '%')", *params.SearchKey)
	}

	var total int64
	var typeModel model.PropertylistEntry
	if err := typeStmt.Model(&typeModel).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	typeStmt.Order(params.GetOrderBy())
	perPage := params.GetPerPage()
	if perPage > 0 {
		offset := perPage * (params.GetPage() - 1)
		typeStmt = typeStmt.Limit(perPage).Offset(offset)
	}

	var typeModels []*model.PropertylistEntry
	if err := typeStmt.Find(&typeModels).Error; err != nil {
		return nil, 0, err
	}

	var properties []*entity.PipelineSettingProperty
	for _, tm := range typeModels {
		var otherModels []*model.PropertylistEntry
		if err := tx.Where(stmt).Where(
			"`key` = ?", tm.Key,
		).Where(
			"`property` != ?", "type",
		).Find(&otherModels).Error; err != nil {
			continue
		}
		prop, err := tm.Entity(otherModels)
		if err != nil {
			log.Println(err)
			continue
		}
		properties = append(properties, prop)
	}

	return properties, uint(total), nil
}

func (r *PipelineSetting) ListEnvironmentProperties(
	tx *gorm.DB,
	params *entity.ListEnvironmentPropertyParams,
) ([]*entity.PipelineSettingProperty, uint, error) {
	keyType, err := model.KeyType(entity.Environment, params.Section)
	if err != nil {
		return nil, 0, err
	}

	stmt := tx.Where("`deleted` = ?", 0).Where("`key_type` = ?", keyType)

	if params.SearchKey != nil {
		stmt.Where("`key` LIKE CONCAT('%', ?, '%')", *params.SearchKey)
	}

	stmt.Order(params.GetOrderBy())
	perPage := params.GetPerPage()
	if perPage > 0 {
		offset := perPage * (params.GetPage() - 1)
		stmt = stmt.Limit(perPage).Offset(offset)
	}

	var modelProps []model.PipelineSettingProperty
	var total int64
	result := stmt.Find(&modelProps)

	if err := result.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	if err := result.Error; err != nil {
		return nil, 0, err
	}

	var entityProps []*entity.PipelineSettingProperty
	for _, m := range modelProps {
		entityProp, err := m.Entity()
		if err != nil {
			return nil, 0, err
		}
		entityProps = append(entityProps, entityProp)
	}

	return entityProps, uint(total), nil
}

func (r *PipelineSetting) GetProperty(
	tx *gorm.DB,
	params *entity.GetPipelineSettingPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	if params.Group == entity.Environment {
		return nil, fmt.Errorf("group %q is not implemented", params.Group)
	}
	keyType, err := model.KeyType(params.Group, params.Section)
	if err != nil {
		return nil, err
	}

	stmt := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_type` = ?", keyType,
	).Where(
		"`key` = ?", params.Key,
	)

	var typeModel model.PropertylistEntry
	if err := tx.Where(stmt).Where(
		"`property` = ?", "type",
	).Take(&typeModel).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
	}

	var otherModels []*model.PropertylistEntry
	if err := tx.Where(stmt).Where(
		"`property` != ?", "type",
	).Find(&otherModels).Error; err != nil {
		return nil, err
	}

	return typeModel.Entity(otherModels)
}

func (r *PipelineSetting) GetEnvironmentProperty(
	tx *gorm.DB,
	params *entity.GetEnvironmentPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	keyType, err := model.KeyType(entity.Environment, params.Section)
	if err != nil {
		return nil, err
	}

	stmt := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_type` = ?", keyType,
	).Where(
		"`key` = ?", params.Key,
	)

	var modelProp model.PipelineSettingProperty
	if err := tx.Where(stmt).Take(&modelProp).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		return nil, err
	}

	return modelProp.Entity()
}

func (r *PipelineSetting) CreateProperty(
	tx *gorm.DB,
	params *entity.CreatePipelineSettingPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	typeModel, otherModels := model.NewPropertylistEntries(params)
	models := []*model.PropertylistEntry{typeModel}
	models = append(models, otherModels...)
	if err := tx.Create(models).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: property with key %q is already exists", entity.ErrBadRequest, params.Key,
			)
		}
		return nil, err
	}
	return typeModel.Entity(otherModels)
}

func (r *PipelineSetting) CreateEnvironmentProperty(
	tx *gorm.DB,
	params *entity.CreateEnvironmentPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	keyType, _ := model.KeyType(entity.Environment, params.Section)
	now := time.Now().UTC()
	obj := map[string]interface{}{}
	property, err := json.Marshal(obj)
	if err != nil {
		return nil, fmt.Errorf(
			"%w: invalid schema", entity.ErrBadRequest,
		)
	}
	modelProp := model.PipelineSettingProperty{
		KeyType:       keyType,
		Key:           params.Key,
		Property:      property,
		CreatedBy:     params.CreatedBy,
		CreatedAtUTC:  &now,
		ModifiedBy:    params.CreatedBy,
		ModifiedAtUTC: &now,
	}
	if err := tx.Create(&modelProp).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: property with key %q is already exists", entity.ErrBadRequest, params.Key,
			)
		}
		return nil, err
	}
	return modelProp.Entity()
}

func (r *PipelineSetting) UpdateProperty(
	tx *gorm.DB,
	params *entity.UpdatePipelineSettingPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	typeModel, otherModels, deleteModels := model.ModifiedPropertylistEntries(params)

	// Work on other schemas
	for _, otherModel := range otherModels {
		stmt := tx.Where(model.PropertylistEntry{
			KeyType:  otherModel.KeyType,
			Key:      otherModel.Key,
			Property: otherModel.Property,
		})
		if err := stmt.Where(
			"`deleted` = ?", 0,
		).Assign(model.PropertylistEntry{
			Data:          otherModel.Data,
			ModifiedAtUTC: otherModel.ModifiedAtUTC,
			ModifiedBy:    otherModel.ModifiedBy,
		}).FirstOrCreate(otherModel).Error; err != nil {
			return nil, err
		}
	}

	for _, deleteModel := range deleteModels {
		stmt := tx.Where(model.PropertylistEntry{
			KeyType:  deleteModel.KeyType,
			Key:      deleteModel.Key,
			Property: deleteModel.Property,
		})
		pm := &model.PropertylistEntry{
			ModifiedAtUTC: deleteModel.ModifiedAtUTC,
			ModifiedBy:    deleteModel.ModifiedBy,
		}
		result := stmt.Model(&pm).Updates(map[string]interface{}{
			"deleted":         gorm.Expr("id"),
			"modified_at_utc": pm.ModifiedAtUTC,
			"modified_by":     pm.ModifiedBy,
		})
		if err := result.Error; err != nil {
			return nil, err
		}
		if result.RowsAffected == 0 {
			fmt.Println("%w: property with key %w not found", entity.ErrRecordNotFound, params.Key)
		}
	}

	// recollect target records
	stmt := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_type` = ?", typeModel.KeyType,
	).Where(
		"`key` = ?", typeModel.Key,
	)
	if err := tx.Where(stmt).Where(
		"`property` = ?", "type",
	).Take(&typeModel).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf(
				"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
	}
	if err := tx.Where(stmt).Where(
		"`property` != ?", "type",
	).Find(&otherModels).Error; err != nil {
		return nil, err
	}

	return typeModel.Entity(otherModels)
}

func (r *PipelineSetting) UpdateEnvironmentProperty(
	tx *gorm.DB,
	params *entity.UpdateEnvironmentPropertyParams,
) (*entity.PipelineSettingProperty, error) {
	keyType, _ := model.KeyType(entity.Environment, params.Section)
	now := time.Now().UTC()
	// obj := map[string]interface{}{}
	property, err := json.Marshal(params.Schema)
	if err != nil {
		return nil, fmt.Errorf(
			"%w: invalid schema", entity.ErrBadRequest,
		)
	}
	var modelProp model.PipelineSettingProperty
	stmt := tx.Where(model.PipelineSettingProperty{
		KeyType: keyType,
		Key:     params.Key,
	})
	if err := stmt.Where("`deleted` = ?", 0).Updates(model.PipelineSettingProperty{
		Property:      property,
		Required:      params.Required,
		ModifiedBy:    params.ModifiedBy,
		ModifiedAtUTC: &now,
	}).First(&modelProp).Error; err != nil {
		return nil, err
	}

	return modelProp.Entity()
}

func (r *PipelineSetting) DeleteProperty(
	tx *gorm.DB,
	params *entity.DeletePipelineSettingPropertyParams,
) error {
	if params.Group == entity.Environment {
		return fmt.Errorf("group %q is not implemented", params.Group)
	}
	keyType, err := model.KeyType(params.Group, params.Section)
	if err != nil {
		return err
	}
	now := time.Now().UTC()

	pm := &model.PropertylistEntry{
		ModifiedAtUTC: &now,
		ModifiedBy:    params.ModifiedBy,
	}
	result := tx.Model(pm).Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_type` = ?", keyType,
	).Where(
		"`key` = ?", params.Key,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": pm.ModifiedAtUTC,
		"modified_by":     pm.ModifiedBy,
	})
	if err := result.Error; err != nil {
		return err
	}
	if result.RowsAffected == 0 {
		return fmt.Errorf(
			"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
		)
	}

	return nil
}

func (r *PipelineSetting) DeleteEnvironmentProperty(
	tx *gorm.DB,
	params *entity.DeleteEnvironmentPropertyParams,
) error {
	keyType, err := model.KeyType(entity.Environment, nil)
	if err != nil {
		return err
	}
	now := time.Now().UTC()

	pm := &model.PipelineSettingProperty{
		ModifiedAtUTC: &now,
		ModifiedBy:    params.ModifiedBy,
	}
	result := tx.Model(pm).Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_type` = ?", keyType,
	).Where(
		"`key` = ?", params.Key,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": pm.ModifiedAtUTC,
		"modified_by":     pm.ModifiedBy,
	})
	if err := result.Error; err != nil {
		return err
	}
	if result.RowsAffected == 0 {
		return fmt.Errorf(
			"%w: property with key %q not found", entity.ErrRecordNotFound, params.Key,
		)
	}

	return nil
}

func (r *PipelineSetting) CountValues(
	tx *gorm.DB,
	params entity.GetPipelineSettingPropertyParams,
) (uint, error) {
	stmt := tx.Where("`deleted` = ?", 0).Where("`key` = ?", params.Key)
	if params.Section != nil && *params.Section != 0 {
		stmt = stmt.Where("`section_type` = ?", (*params.Section).String())
	}
	var m model.PipelineSettingValueEntry
	stmt, err := m.StmtWithGroup(stmt, params.Group)
	if err != nil {
		return 0, err
	}
	var total int64
	if err := stmt.Count(&total).Error; err != nil {
		return 0, err
	}
	return uint(total), nil
}

func (r *PipelineSetting) CountEnvironmentValues(
	tx *gorm.DB,
	params entity.GetEnvironmentPropertyParams,
) (uint, error) {
	stmt := tx.Where("`deleted` = ?", 0).Where("`prop_key` = ?", params.Key)
	if params.Section != nil && *params.Section != 0 {
		stmt = stmt.Where("`section_type` = ?", (*params.Section).String())
	}
	var m model.PipelineSettingValueEntry
	stmt, err := m.StmtWithGroup(stmt, entity.Environment)
	if err != nil {
		return 0, err
	}
	var total int64
	if err := stmt.Count(&total).Error; err != nil {
		return 0, err
	}
	return uint(total), nil
}

// Value

func (r *PipelineSetting) ListValues(
	tx *gorm.DB,
	params *entity.ListPipelineSettingValueParams,
) ([]*entity.PipelineSettingValue, uint, error) {
	stmt := tx.Where("`deleted` = ?", 0)
	if params.Project != nil && *params.Project != "" {
		stmt = stmt.Where(
			"`section_type` = ?", entity.ProjectSection.String(),
		).Where(
			"`section_name` = ?", *params.Project,
		)
	} else if params.Studio != nil && *params.Studio != "" {
		stmt = stmt.Where(
			"`section_type` = ?", entity.StudioSection.String(),
		).Where(
			"`section_name` = ?", *params.Studio,
		)
	} else if params.Common != nil && *params.Common != "" {
		stmt = stmt.Where(
			"`section_type` = ?", entity.CommonSection.String(),
		).Where(
			"`section_name` = ?", *params.Common,
		)
	}

	var m model.PipelineSettingValueEntry
	stmt, err := m.StmtWithGroup(stmt, params.Group)
	if err != nil {
		return nil, 0, err
	}

	if params.SearchKey != nil {
		stmt.Where("`key` LIKE CONCAT('%', ?, '%')", *params.SearchKey)
	}

	var total int64
	if err := stmt.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var models []*model.PipelineSettingValueEntry
	stmt.Order(params.GetOrderBy())
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Limit(perPage).Offset(offset).Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.PipelineSettingValue
	for _, m := range models {
		e, err := r.valueEntity(tx, params.Group, m)
		if err != nil {
			log.Println(err)
			continue
		}
		entities = append(entities, e)
	}
	return entities, uint(total), nil
}

func (r *PipelineSetting) ListEnvironmentValues(
	tx *gorm.DB,
	params *entity.ListEnvironmentValueParams,
) ([]*entity.PipelineSettingValue, uint, error) {
	stmt := tx.Where("`deleted` = ?", 0)
	if params.Project != nil && *params.Project != "" {
		stmt = stmt.Where(
			"`section_type` = ?", entity.ProjectSection.String(),
		).Where(
			"`section_name` = ?", *params.Project,
		)
	} else if params.Studio != nil && *params.Studio != "" {
		stmt = stmt.Where(
			"`section_type` = ?", entity.StudioSection.String(),
		).Where(
			"`section_name` = ?", *params.Studio,
		)
	} else if params.Common != nil && *params.Common != "" {
		stmt = stmt.Where(
			"`section_type` = ?", entity.CommonSection.String(),
		).Where(
			"`section_name` = ?", *params.Common,
		)
	}

	if params.PropKey != nil {
		stmt = stmt.Where("`prop_key` = ?", *params.PropKey)
	}
	if params.EnvKey != nil {
		stmt = stmt.Where("`env_key` = ?", *params.EnvKey)
	}
	if params.SearchKey != nil {
		stmt = stmt.Where("`prop_key` LIKE CONCAT('%', ?, '%') OR `env_key` LIKE CONCAT('%', ?, '%')", *params.SearchKey, *params.SearchKey)
	}

	var m model.PipelineSettingEnvironment
	stmt = stmt.Model(m)

	var models []*model.PipelineSettingEnvironment
	stmt.Order(params.GetOrderBy())
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Limit(perPage).Offset(offset).Debug().Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.PipelineSettingValue
	for _, m := range models {
		e, err := r.environmentValueEntity(tx, params.Group, m)
		if err != nil {
			continue
		}
		entities = append(entities, e)
	}
	return entities, uint(len(entities)), nil
}

func (r *PipelineSetting) GetValue(
	tx *gorm.DB,
	params *entity.GetPipelineSettingValueParams,
) (*entity.PipelineSettingValue, error) {
	var m model.PipelineSettingValueEntry
	sectionEntries := params.SectionEntries()
	if len(sectionEntries) == 0 {
		return nil, entity.ErrSectionNotSelected
	}
	stmt, err := m.StmtWithGroup(tx, params.Group)
	if err != nil {
		return nil, err
	}
	stmt = stmt.Where("`deleted` = ?", 0).Where("`key` = ?", params.Key)

	if !params.Composite {
		for _, entry := range sectionEntries {
			stmt = stmt.Where(
				"`section_type` = ?", entry.Section.String(),
			).Where(
				"`section_name` = ?", entry.Name,
			)
		}
		if err := stmt.Take(&m).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return nil, fmt.Errorf(
					"%w: value with key %q not found", entity.ErrRecordNotFound, params.Key,
				)
			}
			return nil, err
		}

	} else {
		conditionGroups := tx
		for i, entry := range sectionEntries {
			conditionGroup := tx.Where(
				"`section_type` = ?", entry.Section.String(),
			).Where(
				"`section_name` = ?", entry.Name,
			)
			if i == 0 {
				conditionGroups = conditionGroups.Where(conditionGroup)
			} else {
				conditionGroups = conditionGroups.Or(conditionGroup)
			}
		}
		stmt.Where(conditionGroups)

		var models []*model.PipelineSettingValueEntry
		if err := stmt.Find(&models).Error; err != nil {
			return nil, err
		}
		if len(models) == 0 {
			return nil, fmt.Errorf(
				"%w: value with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
		for _, section := range []entity.PipelineSettingSection{
			entity.CommonSection,
			entity.StudioSection,
			entity.ProjectSection,
		} {
			for _, sm := range models {
				if sm.SectionType == section.String() {
					m = *sm
				}
			}
		}
		// TODO: resolve formatter
	}

	return r.valueEntity(tx, params.Group, &m)
}

func (r *PipelineSetting) GetEnvironmentValue(
	tx *gorm.DB,
	params *entity.GetEnvironmentValueParams,
) (*entity.PipelineSettingValue, error) {
	var m model.PipelineSettingEnvironment
	stmt := tx.Model(m)
	stmt = stmt.Where("`deleted` = ?", 0)
	stmt = stmt.Where("`id` = ?", params.ID)

	sectionEntries := params.SectionEntries()
	if len(sectionEntries) == 0 {
		return nil, entity.ErrSectionNotSelected
	}

	if !params.Composite {
		for _, entry := range sectionEntries {
			stmt = stmt.Where(
				"`section_type` = ?", entry.Section.String(),
			).Where(
				"`section_name` = ?", entry.Name,
			)
		}
		if err := stmt.Take(&m).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return nil, entity.ErrRecordNotFound
			}
			return nil, err
		}
	} else {
		conditionGroups := tx
		for i, entry := range sectionEntries {
			conditionGroup := tx.Where(
				"`section_type` = ?", entry.Section.String(),
			).Where(
				"`section_name` = ?", entry.Name,
			)
			if i == 0 {
				conditionGroups = conditionGroups.Where(conditionGroup)
			} else {
				conditionGroups = conditionGroups.Or(conditionGroup)
			}
		}
		stmt = stmt.Where(conditionGroups)
		if err := stmt.Take(&m).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return nil, entity.ErrRecordNotFound
			}
			return nil, err
		}
	}

	e, err := r.environmentValueEntity(tx, params.Group, &m)
	if err != nil {
		return nil, err
	}

	return e, nil
}

func (r *PipelineSetting) CreateValue(
	tx *gorm.DB,
	params *entity.CreatePipelineSettingValueParams,
) (*entity.PipelineSettingValue, error) {
	m := model.NewPipelineSettingValue(params)
	stmt, err := m.StmtWithGroup(tx, params.Group)
	if err != nil {
		return nil, err
	}
	if err := stmt.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: value with key %s is already exists", entity.ErrBadRequest, params.Key,
			)
		}
		return nil, err
	}
	return r.valueEntity(tx, params.Group, m)
}

func (r *PipelineSetting) CreateEnvironmentValue(
	tx *gorm.DB,
	params *entity.CreateEnvironmentValueParams,
) (*entity.PipelineSettingValue, error) {
	var sectionType string
	var sectionName string
	if params.Project != nil {
		sectionType = "project"
		sectionName = *params.Project
	} else if params.Studio != nil {
		sectionType = "studio"
		sectionName = *params.Studio
	} else if params.Common != nil {
		sectionType = "common"
		sectionName = *params.Common
	}

	now := time.Now().UTC()
	value, err := json.Marshal(params.Value)
	if err != nil {
		return nil, fmt.Errorf(
			"%w: invalid schema", entity.ErrBadRequest,
		)
	}

	m := &model.PipelineSettingEnvironment{
		SectionType:   sectionType,
		SectionName:   sectionName,
		PropKey:       params.PropKey,
		Value:         value,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		ModifiedBy:    params.CreatedBy,
		CreatedBy:     params.CreatedBy,
	}

	stmt := tx.Model(m)
	stmt = stmt.Where("`deleted` = ?", 0).Where("`key` = ?", params.PropKey)
	if err := stmt.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: value with key %s is already exists", entity.ErrBadRequest, params.PropKey,
			)
		}
		return nil, err
	}

	result := &entity.PipelineSettingValue{
		ID:            uint32(m.ID),
		Group:         entity.Environment,
		Section:       m.SectionType,
		Entry:         m.SectionName,
		Key:           m.PropKey,
		Value:         params.Value,
		CreatedBy:     m.CreatedBy,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		ModifiedAtUTC: m.ModifiedAtUTC,
	}

	return result, nil
}

func (r *PipelineSetting) UpdateValue(
	tx *gorm.DB,
	params *entity.UpdatePipelineSettingValueParams,
) (*entity.PipelineSettingValue, error) {
	var m model.PipelineSettingValueEntry
	stmt, err := m.StmtWithGroup(tx, params.Group)
	if err != nil {
		return nil, err
	}

	stmt = stmt.Where("`deleted` = ?", 0).Where("`key` = ?", params.Key)
	if params.Project != nil && *params.Project != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.ProjectSection.String(),
		).Where(
			"section_name = ?", *params.Project,
		)
	} else if params.Studio != nil && *params.Studio != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.StudioSection.String(),
		).Where(
			"section_name = ?", *params.Studio,
		)
	} else if params.Common != nil && *params.Common != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.CommonSection.String(),
		).Where(
			"section_name = ?", *params.Common,
		)
	} else {
		return nil, errors.New("no section info")
	}
	strvalue := model.StringifyValue(params.Value)
	modifiedAtUTC := time.Now().UTC()
	result := stmt.Updates(model.PipelineSettingValueEntry{
		Value:         &strvalue,
		ModifiedAtUTC: &modifiedAtUTC,
		ModifiedBy:    params.ModifiedBy,
	})
	if err := result.Error; err != nil {
		return nil, err
	}

	model, err := r.GetValue(tx, &entity.GetPipelineSettingValueParams{
		Group:     params.Group,
		Common:    params.Common,
		Studio:    params.Studio,
		Project:   params.Project,
		Key:       params.Key,
		Composite: false,
	})
	if err != nil {
		return nil, err
	}

	return model, nil
}

func (r *PipelineSetting) UpdateEnvironmentValue(
	tx *gorm.DB,
	params *entity.UpdateEnvironmentValueParams,
) (*entity.PipelineSettingValue, error) {
	var m model.PipelineSettingEnvironment
	stmt := tx.Model(m)
	stmt = stmt.Where("`deleted` = ?", 0).Where("`id` = ?", params.ID)

	if params.Project != nil && *params.Project != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.ProjectSection.String(),
		).Where(
			"section_name = ?", *params.Project,
		)
	} else if params.Studio != nil && *params.Studio != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.StudioSection.String(),
		).Where(
			"section_name = ?", *params.Studio,
		)
	} else if params.Common != nil && *params.Common != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.CommonSection.String(),
		).Where(
			"section_name = ?", *params.Common,
		)
	} else {
		return nil, errors.New("no section info")
	}
	value, err := json.Marshal(params.Value)
	if err != nil {
		return nil, fmt.Errorf(
			"%w: invalid schema", entity.ErrBadRequest,
		)
	}
	now := time.Now().UTC()
	result := stmt.Updates(model.PipelineSettingEnvironment{
		Value:         value,
		ModifiedAtUTC: &now,
		ModifiedBy:    params.ModifiedBy,
	})
	if err := result.Error; err != nil {
		return nil, err
	}
	envParams := &entity.GetEnvironmentValueParams{
		Group:   entity.Environment,
		Common:  params.Common,
		Studio:  params.Studio,
		Project: params.Project,
		ID:      params.ID,
	}
	model, err := r.GetEnvironmentValue(tx, envParams)
	if err != nil {
		return nil, err
	}

	return model, nil
}

func (r *PipelineSetting) DeleteValue(
	tx *gorm.DB,
	params *entity.DeletePipelineSettingValueParams,
) error {
	var m model.PipelineSettingValueEntry
	tx, err := m.StmtWithGroup(tx, params.Group)
	if err != nil {
		return err
	}

	stmt := tx.Where("`deleted` = ?", 0).Where("`key` = ?", params.Key)
	if params.Project != nil && *params.Project != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.ProjectSection.String(),
		).Where(
			"section_name = ?", *params.Project,
		)
	} else if params.Studio != nil && *params.Studio != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.StudioSection.String(),
		).Where(
			"section_name = ?", *params.Studio,
		)
	} else if params.Common != nil && *params.Common != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.CommonSection.String(),
		).Where(
			"section_name = ?", *params.Common,
		)
	} else {
		return errors.New("no section info")
	}

	if err := stmt.Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: value with key %q not found", entity.ErrRecordNotFound, params.Key,
			)
		}
	}

	now := time.Now().UTC()

	m.Deleted = m.ID
	m.ModifiedAtUTC = &now
	m.ModifiedBy = params.ModifiedBy
	return tx.Save(m).Error
}

func (r *PipelineSetting) DeleteEnvironmentValue(
	tx *gorm.DB,
	params *entity.DeleteEnvironmentValueParams,
) error {
	var m model.PipelineSettingEnvironment
	stmt := tx.Model(m)
	stmt = stmt.Where("`deleted` = ?", 0).Where("`id` = ?", params.ID)

	if params.Project != nil && *params.Project != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.ProjectSection.String(),
		).Where(
			"section_name = ?", *params.Project,
		)
	} else if params.Studio != nil && *params.Studio != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.StudioSection.String(),
		).Where(
			"section_name = ?", *params.Studio,
		)
	} else if params.Common != nil && *params.Common != "" {
		stmt = stmt.Where(
			"section_type = ?", entity.CommonSection.String(),
		).Where(
			"section_name = ?", *params.Common,
		)
	} else {
		return errors.New("no section info")
	}

	if err := stmt.Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return fmt.Errorf(
				"%w: value with id %q not found", entity.ErrRecordNotFound, params.ID,
			)
		}
	}

	now := time.Now().UTC()

	m.Deleted = m.ID
	m.ModifiedAtUTC = &now
	m.ModifiedBy = params.ModifiedBy
	return tx.Save(m).Error
}

func (r *PipelineSetting) valueEntity(
	tx *gorm.DB,
	group entity.PipelineSettingGroup,
	m *model.PipelineSettingValueEntry,
) (*entity.PipelineSettingValue, error) {
	section, _ := entity.ParsePipelineSettingSection(m.SectionType)
	property, err := r.GetProperty(tx, &entity.GetPipelineSettingPropertyParams{
		Group:   group,
		Section: &section,
		Key:     m.Key,
	})
	if err != nil {
		if group == entity.Config {
			return nil, fmt.Errorf(
				"%w: property with key %q in section %q not found",
				entity.ErrRecordNotFound, m.Key, m.SectionType,
			)
		}
		return nil, fmt.Errorf(
			"%w: property with key %q not found",
			entity.ErrRecordNotFound, m.Key,
		)
	}
	return m.Entity(group, property.Schema)
}

func (r *PipelineSetting) environmentValueEntity(
	tx *gorm.DB,
	group entity.PipelineSettingGroup,
	m *model.PipelineSettingEnvironment,
) (*entity.PipelineSettingValue, error) {
	fmt.Println("environmentValueEntity")
	fmt.Println("environmentValueEntity")
	section, _ := entity.ParsePipelineSettingSection(m.SectionType)
	property, err := r.GetEnvironmentProperty(tx, &entity.GetEnvironmentPropertyParams{
		Section: &section,
		Key:     m.PropKey,
	})

	fmt.Println(property)
	fmt.Println(err)
	if err != nil {
		return nil, fmt.Errorf(
			"%w: property with key %q not found",
			entity.ErrRecordNotFound, m.PropKey,
		)
	}
	return m.Entity(group, property.Schema)
}
