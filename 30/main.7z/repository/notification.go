package repository

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"html/template"
	"io"
	"log"
	"log/slog"
	"net/http"
	"net/mail"
	"net/smtp"
	"os"
	"sort"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	notif "github.com/PolygonPictures/central30-web/front/repository/notification"
	"google.golang.org/api/chat/v1"
	"gorm.io/gorm"
)

type Notification struct {
	db              *gorm.DB
	settingRepo     *PipelineSetting
	projectWebhooks string
	systemWebhook   string
}

func NewNotification(
	db *gorm.DB,
	settingRepo *PipelineSetting,
) (*Notification, error) {
	projectWebhooks := os.Getenv("PPIP30_GOOGLECHAT_WEBHOOK_PROJECT")
	if projectWebhooks == "" {
		slog.Warn("projectWebhook is not set")
	}
	systemWebhook := os.Getenv("PPIP30_GOOGLECHAT_WEBHOOK_SYSTEM")
	if systemWebhook == "" {
		slog.Warn("systemWebhook is not set")
	}
	return &Notification{
		db:              db,
		settingRepo:     settingRepo,
		projectWebhooks: projectWebhooks,
		systemWebhook:   systemWebhook,
	}, nil
}

func (r *Notification) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *Notification) SendPublishNotification(
	db *gorm.DB,
	lgr entity.Logger,
	e *entity.PublishTransactionInfoNotification,
) error {
	issendemailinfo, ok := e.AdditionalInfo["is_send_email"]
	// success without sending email
	if !ok {
		return errors.New("[EmailSender] flag `is_send_email` is not found")
	}

	issendemail, ok := issendemailinfo.(bool)
	if !ok {
		return errors.New("[EmailSender] failed to convert Flag `is_send_email` into bool")
	}
	if !issendemail {
		return errors.New("[EmailSender] flag `is_send_email` is false")
	}

	// success without sending email
	if e.Operation == "download" ||
		e.Operation == "upload" && e.Event == "completed" ||
		e.Event == "start" ||
		*e.Component == "_org" ||
		*e.Component == "_tmb" {
		return errors.New("[EmailSender] untargetted Operation/Event/Component")
	}

	componentType := "components"
	if *e.Component == "_raw" {
		componentType = "preComponents"
	}
	if *e.Component == "_review" {
		componentType = "postComponents"
	}

	// send email on publishing as notification
	shortpath := strings.Join(strings.Split(e.RevisionPath, "/")[2:], "/")
	user := e.User
	computer := e.Computer
	toolname := e.ToolName
	toolversion := e.ToolVersion
	publishedtime := e.PublishedTime
	displaynamekey := "displayName"
	studio := e.Studio
	componentkey := fmt.Sprintf(
		"/ppip/roots/%s/phases/%s/%s/%s/emailAddress",
		*e.Root,
		*e.Phase,
		componentType,
		*e.Component,
	)
	setting, err := r.getPipelineSettingValue(
		db,
		entity.Preference,
		nil,
		nil,
		&e.Project,
		componentkey,
	)
	if setting == nil {
		return fmt.Errorf(
			"[EmailSender] email address is not set to pipeline setting: %s",
			componentkey,
		)
	}
	if err != nil {
		return fmt.Errorf("[EmailSender] error in fetching email pipeliine setting: %e", err)
	}
	studiosetting, err := r.getPipelineSettingValue(
		db,
		entity.Config,
		nil,
		&studio,
		nil,
		displaynamekey,
	)
	if err != nil {
		lgr.Warn("[EmailSender] error in finding studio setting: " + err.Error())
	}
	if studiosetting == nil {
		msg := fmt.Sprintf(
			"[EmailSender] failed to fetch studio pipeline setting: %s",
			displaynamekey,
		)
		lgr.Warn(msg)
	} else {
		studiodispname, ok := studiosetting.(string)
		if !ok {
			msg := fmt.Sprintf(
				"[EmailSender] failed to convert pipeline setting into string: %s\n",
				displaynamekey,
			)
			lgr.Warn(msg)
		} else {
			studio = studiodispname
		}
	}
	project := e.Project
	projectsetting, err := r.getPipelineSettingValue(
		db,
		entity.Config,
		nil,
		nil,
		&project,
		displaynamekey,
	)
	if err != nil {
		lgr.Warn("[EmailSender] error in finding project setting: " + err.Error())
	}
	if projectsetting == nil {
		msg := fmt.Sprintf(
			"[EmailSender] failed to fetch project pipeline setting: %s",
			displaynamekey,
		)
		lgr.Warn(msg)
	} else {
		projectdispname, ok := projectsetting.(string)
		if !ok {
			msg := fmt.Sprintf(
				"[EmailSender] failed to convert pipeline setting into string: %s\n",
				displaynamekey,
			)
			lgr.Warn(msg)
		} else {
			project = projectdispname
		}
	}
	operation := e.Operation
	if *e.Component == "_raw" {
		operation = "pre-publish"
	}
	subject := fmt.Sprintf(
		"[%s][%s] %s %s: %s",
		project,
		studio,
		operation,
		e.Event,
		shortpath,
	)
	bodydata := entity.PublishNotificationTemplateData{
		StudioDisplayName:  studio,
		StudioKeyName:      e.Studio,
		ProjectDisplayName: project,
		ProjectKeyName:     e.Project,
		RevisionPath:       shortpath,
		TaskID:             e.TaskID,
		SubTaskID:          e.SubtaskID,
		User:               user,
		Computer:           computer,
		ToolName:           toolname,
		ToolVersion:        toolversion,
	}
	if e.PublishedTime != nil {
		strdate := fmt.Sprint(publishedtime)
		timezonekey := "timezone"
		setting, err := r.getPipelineSettingValue(
			db,
			entity.Config,
			nil,
			&e.Studio,
			nil,
			timezonekey,
		)
		if err != nil || setting == nil {
			lgr.Info("[EmailSender] timezone is not found: " + err.Error())
		} else {
			timezone := setting.(string)
			loc, err := time.LoadLocation(timezone)
			if err != nil {
				lgr.Warn("[EmailSender] error in loading location by timezone: " + err.Error())
			} else {
				strdate = fmt.Sprint(publishedtime.In(loc))
			}
		}
		bodydata.PublishedTime = &strdate
	}
	toaddr := setting.([]string)
	serveraddr := "10.1.10.5:25"
	entry := "default"
	rawConfig, err := r.getPipelineSettingValue(
		db,
		entity.Config,
		&entry,
		nil,
		nil,
		"mailServerAddress",
	)
	if err == nil && rawConfig != nil {
		if strConfig, ok := rawConfig.(string); ok {
			serveraddr = strConfig
		}
	}
	sendername := os.Getenv("PPI_EMAIL_SENDER_NAME")
	if sendername == "" {
		sendername = "noreply@ppi.co.jp"
	}
	senderaddr := os.Getenv("PPI_EMAIL_SENDER_ADDRESS")
	if senderaddr == "" {
		senderaddr = "noreply@ppi.co.jp"
	}
	sender := mail.Address{
		Name:    sendername,
		Address: senderaddr,
	}
	if e.Event == "failed" {
		bodydata.StackTrace = e.StackTrace
		// Currently hard coding, gonna fetch from default later
		toaddr = append(toaddr, "pipeline30@ppi.co.jp")
	}
	t, err := template.ParseFiles("template/publishEmail.html")
	if err != nil {
		return errors.New("[EmailSender] failed to parse html template")
	}
	var bodybytes bytes.Buffer
	if err := t.Execute(&bodybytes, bodydata); err != nil {
		return errors.New("[EmailSender] failed to apply a parsed template")
	}

	if err := notif.CheckPublishEmailDomainRestriction(toaddr, e.Project); err != nil {
		return fmt.Errorf("[EmailSender] failed to send publish notification: %s", err.Error())
	}

	maildata := buildEmail(&entity.EmailData{
		Sender:  sender.Address,
		To:      toaddr,
		Subject: subject,
		Body:    bodybytes.String(),
	})
	// call sender functions with goroutine
	go r.sendEmail(
		&entity.EmailSenderInfo{
			Server:  serveraddr,
			Subject: subject,
			Sender:  &sender,
			To:      toaddr,
			Cc:      nil,
			Message: maildata,
		},
		5,
		[]error{},
	)
	message := chat.Message{
		Cards: []*chat.Card{
			{
				Header: &chat.CardHeader{
					Title:    fmt.Sprintf("%s: %s", operation, e.Event),
					Subtitle: fmt.Sprintf("%s (%s)", studio, e.Studio),
				},
				Sections: []*chat.Section{
					{
						Widgets: []*chat.WidgetMarkup{
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Revision Path",
									Content:          e.RevisionPath,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Task ID",
									Content:          e.TaskID,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Subtask ID",
									Content:          e.SubtaskID,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "User",
									Content:          *user,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Computer",
									Content:          *computer,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Tool Name",
									Content:          *toolname,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Tool Version",
									Content:          *toolversion,
									ContentMultiline: true,
								},
							},
							{
								Buttons: []*chat.Button{
									{
										TextButton: &chat.TextButton{
											Text: "Button to Do Something",
											OnClick: &chat.OnClick{
												OpenLink: &chat.OpenLink{
													Url: "https://pkg.go.dev/google.golang.org/api@v0.33.0/chat/v1#OnClick",
												},
											},
										},
									},
								},
							},
						},
					},
				},
			},
		},
	}

	projectWebhooks := strings.Split(r.projectWebhooks, ",")
	webhookURL := ""

	for _, projectWebhook := range projectWebhooks {
		webhookInfo := strings.Split(projectWebhook, "@")
		if webhookInfo[0] == e.Project {
			webhookURL = webhookInfo[1]
			break
		}
	}

	go r.sendChatMessage(&entity.ChatMessageSenderInfo{
		Webhook: webhookURL,
		Message: &message,
	})
	return nil
}

func (r *Notification) SendReviewStatusNotification(
	db *gorm.DB,
	e *entity.ReviewStatusLogNotification,
) {
	projectDisplayName := e.Project
	displayNameKey := "displayName"
	rawConfig, err := r.getPipelineSettingValue(
		db,
		entity.Config,
		nil,
		nil,
		&e.Project,
		displayNameKey,
	)
	if err != nil {
		log.Println("[EmailSender] Error in finding project setting: " + err.Error())
	}
	if rawConfig == nil {
		log.Printf(
			"[EmailSender] Failed to fetch project pipeline setting: %s",
			displayNameKey,
		)
	} else {
		config, ok := rawConfig.(string)
		if !ok {
			log.Printf(
				"[EmailSender] Failed to convert pipeline setting into string: %s\n",
				displayNameKey,
			)
		} else {
			projectDisplayName = config
		}
	}
	toEmails := e.MailAddresses
	ccEmails := e.MailCCAddresses
	subject := fmt.Sprintf("[%s (%s)] %s", projectDisplayName, e.Project, e.MailSubject)
	metaParams := &entity.MetaParams{
		Studio:        e.Studio,
		Project:       fmt.Sprintf("%s (%s)", projectDisplayName, e.Project),
		UpdateID:      e.UpdateID,
		ModifiedAtUTC: e.ModifiedAtUTC,
		ModifiedBy:    e.ModifiedBy,
		TakeList:      e.TakeList,
		RelationList:  e.RelationList,
		PhaseList:     e.PhaseList,
		EmailToList:   toEmails,
		EmailCcList:   ccEmails,
	}
	langs := make([]string, 0, len(*e.LangSet))
	for lang := range *e.LangSet {
		langs = append(langs, lang)
	}
	sort.Strings(langs)
	t, err := template.ParseFiles("template/reviewEmail.html")
	if err != nil {
		message := errorMessageTemplate(subject, err.Error())
		go r.sendChatMessage(&entity.ChatMessageSenderInfo{
			Webhook: r.systemWebhook,
			Message: message,
		})
		return
	}
	var bodybytes bytes.Buffer
	bodydata := entity.ReviewEmailTemplateData{
		Message: e.MailComment,
		Items:   e.TableParamsList,
		Langs:   langs,
	}
	if err := t.Execute(&bodybytes, bodydata); err != nil {
		message := errorMessageTemplate(subject, err.Error())
		go r.sendChatMessage(&entity.ChatMessageSenderInfo{
			Webhook: r.systemWebhook,
			Message: message,
		})
		return
	}
	serveraddr := "10.1.10.5:25"
	entry := "default"
	rawConfig, err = r.getPipelineSettingValue(
		db,
		entity.Config,
		&entry,
		nil,
		nil,
		"mailServerAddress",
	)
	if err == nil && rawConfig != nil {
		if strConfig, ok := rawConfig.(string); ok {
			serveraddr = strConfig
		}
	}
	sendername := os.Getenv("PPI_EMAIL_SENDER_NAME")
	if sendername == "" {
		sendername = "noreply@ppi.co.jp"
	}
	senderaddr := os.Getenv("PPI_EMAIL_SENDER_ADDRESS")
	if senderaddr == "" {
		senderaddr = "noreply@ppi.co.jp"
	}
	maildata := buildEmailWithMetadata(&entity.EmailDataWithMeta{
		Sender:     senderaddr,
		To:         toEmails,
		Cc:         ccEmails,
		Subject:    subject,
		Body:       bodybytes.String(),
		MetaParams: metaParams,
	})
	sender := mail.Address{
		Name:    sendername,
		Address: senderaddr,
	}
	go r.sendEmail(
		&entity.EmailSenderInfo{
			Server:  serveraddr,
			Subject: subject,
			Sender:  &sender,
			To:      toEmails,
			Cc:      ccEmails,
			Message: maildata,
		},
		5,
		[]error{},
	)
}

func (r *Notification) SendApiProcessFailure(err *entity.ApiProcessError) {
	message := chat.Message{
		Cards: []*chat.Card{
			{
				Header: &chat.CardHeader{
					Title:    err.Title,
					Subtitle: err.Studio,
				},
				Sections: []*chat.Section{
					{
						Widgets: []*chat.WidgetMarkup{
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         err.InfoLabel,
									Content:          err.InfoContent,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Error",
									Content:          err.Error.Error(),
									ContentMultiline: true,
								},
							},
						},
					},
				},
			},
		},
	}

	go r.sendChatMessage(&entity.ChatMessageSenderInfo{
		Webhook: r.systemWebhook,
		Message: &message,
	})
}

func (r *Notification) SendGeneralFailure(err error) {
	message := errorMessageTemplate("", err.Error())

	go r.sendChatMessage(&entity.ChatMessageSenderInfo{
		Webhook: r.systemWebhook,
		Message: message,
	})
}

func (r *Notification) getPipelineSettingValue(
	db *gorm.DB,
	group entity.PipelineSettingGroup,
	common *string,
	studio *string,
	project *string,
	key string,
) (interface{}, error) {
	getPipelineSettingValueParams := &entity.GetPipelineSettingValueParams{
		Group:     group,
		Common:    common,
		Studio:    studio,
		Project:   project,
		Key:       key,
		Composite: true,
	}
	prefval, err := r.settingRepo.GetValue(db, getPipelineSettingValueParams)
	if err != nil {
		return nil, err
	}
	return prefval.Value, nil
}

// supposed to be executed with goroutine
func (r *Notification) sendEmail(info *entity.EmailSenderInfo, retry uint8, errorStack []error) {
	if retry <= 0 {
		errorMessages := ""
		fmt.Println(errorStack)
		for _, err := range errorStack {
			errorMessages += err.Error() + "\n"
		}
		message := errorMessageTemplate(info.Subject, errorMessages)

		go r.sendChatMessage(&entity.ChatMessageSenderInfo{
			Webhook: r.systemWebhook,
			Message: message,
		})
		return
	}
	errorHandler := func(err error) {
		errorStack = append(errorStack, err)
		time.Sleep(time.Minute)
		r.sendEmail(info, retry-1, errorStack)
	}
	mc, err := smtp.Dial(info.Server)
	if err != nil {
		errorHandler(err)
		return
	}
	defer mc.Close()
	if err = mc.Mail(info.Sender.String()); err != nil {
		errorHandler(err)
		return
	}
	for _, addr := range info.To {
		if err = mc.Rcpt(addr); err != nil {
			errorHandler(err)
			return
		}
	}
	for _, ccaddr := range info.Cc {
		if err = mc.Rcpt(ccaddr); err != nil {
			errorHandler(err)
			return
		}
	}
	w, err := mc.Data()
	if err != nil {
		errorHandler(err)
		return
	}
	_, err = w.Write(info.Message)
	if err != nil {
		errorHandler(err)
		return
	}
	err = w.Close()
	if err != nil {
		errorHandler(err)
		return
	}
	err = mc.Quit()
	if err != nil {
		errorHandler(err)
		return
	}
}

func (r *Notification) sendChatMessage(info *entity.ChatMessageSenderInfo) {
	payload, err := json.Marshal(info.Message)
	if err != nil {
		fmt.Println(err)
		return
	}
	resp, err := http.Post(info.Webhook, "application/json; charset=UTF-8", bytes.NewReader(payload))
	if err != nil {
		fmt.Println(err)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		fmt.Println(string(b))
	}
}

func buildEmail(data *entity.EmailData) []byte {
	var buf bytes.Buffer
	boundary := "my-boundary-779"
	// mail header
	buf.WriteString(fmt.Sprintf("From: %s\n", data.Sender))
	buf.WriteString(fmt.Sprintf("To: %s\n", strings.Join(data.To, ";")))
	if data.Cc != nil {
		buf.WriteString(fmt.Sprintf("Cc: %s\n", strings.Join(data.Cc, ";")))
	}
	buf.WriteString(fmt.Sprintf("Subject: %s\n", data.Subject))
	buf.WriteString("MIME-Version: 1.0\n")
	buf.WriteString(fmt.Sprintf("Content-Type: multipart/mixed; boundary=%s\n", boundary))
	buf.WriteString(fmt.Sprintf("\n--%s\n", boundary))
	// mail body
	buf.WriteString("Content-Type: text/html; charset=\"utf-8\"\n")
	buf.WriteString(fmt.Sprintf("\n%s", data.Body))
	return buf.Bytes()
}

func buildEmailWithMetadata(data *entity.EmailDataWithMeta) []byte {
	var buf bytes.Buffer
	studio := data.MetaParams.Studio
	project := data.MetaParams.Project
	t := time.Now().UTC()
	fileName := fmt.Sprintf("ppiReview_%s_%s_%s.json", studio, project, t.Format("20060102-150405"))
	buf.WriteString(fmt.Sprintf("From: %s\n", data.Sender))
	buf.WriteString(fmt.Sprintf("To: %s\n", strings.Join(data.To, ";")))
	buf.WriteString(fmt.Sprintf("Cc: %s\n", strings.Join(data.Cc, ";")))
	buf.WriteString(fmt.Sprintf("Subject: %s\n", data.Subject))
	boundary := "my-boundary-779"
	buf.WriteString("MIME-Version: 1.0\n")
	buf.WriteString(
		fmt.Sprintf("Content-Type: multipart/mixed; boundary=%s\n", boundary),
	)
	buf.WriteString(fmt.Sprintf("\n--%s\n", boundary))
	buf.WriteString("Content-Type: text/html; charset=\"utf-8\"\n")
	buf.WriteString(fmt.Sprintf("\n%s", data.Body))
	buf.WriteString(fmt.Sprintf("\n--%s\n", boundary))
	buf.WriteString("Content-Type: text/plain; charset=\"utf-8\"\n")
	buf.WriteString("Content-Transfer-Encoding: base64\n")
	buf.WriteString(fmt.Sprintf("Content-Disposition: attachment; filename=%s\n", fileName))
	buf.WriteString(fmt.Sprintf("Content-ID: <%s>\n\n", fileName))
	metaparamjson, err := json.Marshal(data.MetaParams)
	if err != nil {
		fmt.Println("JSON Marshal error:", err)
		return buf.Bytes()
	}
	var temp bytes.Buffer
	err = json.Indent(&temp, metaparamjson, "", "  ")
	if err != nil {
		panic(err)
	}
	metaparamjson = temp.Bytes()
	b := make([]byte, base64.StdEncoding.EncodedLen(len(metaparamjson)))
	base64.StdEncoding.Encode(b, metaparamjson)
	buf.Write(b)
	buf.WriteString(fmt.Sprintf("\n--%s", boundary))
	buf.WriteString("--")
	return buf.Bytes()
}

func errorMessageTemplate(subject string, message string) *chat.Message {
	return &chat.Message{
		Cards: []*chat.Card{
			{
				Header: &chat.CardHeader{
					Title: "failure in sending email",
				},
				Sections: []*chat.Section{
					{
						Widgets: []*chat.WidgetMarkup{
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Email Subject",
									Content:          subject,
									ContentMultiline: true,
								},
							},
							{
								KeyValue: &chat.KeyValue{
									TopLabel:         "Error",
									Content:          message,
									ContentMultiline: true,
								},
							},
						},
					},
				},
			},
		},
	}
}
