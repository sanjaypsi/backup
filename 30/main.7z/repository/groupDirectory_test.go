package repository

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGroupDirectoryAutoMigrate(t *testing.T) {
	_, err := NewGroupDirectory(testDB)
	require.Nil(t, err)
	assert.True(t, testDB.Migrator().HasTable("t_group_directory"))
}
