package repository

import (
	"testing"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/testutil"
)

func TestProjectInfoListReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	repo := newProjectInfoRepository(t)
	f := func(studioKeyName string) ([]*entity.ProjectInfo2, int, error) {
		params := entity.ListProjectInfoParams{Studio: studioKeyName}
		return repo.List(testDB, &params)
	}
	testutil.AssertProjectInfoList(t, testDB, f)
}

func TestProjectInfoGetReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	repo := newProjectInfoRepository(t)
	f := func(projectKeyName string) (*entity.ProjectInfo2, error) {
		params := entity.GetProjectInfoParams{KeyName: projectKeyName}
		return repo.Get(testDB, &params)
	}
	testutil.AssertProjectInfoGet(t, testDB, f)
}

func TestProjectInfoCreateReturnsDisplayName(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	repo := newProjectInfoRepository(t)
	f := func(projectKeyName string) (*entity.ProjectInfo2, error) {
		params := entity.CreateProjectInfoParams{KeyName: projectKeyName}
		return repo.Create(testDB, &params)
	}
	testutil.AssertProjectInfoCreate(t, testDB, f)
}

func newProjectInfoRepository(t *testing.T) *ProjectInfo {
	t.Helper()

	ps, err := NewProjectStudioMap(testDB)
	testutil.AssertNoError(t, err)

	repo, err := NewProjectInfo(testDB, ps)
	testutil.AssertNoError(t, err)

	return repo
}
