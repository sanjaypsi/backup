package repository

import (
	"encoding/json"
	"reflect"
	"strings"

	"github.com/PolygonPictures/central30-web/front/entity"
	"gorm.io/gorm"
)

func column(name string) string {
	return "`" + name + "`"
}

func orderBy(stmt *gorm.DB, orderBy []string) *gorm.DB {
	for _, orderBy := range orderBy {
		if strings.HasPrefix(orderBy, "-") {
			stmt = stmt.Order(column(strings.TrimLeft(orderBy, "-")) + " desc")
		} else {
			stmt = stmt.Order(column(orderBy))
		}
	}
	return stmt
}

func limitOffset(stmt *gorm.DB, params *entity.BaseListParams) *gorm.DB {
	if params != nil {
		perPage := params.GetPerPage()
		offset := perPage * (params.GetPage() - 1)
		stmt = stmt.Limit(perPage).Offset(offset)
	}
	return stmt
}

// JSONBytesEqual compares the JSON in two byte slices.
func JSONBytesEqual(a, b []byte) (bool, error) {
	var j, j2 interface{}
	if err := json.Unmarshal(a, &j); err != nil {
		return false, err
	}
	if err := json.Unmarshal(b, &j2); err != nil {
		return false, err
	}
	return reflect.DeepEqual(j2, j), nil
}
