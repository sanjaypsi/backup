package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/go-sql-driver/mysql"

	"github.com/PolygonPictures/central30-web/front/repository/model"
	"gorm.io/gorm"
)

type ProjectInfo struct {
	db *gorm.DB
	ps *ProjectStudioMap
}

func NewProjectInfo(db *gorm.DB, ps *ProjectStudioMap) (*ProjectInfo, error) {
	if err := db.AutoMigrate(&model.ProjectInfo{}); err != nil {
		return nil, err
	}
	return &ProjectInfo{
		db: db,
		ps: ps,
	}, nil
}

func (r *ProjectInfo) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *ProjectInfo) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *ProjectInfo) List(
	db *gorm.DB,
	params *entity.ListProjectInfoParams,
) ([]*entity.ProjectInfo2, int, error) {
	mappings, _, err := r.ps.List(db, &entity.ListProjectStudioMapParams{Studio: &params.Studio})
	if err != nil {
		return nil, 0, err
	}
	var projects []string
	for _, mapping := range mappings {
		projects = append(projects, mapping.Project)
	}

	projectQuery := db.Model(&model.ProjectInfo{}).Select("*")
	if len(projects) > 0 {
		projectQuery = projectQuery.Where("`name` IN (?)", projects)
	}
	projectQuery = projectQuery.Where("`deleted` = 0")

	var total int64
	if err := projectQuery.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	displayNameQuery := db.Model(&model.ConfigEntry{}).Select("*").Where(
		"`section_type` = 'project'",
	)
	if len(projects) > 0 {
		displayNameQuery = displayNameQuery.Where(
			"`section_name` IN (?)", projects,
		)
	}
	displayNameQuery = displayNameQuery.Where(
		"`key` = 'displayName'",
	).Where(
		"`deleted` = 0",
	)

	stmt := db.Table("(?) AS p", projectQuery).Select(
		strings.Join([]string{
			"p.name AS key_name",
			"c.value AS display_name",
			"p.created_at_utc",
			"p.modified_at_utc",
			"p.modified_by",
			"p.created_by",
			"p.id",
		}, ", "),
	).Joins("LEFT OUTER JOIN (?) AS c ON p.name = c.section_name", displayNameQuery)

	if params.BaseListParams != nil {
		perPage := params.GetPerPage()
		offset := perPage * (params.GetPage() - 1)
		stmt = stmt.Limit(perPage).Offset(offset)
	}

	var entities []*entity.ProjectInfo2
	result := stmt.Scan(&entities)
	if err := result.Error; err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, 0, entity.ErrInternalServerError
	}

	for _, e := range entities {
		e.Repo = r.ps
	}

	return entities, int(total), nil
}

func (r *ProjectInfo) Get(
	db *gorm.DB,
	params *entity.GetProjectInfoParams,
) (*entity.ProjectInfo2, error) {
	projectQuery := db.Model(&model.ProjectInfo{}).Select("*").Where(
		"`name` = ?", params.KeyName,
	).Where(
		"`deleted` = 0",
	)

	displayNameQuery := db.Model(&model.ConfigEntry{}).Select("*").Where(
		"`section_type` = 'project'",
	).Where(
		"`section_name` = ?", params.KeyName,
	).Where(
		"`key` = 'displayName'",
	).Where(
		"`deleted` = 0",
	)

	stmt := db.Table("(?) AS p", projectQuery).Select(
		strings.Join([]string{
			"p.name AS key_name",
			"c.value AS display_name",
			"p.created_at_utc",
			"p.modified_at_utc",
			"p.modified_by",
			"p.created_by",
			"p.id",
		}, ", "),
	).Joins("LEFT OUTER JOIN (?) AS c ON p.name = c.section_name", displayNameQuery)

	var e entity.ProjectInfo2
	result := stmt.Scan(&e)
	if err := result.Error; err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, entity.ErrInternalServerError
	}
	if result.RowsAffected == 0 {
		return nil, entity.ErrRecordNotFound
	}
	e.Repo = r.ps
	return &e, nil
}

func (r *ProjectInfo) Create(
	tx *gorm.DB,
	params *entity.CreateProjectInfoParams,
) (*entity.ProjectInfo2, error) {
	m := model.NewProjectInfo(params)
	if err := tx.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: project with key name %q already exists",
				entity.ErrBadRequest, params.KeyName,
			)
		}
		return nil, err
	}

	e := m.Entity(r.ps)

	var cm model.ConfigEntry
	if err := tx.Select("*").Where(
		"`section_type` = 'project'",
	).Where(
		"`section_name` = ?", params.KeyName,
	).Where(
		"`key` = 'displayName'",
	).Where(
		"`deleted` = 0",
	).Take(&cm).Error; err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, entity.ErrInternalServerError
	}
	e.DisplayName = cm.Value

	return e, nil
}

func (r *ProjectInfo) Delete(
	tx *gorm.DB,
	params *entity.DeleteProjectInfoParams,
) error {
	now := time.Now().UTC()

	// Delete the record related to the project from the table "t_project_studio_map"
	if err := tx.Model(model.ProjectStudioMap{}).Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.KeyName,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": now,
		"modified_by":     params.ModifiedBy,
	}).Error; err != nil {
		return err
	}

	// Delete the project from the table "t_studio_info"
	var m model.ProjectInfo
	if err := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`name` = ?", params.KeyName,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return entity.ErrRecordNotFound
		}
		return err
	}
	m.Deleted = m.ID
	m.ModifiedAtUTC = &now
	m.ModifiedBy = params.ModifiedBy
	return tx.Save(m).Error
}
