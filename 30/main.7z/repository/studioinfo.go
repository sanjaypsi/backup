package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/go-sql-driver/mysql"

	"github.com/PolygonPictures/central30-web/front/repository/model"
	"gorm.io/gorm"
)

func NewStudioInfo(db *gorm.DB) (*StudioInfo, error) {
	if err := db.AutoMigrate(&model.StudioInfo{}, &model.ProjectStudioMap{}); err != nil {
		return nil, err
	}
	if err := db.Model(&model.StudioInfo{}).Association("Projects").Error; err != nil {
		return nil, err
	}
	return &StudioInfo{
		db: db,
	}, nil
}

type StudioInfo struct {
	db *gorm.DB
}

func (r *StudioInfo) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *StudioInfo) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *StudioInfo) List(
	db *gorm.DB,
	params *entity.ListStudioInfoParams,
) ([]*entity.StudioInfo2, int, error) {
	stmt := db.Where("`deleted` = ?", 0)
	if params.Studio != "ppi" && params.Studio != "ppidev" {
		stmt.Where("`name` = ?", params.Studio)
	}
	var total int64
	var m model.StudioInfo
	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	if params.BaseListParams != nil {
		perPage := params.GetPerPage()
		offset := perPage * (params.GetPage() - 1)
		stmt = stmt.Limit(perPage).Offset(offset)
	}

	var models []*model.StudioInfo
	if err := stmt.Preload("Projects", "`deleted` = ?", 0).Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.StudioInfo2
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, int(total), nil
}

func (r *StudioInfo) Get(
	db *gorm.DB,
	params *entity.GetStudioInfoParams,
) (*entity.StudioInfo2, error) {
	m, err := r.get(db, params)
	if err != nil {
		return nil, err
	}
	return m.Entity(), nil
}

func (r *StudioInfo) get(
	db *gorm.DB,
	params *entity.GetStudioInfoParams,
) (*model.StudioInfo, error) {
	var m model.StudioInfo
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`name` = ?", params.KeyName,
	).Preload(
		"Projects", "`deleted` = ?", 0,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	return &m, nil
}

func (r *StudioInfo) Create(
	tx *gorm.DB,
	params *entity.CreateStudioInfoParams,
) (*entity.StudioInfo2, error) {
	m := model.NewStudioInfo(params)
	if err := tx.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			return nil, fmt.Errorf(
				"%w: studio with key name %q already exists",
				entity.ErrBadRequest, params.KeyName,
			)
		}
		return nil, err
	}
	return m.Entity(), nil
}

func (r *StudioInfo) Update(
	tx *gorm.DB,
	params *entity.UpdateStudioParams,
) (*entity.StudioInfo2, error) {
	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}

	switch params.Operation {
	case "add":
		var entiries []*model.ProjectStudioMap
		for _, projectName := range params.Projects {
			entry := model.NewProjectStudioMap(&entity.CreateProjectStudioMapParams{
				Project:   projectName,
				Studio:    params.KeyName,
				CreatedBy: &modifiedBy,
			})
			entiries = append(entiries, entry)
		}
		if err := tx.Create(&entiries).Error; err != nil {
			var mysqlErr *mysql.MySQLError
			if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
				return nil, fmt.Errorf(
					"%w: one of the projects %q is already exists",
					entity.ErrBadRequest, params.Projects,
				)
			}
		}
	case "remove":
		var mm *model.ProjectStudioMap
		result := tx.Model(&mm).Where(
			"`deleted` = ?", 0,
		).Where(
			"`studio` = ?", params.KeyName,
		).Where(
			"`project` IN ?", params.Projects,
		).Updates(map[string]interface{}{
			"deleted":         gorm.Expr("id"),
			"modified_at_utc": now,
			"modified_by":     modifiedBy,
		})
		if err := result.Error; err != nil {
			return nil, err
		}
		if result.RowsAffected == 0 {
			return nil, fmt.Errorf(
				"%w: any of the projects %q not found", entity.ErrRecordNotFound, params.Projects,
			)
		}
	default:
		return nil, fmt.Errorf("invalid operation %q", params.Operation)
	}

	var sm *model.StudioInfo
	result := tx.Model(sm).Where(
		"`deleted` = ?", 0,
	).Where(
		"`name` = ?", params.KeyName,
	).Updates(map[string]interface{}{
		"modified_at_utc": now,
		"modified_by":     modifiedBy,
	})
	if err := result.Error; err != nil {
		return nil, err
	}
	if result.RowsAffected == 0 {
		return nil, fmt.Errorf(
			"%w: studio with keyName %q not found", entity.ErrRecordNotFound, params.KeyName,
		)
	}

	sm, err := r.get(tx, &entity.GetStudioInfoParams{
		KeyName: params.KeyName,
	})
	if err != nil {
		return nil, err
	}
	return sm.Entity(), nil
}

func (r *StudioInfo) Delete(
	tx *gorm.DB,
	params *entity.DeleteStudioInfoParams,
) error {
	now := time.Now().UTC()

	// Delete studio-related records from the table "t_project_studio_map"
	if err := tx.Model(model.ProjectStudioMap{}).Where(
		"`deleted` = ?", 0,
	).Where(
		"`studio` = ?", params.KeyName,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": now,
		"modified_by":     params.ModifiedBy,
	}).Error; err != nil {
		return err
	}

	// Remove the studio from the table "t_studio_info"
	var m model.StudioInfo
	if err := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`name` = ?", params.KeyName,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return entity.ErrRecordNotFound
		}
		return err
	}
	m.Deleted = m.ID
	m.ModifiedAtUTC = &now
	m.ModifiedBy = params.ModifiedBy
	return tx.Save(m).Error
}
