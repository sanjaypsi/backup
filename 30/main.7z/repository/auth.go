package repository

import (
	"context"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/golang-jwt/jwt"
	"gorm.io/gorm"
)

func loadPrivateKey(stringkey string) (*rsa.PrivateKey, error) {
	content := []byte(stringkey)
	block, _ := pem.Decode(content)
	if block == nil {
		return nil, errors.New("failed to decode PEM block containing private key")
	}
	if block.Type != entity.KeytypePrivate {
		return nil, fmt.Errorf("invalid private key type: %s", block.Type)
	}
	return x509.ParsePKCS1PrivateKey(block.Bytes)
}

func loadPublicKey(stringkey string) (interface{}, error) {
	content := []byte(stringkey)
	block, _ := pem.Decode(content)
	if block == nil {
		return nil, errors.New("failed to decode PEM block containing public key")
	}
	if block.Type != entity.KeytypePublic {
		return nil, fmt.Errorf("invalid public key type: %s", block.Type)
	}
	return x509.ParsePKIXPublicKey(block.Bytes)
}

type Auth struct {
	db              *gorm.DB
	ps              *ProjectStudioMap
	signingKey      *rsa.PrivateKey
	verificationKey interface{}
	stuRepo         *StudioInfo
}

func NewAuth(db *gorm.DB, ps *ProjectStudioMap, stuRepo *StudioInfo) (*Auth, error) {
	db.AutoMigrate(&model.StudioAuth{})
	signingKeyStr := os.Getenv("PPI_KEY_PRIVATE")
	verificationKeyStr := os.Getenv("PPI_KEY_PUBLIC")
	if signingKeyStr == "" || verificationKeyStr == "" {
		return nil, errors.New("key not found")
	}
	signingKey, err := loadPrivateKey(strings.Replace(signingKeyStr, `\n`, "\n", -1))
	if err != nil {
		return nil, err
	}
	verificationKey, err := loadPublicKey(strings.Replace(verificationKeyStr, `\n`, "\n", -1))
	if err != nil {
		return nil, err
	}
	return &Auth{
		db:              db,
		ps:              ps,
		signingKey:      signingKey,
		verificationKey: verificationKey,
		stuRepo:         stuRepo,
	}, nil
}

func (r *Auth) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

type Entry struct {
	Name string
}

type CustomClaims struct {
	*jwt.StandardClaims
	Section entity.Section
	Entry   Entry
}

func (r *Auth) ParseToken(db *gorm.DB, tokenStr string) (string, error) {
	token, err := r.parse(tokenStr)
	if err != nil {
		return "", entity.ErrUnauthorized
	}
	name := r.extractEntryName(token)
	if name == "" || r.checkForStudio(r.db, name) != nil {
		return "", entity.ErrUnauthorized
	}
	return name, nil
}

func (r *Auth) CheckProjectAccess(db *gorm.DB, params *entity.ProjectAccessParams) error {
	db.Model(&model.ProjectStudioMap{})
	mappings, _, err := r.ps.List(db, &entity.ListProjectStudioMapParams{Studio: &params.Studio})
	if err != nil {
		return err
	}
	for _, mapping := range mappings {
		if params.Project == mapping.Project {
			return nil
		}
	}
	return entity.ErrForbidden
}

func (r *Auth) CreateNewToken(entry string) (string, error) {
	t := jwt.New(jwt.GetSigningMethod(entity.Sign))
	t.Claims = &CustomClaims{
		&jwt.StandardClaims{
			ExpiresAt: time.Now().Add(time.Hour * 1).Unix(),
			IssuedAt:  time.Now().Unix(),
		},
		entity.StudioAuth,
		Entry{entry},
	}
	signedStr, err := t.SignedString(r.signingKey)
	if err != nil {
		return "", err
	}
	return signedStr, nil
}

func (r *Auth) Login(db *gorm.DB, params *entity.LoginParams) (string, error) {
	info, err := queryLoginInfo(db, params.Studio)
	if err != nil {
		return "", err
	}
	sha256 := sha256.Sum256([]byte(params.Password + info.Salt))
	hash := hex.EncodeToString(sha256[:])
	if info.Password != hash {
		return "", entity.ErrUnauthorized
	}
	return params.Studio, nil
}

func queryLoginInfo(db *gorm.DB, studio string) (*model.StudioAuth, error) {
	var m model.StudioAuth
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`studio` = ?", studio,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	return &m, nil
}

func (r *Auth) parse(tokenStr string) (*jwt.Token, error) {
	token, err := jwt.ParseWithClaims(
		tokenStr,
		&CustomClaims{},
		func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
				return nil, entity.ErrUnauthorized
			}
			return r.verificationKey, nil
		},
	)
	return token, err
}

func (r *Auth) extractEntryName(token *jwt.Token) string {
	if token == nil {
		return ""
	}
	entry := ""
	claim, ok := token.Claims.(*CustomClaims)
	if ok {
		entry = claim.Entry.Name
	}
	return entry
}

func (r *Auth) checkForStudio(db *gorm.DB, studio string) error {
	db.Model(&model.StudioInfo{})
	_, err := r.stuRepo.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	})
	return err
}
