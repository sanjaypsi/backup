package repository

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/entity/pipelineParameter"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"
)

type PipelineParameter struct {
	db *gorm.DB
}

func NewPipelineParameter(db *gorm.DB) (*PipelineParameter, error) {
	if err := db.AutoMigrate(
		&model.PipelineParameter{},
		&model.PipelineParameterLocation{},
		&model.PipelineParameterValue{},
	); err != nil {
		return nil, err
	}
	return &PipelineParameter{
		db: db,
	}, nil
}

func (r *PipelineParameter) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *PipelineParameter) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

// Parameter

func (r *PipelineParameter) ListParameterUpdates(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.ListParameterUpdatesParams,
) ([]*pipelineParameter.Parameter, uint, error) {
	stmt := db

	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
	}

	var total int64
	if err := stmt.Model(&model.PipelineParameter{}).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving the total number of parameters",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	stmt = orderBy(stmt, []string{"modified_at_utc"})
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.PipelineParameter
	if err := stmt.Find(&models).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of parameters",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	entities := make([]*pipelineParameter.Parameter, len(models))
	for i, m := range models {
		entities[i] = m.Entity(true)
	}
	return entities, uint(total), nil
}

func (r *PipelineParameter) ListParameters(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.ListParametersParams,
) ([]*pipelineParameter.Parameter, uint, error) {
	stmt := db.Where("`deleted` = ?", 0)

	var total int64
	var m model.PipelineParameter
	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving the total number of parameters",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.PipelineParameter
	if err := stmt.Find(&models).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of parameters",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	entities := make([]*pipelineParameter.Parameter, len(models))
	for i, m := range models {
		entities[i] = m.Entity(false)
	}
	return entities, uint(total), nil
}

func (r *PipelineParameter) GetParameter(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.GetParameterParams,
) (*pipelineParameter.Parameter, error) {
	var m model.PipelineParameter

	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_name` = ?", params.KeyName,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("parameter not found")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while retrieving the parameter")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (r *PipelineParameter) CreateParameter(
	tx *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.CreateParameterParams,
) (*pipelineParameter.Parameter, error) {
	m := model.NewPipelineParameter(params)

	if err := tx.Create(&m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			retErr := entity.NewConflictError("parameter already exists")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while creating a parameter")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (r *PipelineParameter) DeleteParameter(
	tx *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.DeleteParameterParams,
) error {
	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	var m *model.PipelineParameter

	result := tx.Model(m).Where(
		"`deleted` = ?", 0,
	).Where(
		"`key_name` = ?", params.KeyName,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": now,
		"modified_by":     modifiedBy,
	})
	if err := result.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("parameter not found")
			lgr.Warnf("%v: %v", retErr, err)
			return retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while deleting the parameter")
		lgr.Errorf("%v: %v", retErr, err)
		return retErr
	}

	if result.RowsAffected == 0 {
		retErr := entity.NewNotFoundError("parameter not found")
		lgr.Error(retErr.Error())
		return retErr
	}

	return nil
}

// Location

func (r *PipelineParameter) ListLocationUpdates(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.ListLocationUpdatesParams,
) ([]*pipelineParameter.Location, uint, error) {
	stmt := db.Where("`project` = ?", params.Project)

	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
	}

	var total int64
	if err := stmt.Model(&model.PipelineParameterLocation{}).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving the number of locations",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	stmt = orderBy(stmt, []string{"modified_at_utc"})
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.PipelineParameterLocation
	if err := stmt.Find(&models).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of locations",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	entities := make([]*pipelineParameter.Location, len(models))
	for i, m := range models {
		entities[i] = m.Entity(true)
	}
	return entities, uint(total), nil
}

func (p *PipelineParameter) ListLocations(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.ListLocationsParams,
) ([]*pipelineParameter.Location, uint, error) {
	stmt := db.Where("`deleted` = ?", 0).Where("`project` = ?", params.Project)

	if params.Parameter != nil {
		stmt = stmt.Where("`parameter` = ?", *params.Parameter)
	}

	var total int64
	if err := stmt.Model(&model.PipelineParameterLocation{}).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving the number of locations",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.PipelineParameterLocation
	if err := stmt.Find(&models).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving a list of locations",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	entities := make([]*pipelineParameter.Location, len(models))
	for i, m := range models {
		entities[i] = m.Entity(false)
	}
	return entities, uint(total), nil
}

func (p *PipelineParameter) GetLocation(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.GetLocationParams,
) (*pipelineParameter.Location, error) {
	var m model.PipelineParameterLocation
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("location not found")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while retrieving location")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (p *PipelineParameter) CreateLocation(
	tx *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.CreateLocationParams,
) (*pipelineParameter.Location, error) {
	m := model.NewPipelineParameterLocation(params)

	if err := tx.Create(&m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			retErr := entity.NewConflictError("location already exists")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while creating a location")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (p *PipelineParameter) DeleteLocation(
	tx *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.DeleteLocationParams,
) error {
	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	var m *model.PipelineParameterLocation

	result := tx.Model(m).Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`id` = ?", params.ID,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": now,
		"modified_by":     modifiedBy,
	})
	if err := result.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("location not found")
			lgr.Warnf("%v: %v", retErr, err)
			return retErr
		}

		retErr := entity.NewBadGatewayError("could not delete the location")
		lgr.Errorf("%v: %v", retErr, err)
		return retErr
	}

	if result.RowsAffected == 0 {
		retErr := entity.NewNotFoundError("could not delete location")
		lgr.Error(retErr.Error())
		return retErr
	}

	return nil
}

// Value

func (r *PipelineParameter) ListValueUpdates(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.ListValueUpdatesParams,
) ([]*pipelineParameter.Value, uint, error) {
	var studio string
	if params.Studio != nil {
		studio = *params.Studio
	}
	var project string
	if params.Project != nil {
		project = *params.Project
	}
	stmt := db.Where("`studio` = ?", studio).Where("`project` = ?", project)

	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
	}

	var total int64
	if err := stmt.Model(&model.PipelineParameterValue{}).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieve the number of values",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	stmt = orderBy(stmt, []string{"modified_at_utc"})
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.PipelineParameterValue
	if err := stmt.Find(&models).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving the list of values",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	entities := make([]*pipelineParameter.Value, len(models))
	for i, m := range models {
		entities[i] = m.Entity(true)
	}
	return entities, uint(total), nil
}

func (r *PipelineParameter) CountValues(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.GetParameterParams,
) (uint, error) {
	var total int64
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`parameter` = ?", params.KeyName,
	).Model(&model.PipelineParameterValue{}).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return 0, nil
		}

		retErr := entity.NewBadGatewayError(
			"a problem occurred while retrieving the number of values",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return 0, retErr
	}

	return uint(total), nil
}

func (r *PipelineParameter) ListValues(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.ListValuesParams,
) ([]*pipelineParameter.Value, uint, error) {
	stmt := db.Where("`deleted` = ?", 0)

	if params.Parameter != nil {
		stmt = stmt.Where("`parameter` = ?", *params.Parameter)
	}

	if params.FilterParameter != nil {
		stmt = stmt.Where("`parameter` LIKE CONCAT('%', ?, '%')", *params.FilterParameter)
	}

	if len(params.Projects) != 0 {
		stmt = stmt.Where("`project` IN ?", params.Projects)
	}

	if params.FilterProject != nil {
		stmt = stmt.Where("`project` LIKE CONCAT('%', ?, '%')", *params.FilterProject)
	}

	if len(params.Studios) != 0 {
		stmt = stmt.Where("`studio` IN ?", params.Studios)
	}

	if params.FilterStudio != nil {
		stmt = stmt.Where("`studio` LIKE CONCAT('%', ?, '%')", *params.FilterStudio)
	}

	if params.Location != nil {
		stmt = stmt.Where("`location` = ?", *params.Location)
	}

	if params.FilterLocation != nil {
		stmt = stmt.Where("`location` LIKE CONCAT('%', ?, '%')", *params.FilterLocation)
	}

	if params.FilterValue != nil {
		stmt = stmt.Where("`value` LIKE CONCAT('%', ?, '%')", *params.FilterValue)
	}

	var total int64
	if err := stmt.Model(&model.PipelineParameterValue{}).Count(&total).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadRequestError(
			"a problem occurred while retrieving the number of values",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.PipelineParameterValue
	if err := stmt.Find(&models).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, 0, nil
		}

		retErr := entity.NewBadRequestError(
			"a problem occurred while retrieving the list of values",
		)
		lgr.Errorf("%v: %v", retErr, err)
		return nil, 0, retErr
	}

	entities := make([]*pipelineParameter.Value, len(models))
	for i, m := range models {
		entities[i] = m.Entity(false)
	}
	return entities, uint(total), nil
}

func (r *PipelineParameter) GetValue(
	db *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.GetValueParams,
) (*pipelineParameter.Value, error) {
	var m model.PipelineParameterValue

	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("value not found")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while retrieving the value")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (r *PipelineParameter) CreateValue(
	tx *gorm.DB,
	lgr entity.Logger,
	params *pipelineParameter.CreateValueParams,
) (*pipelineParameter.Value, error) {
	m, err := model.NewPipelineParameterValue(lgr, params)
	if err != nil {
		return nil, err
	}

	if err := tx.Create(m).Error; err != nil {
		var mysqlErr *mysql.MySQLError
		if errors.As(err, &mysqlErr) && mysqlErr.Number == 1062 {
			retErr := entity.NewConflictError("value already exists")
			lgr.Errorf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while creating a value")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (r *PipelineParameter) UpdateValue(
	tx *gorm.DB,
	lgr entity.Logger,
	params *pipelineParameter.UpdateValueParams,
) (*pipelineParameter.Value, error) {
	var m model.PipelineParameterValue
	if err := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("value not found")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while updating the value")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	value, err := json.Marshal(params.Value)
	if err != nil {
		retErr := entity.NewBadRequestErrorf("could not marshal value: %v", params.Value)
		lgr.Warnf("%v: %v", retErr, err)
		return nil, retErr
	}

	equal, err := JSONBytesEqual(m.Value, value)
	if err != nil {
		retErr := entity.NewBadRequestError("could not marshal value")
		lgr.Warnf("%v: %v", retErr, err)
		return nil, retErr
	}
	if equal {
		retErr := entity.NewNotModifiedError("value are not modified")
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	m.Value = value
	m.ModifiedAtUTC = now
	m.ModifiedBy = modifiedBy
	result := tx.Model(&m).Select("*").Updates(m)

	if err := result.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("value not found")
			lgr.Warnf("%v: %v", retErr, err)
			return nil, retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while updating value")
		lgr.Errorf("%v: %v", retErr, err)
		return nil, retErr
	}

	if result.RowsAffected == 0 {
		retErr := entity.NewNotFoundError("value not found")
		lgr.Warn(retErr.Error())
		return nil, retErr
	}

	return m.Entity(false), nil
}

func (p *PipelineParameter) DeleteValue(
	tx *gorm.DB,
	lgr entity.Logger,
	params pipelineParameter.DeleteValueParams,
) error {
	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	var m *model.PipelineParameterValue

	result := tx.Model(m).Where(
		"`deleted` = ?", 0,
	).Where(
		"`id` = ?", params.ID,
	).Updates(map[string]interface{}{
		"deleted":         gorm.Expr("id"),
		"modified_at_utc": now,
		"modified_by":     modifiedBy,
	})
	if err := result.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			retErr := entity.NewNotFoundError("value not found")
			lgr.Warnf("%v: %v", retErr, err)
			return retErr
		}

		retErr := entity.NewBadGatewayError("a problem occurred while deleting value")
		lgr.Errorf("%v: %v")
		return retErr
	}

	if result.RowsAffected == 0 {
		retErr := entity.NewNotFoundError("value not found")
		lgr.Warn(retErr.Error())
		return retErr
	}

	return nil
}
