package repository

import (
	"context"
	"errors"
	"reflect"
	"testing"
	"time"

	"cloud.google.com/go/logging"
	"cloud.google.com/go/logging/logadmin"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type StubCloudLoggingFinder struct {
	Entry *logging.Entry
	Err   error
}

func (f StubCloudLoggingFinder) FindOne(
	ctx context.Context,
	opts ...logadmin.EntriesOption,
) (*logging.Entry, error) {
	return f.Entry, f.Err
}

func TestDataSyncClientGetStatus(t *testing.T) {
	gcpProject := "test_gcp_project"
	project := "potoodev"
	studio := "ppidev"
	ctx := context.Background()
	timestamp := time.Now()

	cases := []struct {
		name  string
		entry *logging.Entry
		err   error
		want  *entity.DataSyncClientStatus
	}{
		{
			name:  "healthy",
			entry: &logging.Entry{Timestamp: timestamp},
			err:   nil,
			want: &entity.DataSyncClientStatus{
				Project:     project,
				Studio:      studio,
				Status:      "healthy",
				ConfirmedAt: &timestamp,
			},
		},
		{
			name:  "unhealthy",
			entry: nil,
			err:   entity.ErrLogEntryNotFound,
			want: &entity.DataSyncClientStatus{
				Project:     project,
				Studio:      studio,
				Status:      "unhealthy",
				ConfirmedAt: nil,
			},
		},
	}

	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			finder := StubCloudLoggingFinder{
				Entry: test.entry,
				Err:   test.err,
			}
			client := NewDataSyncClient(finder, gcpProject)

			got, err := client.GetStatus(ctx, project, studio)
			if err != nil {
				t.Fatal(err)
			}

			if !reflect.DeepEqual(got, test.want) {
				t.Errorf("got %v, want %v", got, test.want)
			}
		})
	}

	t.Run("unexpected error", func(t *testing.T) {
		errUnexpected := errors.New("unexpected error")

		finder := StubCloudLoggingFinder{
			Entry: nil,
			Err:   errUnexpected,
		}
		client := NewDataSyncClient(finder, gcpProject)

		got, err := client.GetStatus(ctx, project, studio)
		if !errors.Is(err, errUnexpected) {
			t.Fatal(err)
		}

		if got != nil {
			t.Errorf("expected nil, got %v", got)
		}
	})
}
