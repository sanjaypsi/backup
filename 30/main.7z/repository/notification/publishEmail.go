package notification

import (
	"fmt"
	"slices"
	"strings"
)

type domainList []string

type domainRule map[string]domainList

var publishEmailDomainRule = domainRule{
	"drk": {
		"chayapictures.com",
		"ppi-my.com",
		"ppi.co.jp",
	},
}

var publishEmailDefaultDomains = domainList{
	"ppi-my.com",
	"ppi.co.jp",
}

func (dr domainRule) get(key string, fallback domainList) domainList {
	domains, ok := dr[key]
	if ok {
		return domains
	} else {
		return fallback
	}
}

func checkEmailAddressDomain(addrs []string, allowDomains domainList) error {
	var failures []string
	for _, addr := range addrs {
		parts := strings.Split(addr, "@")
		if len(parts) != 2 {
			continue
		}
		domain := parts[1]
		if !slices.Contains(allowDomains, domain) {
			failures = append(failures, addr)
		}
	}

	if len(failures) > 0 {
		return fmt.Errorf("failed to email address domain check: failures=%s, allow-domains: %s", failures, allowDomains)
	}

	return nil
}

// CheckPublishEmailDomainRestriction は、パブリッシュメールの送信先アドレス
// のドメイン名がプロジェクトで想定したものかどうかをチェックします。
//
// addrs はメールアドレスのリスト、project はプロジェクトキー名です。各メー
// ルアドレスのドメイン名が、全てプロジェクトで想定したものであれば nil を返
// し、想定外のドメイン名を持つメールアドレスが1つ以上あった場合はエラーを返
// します。
//
// プロジェクトで想定するドメイン名のリストは publishEmailDomainRule 変数か
// ら projectをキーにして取得されます。この変数に project のキーが存在しない
// 場合は、ドメイン名のリストとして publishEmailDefaultDomains が使用されま
// す。
func CheckPublishEmailDomainRestriction(addrs []string, project string) error {
	allowDomains := publishEmailDomainRule.get(project, publishEmailDefaultDomains)
	if err := checkEmailAddressDomain(addrs, allowDomains); err != nil {
		return fmt.Errorf("failed to publish email domain restriction check: project=%s: %s", project, err.Error())
	}

	return nil
}
