package notification

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestCheckEmailAddressDomain(t *testing.T) {
	tests := []struct {
		name    string
		addrs   []string
		allows  domainList
		success bool
	}{
		{
			name:    "success",
			addrs:   []string{"foo@ppi.co.jp"},
			allows:  domainList{"ppi.co.jp"},
			success: true,
		},
		{
			name:    "success (multiple addrs)",
			addrs:   []string{"foo@ppi.co.jp", "bar@ppi.co.jp"},
			allows:  domainList{"ppi.co.jp"},
			success: true,
		},
		{
			name:    "success (multiple allows, first match)",
			addrs:   []string{"foo@ppi.co.jp"},
			allows:  domainList{"ppi.co.jp", "ppi-my.com"},
			success: true,
		},
		{
			name:    "success (multiple allows, last match)",
			addrs:   []string{"foo@ppi-my.com"},
			allows:  domainList{"ppi.co.jp", "ppi-my.com"},
			success: true,
		},
		{
			name:    "success (addrs is nil)",
			addrs:   nil,
			allows:  domainList{"ppi.co.jp"},
			success: true,
		},
		{
			name:    "success (addrs and allows are nil)",
			addrs:   nil,
			allows:  nil,
			success: true,
		},
		{
			name:    "success (addrs only have no domain address)",
			addrs:   []string{"foo"},
			allows:  domainList{"ppi.co.jp"},
			success: true,
		},
		{
			name:    "success (addrs contains no domain address)",
			addrs:   []string{"foo@ppi.co.jp", "bar"},
			allows:  domainList{"ppi.co.jp"},
			success: true,
		},
		{
			name:    "failed",
			addrs:   []string{"foo@ppi-my.com"},
			allows:  domainList{"ppi.co.jp"},
			success: false,
		},
		{
			name:    "failed (multiple allows)",
			addrs:   []string{"foo@ppi-my.com"},
			allows:  domainList{"ppi.co.jp", "example.com"},
			success: false,
		},
		{
			name:    "failed (addrs contains an address which it's domain not in allows",
			addrs:   []string{"foo@ppi.co.jp", "bar@ppi-my.com"},
			allows:  domainList{"ppi.co.jp"},
			success: false,
		},
		{
			name:    "failed (allows is nil)",
			addrs:   domainList{"foo@ppi-my.com"},
			allows:  nil,
			success: false,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			err := checkEmailAddressDomain(test.addrs, test.allows)
			success := err == nil
			assert.True(t, success == test.success)
		})
	}
}

func TestCheckPublishEmailDomainRestriction(t *testing.T) {
	tests := []struct {
		name    string
		addrs   []string
		project string
	}{
		{
			name:    "drk - ppi",
			addrs:   []string{"foo@ppi.co.jp"},
			project: "drk",
		},
		{
			name:    "drk - ppm",
			addrs:   []string{"foo@ppi-my.com"},
			project: "drk",
		},
		{
			name:    "drk - chaya",
			addrs:   []string{"foo@chayapictures.com"},
			project: "drk",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			err := CheckPublishEmailDomainRestriction(test.addrs, test.project)
			assert.NoError(t, err)
		})
	}
}

func TestCheckPublishEmailDomainRestriction_defaultDomains(t *testing.T) {
	tests := []struct {
		name    string
		addrs   []string
		project string
	}{
		{
			name:    "ppi",
			addrs:   []string{"foo@ppi.co.jp"},
			project: "potoodev",
		},
		{
			name:    "ppm",
			addrs:   []string{"foo@ppi-my.com"},
			project: "potoodev",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			require.NotContains(t, publishEmailDomainRule, test.project)
			err := CheckPublishEmailDomainRestriction(test.addrs, test.project)
			assert.NoError(t, err)
		})
	}
}

func TestCheckPublishEmailDomainRestriction_failed(t *testing.T) {
	addrs := []string{"foo@chayapictures.com"}
	project := "potoodev"
	require.NotContains(t, publishEmailDomainRule, project)
	err := CheckPublishEmailDomainRestriction(addrs, project)
	assert.Error(t, err)
}
