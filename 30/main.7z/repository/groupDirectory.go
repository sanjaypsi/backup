package repository

import (
	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/repository/model"
)

// GroupDirectory is a repository that manages group directory records.
type GroupDirectory struct {
	db *gorm.DB
}

// NewGroupDirectory creates a new GroupDirectory repository.
func NewGroupDirectory(db *gorm.DB) (*GroupDirectory, error) {
	if err := db.AutoMigrate(&model.GroupDirectory{}); err != nil {
		return nil, err
	}
	return &GroupDirectory{
		db: db,
	}, nil
}
