import React, { useMemo, useState, useCallback } from 'react';
import { Box, Typography, IconButton } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import { PivotGroup, SortDir } from './types';

type Props = {
  /** Groups returned by the backend when view=grouped */
  groups?: PivotGroup[];

  /** 0-based UI page index (used by backend request; this component just renders what it receives) */
  page: number;

  /** Assets per page (used by backend request; this component just renders what it receives) */
  rowsPerPage: number;

  /** Current UI sort key (used for sorting items within a group) */
  sortKey: string;

  /** Current UI sort direction (asc/desc/none) */
  sortDir: SortDir;
};

const normalizeGroupName = (v: string | null | undefined) => {
  const raw = v ? v : 'unassigned';
  return String(raw).trim().toLowerCase();
};

const displayKey = (v: string | null | undefined) => {
  const raw = v ? v : 'UNASSIGNED';
  return String(raw).trim().toUpperCase();
};

function getGroupTotalCount(g: PivotGroup): number {
  const anyG: any = g as any;
  if (typeof anyG.total_count === 'number') return anyG.total_count;
  if (typeof anyG.itemsCount === 'number') return anyG.itemsCount;
  if (typeof anyG.totalCount === 'number') return anyG.totalCount;
  return Array.isArray(g.items) ? g.items.length : 0;
}

function compareStringsAsc(a: string, b: string) {
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
}

function mapSortKey(sortKey: string) {
  // UI label -> actual asset field key
  if (sortKey === 'group_1_name') return 'group_1';
  return sortKey;
}

function getComparableValue(row: any, key: string) {
  const v = row && row[key] != null ? row[key] : '';
  const s = String(v).trim();
  // keep blanks / '-' as lowest priority
  if (s === '' || s === '-') return null;
  return s.toLowerCase();
}

const AssetsGroupedDataTable: React.FC<Props> = ({
  groups = [],
  page,
  rowsPerPage,
  sortKey,
  sortDir,
}) => {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const toggle = useCallback((key: string) => {
    setCollapsed(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  /**
   * Behavior (ShotGrid-like):
   * - Group order: ALWAYS alphabetical A→Z, and UNASSIGNED ALWAYS LAST.
   * - Items inside each group: sorted by sortKey/sortDir (asc/desc). If sortDir=none, no item sorting.
   * - Pagination: this component renders what backend returns (groups can be split across pages).
   */
  const processedGroups = useMemo(() => {
    // 1) Group order (A→Z, UNASSIGNED last)
    const orderedGroups = [...groups].sort((a, b) => {
      const na = normalizeGroupName(a.top_group_node);
      const nb = normalizeGroupName(b.top_group_node);

      const aIsUn = na === 'unassigned';
      const bIsUn = nb === 'unassigned';

      if (aIsUn && !bIsUn) return 1;  // UNASSIGNED last
      if (!aIsUn && bIsUn) return -1; // UNASSIGNED last

      return compareStringsAsc(na, nb);
    });

    // 2) Sort items inside each group
    if (sortDir === 'none') return orderedGroups;

    const key = mapSortKey(sortKey);
    const dir: 'asc' | 'desc' = sortDir === 'desc' ? 'desc' : 'asc';

    return orderedGroups.map(g => {
      const items = Array.isArray(g.items) ? g.items : [];
      const sortedItems = [...items].sort((a: any, b: any) => {
        const va = getComparableValue(a, key);
        const vb = getComparableValue(b, key);

        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;

        const comp = va.localeCompare(vb, undefined, { numeric: true, sensitivity: 'base' });
        return dir === 'asc' ? comp : -comp;
      });

      return { ...g, items: sortedItems };
    });
  }, [groups, sortKey, sortDir]);

  return (
    <Box width="100%">
      {processedGroups.map(group => {
        const groupNameRaw = group.top_group_node ? group.top_group_node : 'unassigned';
        const groupName = String(groupNameRaw);

        const isCollapsed = !!collapsed[groupName];
        const groupItems = Array.isArray(group.items) ? group.items : [];
        const totalCount = getGroupTotalCount(group);

        return (
          <Box key={groupName} mb={0.5}>
            {/* Group Header */}
            <Box
              px={1}
              py={0.5}
              display="flex"
              alignItems="center"
              style={{
                background: 'rgba(255,255,255,0.08)',
                borderBottom: '1px solid rgba(255,255,255,0.12)',
                cursor: 'pointer',
                userSelect: 'none',
              }}
              onClick={() => toggle(groupName)}
            >
              <IconButton size="small" style={{ padding: 4, marginRight: 8 }}>
                {isCollapsed ? <ChevronRightIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
              </IconButton>

              <Typography variant="subtitle2" style={{ fontWeight: 700, fontSize: '0.75rem' }}>
                {displayKey(groupName)}
                <span style={{ marginLeft: 8, color: '#00b7ff' }}>({totalCount})</span>
              </Typography>
            </Box>

            {/* Rows */}
            {!isCollapsed && (
              <Box>
                {groupItems.map((asset: any, idx: number) => (
                  <Box
                    key={String(asset.id || asset.relation || asset.asset_name || `${groupName}-${idx}`)}
                    px={6}
                    py={0.75}
                    style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}
                  >
                    <Typography variant="body2" style={{ fontSize: '0.85rem' }}>
                      {asset.group_1 || ''}
                    </Typography>
                  </Box>
                ))}
              </Box>
            )}
          </Box>
        );
      })}
    </Box>
  );
};

export default AssetsGroupedDataTable;