import React, { useCallback, useMemo, useState } from "react";
import {
  Box,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  makeStyles,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import { PivotGroup, SortDir } from "./types";

/** ----------------------------------------------------------------
 *  COLORS (match list view look)
 *  ---------------------------------------------------------------- */
const COLORS = {
  PAGE_BG: "#3d3d3dff",
  TABLE_BG: "#3d3d3dff",
  HEADER_BG: "#3d3d3dff",
  HEADER_BORDER: "#3d3d3dff",
  GRID_LINE: "#555555",
  ROW_BG: "#3d3d3dff",
  GROUP_BG: "#3a3838ff",
  GROUP_TEXT: "#00b7ff",
  TEXT: "#e0e0e0",
  MUTED: "#bdbdbd",

  // top/bottom edge line for NON-phase columns
  COL_EDGE: "#6b6b6b",

  // ✅ use your phase config (lineColor + backgroundColor)
  PHASE: {
    mdl: { lineColor: "#3295fd", backgroundColor: "#354d68" },
    rig: { lineColor: "#c061fd", backgroundColor: "#5e3568" },
    bld: { lineColor: "#fc2f8c", backgroundColor: "#5a0028" },
    dsn: { lineColor: "#98f2bf", backgroundColor: "#045660" },
    ldv: { lineColor: "#fe5cff", backgroundColor: "#683566" },
  },
};

/** ----------------------------------------------------------------
 *  UI controls - REDUCED FOR COMPACTNESS
 *  ---------------------------------------------------------------- */
const UI = {
  ROW_HEIGHT: 54, // Reduced from 54
  ROW_PAD_Y: 2,
  ROW_PAD_X: 4, // Reduced from 8

  // ✅ move NAME + THUMB a bit left
  NAME_PAD_X: 2, // Reduced from 4
  THUMB_PAD_X: 4, // Reduced from 6

  ROW_GAP_PX: 0,
  GROUP_ROW_GAP_PX: 2,
  PHASE_GAP_PX: 1,

  RAIL_PX: 2, // Reduced from 3

  THUMB_WIDTH: 90, // Reduced from 90
  NAME_WIDTH: 120, // Reduced from 150
  RELATION_WIDTH: 70, // Reduced from 70
  PHASE_COL_WIDTH: 100, // Reduced from 97 - KEY REDUCTION

  // ✅ "top & bottom line" thickness in header
  COL_EDGE_PX: 1, // Reduced from 2

  // ✅ thumbs width/height
  THUMB_BOX_W: 75, // Reduced from 50
  THUMB_BOX_H: 50, // Reduced from 28
  THUMB_RADIUS: 2,
  
  // ✅ Font sizes matching your image
  FONT_SIZE_HEADER: 12,    // Column headers
  FONT_SIZE_CONTENT: 12,   // Content text
  FONT_SIZE_GROUP: 12,     // Group header text
};

type ColumnId =
  | "thumbnail"
  | "group_1_name"
  | "mdl_work"
  | "mdl_appr"
  | "mdl_submitted"
  | "rig_work"
  | "rig_appr"
  | "rig_submitted"
  | "bld_work"
  | "bld_appr"
  | "bld_submitted"
  | "dsn_work"
  | "dsn_appr"
  | "dsn_submitted"
  | "ldv_work"
  | "ldv_appr"
  | "ldv_submitted"
  | "relation";

type Column = {
  id: ColumnId;
  label: string;
  sortable?: boolean;
  phase?: keyof typeof COLORS.PHASE; // mdl|rig|bld|dsn|ldv
  kind?: "work" | "appr" | "submitted";
};

type Props = {
  groups?: PivotGroup[];

  // sorting
  sortKey: string;
  sortDir: SortDir;
  onSortChange: (key: string) => void;

  // group name sorting
  groupSortDir?: SortDir;
  onGroupSortToggle?: () => void;

  dateTimeFormat: Intl.DateTimeFormat;
  hiddenColumns?: Set<string>;

  /** ✅ IMPORTANT: pass footer from Panel so it renders (sticky) */
  tableFooter?: React.ReactNode;
};

// SHORTENED COLUMN LABELS FOR COMPACTNESS
const COLUMNS: Column[] = [
  { id: "thumbnail", label: "THUMB" }, // Changed from "THUMBNAIL"
  { id: "group_1_name", label: "NAME", sortable: true },

  { id: "mdl_work", label: "MDL WORK", sortable: true, phase: "mdl", kind: "work" },
  { id: "mdl_appr", label: "MDL APPR", sortable: true, phase: "mdl", kind: "appr" },
  { id: "mdl_submitted", label: "MDL Submitted At", sortable: true, phase: "mdl", kind: "submitted" }, // Shortened

  { id: "rig_work", label: "RIG WORK", sortable: true, phase: "rig", kind: "work" },
  { id: "rig_appr", label: "RIG APPR", sortable: true, phase: "rig", kind: "appr" },
  { id: "rig_submitted", label: "RIG Submitted At", sortable: true, phase: "rig", kind: "submitted" }, // Shortened
  
  { id: "bld_work", label: "BLD WORK", sortable: true, phase: "bld", kind: "work" },
  { id: "bld_appr", label: "BLD APPR", sortable: true, phase: "bld", kind: "appr" },
  { id: "bld_submitted", label: "BLD Submitted At", sortable: true, phase: "bld", kind: "submitted" }, // Shortened

  { id: "dsn_work", label: "DSN WORK", sortable: true, phase: "dsn", kind: "work" },
  { id: "dsn_appr", label: "DSN APPR", sortable: true, phase: "dsn", kind: "appr" },
  { id: "dsn_submitted", label: "DSN Submitted At", sortable: true, phase: "dsn", kind: "submitted" }, // Shortened

  { id: "ldv_work", label: "LDV WORK", sortable: true, phase: "ldv", kind: "work" },
  { id: "ldv_appr", label: "LDV APPR", sortable: true, phase: "ldv", kind: "appr" },
  { id: "ldv_submitted", label: "LDV Submitted At", sortable: true, phase: "ldv", kind: "submitted" }, // Shortened

  { id: "relation", label: "Relation", sortable: true }, // Changed from "RELATION"
];

/**
 * ✅ Single scroll container:
 * - ONE vertical scrollbar
 * - horizontal scroll works on data
 * - sticky header + sticky footer stay visible
 */
const useStyles = makeStyles(() => ({
  root: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    background: COLORS.PAGE_BG,
  },

  // IMPORTANT: do NOT create a nested scroll container in Group view.
  // The parent panel (ListView behavior) should be the only scrolling ancestor.
  scroller: {
    width: "100%",
    overflow: "visible",
  },

  // COMPACT TABLE STYLING
  table: {
    background: COLORS.TABLE_BG,
    width: "max-content",
    minWidth: "100%",
    tableLayout: "fixed",
    borderCollapse: "separate",
    borderSpacing: 0,
  },

  groupHeader: {
    '&:hover': {
      backgroundColor: `${COLORS.GROUP_BG}dd !important`,
    },
  },
  
  sortIndicator: {
    transition: 'color 0.2s ease-in-out',
  },
  
  activeSort: {
    color: '#00b7ff !important',
  },
}));

/**
 * Utility functions for consistent empty value handling
 */
const isEmptyValue = (value: any): boolean => {
  if (value === null || value === undefined) return true;
  const str = String(value).trim();
  return str === '' || str === '-' || str === '—' || str === 'null' || str === 'undefined';
};

const formatForDisplay = (value: any): string => {
  if (isEmptyValue(value)) return '—';
  return String(value).trim();
};

function getPhaseMetadata(visibleCols: Column[]) {
  const map: Record<string, { start: string; end: string }> = {};
  visibleCols.forEach((col) => {
    if (!col.phase) return;
    if (!map[col.phase]) map[col.phase] = { start: col.id, end: col.id };
    else map[col.phase].end = col.id;
  });
  return map;
}

function formatSubmitted(val: any) {
  if (isEmptyValue(val)) return '—';
  const s = String(val);
  return s.indexOf("T") >= 0 ? s.split("T")[0] : s;
}

function statusColor(status?: string) {
  if (isEmptyValue(status)) return COLORS.MUTED;
  
  const s = (status || "").toLowerCase();
  if (s.includes("approved")) return "#32cd32";
  if (s.includes("review")) return "#ffa500";
  if (s.includes("retake")) return "#ff4f4f";
  if (s.includes("hold")) return "#ffdd55";
  if (s === "check") return "#ca25ed";
  return COLORS.MUTED;
}

function renderThumbnail(asset: any) {
  const url = asset.thumbnail_url || asset.thumbnail;
  return (
    <Box display="flex" alignItems="center" justifyContent="flex-start">
      <Box
        style={{
          width: UI.THUMB_BOX_W,
          height: UI.THUMB_BOX_H,
          borderRadius: UI.THUMB_RADIUS,
          backgroundColor: "#2a2a2a",
          overflow: "hidden",
        }}
      >
        {url ? (
          <img
            src={url}
            alt=""
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              display: "block",
            }}
          />
        ) : null}
      </Box>
    </Box>
  );
}

function renderAssetField(asset: any, col: Column) {
  if (col.id === "thumbnail") return renderThumbnail(asset);

  if (col.id === "group_1_name") {
    return (
      <Typography noWrap style={{ 
        fontSize: UI.FONT_SIZE_CONTENT, 
        fontWeight: 500 
      }}>
        {formatForDisplay(asset.group_1 || asset.group_1_name)}
      </Typography>
    );
  }

  if (col.id === "relation") {
    return (
      <Typography style={{ 
        fontSize: UI.FONT_SIZE_CONTENT, 
        fontWeight: 500 
      }}>
        {formatForDisplay(asset.relation)}
      </Typography>
    );
  }

  const phase = col.phase;
  if (!phase) return <span>—</span>;

  if (col.kind === "submitted") {
    const submittedAt = asset[phase + "_submitted_at_utc"];
    const formatted = formatSubmitted(submittedAt);
    return (
      <Typography style={{ 
        fontSize: UI.FONT_SIZE_CONTENT, 
        fontWeight: 500 
      }}>
        {formatted}
      </Typography>
    );
  }

  const field = col.kind === "work" ? "work_status" : "approval_status";
  const raw = asset[phase + "_" + field];
  const text = formatForDisplay(raw);

  return (
    <Typography style={{ 
      fontSize: UI.FONT_SIZE_CONTENT, 
      fontWeight: 500, 
      color: statusColor(text === '—' ? '' : text) 
    }}>
      {text}
    </Typography>
  );
}

/**
 * ✅ Header top line + bottom line (per column)
 * ✅ Remove middle line between THUMB and NAME
 * ✅ Phase rails + phase gap
 * ✅ REDUCED PADDING FOR COMPACTNESS
 */
function buildCellStyle(
  col: Column,
  phaseMeta: Record<string, { start: string; end: string }>,
  opts: { header?: boolean; isGroupRow?: boolean } = {}
): React.CSSProperties {
  const { header = false, isGroupRow = false } = opts;

  const meta = col.phase ? phaseMeta[col.phase] : null;
  const isPhaseStart = !!(meta && meta.start === col.id);
  const isPhaseEnd = !!(meta && meta.end === col.id);

  const phaseCfg = col.phase ? COLORS.PHASE[col.phase] : null;
  const edgeColor = col.phase ? phaseCfg!.lineColor : COLORS.COL_EDGE;

  const headerBg = col.phase ? phaseCfg!.backgroundColor : COLORS.HEADER_BG;

  const paddingX =
    col.id === "group_1_name" ? UI.NAME_PAD_X : col.id === "thumbnail" ? UI.THUMB_PAD_X : UI.ROW_PAD_X;

  const style: React.CSSProperties = {
    backgroundColor: header ? headerBg : COLORS.ROW_BG,
    color: header ? "#fff" : COLORS.TEXT,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    height: UI.ROW_HEIGHT,
    padding: `${header ? 4 : UI.ROW_PAD_Y}px ${paddingX}px`,
    fontSize: header ? UI.FONT_SIZE_HEADER : UI.FONT_SIZE_CONTENT,
    fontWeight: header ? 500 : 300,
    borderLeft: "0px",
    borderRight: "0px",
    borderBottom: header
      ? "1px solid " + COLORS.HEADER_BORDER
      : (isGroupRow ? UI.GROUP_ROW_GAP_PX : UI.ROW_GAP_PX) + "px solid " + COLORS.TABLE_BG,
  };

  // ✅ top + bottom line in header for each column
  const shadows: string[] = [];
  if (header) {
    shadows.push(`inset 0 ${UI.COL_EDGE_PX}px 0 0 ${edgeColor}`);
    shadows.push(`inset 0 -${UI.COL_EDGE_PX}px 0 0 ${edgeColor}`);
  }

  // phase rails
  if (col.phase) {
    const rail = phaseCfg!.lineColor;
    if (isPhaseStart) shadows.push(`inset ${UI.RAIL_PX}px 0 0 0 ${rail}`);
    if (isPhaseEnd) shadows.push(`inset -${UI.RAIL_PX}px 0 0 0 ${rail}`);

    // gap after phase end
    if (isPhaseEnd) style.borderRight = UI.PHASE_GAP_PX + "px solid " + COLORS.TABLE_BG;
  } else {
    // ✅ remove vertical line between THUMBNAIL and NAME
    if (col.id === "thumbnail") style.borderRight = "0px";
    else style.borderRight = "1px solid " + (header ? COLORS.HEADER_BORDER : COLORS.GRID_LINE);
  }

  if (shadows.length) style.boxShadow = shadows.join(", ");

  return style;
}

const AssetsGroupedDataTable: React.FC<Props> = ({
  groups = [],
  sortKey,
  sortDir,
  onSortChange,
  dateTimeFormat,
  hiddenColumns = new Set(),
  tableFooter,
}) => {
  const classes = useStyles();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const toggle = useCallback((key: string) => {
    setCollapsed((prev) => ({ ...prev, [key]: !prev[key] }));
  }, []);

  /**
   * LIST view column visibility uses ids like:
   *   mdl_work_status / mdl_approval_status / mdl_submitted_at
   * But GROUP view column ids are:
   *   mdl_work / mdl_appr / mdl_submitted
   *
   * So we map grouped-column ids -> list-column ids before checking `hiddenColumns`.
   */
  const isGroupedColHidden = useCallback(
    (groupColId: string) => {
      if (!hiddenColumns || hiddenColumns.size === 0) return false;

      // fixed columns
      if (groupColId === "thumbnail" || groupColId === "group_1_name") return false;
      if (groupColId === "relation") return hiddenColumns.has("relation");

      // phase columns
      const m = groupColId.match(/^(mdl|rig|bld|dsn|ldv)_(work|appr|submitted)$/i);
      if (!m) return hiddenColumns.has(groupColId);

      const phase = m[1].toLowerCase();
      const kind = m[2].toLowerCase();

      if (kind === "work") return hiddenColumns.has(`${phase}_work_status`);
      if (kind === "appr") return hiddenColumns.has(`${phase}_approval_status`);
      return hiddenColumns.has(`${phase}_submitted_at`);
    },
    [hiddenColumns],
  );

  const visibleColumns = useMemo(() => {
    return COLUMNS.filter((c) => !isGroupedColHidden(c.id));
  }, [isGroupedColHidden]);

  const phaseMeta = useMemo(() => getPhaseMetadata(visibleColumns), [visibleColumns]);

  // Render sort indicator for column headers
  const renderSortIndicator = (colId: string) => {
    if (sortKey !== colId) return null;
    
    return (
      <Box ml={0.5} display="flex" flexDirection="column">
        {/* Up arrow for ascending */}
        <Box 
          style={{ 
            height: 4,
            fontSize: 8,
            color: sortDir === "asc" ? "#00b7ff" : "#555",
            lineHeight: "4px"
          }}
        >
          ▲
        </Box>
        {/* Down arrow for descending */}
        <Box 
          style={{ 
            height: 4,
            fontSize: 8,
            color: sortDir === "desc" ? "#00b7ff" : "#555",
            lineHeight: "4px"
          }}
        >
          ▼
        </Box>
      </Box>
    );
  };

  return (
    <Box className={classes.root}>
      <Box className={classes.scroller}>
        <Table size="small" stickyHeader className={classes.table}>
          {/* fixed column widths - COMPACT SIZES */}
          <colgroup>
            {visibleColumns.map((col) => {
              let w = UI.PHASE_COL_WIDTH;
              if (col.id === "thumbnail") w = UI.THUMB_WIDTH;
              if (col.id === "group_1_name") w = UI.NAME_WIDTH;
              if (col.id === "relation") w = UI.RELATION_WIDTH;
              return <col key={col.id} style={{ width: w }} />;
            })}
          </colgroup>

          <TableHead>
            <TableRow>
              {visibleColumns.map((col) => (
                <TableCell
                  key={col.id}
                  align={col.id === "group_1_name" || col.id === "thumbnail" ? "left" : "center"}
                  onClick={() => col.sortable && onSortChange(col.id)}
                  style={{
                    ...buildCellStyle(col, phaseMeta, { header: true }),
                    cursor: col.sortable ? "pointer" : "default",
                    zIndex: 5,
                  }}
                >
                  <Box
                    display="flex"
                    alignItems="center"
                    justifyContent={col.id === "group_1_name" || col.id === "thumbnail" ? "flex-start" : "center"}
                  >
                    <Typography style={{ 
                      fontSize: UI.FONT_SIZE_HEADER, 
                      fontWeight: 500 
                    }}>
                      {col.label}
                    </Typography>

                    {renderSortIndicator(col.id)}
                  </Box>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {groups.map((group) => {
              const groupName = group.top_group_node || "UNASSIGNED";
              const isCollapsed = !!collapsed[groupName];
              const visibleCount = (group.items || []).length;
              const totalCount = (group as any).totalCount || visibleCount;

              return (
                <React.Fragment key={groupName}>
                  {/* Group row (click only expands/collapses) */}
                  <TableRow
                    className={classes.groupHeader}
                    onClick={() => {
                      // ✅ Group row click should ONLY expand/collapse
                      toggle(groupName);
                    }}
                    style={{ cursor: "pointer" }}
                  >
                    <TableCell
                      colSpan={visibleColumns.length}
                      style={{
                        backgroundColor: COLORS.GROUP_BG,
                        color: COLORS.GROUP_TEXT,
                        borderBottom: UI.GROUP_ROW_GAP_PX + "px solid " + COLORS.TABLE_BG,
                        padding: "6px 10px",
                        fontWeight: 900,
                        position: "relative",
                      }}
                    >
                      <Box display="flex" alignItems="center" justifyContent="space-between">
                        <Box display="flex" alignItems="center">
                          <IconButton
                            size="small"
                            style={{ color: COLORS.GROUP_TEXT, padding: 0 }}
                            onClick={(e) => {
                              // ✅ clicking the chevron should only toggle (and not bubble to other handlers)
                              e.stopPropagation();
                              toggle(groupName);
                            }}
                          >
                            {isCollapsed ? (
                              <ChevronRightIcon fontSize="small" />
                            ) : (
                              <ExpandMoreIcon fontSize="small" />
                            )}
                          </IconButton>

                          <Typography
                            style={{
                              color: COLORS.GROUP_TEXT,
                              fontSize: UI.FONT_SIZE_GROUP,
                              fontWeight: 900,
                            }}
                          >
                            {groupName.toUpperCase()}
                          </Typography>
                          <Typography
                            style={{
                              fontSize: UI.FONT_SIZE_GROUP - 1,
                              fontWeight: 800,
                              marginLeft: 6,
                            }}>
                             ({visibleCount} of {totalCount})
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                  </TableRow>

                  {/* Data rows */}
                  {!isCollapsed &&
                    (group.items || []).map((asset: any, idx: number) => (
                      <TableRow key={groupName + "-" + idx} hover>
                        {visibleColumns.map((col) => (
                          <TableCell
                            key={col.id}
                            align={col.id === "group_1_name" || col.id === "thumbnail" ? "left" : "center"}
                            style={buildCellStyle(col, phaseMeta)}
                          >
                            {renderAssetField(asset, col)}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                </React.Fragment>
              );
            })}
          </TableBody>

          {/* ✅ Sticky footer pagination */}
          {tableFooter ? tableFooter : null}
        </Table>
      </Box>
      
    </Box>
  );
};

export default AssetsGroupedDataTable;