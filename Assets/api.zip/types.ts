import { TableCellProps } from "@material-ui/core/TableCell";
import { ReactElement } from "react";
import { Project } from '../../types';

export type AssetsDataTableProps = {
  project: Project | null | undefined,
  assets: Asset[],
  phaseComponents: { [key: string]: string[] },
  latestComponents: LatestComponents,
  tableFooter: ReactElement,
  dateTimeFormat: Intl.DateTimeFormat,

  // Added for filtering
  assetNameKey: string,
  applovalStatues: string[],
  workStatues: string[],

};

export type RecordTableHeadProps = {
  columns: Column[],
  phaseComponents: { [key: string]: string[] },
};

export type Colors = Readonly<{
  lineColor: string,
  backgroundColor: string,
}>;

export type Column = Readonly<{
  id: string,
  label: string,
  colors?: Colors,
  align?: TableCellProps['align'],
}>;

export type PageProps = Readonly<{
  page: number,
  rowsPerPage: number,
}>;

export type ReviewInfo = {
  task_id: string,
  project: string,
  take_path: string,
  root: string,
  relation: string,
  phase: string,
  component: string,
  take: string,
  approval_status: string,
  work_status: string,
  submitted_at_utc: string,
  submitted_user: string,
  modified_at_utc: string,
  id: number,
  groups: string[],
  group_1: string,
  review_comments: ReviewComment[],
};

type ReviewComment = {
  text: string,
  language: string,
  attachments: string[],
  is_translated: boolean,
  need_translation: boolean
};

export type Asset = Readonly<{
  name: string,
  relation: string,
}>;

export type FilterProps = Readonly<{
  assetNameKey: string,
  applovalStatues: string[],
  workStatues: string[],
}>;

export type ChipDeleteFunction = (value: string) => void;

export type AssetRowProps = Readonly<{
  asset: Asset,
  reviewInfos: { [key: string]: ReviewInfo },
  thumbnails: { [key: string]: string },
  phaseComponents: { [key: string]: string[] },
  latestComponents: LatestComponents,
  dateTimeFormat: Intl.DateTimeFormat,
  isLastRow: boolean,
}>;

export type LatestAssetComponentDocument = Readonly<{
  component: string,
  groups: string[],
  phase: string,
  submitted_at_utc: string,
}>;

type LatestComponent = Readonly<{
  component: string,
  latest_document: LatestAssetComponentDocument,
}>

export type LatestComponents = {
  [key: string]: LatestComponent[],
};

export type LatestAssetComponentDocumentsResponse = Readonly<{
  component: string,
  latest_document: LatestAssetComponentDocument,
}>;


/* 
========================================================================
Fetch Assets Pivoted API
- New function to fetch pivoted assets with filtering and sorting
- Replaces previous fetchAssets implementation with enhanced functionality
- Maintains consistent coding style with async/await and fetch API
- Added comments for clarity and maintainability
- Add by Sanjay - PSI
======================================================================== 
*/
export type SortDir = 'asc' | 'desc' | 'none';

export type AssetsPivotResponse = {
  project: string,
  root: string,
  page: number,
  per_page: number,
  total: number,
  count: number,
  data: Asset[],
  ts: string,
  sort_dir: SortDir,
  assets: Asset[],
  groups: PivotGroup[],
};

export type PivotGroup = {
  name: string,
  components: string[],
};
