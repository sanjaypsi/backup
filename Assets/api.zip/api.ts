import { AuthorizationError } from '../../../auth/types';
import { getAuthHeader, setNewToken } from '../../../auth/util';
import { Asset, LatestAssetComponentDocumentsResponse, ReviewInfo, AssetsPivotResponse } from './types';

type ReviewInfoListResponse = {
  reviews: ReviewInfo[],
  next: string | null,
  total: number,
};

export type AssetsResponse = {
  assets: Asset[],
  total: number,
};

export const fetchAssets = async (
  project: string,
  page: number,
  rowsPerPage: number,
  signal?: AbortSignal | null,
): Promise<AssetsResponse> => {
  const headers = getAuthHeader();
  let url: string | null = `/api/projects/${project}/reviews/assets`
  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch parameters.');
  }
  setNewToken(res);
  const json: AssetsResponse = await res.json();
  return json;
};

export const fetchAssetReviewInfos = async (
  project: string,
  asset: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<ReviewInfoListResponse> => {
  const url = `/api/projects/${project}/assets/${asset}/relations/${relation}/reviewInfos`;
  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch review infos.');
  }
  setNewToken(res);
  const json: ReviewInfoListResponse = await res.json();
  return json;
};

export const fetchAssetThumbnail = async (
  project: string,
  asset: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  const url = `/api/projects/${project}/assets/${asset}/relations/${relation}/reviewthumbnail`;
  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 204) {
    return null; // 204 is allowed, it means the thumbnail does not exist.
  }
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch thumbnail.');
  }
  setNewToken(res);
  return res;
};

export const fetchLatestAssetComponents = async (
  project: string,
  asset: string,
  relation: string,
  components: string[],
  signal?: AbortSignal | null,
): Promise<LatestAssetComponentDocumentsResponse[]> => {
  let url = `/api/projects/${project}/latestAssetsOperationInfos`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('asset', asset);
  params.set('relation', relation);
  components.forEach(component => params.append('component', component));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch latest asset components.');
  }
  setNewToken(res);
  const json: LatestAssetComponentDocumentsResponse[] = await res.json();
  return json;
};

export const fetchGenerateAssetCsv = async (
  project: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  let url = `/api/projects/${project}/assets/generateCsv`;
  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to generate CSV.');
  }
  setNewToken(res);
  return res;
};

/*
========================================================================
   Fetch Assets Pivoted API
   - New function to fetch pivoted assets with filtering and sorting
   - Replaces previous fetchAssets implementation with enhanced functionality
   - Retains original fetchAssets and fetchAssetReviewInfos for backward compatibility
   - Uses URLSearchParams for cleaner query parameter handling
   - Encodes project, asset, and relation parameters to ensure URL safety
   - Improved error handling and response validation
   - Maintains consistent coding style with async/await and fetch API
   - Added comments for clarity and maintainability
   - Add by PSI
====================================================================== 
*/
export const fetchAssetsPivot = async (
  project: string,
  page: number,
  rowsPerPage: number,
  sortKey: string,
  sortDir: string,
  phase: string,
  assetNameKey: string,
  approvalStatuses: string[],
  workStatuses: string[],
  view: 'list' | 'grouped',
  signal?: AbortSignal | null,
): Promise<AssetsPivotResponse> => {
  const headers = getAuthHeader();
  const encodedProject = encodeURIComponent(project);
  let url = `/api/projects/${encodedProject}/reviews/assets/pivot`;

  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  if (sortKey) params.set('sort', sortKey);
  if (sortDir) params.set('dir', sortDir.toUpperCase());
  if (phase && phase !== 'none') params.set('phase', phase);
  if (view) params.set('view', view);

  const trimmed = (assetNameKey || '').trim();
  if (trimmed) {
    params.set('name', trimmed);
    params.set('name_mode', 'prefix');
  }

  // ✅ FIX: Ensure CSV formats for array filters
  if (workStatuses.length) params.set('work', workStatuses.join(','));
  if (approvalStatuses.length) params.set('appr', approvalStatuses.join(','));

  url += `?${params.toString()}`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout for pivot

  try {
    const res = await fetch(url, {
      method: 'GET',
      headers,
      mode: 'cors',
      signal: signal || controller.signal,
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      const errorText = await res.text();
      // This will now show the actual Go backend error in your console
      throw new Error(`Pivot API Error [${res.status}]: ${errorText}`);
    }

    setNewToken(res);
    return await res.json();
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
};