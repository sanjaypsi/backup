import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';
import { RouteComponentProps } from "react-router-dom";
import { Container, Paper, styled } from '@material-ui/core';
import { ButtonProps } from '@material-ui/core/Button';
import { SelectProps } from '@material-ui/core/Select';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import { TextFieldProps } from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import { fetchGenerateAssetCsv } from './api';
import {
  useFetchAssets,
  useFetchLatestAssetComponents,
  useFetchPipelineSettingAssetComponents
} from './hooks';
import { FilterProps, PageProps } from './types';
import AssetsDataTable from './AssetsDataTable';
import AssetTableFilter from './AssetDataTableFilter';
import AssetsDataTableFooter from './AssetsDataTableFooter';
import DownloadFab from './DownloadFab';
import { useCurrentProject } from '../../hooks';
import { Project } from '../../types';
import { useCurrentStudio } from '../../../studio/hooks';
import { queryConfig } from '../../../new-pipeline-setting/api';

const StyledContainer = styled(Container)(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
});

const StyledContentDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'row',
}));

const StyledTableDiv = styled('div')(({
  paddingBottom: 8,
}));

const CsvDownloadComponent = ({ currentProject }: { currentProject: Project | null | undefined }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorDialogOpen, setErrorDialogOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleErrorDialogClose = () => {
    setErrorDialogOpen(false);
  };

  const handleFetchGenerateAssetCsv = useCallback(async () => {
    if (currentProject == null) {
      console.warn('Project not selected.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60 * 5000);

    try {
      const res = await fetchGenerateAssetCsv(
        currentProject.key_name,
        controller.signal,
      );

      if (res != null) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'asset_data.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }
    } catch (err) {
      console.error('Failed to download CSV:', err);
      setErrorMessage('Failed to download CSV');
      setErrorDialogOpen(true);
    } finally {
      clearTimeout(timeoutId);
      setIsLoading(false);
    }
  }, [currentProject]);

  return (
    <div>
      <DownloadFab
        onClick={handleFetchGenerateAssetCsv}
        disabled={isLoading}
      />
      <Dialog
        open={errorDialogOpen}
        onClose={handleErrorDialogClose}
        aria-labelledby="error-dialog-title"
      >
        <DialogTitle id="error-dialog-title">CSV Download Error</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {errorMessage}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleErrorDialogClose} color="primary" autoFocus>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

const AssetsDataTablePanel: React.FC<RouteComponentProps> = () => {
  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };
  const initFilterProps = {
    assetNameKey: '',
    applovalStatues: [],
    workStatues: [],
  };
  const [pageProps, setPageProps]     = useState<PageProps>(initPageProps);
  const [filterProps, setFilterProps] = useState<FilterProps>(initFilterProps);
  const { currentProject }  = useCurrentProject();
  const { assets, total }   = useFetchAssets(
    currentProject,
    pageProps.page,
    pageProps.rowsPerPage,
  );
  const { phaseComponents } = useFetchPipelineSettingAssetComponents(currentProject);


  const { currentStudio }       = useCurrentStudio();
  const [timeZone, setTimeZone] = useState<string | undefined>();
  const { latestComponents }    = useFetchLatestAssetComponents(currentProject, assets, phaseComponents);

  // Debug
  console.log('AssetsDataTablePanel currentProject, phaseComponents, latestComponents', { currentProject, phaseComponents, latestComponents });

  useEffect(() => {
    if (currentStudio == null) {
      return
    }
    const controller = new AbortController();
    (async () => {
      try {
        const res: string | null = await queryConfig(
          'studio',
          currentStudio.key_name,
          'timezone',
        ).catch(e => {
          if (e.name === 'AbortError') {
            return;
          }
          throw e;
        });
        if (res != null) {
          setTimeZone(res);
        }
      } catch (e) {
        console.error(e);
      }
    })();
    return () => {
      controller.abort();
    };
  }, [currentStudio]);

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  const handleFilterAssetNameChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      assetNameKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleApprovalStatusesChange: SelectProps['onChange'] = (event: React.ChangeEvent<{ value: unknown }>) => {
    setFilterProps({
      ...filterProps,
      applovalStatues: event.target.value as string[],
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleWorkStatusesChange: SelectProps['onChange'] = (event: React.ChangeEvent<{ value: unknown }>) => {
    setFilterProps({
      ...filterProps,
      workStatues: event.target.value as string[],
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleApprovalStatusesChipDelete = (name: string) => {
    setFilterProps({
      ...filterProps,
      applovalStatues: filterProps.applovalStatues.filter(value => value !== name),
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleWorkStatusesChipDelete = (name: string) => {
    setFilterProps({
      ...filterProps,
      workStatues: filterProps.workStatues.filter(value => value !== name),
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleFilterResetClick: ButtonProps['onClick'] = () => { setFilterProps(initFilterProps); };

  const dateTimeFormat = new Intl.DateTimeFormat(
    undefined,
    {
      timeZone: timeZone,
      dateStyle: 'medium',
      timeStyle: 'medium'
    }
  );

  const tableFooter = (
    <AssetsDataTableFooter
      count={total}
      page={pageProps.page}
      rowsPerPage={pageProps.rowsPerPage}
      onChangePage={handlePageChange}
      onChangeRowsPerPage={handleRowsPerPageChange}
    />
  );

  return (
    <StyledContainer maxWidth="xl">
      <AssetTableFilter
        filterAssetName={filterProps.assetNameKey}
        selectApprovalStatuses={filterProps.applovalStatues}
        selectWorkStatuses={filterProps.workStatues}
        onAssetNameChange={handleFilterAssetNameChange}
        onApprovalStatusesChange={handleApprovalStatusesChange}
        onWorkStatusesChange={handleWorkStatusesChange}
        onApprovalStatusChipDelete={handleApprovalStatusesChipDelete}
        onWorkStatusChipDelete={handleWorkStatusesChipDelete}
        onResetClick={handleFilterResetClick}
      >
      </AssetTableFilter>
      <StyledTableDiv>
        <StyledPaper>
          <StyledContentDiv>
            <AssetsDataTable
              project={currentProject}
              assets={assets}
              phaseComponents={phaseComponents}
              latestComponents={latestComponents}
              tableFooter={tableFooter}
              dateTimeFormat={dateTimeFormat}
              assetNameKey={" "}
              applovalStatues={[]}
              workStatues={[]}
            />
          </StyledContentDiv>
        </StyledPaper>
      </StyledTableDiv>

      <CsvDownloadComponent
        currentProject={currentProject}
      />

    </StyledContainer>
  );
};

export default AssetsDataTablePanel;
