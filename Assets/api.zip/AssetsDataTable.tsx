import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
} from "@material-ui/core";
import {
  AssetRowProps,
  AssetsDataTableProps,
  Colors,
  Column,
  RecordTableHeadProps,
} from "./types";
import {
  useFetchAssetReviewInfos,
  useFetchAssetThumbnails,
} from './hooks';


const ASSET_PHASES: { [key: string]: Colors } = {
  mdl: {
    lineColor: '#3295fd',
    backgroundColor: '#354d68',
  },
  rig: {
    lineColor: '#c061fd',
    backgroundColor: '#5e3568',
  },
  bld: {
    lineColor: '#fc2f8c',
    backgroundColor: '#5a0028',
  },
  dsn: {
    lineColor: '#98f2fb',
    backgroundColor: '#045660',
  },
  ldv: {
    lineColor: '#fe5cff',
    backgroundColor: '#683566',
  },
};

type Status = Readonly<{
  displayName: string,
  color: string,
}>;

const APPROVAL_STATUS: { [key: string]: Status } = {
  check: {
    displayName: 'Check',
    color: '#ca25ed',
  },
  clientReview: {
    displayName: 'Client Review',
    color: '#005fbd',
  },
  dirReview: {
    displayName: 'Dir Review',
    color: '#007fff',
  },
  epdReview: {
    displayName: 'EPD Review',
    color: '#4fa7ff',
  },
  clientOnHold: {
    displayName: 'Client On Hold',
    color: '#d69b00',
  },
  dirOnHold: {
    displayName: 'Dir On Hold',
    color: '#ffcc00',
  },
  epdOnHold: {
    displayName: 'EPD On Hold',
    color: '#ffdd55',
  },
  execRetake: {
    displayName: 'Exec Retake',
    color: '#a60000',
  },
  clientRetake: {
    displayName: 'Client Retake',
    color: '#c60000',
  },
  dirRetake: {
    displayName: 'Dir Retake',
    color: '#ff0000',
  },
  epdRetake: {
    displayName: 'EPD Retake',
    color: '#ff4f4f',
  },
  clientApproved: {
    displayName: 'Client Approved',
    color: '#1d7c39',
  },
  dirApproved: {
    displayName: 'Dir Approved',
    color: '#27ab4f',
  },
  epdApproved: {
    displayName: 'EPD Approved',
    color: '#5cda82',
  },
  other: {
    displayName: 'Other',
    color: '#9a9a9a',
  },
  omit: {
    displayName: 'Omit',
    color: '#646464',
  },
};

const WORK_STATUS: { [key: string]: Status } = {
  check: {
    displayName: 'Check',
    color: '#e287f5',
  },
  cgsvOnHold: {
    displayName: 'CGSV On Hold',
    color: '#ffdd55',
  },
  svOnHold: {
    displayName: 'SV On Hold',
    color: '#ffe373',
  },
  leadOnHold: {
    displayName: 'Lead On Hold',
    color: '#fff04f',
  },
  cgsvRetake: {
    displayName: 'CGSV Retake',
    color: '#ff4f4f',
  },
  svRetake: {
    displayName: 'SV Retake',
    color: '#ff8080',
  },
  leadRetake: {
    displayName: 'Lead Retake',
    color: '#ffbbbb',
  },
  cgsvApproved: {
    displayName: 'CGSV Approved',
    color: '#5cda82',
  },
  svApproved: {
    displayName: 'SV Approved',
    color: '#83e29f',
  },
  leadApproved: {
    displayName: 'Lead Approved',
    color: '#b9eec9',
  },
  svOther: {
    displayName: 'SV Other',
    color: '#9a9a9a',
  },
  leadOther: {
    displayName: 'Lead Other',
    color: '#dbdbdb',
  },
};

const columns: Column[] = [
  {
    id: 'thumbnail',
    label: 'Thumbnail',
  },
  {
    id: 'group_1_name',
    label: 'Name',
  },
  {
    id: 'mdl_work_status',
    label: 'MDL WORK',
    colors: ASSET_PHASES['mdl'],
  },
  {
    id: 'mdl_approval_status',
    label: 'MDL APPR',
    colors: ASSET_PHASES['mdl'],
  },
  {
    id: 'mdl_submitted_at',
    label: '_mdl_ Submitted At',
    colors: ASSET_PHASES['mdl'],
  },
  {
    id: 'rig_work_status',
    label: 'RIG WORK',
    colors: ASSET_PHASES['rig'],
  },
  {
    id: 'rig_approval_status',
    label: 'RIG APPR',
    colors: ASSET_PHASES['rig'],
  },
  {
    id: 'rig_submitted_at',
    label: '_rig_ Submitted At',
    colors: ASSET_PHASES['rig'],
  },
  {
    id: 'bld_work_status',
    label: 'BLD WORK',
    colors: ASSET_PHASES['bld'],
  },
  {
    id: 'bld_approval_status',
    label: 'BLD APPR',
    colors: ASSET_PHASES['bld'],
  },
  {
    id: 'bld_submitted_at',
    label: '_bld_ Submitted At',
    colors: ASSET_PHASES['bld'],
  },
  {
    id: 'dsn_work_status',
    label: 'DSN WORK',
    colors: ASSET_PHASES['dsn'],
  },
  {
    id: 'dsn_approval_status',
    label: 'DSN APPR',
    colors: ASSET_PHASES['dsn'],
  },
  {
    id: 'dsn_submitted_at',
    label: '_dsn_ Submitted At',
    colors: ASSET_PHASES['dsn'],
  },
  {
    id: 'ldv_work_status',
    label: 'LDV WORK',
    colors: ASSET_PHASES['ldv'],
  },
  {
    id: 'ldv_approval_status',
    label: 'LDV APPR',
    colors: ASSET_PHASES['ldv'],
  },
  {
    id: 'ldv_submitted_at',
    label: '_ldv_ Submitted At',
    colors: ASSET_PHASES['ldv'],
  },
  {
    id: 'relation',
    label: 'Relation',
  },
];

type TooltipTableCellProps = {
  tooltipText: string,
  status: Status | undefined,
  leftBorderStyle: string,
  rightBorderStyle: string,
  bottomBorderStyle: string,
};

const MultiLineTooltipTableCell: React.FC<TooltipTableCellProps> = (
  { tooltipText, status, leftBorderStyle, rightBorderStyle, bottomBorderStyle = 'none' }
) => {
  const [open, setOpen] = React.useState(false);
  const isTooltipTextEmpty = tooltipText && tooltipText.trim().length > 0;

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const handleTooltipOpen = () => {
    setOpen(true);
  };

  const statusText = (status != null) ? status['displayName'] : '-';

  return (
    <TableCell
      style={{
        color: (status != null) ? status['color'] : '',
        fontStyle: (tooltipText === '') ? 'normal' : 'oblique',
        borderLeft: leftBorderStyle,
        borderRight: rightBorderStyle,
        borderBottom: bottomBorderStyle,
      }}
      onClick={isTooltipTextEmpty ? handleTooltipOpen : undefined}
    >
      {isTooltipTextEmpty ? (
        <Tooltip
          title={
            <div
              style={{ fontSize: '0.8rem', whiteSpace: 'pre-wrap' }}>
              {tooltipText}
            </div>
          }
          onClose={handleTooltipClose}
          open={open}
          arrow
        >
          <span>{statusText}</span>
        </Tooltip>
      ) : (
        <span>{statusText}</span>
      )}
    </TableCell >
  );
};

const RecordTableHead: React.FC<RecordTableHeadProps> = ({
  columns,
  phaseComponents,
}) => {
  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => {
          const borderLineStyle = column.colors ? `solid 3px ${column.colors.lineColor}` : 'none';
          const borderTopStyle = column.colors ? borderLineStyle : 'none';
          const borderLeftStyle = (column.id.indexOf('work_status') !== -1) ? borderLineStyle : 'none';
          const borderRightStyle = (column.id.indexOf('approval_status') !== -1) ? borderLineStyle : 'none';
          if (column.id.indexOf('submitted_at') === -1) {
            return (
              <TableCell
                key={column.id}
                style={
                  {
                    backgroundColor: column.colors ? column.colors.backgroundColor : 'none',
                    borderTop: borderTopStyle,
                    borderLeft: borderLeftStyle,
                    borderRight: borderRightStyle,
                  }
                }
              >
                {column.label}
              </TableCell>
            );
          } else {
            const phase = column.id.replace('_submitted_at', '');
            const components = phaseComponents[phase] || [];
            return components.map((component) => {
              const id = component.toLowerCase() + '_submitted_at';
              const label = column.label.replace(`_${phase}_`, `${component}`);
              return (
                <TableCell
                  key={id}
                  style={
                    {
                      backgroundColor: column.colors ? column.colors.backgroundColor : 'none',
                    }
                  }
                >
                  {label}
                </TableCell>
              );
            });
          }
        })}
      </TableRow>
    </TableHead>
  );
};

const AssetRow: React.FC<AssetRowProps> = ({
  asset,
  reviewInfos,
  thumbnails,
  phaseComponents,
  latestComponents,
  dateTimeFormat,
  isLastRow,
}) => {
  return (
    <TableRow>
      <TableCell>
        {thumbnails[`${asset.name}-${asset.relation}`] ? (
          <img
            src={thumbnails[`${asset.name}-${asset.relation}`]}
            alt={`${asset.name} thumbnail`}
            style={{ width: '100px', height: 'auto' }}
          />
        ) : (
          <span>No Thumbnail</span>
        )}
      </TableCell>
      <TableCell>{asset.name}</TableCell>
      {Object.entries(ASSET_PHASES).map(([phase, { lineColor }]) => {
        const reviewInfoName = `${asset.name}-${asset.relation}-${phase}`;
        const info = reviewInfos[reviewInfoName];
        const workStatus: Status | undefined = info && WORK_STATUS[info.work_status];
        const approvalStatus: Status | undefined = info && APPROVAL_STATUS[info.approval_status];
        const tooltipText: string = info && info.review_comments
          .filter(reviewComment => reviewComment.text !== '')
          .map(reviewComment => `${reviewComment.language}:\n${reviewComment.text}`)
          .join('\n') || '';
        const borderLineStyle = `solid 3px ${lineColor}`;
        const latestDocuments = latestComponents[`${asset.name}-${asset.relation}`] || [];

        return (
          <React.Fragment key={`${reviewInfoName}-work-appr`}>
            <MultiLineTooltipTableCell
              tooltipText={tooltipText}
              status={workStatus}
              leftBorderStyle={borderLineStyle}
              rightBorderStyle={'none'}
              bottomBorderStyle={isLastRow ? borderLineStyle : 'none'}
            />
            <MultiLineTooltipTableCell
              tooltipText={tooltipText}
              status={approvalStatus}
              leftBorderStyle={'none'}
              rightBorderStyle={borderLineStyle}
              bottomBorderStyle={isLastRow ? borderLineStyle : 'none'}
            />
            {(phase in phaseComponents ? phaseComponents[phase] : []).map((component) => {
              const latestDocument = latestDocuments.find(doc => doc.component === component);

              return (
                <TableCell key={`${reviewInfoName}-${component}`}>
                  {latestDocument ? dateTimeFormat.format(new Date(latestDocument.latest_document.submitted_at_utc)) : '-'}
                </TableCell>
              );
            })}
          </React.Fragment>
        );
      })}
      <TableCell>{asset.relation}</TableCell>
    </TableRow>
  );
};

const AssetsDataTable: React.FC<AssetsDataTableProps> = ({
  project,
  assets,
  phaseComponents,
  latestComponents,
  tableFooter,
  dateTimeFormat,
  assetNameKey,
  applovalStatues,
  workStatues,
}) => {
  if (project == null) {
    return null;
  }
  const { reviewInfos } = useFetchAssetReviewInfos(project, assets);
  const { thumbnails } = useFetchAssetThumbnails(project, assets);

  return (
    <Table stickyHeader>
      <RecordTableHead
        key='asset-data-table-head'
        columns={columns}
        phaseComponents={phaseComponents}
      />
      <TableBody>
        {assets.map((asset, index) => (
          <AssetRow
            key={`${asset.name}-${asset.relation}-${index}`}
            asset={asset}
            reviewInfos={reviewInfos}
            thumbnails={thumbnails}
            phaseComponents={phaseComponents}
            latestComponents={latestComponents}
            dateTimeFormat={dateTimeFormat}
            isLastRow={(index === assets.length - 1)}
          />
        ))}
      </TableBody>
      {tableFooter || null}
    </Table>
  );
};

export default AssetsDataTable;
