package entity

import (
	"net/mail"
	"time"

	"google.golang.org/api/chat/v1"
)

type PublishTransactionInfoNotification struct {
	Studio         string
	Project        string
	TaskID         string
	SubtaskID      string
	Root           *string
	Phase          *string
	Component      *string
	Revision       *string
	Operation      string
	Event          string
	RevisionPath   string
	User           *string
	Computer       *string
	ToolName       *string
	ToolVersion    *string
	PublishedTime  *time.Time
	StackTrace     *string
	AdditionalInfo JSONObject
}

type ApiProcessError struct {
	Studio      string
	Title       string
	InfoLabel   string
	InfoContent string
	Error       error
}

type ReviewStatusLogNotification struct {
	IsSendEmail     bool
	Studio          string
	Project         string
	MailAddresses   []string
	MailCCAddresses []string
	MailSubject     string
	MailComment     string
	ModifiedAtUTC   time.Time
	ModifiedBy      string
	RelationList    []string
	PhaseList       []string
	TakeList        []string
	TableParamsList []*ReviewEmailItem
	LangSet         *map[string]struct{}
	UpdateID        string
}

type EmailData struct {
	Sender  string
	To      []string
	Cc      []string
	Subject string
	Body    string
}

type EmailDataWithMeta struct {
	Sender     string
	To         []string
	Cc         []string
	Subject    string
	Body       string
	MetaParams *MetaParams `json:"meta_list"`
}

type MetaParams struct {
	Studio        string    `json:"studio"`
	Project       string    `json:"project"`
	UpdateID      string    `json:"update_id"`
	ModifiedAtUTC time.Time `json:"modified_at_utc"`
	ModifiedBy    string    `json:"modified_by"`
	TakeList      []string  `json:"take_list"`
	RelationList  []string  `json:"relation_list"`
	PhaseList     []string  `json:"phase_list"`
	EmailToList   []string  `json:"email_to_list"`
	EmailCcList   []string  `json:"email_cc_list,omitempty"`
}

type PublishNotificationTemplateData struct {
	StudioDisplayName  string
	StudioKeyName      string
	ProjectDisplayName string
	ProjectKeyName     string
	RevisionPath       string
	TaskID             string
	SubTaskID          string
	User               *string
	PublishedTime      *string
	Computer           *string
	ToolName           *string
	ToolVersion        *string
	StackTrace         *string
}

type ReviewEmailItem struct {
	Group               string            `binding:"required"`
	Take                string            `binding:"required"`
	Phase               string            `binding:"required"`
	Component           string            `binding:"required"`
	Changes             string            `binding:"required"`
	ApprovalStatus      string            `binding:"required"`
	ApprovalStatusColor string            `binding:"required"`
	WorkStatus          string            `binding:"required"`
	WorkStatusColor     string            `binding:"required"`
	Comments            map[string]string `binding:"omitempty"`
}

type ReviewEmailTemplateData struct {
	Message string
	Items   []*ReviewEmailItem
	Langs   []string
}

type EmailSenderInfo struct {
	Server  string
	Subject string
	Sender  *mail.Address
	To      []string
	Cc      []string
	Message []byte
}

type ChatMessageSenderInfo struct {
	Webhook string
	Message *chat.Message
}
