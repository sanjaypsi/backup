package entity

import (
	"time"

	"gorm.io/gorm"
)

type ProjectStudioMap struct {
	Project       string
	Studio        string
	CreatedAtUTC  *time.Time
	ModifiedAtUTC *time.Time
	CreatedBy     *string
	ModifiedBy    *string
	ID            int32
}

type ListProjectStudioMapParams struct {
	Project *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio  *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
}

type CreateProjectStudioMapParams struct {
	Project   string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio    string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type DeleteProjectStudioMapParams struct {
	Project    string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio     string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

type ProjectStudioMapRepository interface {
	List(db *gorm.DB, params *ListProjectStudioMapParams) ([]*ProjectStudioMap, int, error)
}
