package entity

type GetAssetThumbnailParams struct {
	Project  string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Asset    string `binding:"required,min=1,max=100,alphanumunderscore"`
	Relation string `binding:"required,min=1,max=30,alphanumunderscore"`
}

type GetShotThumbnailParams struct {
	Project  string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Group1   string `binding:"required,min=1,max=100,alphanumunderscore"`
	Group2   string `binding:"required,min=1,max=100,alphanumunderscore"`
	Group3   string `binding:"required,min=1,max=100,alphanumunderscore"`
	Relation string `binding:"required,min=1,max=30,alphanumunderscore"`
}
