package entity

import "mime/multipart"

// Upstream struct for Get CommentAttachment
type GetCommentAttachmentParams struct {
	CommentID    string
	Project      string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	AttachmentID string `binding:"required,uuid"`
}

// Downstream struct for Get CommentAttachment
type DownloadAttachment struct {
	DataPath string
	FileName string
}

// Upstream struct for Post CommentAttachment
type PostCommentAttachmentParams struct {
	CommentID string
	Project   string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Lang      string `binding:"required,excludesall=!()#@{}"`
	FileName  string `binding:"required,excludesall=!()#@{}"`
	FileData  *multipart.File
}
