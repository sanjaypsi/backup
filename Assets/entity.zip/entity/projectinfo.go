package entity

import (
	"time"

	"gorm.io/gorm"
)

type ProjectInfo2 struct {
	KeyName       string                     `json:"key_name"`
	DisplayName   *string                    `json:"display_name"`
	CreatedAtUTC  *time.Time                 `json:"created_at_utc"`
	ModifiedAtUTC *time.Time                 `json:"modified_at_utc"`
	ModifiedBy    *string                    `json:"modified_by"`
	CreatedBy     *string                    `json:"created_by"`
	ID            int32                      `json:"id"`
	Repo          ProjectStudioMapRepository `json:"-" gorm:"-"`
}

func (p *ProjectInfo2) Studios(db *gorm.DB) ([]string, error) {
	infos, _, err := p.Repo.List(db, &ListProjectStudioMapParams{
		Project: &p.KeyName,
	})
	if err != nil {
		return nil, err
	}
	var studios []string
	for _, info := range infos {
		studios = append(studios, info.Studio)
	}
	return studios, nil
}

type ListProjectInfoParams struct {
	*BaseListParams
	Studio string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
}

func (*ListProjectInfoParams) DefaultPerPage() int {
	return 50
}

type GetProjectInfoParams struct {
	KeyName string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
}

type CreateProjectInfoParams struct {
	KeyName   string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type DeleteProjectInfoParams struct {
	KeyName    string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}
