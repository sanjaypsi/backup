package entity

type contextKey string

const (
	KeyUser contextKey = "user"
	KeyTx   contextKey = "tx"
)

const MaxPathLength = 1000

const (
	JSONEnum     string = "enum"
	JSONType     string = "type"
	JSONItems    string = "items"
	JSONDefault  string = "default"
	JSONPattern  string = "pattern"
	JSONRequired string = "required"
	JSONMaximum  string = "maximum"
	JSONMinimum  string = "minimum"
	JSONArray    string = "array"
	JSONString   string = "string"
	JSONInteger  string = "integer"
	JSONNumber   string = "number"
	JSONBoolean  string = "boolean"
)

const (
	Sign           = "RS256"
	KeytypePrivate = "RSA PRIVATE KEY"
	KeytypePublic  = "PUBLIC KEY"
	Bearer         = "Bearer"
	BearerLength   = 2
	TokenPos       = 1
	AuthHeader     = "Authorization"
	QueryToken     = "access_token"
	Localdev       = "http://localhost:3000"
	RunEnv         = "PPI_RUN_ENV"
	LocalEnv       = "local"
	// SkipAuth       = true
	SkipAuth = false
)

type Section int

const (
	StudioAuth Section = iota
	ProjctAuth
	UserAuth
)
