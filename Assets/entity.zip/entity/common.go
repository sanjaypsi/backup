package entity

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

var (
	ErrNotModified         = errors.New("not modified")          // 304
	ErrBadRequest          = errors.New("bad request")           // 400
	ErrUnauthorized        = errors.New("unauthorized")          // 401
	ErrForbidden           = errors.New("forbidden")             // 403
	ErrRecordNotFound      = errors.New("not found")             // 404  TODO: rename to ErrNotFound
	ErrConflict            = errors.New("conflict")              // 409
	ErrInternalServerError = errors.New("internal server error") // 500
	ErrBadGateway          = errors.New("bad gateway")           // 503

	// ErrLogEntryNotFound indicates that Cloud Logging log entry not found.
	ErrLogEntryNotFound = errors.New("log entry not found")
)

func NewNotModifiedError(msg string) error {
	return fmt.Errorf(msg+": %w", ErrNotModified)
}

func NewNotFoundError(msg string) error {
	return fmt.Errorf(msg+": %w", ErrRecordNotFound)
}

func NewBadRequestError(msg string) error {
	return fmt.Errorf(msg+": %w", ErrBadRequest)
}

func NewBadRequestErrorf(msg string, args ...interface{}) error {
	msg += ": %w"
	args = append(args, ErrBadRequest)
	return fmt.Errorf(msg, args...)
}

func NewConflictError(msg string) error {
	return fmt.Errorf(msg+": %w", ErrConflict)
}

func NewInternalServerError(msg string) error {
	return fmt.Errorf(msg+": %w", ErrInternalServerError)
}

func NewBadGatewayError(msg string) error {
	return fmt.Errorf(msg+": %w", ErrBadGateway)
}

type LogSeverity int

const (
	DEFAULT LogSeverity = 0
	DEBUG   LogSeverity = 100
	INFO    LogSeverity = 200
	WARNING LogSeverity = 400
	ERROR   LogSeverity = 500
)

func (s LogSeverity) String() string {
	switch s {
	case INFO:
		return "INFO"
	case WARNING:
		return "WARNING"
	case ERROR:
		return "ERROR"
	default:
		return "DEFAULT"
	}
}

func (s LogSeverity) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

type Logger interface {
	// SetLabel sets a key-value pair as a label in the logger's entry.
	SetLabel(key, value string)
	// SetProject sets the project name to the logger entry and label.
	SetProject(project string)
	// SetStudio sets the studio name to the logger entry and label.
	SetStudio(studio string)
	// SetSeverity sets the severity level of the logger.
	SetSeverity(severity LogSeverity)
	// SetMessage sets the message of the logger's entry.
	SetMessage(mst string)
	// Print sets the provided message as an entry in the logger and prints the entry marshaled
	// into JSON to standard out.
	Print(mst string)
	// Printf formats the provided msg using the args, sets it as an entry in the logger, and
	// prints the entry marshaled in JSON to standard output.
	Printf(mst string, args ...any)
	Debug(msg string)
	Debugf(msg string, args ...interface{})
	Info(msg string)
	Infof(msg string, args ...interface{})
	Warn(msg string)
	Warnf(msg string, args ...interface{})
	Error(msg string)
	Errorf(msg string, args ...interface{})
	Set(key string, value interface{})
	// With creates a new Logger instance with an additional key-value pair added to the existing
	// log entry.
	With(key string, value any) Logger
}

// JSONObject represents a json object type.
type JSONObject map[string]interface{}

func (j *JSONObject) UnmarshalJSON(b []byte) error {
	var result map[string]interface{}
	if err := json.Unmarshal(b, &result); err != nil {
		return err
	}
	*j = JSONObject(result)
	return nil
}

func (j JSONObject) MarshalJSON() ([]byte, error) {
	var value map[string]interface{} = j
	return json.Marshal(value)
}

type BaseEntity struct {
	CreatedBy     string    `json:"created_by"`
	CreatedAtUTC  time.Time `json:"created_at_utc"`
	ModifiedBy    string    `json:"modified_by"`
	ModifiedAtUTC time.Time `json:"modified_at_utc"`
	Deleted       *uint32   `json:"deleted,omitempty"`
}

type BaseListParams struct {
	PerPage   *int    `binding:"omitempty,min=0"`
	Page      *int    `binding:"omitempty,min=0"`
	Order     *string `binding:"omitempty"`
	OrderBy   *string `binding:"omitempty"`
	SearchKey *string `binding:"omitempty"`
}

func (*BaseListParams) DefaultPerPage() int {
	return 500
}

func (p *BaseListParams) GetPerPage() int {
	if p.PerPage == nil {
		return p.DefaultPerPage()
	}
	return *p.PerPage
}

func (p *BaseListParams) GetPage() int {
	if p.Page == nil {
		return 1
	}
	return *p.Page
}

func (p *BaseListParams) GetOrderBy() string {
	if p.OrderBy == nil {
		return "`id` ASC"
	}
	order := "ASC"
	orderBy := *p.OrderBy
	if orderBy[0:1] == "-" {
		order = "DESC"
		orderBy = orderBy[1:]
	}
	return "`" + orderBy + "`" + " " + order
}
