package entity

import "time"

// DataSyncClientStatus represents PPI DataSync Client operational status.
type DataSyncClientStatus struct {
	Project     string     `json:"project"`
	Studio      string     `json:"studio"`
	Status      string     `json:"status"`
	ConfirmedAt *time.Time `json:"confirmed_at"`
}
