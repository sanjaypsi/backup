package entity

import (
	"time"
)

// PublishTransactionInfo represents a publish transaction info entity.
type PublishTransactionInfo struct {
	LogID          string     `json:"log_id"`
	TaskID         string     `json:"task_id"`
	SubtaskID      string     `json:"subtask_id"`
	Studio         string     `json:"studio"`
	Project        string     `json:"project"`
	ProjectPath    string     `json:"project_path"`
	RevisionPath   string     `json:"revision_path"`
	Root           *string    `json:"root"`
	Groups         []string   `json:"groups"`
	Relation       *string    `json:"relation"`
	Phase          *string    `json:"phase"`
	Component      *string    `json:"component"`
	Revision       *string    `json:"revision"`
	NumBytes       *int64     `json:"num_bytes"`
	NumFiles       *int32     `json:"num_files"`
	ToolName       *string    `json:"tool_name"`
	ToolVersion    *string    `json:"tool_version"`
	Computer       *string    `json:"computer"`
	OS             *string    `json:"os"`
	OSVersion      *string    `json:"os_version"`
	User           *string    `json:"user"`
	TimestampUTC   *time.Time `json:"timestamp_utc"`
	Operation      string     `json:"operation"`
	Event          string     `json:"event"`
	StackTrace     *string    `json:"stack_trace"`
	AdditionalInfo JSONObject `json:"additional_info"`

	CreatedAtUTC  time.Time `json:"created_at_utc"`
	ModifiedAtUTC time.Time `json:"modified_at_utc"`
	ModifiedBy    string    `json:"modified_by"`
	CreatedBy     string    `json:"created_by"`
	ID            int32     `json:"id"`
}

type ListPublishTransactionInfoParams struct {
	Project string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	*BaseListParams
	RevisionPath *string `binding:"omitempty"`
	Operation    *string `binding:"omitempty"`
	Event        *string `binding:"omitempty"`
	Studio       *string `binding:"omitempty"`
	Root         *string `binding:"omitempty"`
	Group        *string `binding:"omitempty"`
	Phase        *string `binding:"omitempty"`
	Component    *string `binding:"omitempty"`
	User         *string `binding:"omitempty"`
	Revision     *string `binding:"omitempty"`
	IsExact      bool
}

func (*ListPublishTransactionInfoParams) DefaultPerPage() int {
	return 50
}

type GetPublishTransactionInfoParams struct {
	Project string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	LogID   string `binding:"uuid"`
}

type CreatePublishTransactionInfoParams struct {
	LogID          string     `binding:"uuid"`
	TaskID         string     `binding:"uuid"`
	SubtaskID      string     `binding:"uuid"`
	Studio         string     `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project        string     `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ProjectPath    string     `binding:"min=1,max=1000,excludesall=<>\"\\0x7C?*;"`
	RevisionPath   string     `binding:"min=1,max=1000,excludesall=<>:\"\\0x7C?*;,dirpath"`
	Root           *string    `binding:"omitempty,max=30,alphanumunderscore,startsnotwithdigit"`
	Groups         []string   `binding:"omitempty,dive,min=1,alphanumunderscore,startsnotwithdot"`
	Relation       *string    `binding:"omitempty,max=100,alphanumunderscore,startsnotwithdigit"`
	Phase          *string    `binding:"omitempty,max=100,alphanumunderscore,startsnotwithdigit"`
	Component      *string    `binding:"omitempty,max=100,alphanumunderscore,startsnotwithdigit"`
	Revision       *string    `binding:"omitempty,revision"`
	NumBytes       *int64     ``
	NumFiles       *int32     ``
	ToolName       *string    `binding:"omitempty,max=50,alphanumunderscore"`
	ToolVersion    *string    `binding:"omitempty,max=30,printascii"`
	Computer       *string    `binding:"omitempty,max=30"`
	OS             *string    `binding:"omitempty,oneof=lnx mac win"`
	OSVersion      *string    `binding:"omitempty,max=1000"`
	User           *string    `binding:"omitempty,max=100"`
	TimestampUTC   *time.Time `binding:"omitempty"`
	Operation      string     `binding:"min=1,max=30,alphanum,shouldoneof=publish upload download review"`
	Event          string     `binding:"min=1,max=30,alphanum,shouldoneof=started completed failed canceled"`
	StackTrace     *string    ``
	AdditionalInfo JSONObject ``
	CreatedBy      *string    `binding:"omitempty,min=1,max=100"`
}

type DeletePublishTransactionInfoParams struct {
	Project    string  `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	LogID      int32   `binding:"required"`
	ModifiedBy *string `binding:"omitempty,max=100"`
}
