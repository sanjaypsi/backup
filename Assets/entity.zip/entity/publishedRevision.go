package entity

import "time"

type ListPublishedRevisionDeliveryParams struct {
	*BaseListParams
	Project       string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root          *string `binding:"omitempty"`
	Group         *string `binding:"omitempty"`
	Relation      *string `binding:"omitempty"`
	Phase         *string `binding:"omitempty"`
	Component     *string `binding:"omitempty"`
	Revision      *string `binding:"omitempty"`
	Studio        *string `binding:"omitempty"`
	SubmittedUser *string `binding:"omitempty"`
	ExactMatch    *string `binding:"omitempty"`
}

type ListPublishedRevisionUsecaseParams struct {
	Project      string          `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	PublishInfos []*DocumentInfo ``
}

// json structure for return value to ListComposite API
type PublishedRevision struct {
	ID             uint32    `json:"id"`
	IsOfficial     bool      `json:"is_official"`
	Project        string    `json:"project"`
	Root           string    `json:"root"`
	Group          string    `json:"group"`
	Relation       string    `json:"relation"`
	Phase          string    `json:"phase"`
	Component      string    `json:"component"`
	Revision       string    `json:"revision"`
	Studio         string    `json:"studio"`
	SubmittedUser  string    `json:"submitted_user"`
	SubmittedAtUTC time.Time `json:"submitted_at_utc"`
	TaskID         string    `json:"task_id"`
	SubtaskID      string    `json:"subtask_id"`
	CreatedBy      string    `json:"created_by"`
	CreatedAtUTC   time.Time `json:"created_at_utc"`
	ModifiedBy     string    `json:"modified_by"`
	ModifiedAtUTC  time.Time `json:"modified_at_utc"`
}
