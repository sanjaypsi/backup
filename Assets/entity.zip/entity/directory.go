package entity

import (
	"time"
)

// Directory

type Directory struct {
	Project       string        `json:"project"`
	Path          string        `json:"path"`
	Depth         int32         `json:"depth"`
	Status        DeletionState `json:"status"`
	CreatedAtUTC  *time.Time    `json:"created_at_utc"`
	ModifiedAtUTC *time.Time    `json:"modified_at_utc"`
	Deleted       *int32        `json:"deleted,omitempty"`
	CreatedBy     *string       `json:"created_by"`
	ModifiedBy    *string       `json:"modified_by"`
	ID            int32         `json:"id"`
}

type ListDirectoryParams struct {
	Project       string         `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Paths         []string       ``
	PathPrefix    *string        `binding:"omitempty,min=1,max=1000"`
	Status        *DeletionState ``
	Depth         *int32         `bindinf:"omitempty,min=0"`
	ModifiedSince *time.Time     ``
	OrderBy       []string       `binding:"omitempty,dive,oneof=modified_at_utc -modified_at_utc path -path id -id"`
	SQLite        bool           ``
	GroupDir      bool           ``
	*BaseListParams
}

type GetDirectoryParams struct {
	Project string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path    string `binding:"min=1,max=1000,dirpath"`
}

type CreateDirectoryParams struct {
	Project   string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path      string  `binding:"min=1,max=1000,dirpath"`
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type ValidateDirectoryParams struct {
	Studio  string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path    string `binding:"min=1,max=1000,dirpath,grppath"`
}

func (p *CreateDirectoryParams) WithPath(path string) *CreateDirectoryParams {
	return &CreateDirectoryParams{
		Project:   p.Project,
		Path:      path,
		CreatedBy: p.CreatedBy,
	}
}

type DeleteDirectoryParams struct {
	SetDeleted bool     ``
	Project    string   `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path       string   `binding:"min=1,max=1000,dirpath"`
	ChildPaths []string `binding:"omitempty,dive,min=1,max=1000,dirpath"`
	ModifiedBy *string  `binding:"omitempty,min=1,max=100"`
}

type DeleteDirectoryFromStudioParams struct {
	Project    string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio     string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path       string  `binding:"min=1,max=1000,dirpath"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

// Directory Deletion Info

type DirectoryDeletionInfo struct {
	DirectoryID   int32
	Studio        string
	Status        DeletionState
	CreatedAtUTC  *time.Time
	ModifiedAtUTC *time.Time
	CreatedBy     *string
	ModifiedBy    *string
	ID            int32
}

type ListDirectoryDeletionInfoParams struct {
	DirectoryIDs []int32       `binding:"min=1"`
	Status       DeletionState ``
}

type CreateDirectoryDeletionInfoParams struct {
	Studios      []string `binding:"min=1,dive,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	DirectoryIDs []int32  `binding:"min=1"`
	CreatedBy    *string  `binding:"omitempty,min=1,max=100"`
}

type DeleteDirectoryDeletionInfoParams struct {
	Studio       string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	DirectoryIDs []int32 `binding:"min=1"`
	ModifiedBy   *string `binding:"omitempty,min=1,max=100"`
}
