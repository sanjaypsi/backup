package dataDependency

import (
	"time"

	"github.com/neo4j/neo4j-go-driver/v5/neo4j/db"
)

// DependencyStrength represents the strength of a dependency in the system.
type DependencyStrength string

const (
	// Strong represents a strong dependency strength.
	Strong DependencyStrength = "strong"
	// Weak represents a weak dependency strength.
	Weak DependencyStrength = "weak"
)

// StorageSection represents a type for defining different sections of storage.
type StorageSection string

const (
	// Shared represents a storage section that is shared among multiple studios.
	Shared StorageSection = "shared"
	// Unshared represents a storage section that is unshared among multiple studios.
	Unshared StorageSection = "unshared"
)

// DependencyConnection represents a connection between entities with a specified strength.
type DependencyConnection struct {
	// The Strength field indicates the strength of dependency between the connected entities.
	Strength DependencyStrength `json:"strength"`
}

// NewDependencyConnectionFromRecord creates a new DependencyConnection instance from a given
// database record. It extracts the "strength" field from the record and converts it to a
// DependencyStrength type.
//
// Parameters:
//   - r *db.Record - The database record from which to create the DependencyConnection.
//
// Returns:
//   - DependencyConnection - A pointer to the newly created DependencyConnection instance.
func NewDependencyConnectionFromRecord(r *db.Record) *DependencyConnection {
	strength, _ := r.Get("strength")
	return &DependencyConnection{
		Strength: DependencyStrength(strength.(string)),
	}
}

// ContentDependency represents a dependency content and its strength of the dependency.
type ContentDependency struct {
	Content  *Content           `json:"content"`
	Strength DependencyStrength `json:"strength"`
}

// NewContentDependencyFromRecord creates a new ContentDependency instance from a database record.
// It extracts the content and strength fields from the record and initializes a ContentDependency
// struct.
//
// Parameters:
//   - r: A pointer to a db.Record containing the data for the ContentDependency.
//
// Returns:
//   - A pointer to a newly created ContentDependency instance.
func NewContentDependencyFromRecord(r *db.Record) *ContentDependency {
	content := NewContentFromRecord(r)
	strength, _ := r.Get("strength")

	return &ContentDependency{
		Content:  content,
		Strength: DependencyStrength(strength.(string)),
	}
}

// Root represents the root entity containing metadata about a project.
type Root struct {
	Project   string    `json:"project"`
	KeyName   string    `json:"key_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewRootFromRecord creates a new Root instance from a given db.Record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - keyName: the key name (string)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's name (string)
//
// Parameters:
//   - r: A pointer to a db.Record containing the data to populate the Root struct.
//
// Returns:
//   - A pointer to a newly created Root struct populated with data from the record.
func NewRootFromRecord(r *db.Record) *Root {
	project, _ := r.Get("project")
	keyName, _ := r.Get("keyName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &Root{
		Project:   project.(string),
		KeyName:   keyName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// Group represents a collection of related entities within a project.
type Group struct {
	Project   string    `json:"project"`
	Root      string    `json:"root"`
	KeyName   string    `json:"key_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewGroupFromRecord creates a new Group instance from a database record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root directory (string)
//   - keyName: the key name (string)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's name (string)
//
// Parameters:
//   - r: a pointer to a db.Record from which the Group fields are extracted.
//
// Returns:
//   - A pointer to a newly created Group instance.
func NewGroupFromRecord(r *db.Record) *Group {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	keyName, _ := r.Get("keyName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &Group{
		Project:   project.(string),
		Root:      root.(string),
		KeyName:   keyName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// Relation represents a collection of related entities within a project.
type Relation struct {
	Project   string    `json:"project"`
	Root      string    `json:"root"`
	Group     string    `json:"group"`
	KeyName   string    `json:"key_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewRelationFromRecord creates a new Relation instance from a database record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root directory (string)
//   - group: the group name (string)
//   - keyName: the key name (string)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's name (string)
//
// Parameters:
//   - r: A pointer to a db.Record from which the Relation fields are extracted.
//
// Returns:
//   - A pointer to a newly created Relation instance.
func NewRelationFromRecord(r *db.Record) *Relation {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	group, _ := r.Get("group")
	keyName, _ := r.Get("keyName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &Relation{
		Project:   project.(string),
		Root:      root.(string),
		Group:     group.(string),
		KeyName:   keyName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// PhaseDirectory represents the structure of a phase directory in a project.
type PhaseDirectory struct {
	Project   string    `json:"project"`
	Root      string    `json:"root"`
	Group     string    `json:"group"`
	Relation  string    `json:"relation"`
	KeyName   string    `json:"key_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewPhaseDirectoryFromRecord creates a new PhaseDirectory instance from a database record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root directory (string)
//   - group: the group name (string)
//   - relation: the relation type (string)
//   - keyName: the key name (string)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's name (string)
//
// Parameters:
//   - r: a pointer to a db.Record containing the necessary fields.
//
// Returns:
//   - A pointer to a PhaseDirectory instance populated with the extracted fields.
func NewPhaseDirectoryFromRecord(r *db.Record) *PhaseDirectory {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	group, _ := r.Get("group")
	relation, _ := r.Get("relation")
	keyName, _ := r.Get("keyName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &PhaseDirectory{
		Project:   project.(string),
		Root:      root.(string),
		Group:     group.(string),
		Relation:  relation.(string),
		KeyName:   keyName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// ComponentDirectory represents the structure of a component directory in the project.
type ComponentDirectory struct {
	Project   string    `json:"project"`
	Root      string    `json:"root"`
	Group     string    `json:"group"`
	Relation  string    `json:"relation"`
	Phase     string    `json:"phase"`
	KeyName   string    `json:"key_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewComponentDirectoryFromRecord creates a new ComponentDirectory instance from a database
// record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root directory (string)
//   - group: the group name (string)
//   - relation: the relation type (string)
//   - phase: the phase of the project (string)
//   - keyName: the key name (string)
//   - createdAt: the creation time (time.Time)
//   - createdBy: the creator's name (string)
//
// Parameters:
//   - r: a pointer to a db.Record containing the necessary fields.
//
// Returns:
//   - A pointer to a ComponentDirectory instance populated with the extracted fields.
func NewComponentDirectoryFromRecord(r *db.Record) *ComponentDirectory {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	group, _ := r.Get("group")
	relation, _ := r.Get("relation")
	phase, _ := r.Get("phase")
	keyName, _ := r.Get("keyName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &ComponentDirectory{
		Project:   project.(string),
		Root:      root.(string),
		Group:     group.(string),
		Relation:  relation.(string),
		Phase:     phase.(string),
		KeyName:   keyName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// Revision represents the structure of a component revision in the project.
type Revision struct {
	Project   string    `json:"project"`
	Root      string    `json:"root"`
	Group     string    `json:"group"`
	Relation  string    `json:"relation"`
	Phase     string    `json:"phase"`
	Component string    `json:"component"`
	KeyName   string    `json:"key_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewRevisionFromRecord creates a new Revision instance from a database record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root identifier (string)
//   - group: the group identifier (string)
//   - relation: the relation identifier (string)
//   - phase: the phase identifier (string)
//   - component: the component identifier (string)
//   - keyName: the key name (string)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's identifier (string)
//
// Parameters:
//   - r: a pointer to a db.Record from which the fields are extracted.
//
// Returns:
//   - A pointer to a newly created Revision instance populated with the extracted fields.
func NewRevisionFromRecord(r *db.Record) *Revision {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	group, _ := r.Get("group")
	relation, _ := r.Get("relation")
	phase, _ := r.Get("phase")
	component, _ := r.Get("component")
	keyName, _ := r.Get("keyName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &Revision{
		Project:   project.(string),
		Root:      root.(string),
		Group:     group.(string),
		Relation:  relation.(string),
		Phase:     phase.(string),
		Component: component.(string),
		KeyName:   keyName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// Content represents the structure of a content entity with various attributes.
type Content struct {
	Project   string    `json:"project"`
	Root      string    `json:"root"`
	Group     string    `json:"group"`
	Relation  string    `json:"relation"`
	Phase     string    `json:"phase"`
	Component string    `json:"component"`
	Revision  string    `json:"revision"`
	FileName  string    `json:"file_name"`
	CreatedAt time.Time `json:"created_at"`
	CreatedBy string    `json:"created_by"`
}

// NewContentFromRecord creates a new Content instance from a database record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root identifier (string)
//   - group: the group identifier (string)
//   - relation: the relation identifier (string)
//   - phase: the phase identifier (string)
//   - component: the component identifier (string)
//   - revision: the revision identifier (string)
//   - fileName: the file name (string)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's identifier (string)
//
// Parameters:
//   - r: a pointer to a db.Record from which the content fields are extracted.
//
// Returns:
//   - A pointer to a newly created Content instance populated with the extracted fields.
func NewContentFromRecord(r *db.Record) *Content {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	group, _ := r.Get("group")
	relation, _ := r.Get("relation")
	phase, _ := r.Get("phase")
	component, _ := r.Get("component")
	revision, _ := r.Get("revision")
	fileName, _ := r.Get("fileName")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &Content{
		Project:   project.(string),
		Root:      root.(string),
		Group:     group.(string),
		Relation:  relation.(string),
		Phase:     phase.(string),
		Component: component.(string),
		Revision:  revision.(string),
		FileName:  fileName.(string),
		CreatedAt: createdAt.(time.Time),
		CreatedBy: createdBy.(string),
	}
}

// ContentFile represents a file containing content related to a specific project.
type ContentFile struct {
	Project        string         `json:"project"`
	Root           string         `json:"root"`
	Group          string         `json:"group"`
	Relation       string         `json:"relation"`
	Phase          string         `json:"phase"`
	Component      string         `json:"component"`
	Revision       string         `json:"revision"`
	Content        string         `json:"content"`
	FilePath       string         `json:"file_path"`
	StorageSection StorageSection `json:"storage_section"`
	CreatedAt      time.Time      `json:"created_at"`
	CreatedBy      string         `json:"created_by"`
}

// NewContentFileFromRecord creates a new ContentFile instance from a database record.
// It extracts the following fields from the record:
//   - project: the project name (string)
//   - root: the root directory (string)
//   - group: the group name (string)
//   - relation: the relation type (string)
//   - phase: the phase of the project (string)
//   - component: the component name (string)
//   - revision: the revision number (string)
//   - content: the content description (string)
//   - filePath: the file path (string)
//   - storageSection: the storage section (string, converted to StorageSection type)
//   - createdAt: the creation timestamp (time.Time)
//   - createdBy: the creator's name (string)
//
// Parameters:
//   - r: a pointer to a db.Record containing the data to be converted.
//
// Returns:
//   - A pointer to a newly created ContentFile instance populated with the extracted data.
func NewContentFileFromRecord(r *db.Record) *ContentFile {
	project, _ := r.Get("project")
	root, _ := r.Get("root")
	group, _ := r.Get("group")
	relation, _ := r.Get("relation")
	phase, _ := r.Get("phase")
	component, _ := r.Get("component")
	revision, _ := r.Get("revision")
	content, _ := r.Get("content")
	filePath, _ := r.Get("filePath")
	storageSection, _ := r.Get("storageSection")
	createdAt, _ := r.Get("createdAt")
	createdBy, _ := r.Get("createdBy")

	return &ContentFile{
		Project:        project.(string),
		Root:           root.(string),
		Group:          group.(string),
		Relation:       relation.(string),
		Phase:          phase.(string),
		Component:      component.(string),
		Revision:       revision.(string),
		Content:        content.(string),
		FilePath:       filePath.(string),
		StorageSection: StorageSection(storageSection.(string)),
		CreatedAt:      createdAt.(time.Time),
		CreatedBy:      createdBy.(string),
	}
}

// Dependency represents a data dependency entity with various attributes.
type Dependency struct {
	Root           string             `json:"root" binding:"min=1"`
	Group          string             `json:"group" binding:"min=1"`
	Relation       string             `json:"relation" binding:"min=1"`
	Phase          string             `json:"phase" binding:"min=1"`
	Component      string             `json:"component" binding:"min=1"`
	Revision       string             `json:"revision" binding:"len=30"`
	FileName       string             `json:"file_name" binding:"min=1"`
	StorageSection StorageSection     `json:"storage_section" binding:"oneof=shared unshared"`
	FilePath       string             `json:"file_path" binding:"min=1"`
	Strength       DependencyStrength `json:"strength" binding:"oneof=strong weak"`
}

// DataDependency represents a structure that holds information about a piece of content and
// its associated dependencies.
type DataDependency struct {
	Content      string        `json:"content" binding:"min=1"`
	Dependencies []*Dependency `json:"dependencies" binding:"omitempty,dive"`
}

// AddContentDependenciesParams represents the parameters required to add dependencies.
type AddContentDependenciesParams struct {
	CreatedBy    *string       `json:"created_by,omitempty" binding:"omitempty,max=100"`
	Dependencies []*Dependency `json:"dependencies" binding:"omitempty,dive"`
}

// ContentDependencyWithFile represents a structure that combines a content dependency with its
// associated content file.
type ContentDependencyWithFile struct {
	*ContentDependency
	ContentFile *ContentFile `json:"content_file"`
}

// ContentAndDependenciesWithFile represents a structure that holds content and its associated
// dependencies.
type ContentAndDependenciesWithFile struct {
	Content      *Content                     `json:"content"`
	Dependencies []*ContentDependencyWithFile `json:"dependencies"`
}
