package entity

import "time"

type ListOfficialRevisionParams struct {
	*BaseListParams
	Project       string     `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	OrderBy       []string   `binding:"omitempty,dive,oneof=id -id is_official -is_official project -project root -root group -group relation -relation phase -phase component -component revision -revision studio -studio submitted_user -submitted_user submitted_at_utc -submitted_at_utc task_id -task_id subtask_id -subtask_id modified_at_utc -modified_at_utc "`
	ModifiedSince *time.Time ``
}

type UpsertOfficialRevisionDeliveryParams struct {
	IsOfficial *bool  `binding:"required"`
	Project    string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root       string `binding:"min=1"`
	Group      string `binding:"min=1,max=100,dirpath,grppath"`
	Relation   string `binding:"min=1"`
	Phase      string `binding:"min=1"`
	Component  string `binding:"min=1"`
	Revision   string `binding:"required,revision"`
	ModifiedBy string ``
}

type UpsertOfficialRevisionUsecaseParams struct {
	IsOfficial     bool
	Project        string
	Root           string
	Group          string
	Relation       string
	Phase          string
	Component      string
	Revision       string
	Studio         string
	SubmittedUser  string
	SubmittedAtUTC time.Time
	TaskID         string
	SubtaskID      string
	CreatedBy      string
	CreatedAtUTC   time.Time
	ModifiedBy     string
	ModifiedAtUTC  time.Time
}

// json structure for return value to List API
type OfficialRevision struct {
	ID             uint32    `json:"id"`
	IsOfficial     bool      `json:"is_official"`
	Project        string    `json:"project"`
	Root           string    `json:"root"`
	Group          string    `json:"group"`
	Relation       string    `json:"relation"`
	Phase          string    `json:"phase"`
	Component      string    `json:"component"`
	Revision       string    `json:"revision"`
	Studio         string    `json:"studio"`
	SubmittedUser  string    `json:"submitted_user"`
	SubmittedAtUTC time.Time `json:"submitted_at_utc"`
	TaskID         string    `json:"task_id"`
	SubtaskID      string    `json:"subtask_id"`
	CreatedBy      string    `json:"created_by"`
	CreatedAtUTC   time.Time `json:"created_at_utc"`
	ModifiedBy     string    `json:"modified_by"`
	ModifiedAtUTC  time.Time `json:"modified_at_utc"`
}
