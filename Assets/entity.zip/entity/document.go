package entity

import (
	"encoding/json"
	"fmt"
)

// Document represents a document.
type Document struct {
	*DocumentInfo
	mongoDB DocumentRepository
}

func (d *Document) String() string {
	return fmt.Sprintf("%v", d.DocumentInfo)
}

// MarshalJSON returns the JSON encoding of struct.
func (d *Document) MarshalJSON() ([]byte, error) {
	return json.Marshal(d.DocumentInfo)
}

// NewDocument returns a new Document
func NewDocument(
	info *DocumentInfo,
	mongoDB DocumentRepository,
) *Document {
	return &Document{
		DocumentInfo: info,
		mongoDB:      mongoDB,
	}
}
