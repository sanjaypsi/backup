package entity

import "time"

type StudioInfo2 struct {
	KeyName  string   `json:"key_name"`
	Projects []string `json:"projects"`

	CreatedAtUTC  *time.Time `json:"created_at_utc"`
	ModifiedAtUTC *time.Time `json:"modified_at_utc"`
	ModifiedBy    *string    `json:"modified_by"`
	CreatedBy     *string    `json:"created_by"`
	ID            int32      `json:"id"`
}

type ListStudioInfoParams struct {
	*BaseListParams
	Studio string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
}

func (*ListStudioInfoParams) DefaultPerPage() int {
	return 50
}

type GetStudioInfoParams struct {
	KeyName string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
}

type CreateStudioInfoParams struct {
	KeyName   string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type UpdateStudioParams struct {
	*GetStudioInfoParams
	Operation  string   `binding:"oneof=add remove"`
	Projects   []string `binding:"min=1"`
	ModifiedBy *string  `binding:"omitempty,min=1,max=100"`
}

type DeleteStudioInfoParams struct {
	KeyName    string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}
