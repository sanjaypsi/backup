package entity

import (
	"time"
)

type GetReviewStatusesParams struct {
	Project         string   `binding:"required"`
	Studio          string   `binding:"required"`
	MailAddresses   []string `binding:"required"`
	MailCCAddresses []string
	MailSubject     string `binding:"required"`
	MailComment     string
	ModifiedAtUTC   time.Time `json:"modified_at_utc"`
	ModifiedBy      string    `binding:"required"`
	TakeParams      []string  `json:"take_params"`
	RelationList    []string  `json:"relation_list"`
	PhaseList       []string  `json:"phase_list"`
}

type ReviewStatusLog struct {
	Studio       string `json:"studio"`
	Project      string `json:"project"`
	UpdateID     string `json:"update_id"`
	ReviewInfoID int32  `json:"review_info_id"`
	StatusType   string `json:"status_type"`
	Status       string `json:"status"`

	CreatedAtUTC  time.Time `json:"created_at_utc"`
	CreatedBy     string    `json:"created_by"`
	ID            int32     `json:"id"`
}

type ListReviewStatusLogParams struct {
	Project      string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio       *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	UpdateID     *string `binding:"omitempty,uuid"`
	ReviewInfoID *int32  ``
	StatusType   *string `binding:"omitempty,min=1,max=20"`
	Status       *string `binding:"omitempty,min=1,max=20"`
	*BaseListParams
}

func (ListReviewStatusLogParams) DefaultPerPage() int {
	return 200
}

type GetReviewStatusLogParams struct {
	Project string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ID      int32  `binding:"required"`
}

type CreateReviewStatusLogParams struct {
	Studio       string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project      string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	UpdateID     string `binding:"required"`
	ReviewInfoID int32  `binding:"required"`
	StatusType   string `binding:"required"`
	Status       string `binding:"required"`

	CreatedAtUTC *time.Time
	CreatedBy    string
	ID           *int32
}
