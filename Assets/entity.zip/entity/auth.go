package entity

type StudioAuthParams struct {
	Project    string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	AuthHeader string `binding:"required"`
}

type ProjectAccessParams struct {
	Studio  string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit,required"`
	Project string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit,required"`
}

type LoginParams struct {
	Studio   string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit,required"`
	Password string `binding:"min=8,max=100,alphanum,required"`
}
