package entity

import (
	"reflect"
	"testing"
)

func TestNewDirPath(t *testing.T) {
	cases := []struct {
		Path   string
		Expect string
	}{
		{"a\\b\\c", "a/b/c"},
		{"/a/b/c/", "a/b/c"},
		{"a//b///c", "a/b/c"},
	}
	for _, tc := range cases {
		path, err := NewDirPath(tc.Path)
		if err != nil {
			t.Fatal(err)
		}
		got := path.String()
		if got != tc.Expect {
			t.Fatalf("got \"%s\"; expect \"%s\"", got, tc.Expect)
		}
	}
}

func TestDirPathDepth(t *testing.T) {
	cases := []struct {
		Path   string
		Expect int
	}{
		{"a", 1},
		{"a/b", 2},
		{"a/b/c", 3},
	}
	for _, tc := range cases {
		path, err := NewDirPath(tc.Path)
		if err != nil {
			t.Fatal(err)
		}
		got := path.Depth()
		if got != tc.Expect {
			t.Fatalf("got %d; expect %d", got, tc.Expect)
		}
	}
}

func TestDirPathPaths(t *testing.T) {
	cases := []struct {
		Path   string
		Expect []string
	}{
		{"a", []string{}},
		{"a/b", []string{"a"}},
		{"a/b/c", []string{"a", "a/b"}},
	}
	for _, tc := range cases {
		t.Run(tc.Path, func(t *testing.T) {
			path, err := NewDirPath(tc.Path)
			if err != nil {
				t.Fatal(err)
			}
			parents := path.Parents()
			got := []string{}
			for _, parent := range parents {
				got = append(got, parent.String())
			}
			if !reflect.DeepEqual(got, tc.Expect) {
				t.Fatalf("got %q; expect %q", got, tc.Expect)
			}
		})
	}
}

func TestDirPathValidate(t *testing.T) {
	cases := []struct {
		Path   string
		Expect bool
	}{
		{".a", false},
		{"a/.b", false},
		{"a/b.c", true},
		{"a/b/c.", true},
		{"../a", false},
		{".", false},
	}
	for _, tc := range cases {
		t.Run(tc.Path, func(t *testing.T) {
			_, err := NewDirPath(tc.Path)
			got := false
			if err == nil {
				got = true
			}
			if got != tc.Expect {
				t.Fatalf("got %t; expect %t", got, tc.Expect)
			}
		})
	}
}
