package pipelineParameter

import (
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/xeipuuv/gojsonschema"
)

// Parameter

type Parameter struct {
	ID          uint32            `json:"id"`
	KeyName     string            `json:"key_name"`
	Schema      entity.JSONObject `json:"schema"`
	DisplayName *string           `json:"display_name"`
	Description *string           `json:"description"`
	*entity.BaseEntity
}

func (p *Parameter) Validate(value interface{}) error {
	schemaLoader := gojsonschema.NewGoLoader(p.Schema)
	valueLoader := gojsonschema.NewGoLoader(value)
	result, err := gojsonschema.Validate(schemaLoader, valueLoader)
	if err != nil {
		return err
	}
	if !result.Valid() {
		var errStr string
		for _, err := range result.Errors() {
			errStr += ":" + err.String()
		}
		return errors.New(errStr)
	}
	return nil
}

type ListParameterUpdatesParams struct {
	ModifiedSince *time.Time `json:"modified_since,omitempty"`
	*entity.BaseListParams
}

type ListParametersParams struct {
	OrderBy []string `json:"order_by,omitempty" binding:"omitempty,dive,oneof=modified_at_utc -modified_at_utc key_name -key_name id -id"`
	*entity.BaseListParams
}

type GetParameterParams struct {
	KeyName string `json:"key_name" binding:"min=1,max=50,alphanumunderscore"`
}

type CreateParameterParams struct {
	KeyName     string            `json:"key_name" binding:"min=1,max=50,alphanumunderscore"`
	Schema      entity.JSONObject `json:"schema" binding:"required"`
	DisplayName *string           `json:"display_name,omitempty" binding:"omitempty,max=50"`
	Description *string           `json:"description,omitempty" binding:"omitempty,max=65535"`
	CreatedBy   *string           `json:"created_by,omitempty" binding:"omitempty,min=1,max=100"`
}

type DeleteParameterParams struct {
	KeyName    string  `json:"key_name" binding:"min=1,max=50,alphanumunderscore"`
	ModifiedBy *string `json:"modified_by,omitempty" binding:"omitempty,min=1,max=100"`
}

// Location

type Location struct {
	ID        uint32 `json:"id"`
	Project   string `json:"project"`
	Parameter string `json:"parameter"`
	Path      string `json:"path"`
	Depth     uint8  `json:"depth"`
	*entity.BaseEntity
}

type ListLocationUpdatesParams struct {
	Project       string     `json:"project" binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ModifiedSince *time.Time `json:"modified_since,omitempty"`
	*entity.BaseListParams
}

type ListLocationsParams struct {
	Project   string   `json:"project" binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Parameter *string  `json:"parameter,omitempty" binding:"omitempty,min=1,max=50,alphanumunderscore"`
	OrderBy   []string `json:"order_by,omitempty" binding:"omitempty,dive,oneof=modified_at_utc -modified_at_utc parameter -parameter path -path id -id"`
	*entity.BaseListParams
}

type GetLocationParams struct {
	Project string `json:"project" binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ID      uint32 `json:"id"`
}

type CreateLocationParams struct {
	Project   string  `json:"project" binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Parameter string  `json:"parameter" binding:"min=1,max=50,alphanumunderscore"`
	Path      string  `json:"path" binding:"max=500,parameterlocation"`
	CreatedBy *string `json:"created_by,omitempty" binding:"omitempty,min=1,max=100"`
}

type DeleteLocationParams struct {
	Project    string  `json:"project" binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ID         uint32  `json:"id"`
	ModifiedBy *string `json:"modified_by,omitempty" binding:"omitempty,min=1,max=100"`
}

// Value

type Value struct {
	ID        uint32      `json:"id"`
	Parameter string      `json:"parameter"`
	Location  string      `json:"location"`
	Depth     uint8       `json:"depth"`
	Value     interface{} `json:"value"`
	Studio    *string     `json:"studio"`
	Project   *string     `json:"project"`
	*entity.BaseEntity
}

type ListValueUpdatesParams struct {
	Studio        *string    `json:"studio,omitempty" binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project       *string    `json:"project,omitempty" binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ModifiedSince *time.Time `json:"modified_since,omitempty"`
	*entity.BaseListParams
}

type ListValuesParams struct {
	Parameter       *string  `json:"parameter,omitempty" binding:"omitempty,min=1,max=50,alphanumunderscore"`
	Studios         []string `json:"studios,omitempty" binding:"omitempty,dive,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Projects        []string `json:"projects,omitempty" binding:"omitempty,dive,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Location        *string  `json:"location,omitempty" binding:"omitempty,max=500,parameterlocation"`
	OrderBy         []string `json:"order_by,omitempty" binding:"omitempty,dive,oneof=modified_at_utc -modified_at_utc parameter -parameter location -location id -id"`
	FilterParameter *string  `json:"filter_parameter,omitempty"`
	FilterStudio    *string  `json:"filter_studio,omitempty"`
	FilterProject   *string  `json:"filter_project,omitempty"`
	FilterLocation  *string  `json:"filter_location,omitempty"`
	FilterValue     *string  `json:"filter_value,omitempty"`
	*entity.BaseListParams
}

type GetValueParams struct {
	ID uint32 `json:"id"`
}

type CreateValueParams struct {
	Parameter string      `json:"parameter" binding:"min=1,max=50,alphanumunderscore"`
	Studio    *string     `json:"studio,omitempty" binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project   *string     `json:"project,omitempty" binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Location  string      `json:"location" binding:"max=500,parameterlocation"`
	Value     interface{} `json:"value" binding:"required"`
	CreatedBy *string     `json:"created_by,omitempty" binding:"omitempty,min=1,max=100"`
}

type UpdateValueParams struct {
	ID         uint32      `json:"id"`
	Parameter  string      `json:"parameter" binding:"min=1,max=50,alphanumunderscore"`
	Value      interface{} `json:"value" binding:"required"`
	ModifiedBy *string     `json:"modified_by,omitempty" binding:"omitempty,min=1,max=100"`
}

type UpsertValueParams struct {
	Parameter  string      `json:"parameter" binding:"min=1,max=50,alphanumunderscore"`
	Studio     *string     `json:"studio,omitempty" binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project    *string     `json:"project,omitempty" binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Location   string      `json:"location" binding:"max=500,parameterlocation"`
	Value      interface{} `json:"value" binding:"required"`
	CreatedBy  *string     `json:"created_by,omitempty" binding:"omitempty,min=1,max=100"`
	ModifiedBy *string     `json:"modified_by,omitempty" binding:"omitempty,min=1,max=100"`
}

type DeleteValueParams struct {
	ID         uint32  `json:"id"`
	ModifiedBy *string `json:"modified_by,omitempty" binding:"omitempty,min=1,max=100"`
}
