package entity

import (
	"context"
	"fmt"
	"log"
)

// Project represents a project.
type Project struct {
	*ProjectInfo
	myRepo  InfoRepository
	colRepo DocumentRepository
}

func (p *Project) String() string {
	return fmt.Sprintf("%v", p.ProjectInfo)
}

// NewProject is a function that creates a new Project.
func NewProject(
	info *ProjectInfo,
	myRepo InfoRepository,
	colRepo DocumentRepository,
) *Project {
	return &Project{
		ProjectInfo: info,
		myRepo:      myRepo,
		colRepo:     colRepo,
	}
}

// CreateDocument creates a new document.
func (p *Project) CreateDocument(
	ctx context.Context,
	collection string,
	params map[string]interface{},
) (*Document, error) {
	info, err := p.colRepo.CreateDocument(ctx, p.Name, collection, params)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("failed to create document for project %v and collection %v by params %v", p.Name, collection, params)
	}
	document := NewDocument(info, p.colRepo)
	return document, nil
}

// GetDocuments returns corresponding documents.
func (p *Project) GetDocuments(
	ctx context.Context,
	collection string,
	param *QueryDocumentsParam,
) ([]*Document, int, error) {
	infos, total, err := p.colRepo.GetDocumentsByFields(ctx, p.Name, collection, param)
	if err != nil {
		log.Println(err)
		return nil, -1, fmt.Errorf("failed to find documents by params %v", param)
	}
	documents := []*Document{}
	for _, info := range infos {
		documents = append(documents, NewDocument(info, p.colRepo))
	}
	return documents, total, nil
}

// GetDocumentByID returns the document corresponding to the id.
func (p *Project) GetDocumentByID(
	ctx context.Context,
	collection string,
	id string,
) (*Document, error) {
	info, err := p.colRepo.GetDocumentByID(ctx, p.Name, collection, id)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("document not found for id %v", id)
	}
	return NewDocument(info, p.colRepo), nil
}

// UpdateDocument updates a document.
func (p *Project) UpdateDocument(
	ctx context.Context,
	collection string,
	id string,
	params map[string]interface{},
) (*Document, error) {
	_, err := p.colRepo.GetDocumentByID(ctx, p.Name, collection, id)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("failed to get document by id %v", id)
	}
	info, err := p.colRepo.UpdateDocument(ctx, p.Name, collection, id, params)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("failed to update document %v", id)
	}
	return NewDocument(info, p.colRepo), nil
}

// DeleteDocument deletes a documet.
func (p *Project) DeleteDocument(ctx context.Context, collection, id string) error {
	_, err := p.colRepo.GetDocumentByID(ctx, p.Name, collection, id)
	if err != nil {
		log.Println(err)
		return fmt.Errorf("failed to get document by id %v", id)
	}
	return p.colRepo.DeleteDocument(ctx, p.Name, collection, id)
}

// GetStudios returns the studios associated with the project.
func (p *Project) GetStudios(ctx context.Context) ([]*Studio, error) {
	infos, err := p.myRepo.GetStudiosByProject(ctx, p.Name)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("failed to get studios by project %v", p.Name)
	}
	studios := []*Studio{}
	for _, info := range infos {
		studio := NewStudio(info, p.myRepo)
		studios = append(studios, studio)
	}
	return studios, nil
}

// GetStudioByName returns the studio corresponding to the name among the studios associated with the project.
func (p *Project) GetStudioByName(ctx context.Context, name string) (*Studio, error) {
	infos, err := p.myRepo.GetStudiosByProject(ctx, p.Name)
	if err != nil {
		log.Println(err)
		return nil, fmt.Errorf("failed to get studios by project %v", p.Name)
	}
	for _, info := range infos {
		if info.Name == name {
			return NewStudio(info, p.myRepo), nil
		}
	}
	return nil, fmt.Errorf("studio %v not found", name)
}
