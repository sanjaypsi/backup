package entity

import "time"

type GroupDirectory struct {
	Project       string        `json:"project"`
	Path          string        `json:"path"`
	Depth         int32         `json:"depth"`
	Status        DeletionState `json:"status"`
	CreatedAtUTC  *time.Time    `json:"created_at_utc"`
	ModifiedAtUTC *time.Time    `json:"modified_at_utc"`
	Deleted       *int32        `json:"deleted,omitempty"`
	CreatedBy     *string       `json:"created_by"`
	ModifiedBy    *string       `json:"modified_by"`
	ID            int32         `json:"id"`
}
