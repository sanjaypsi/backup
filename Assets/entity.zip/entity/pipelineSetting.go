package entity

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/xeipuuv/gojsonschema"
)

var ErrSectionNotSelected = errors.New("section not selected")

// Pipeline Setting Group

// PipelineSettingGroup is a representation of the setting group
type PipelineSettingGroup int

const (
	// Config is a config group of the setting
	Config PipelineSettingGroup = iota + 1
	// Environment is a environment group of the setting
	Environment
	// Preference is a preference group of the setting
	Preference
)

var groupMap = map[PipelineSettingGroup]string{
	Config:      "config",
	Preference:  "preference",
	Environment: "environment",
}

func ParsePipelineSettingGroup(s string) (PipelineSettingGroup, bool) {
	for grp, str := range groupMap {
		if str == strings.ToLower(s) {
			return grp, true
		}
	}
	return 0, false
}

func (g PipelineSettingGroup) String() string {
	str, ok := groupMap[g]
	if ok {
		return str
	}
	return "unknown"
}

func (r PipelineSettingGroup) MarshalJSON() ([]byte, error) {
	return json.Marshal(r.String())
}

// Pipeline Setting Section

type PipelineSettingSection int

const (
	CommonSection PipelineSettingSection = iota + 1
	StudioSection
	ProjectSection
)

var sectionMap = map[PipelineSettingSection]string{
	CommonSection:  "common",
	StudioSection:  "studio",
	ProjectSection: "project",
}

func ParsePipelineSettingSection(s string) (PipelineSettingSection, bool) {
	for sec, str := range sectionMap {
		if str == s {
			return sec, true
		}
	}
	return 0, false
}

func (s PipelineSettingSection) String() string {
	str, ok := sectionMap[s]
	if ok {
		return str
	}
	return ""
}

func (s PipelineSettingSection) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

// JSON Schema

type JSONSchema struct {
	Type    string        `json:"type" binding:"required"`
	Enum    []interface{} `json:"enum,omitempty"`
	Items   *JSONSchema   `json:"items,omitempty"`
	Default interface{}   `json:"default,omitempty"`
	Minimum interface{}   `json:"minimum,omitempty"`
	Maximum interface{}   `json:"maximum,omitempty"`
	Pattern *string       `json:"pattern,omitempty"`
}

func (s *JSONSchema) HasPattern() bool {
	return s.Type == JSONString && s.Pattern != nil ||
		s.Type == JSONArray && s.Items != nil && s.Items.HasPattern()
}

// Properties

type PipelineSettingProperty struct {
	ID            uint32                  `json:"id"`
	Group         PipelineSettingGroup    `json:"group"`
	Section       *PipelineSettingSection `json:"section"`
	Key           string                  `json:"key"`
	Schema        *JSONSchema             `json:"schema"`
	CreatedBy     *string                 `json:"created_by"`
	CreatedAtUTC  *time.Time              `json:"created_at_utc"`
	ModifiedBy    *string                 `json:"modified_by"`
	ModifiedAtUTC *time.Time              `json:"modified_at_utc"`
	Required      bool                    `json:"required"`
}

func (p *PipelineSettingProperty) Validate(value interface{}) error {
	if p.Schema == nil {
		return fmt.Errorf("property %q has no schema", p.Key)
	}
	schemaLoader := gojsonschema.NewGoLoader(p.Schema)
	valueLoader := gojsonschema.NewGoLoader(value)
	result, err := gojsonschema.Validate(schemaLoader, valueLoader)
	if err != nil {
		return err
	}
	if !result.Valid() {
		var errStr string
		for _, err := range result.Errors() {
			errStr += ":" + err.String()
		}
		return errors.New(errStr)
	}
	return nil
}

type GetPipelineSettingPropertyParams struct {
	Group   PipelineSettingGroup
	Section *PipelineSettingSection
	Key     string
}

type GetEnvironmentPropertyParams struct {
	Section *PipelineSettingSection
	Key     string
}

type ListPipelineSettingPropertyParams struct {
	Group   PipelineSettingGroup
	Section *PipelineSettingSection
	*BaseListParams
}

type ListEnvironmentPropertyParams struct {
	Section *PipelineSettingSection
	*BaseListParams
}

type CreatePipelineSettingPropertyParams struct {
	Group     PipelineSettingGroup
	Section   *PipelineSettingSection
	Key       string     `binding:"min=1,max=255"`
	Schema    JSONSchema `binding:"required"`
	Required  bool
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type CreateEnvironmentPropertyParams struct {
	Section   *PipelineSettingSection
	Key       string     `binding:"min=1,max=255"`
	Schema    JSONSchema `binding:"required"`
	Required  bool
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type UpdatePipelineSettingPropertyParams struct {
	Group      PipelineSettingGroup
	Section    *PipelineSettingSection
	Key        string     `binding:"min=1,max=255"`
	Schema     JSONSchema `binding:"required"`
	Required   bool
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

type UpdateEnvironmentPropertyParams struct {
	Section    *PipelineSettingSection
	Key        string     `binding:"min=1,max=255"`
	Schema     JSONSchema `binding:"required"`
	Required   bool
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

type DeletePipelineSettingPropertyParams struct {
	Group      PipelineSettingGroup
	Section    *PipelineSettingSection
	Key        string  `binding:"min=1,max=255"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

type DeleteEnvironmentPropertyParams struct {
	Key        string  `binding:"min=1,max=255"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

// Values

type SectionEntry struct {
	Section PipelineSettingSection
	Name    string
}

type PipelineSettingValue struct {
	ID            uint32               `json:"id"`
	Group         PipelineSettingGroup `json:"group"`
	Section       string               `json:"section"`
	Entry         string               `json:"entry"`
	Key           string               `json:"key"`
	Value         interface{}          `json:"value"`
	CreatedBy     *string              `json:"created_by"`
	CreatedAtUTC  *time.Time           `json:"created_at_utc"`
	ModifiedBy    *string              `json:"modified_by"`
	ModifiedAtUTC *time.Time           `json:"modified_at_utc"`
}

type ListPipelineSettingValueParams struct {
	Group   PipelineSettingGroup
	Common  *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio  *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	PropKey *string `binding:"omitempty"`
	*BaseListParams
}

type ListEnvironmentValueParams struct {
	Group   PipelineSettingGroup
	Common  *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio  *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	EnvKey  *string `binding:"omitempty"`
	PropKey *string `binding:"omitempty"`
	*BaseListParams
}

type GetPipelineSettingValueParams struct {
	Group      PipelineSettingGroup
	Common     *string
	Studio     *string
	Project    *string
	Key        string `binding:"min=1,max=255"`
	Composite  bool
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

func (p *GetPipelineSettingValueParams) SectionEntries() []*SectionEntry {
	var entries []*SectionEntry
	if p.Common != nil && *p.Common != "" {
		entries = append(entries, &SectionEntry{
			Section: CommonSection,
			Name:    *p.Common,
		})
	}
	if p.Studio != nil && *p.Studio != "" {
		entries = append(entries, &SectionEntry{
			Section: StudioSection,
			Name:    *p.Studio,
		})
	}
	if p.Project != nil && *p.Project != "" {
		entries = append(entries, &SectionEntry{
			Section: ProjectSection,
			Name:    *p.Project,
		})
	}
	return entries
}

type GetEnvironmentValueParams struct {
	Group      PipelineSettingGroup
	Common     *string
	Studio     *string
	Project    *string
	Composite  bool
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
	ID         uint32
}

func (p *GetEnvironmentValueParams) SectionEntries() []*SectionEntry {
	var entries []*SectionEntry
	if p.Common != nil && *p.Common != "" {
		entries = append(entries, &SectionEntry{
			Section: CommonSection,
			Name:    *p.Common,
		})
	}
	if p.Studio != nil && *p.Studio != "" {
		entries = append(entries, &SectionEntry{
			Section: StudioSection,
			Name:    *p.Studio,
		})
	}
	if p.Project != nil && *p.Project != "" {
		entries = append(entries, &SectionEntry{
			Section: ProjectSection,
			Name:    *p.Project,
		})
	}
	return entries
}

type CreatePipelineSettingValueParams struct {
	Group     PipelineSettingGroup
	Common    *string     `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio    *string     `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project   *string     `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Key       string      `binding:"min=1,max=255"`
	Value     interface{} `binding:"required"`
	CreatedBy *string     `binding:"omitempty,min=1,max=100"`
}

func (p *CreatePipelineSettingValueParams) Section() PipelineSettingSection {
	if p.Project != nil && *p.Project != "" {
		return ProjectSection
	}
	if p.Studio != nil && *p.Studio != "" {
		return StudioSection
	}
	if p.Common != nil && *p.Common != "" {
		return CommonSection
	}
	return 0
}

type CreateEnvironmentValueParams struct {
	Common    *string     `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio    *string     `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Project   *string     `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	PropKey   string      `binding:"min=1,max=255"`
	Value     interface{} `binding:"required"`
	CreatedBy *string     `binding:"omitempty,min=1,max=100"`
}

func (p *CreateEnvironmentValueParams) Section() PipelineSettingSection {
	if p.Project != nil && *p.Project != "" {
		return ProjectSection
	}
	if p.Studio != nil && *p.Studio != "" {
		return StudioSection
	}
	if p.Common != nil && *p.Common != "" {
		return CommonSection
	}
	return 0
}

type UpdatePipelineSettingValueParams struct {
	Group      PipelineSettingGroup
	Common     *string
	Studio     *string
	Project    *string
	Key        string      `binding:"min=1,max=255"`
	Value      interface{} `binding:"required"`
	ModifiedBy *string     `binding:"omitempty,min=1,max=100"`
}

func (p *UpdatePipelineSettingValueParams) Section() PipelineSettingSection {
	if p.Project != nil && *p.Project != "" {
		return ProjectSection
	}
	if p.Studio != nil && *p.Studio != "" {
		return StudioSection
	}
	if p.Common != nil && *p.Common != "" {
		return CommonSection
	}
	return 0
}

type UpdateEnvironmentValueParams struct {
	ID         uint32
	Common     *string
	Studio     *string
	Project    *string
	Value      interface{} `binding:"required"`
	ModifiedBy *string     `binding:"omitempty,min=1,max=100"`
}

func (p *UpdateEnvironmentValueParams) Section() PipelineSettingSection {
	if p.Project != nil && *p.Project != "" {
		return ProjectSection
	}
	if p.Studio != nil && *p.Studio != "" {
		return StudioSection
	}
	if p.Common != nil && *p.Common != "" {
		return CommonSection
	}
	return 0
}

type DeletePipelineSettingValueParams struct {
	Group      PipelineSettingGroup
	Common     *string
	Studio     *string
	Project    *string
	Key        string  `binding:"min=1,max=255"`
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

type DeleteEnvironmentValueParams struct {
	Common     *string
	Studio     *string
	Project    *string
	ID         uint32
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}
