package entity

import (
	"encoding/json"
	"reflect"
	"testing"
	"time"
)

func TestDataSyncClientStatusMarshal(t *testing.T) {
	confirmedAt, _ := time.Parse(time.RFC3339, "2024-06-20T15:04:05Z")
	s1 := DataSyncClientStatus{
		Project:     "potoodev",
		Studio:      "ppidev",
		Status:      "healthy",
		ConfirmedAt: &confirmedAt,
	}
	b, err := json.Marshal(s1)
	if err != nil {
		t.Fatal(err)
	}

	var s2 DataSyncClientStatus
	err = json.Unmarshal(b, &s2)
	if err != nil {
		t.Fatal(err)
	}

	if !reflect.DeepEqual(s1, s2) {
		t.Errorf("s1 %v, s2 %v", s1, s2)
	}
}
