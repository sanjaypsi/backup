package groupCategory

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

type Entity interface {
	Type() EntityType
}

type EntityType int

const (
	CategoryType EntityType = iota + 1
	GroupType
)

type CategoryEntity struct {
	ID      uint32   `json:"id"`
	Project string   `json:"project"`
	Root    string   `json:"root"`
	Path    string   `json:"path"`
	Depth   uint8    `json:"depth"`
	Groups  []string `json:"groups"`
	*entity.BaseEntity
}

func (e *CategoryEntity) Type() EntityType {
	return CategoryType
}

var _ Entity = (*CategoryEntity)(nil) // Verify that *CategoryEntity implements Entity.

type GroupEntity struct {
	ID              uint32 `json:"id"`
	GroupCategoryID uint32 `json:"group_category_id"`
	Project         string `json:"project"`
	Path            string `json:"path"`
	*entity.BaseEntity
}

func (e *GroupEntity) Type() EntityType {
	return GroupType
}

var _ Entity = (*GroupEntity)(nil) // Verify that *GroupEntity implements Entity.

type ListStandardSubParams struct {
	Root *string `binding:"omitempty,min=1,max=30,alphanumunderscore,startsnotwithdigit"`
}

type ListSinceSubParams struct {
	Type          EntityType
	ModifiedSince *time.Time
}

type ListParams struct {
	SubParams interface{}
	Project   string   `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	OrderBy   []string `binding:"omitempty,dive,oneof=modified_at_utc -modified_at_utc path -path id -id"`
	*entity.BaseListParams
}

type GetParams struct {
	Project string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ID      uint32 ``
}

type CreateParams struct {
	Project   string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root      string  `binding:"min=1,max=30,alphanumunderscore,startsnotwithdigit"`
	Path      string  `binding:"min=1,max=150"`
	CreatedBy *string `binding:"omitempty,min=1,max=100"`
}

type DeleteParams struct {
	Project    string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	ID         uint32  ``
	ModifiedBy *string `binding:"omitempty,min=1,max=100"`
}

type UpdateParams struct {
	*GetParams
	Operation  string   `binding:"oneof=add remove"`
	Groups     []string `binding:"min=1"`
	ModifiedBy *string  `binding:"omitempty,min=1,max=100"`
}

type CreateGroupParams struct {
	GroupCategoryID uint32  ``
	Path            string  `binding:"min=1,max=150,dirpath"`
	Project         string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	CreatedBy       *string `binding:"omitempty,min=1,max=100"`
}
