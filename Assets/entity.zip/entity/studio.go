package entity

import (
	"fmt"
)

type Studio struct {
	*StudioInfo
	db InfoRepository
}

func (s *Studio) String() string {
	return fmt.Sprintf("%v", s.StudioInfo)
}

func NewStudio(info *StudioInfo, db InfoRepository) *Studio {
	return &Studio{StudioInfo: info, db: db}
}
