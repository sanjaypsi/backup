package entity

import (
	"errors"
	"fmt"
	"regexp"
	"strings"
)

// DirPath represents the directory path.
type DirPath struct {
	path string
}

// NewDirPath is a function that creates a new DirPath.
func NewDirPath(path string) (*DirPath, error) {
	d := &DirPath{path}
	d.normalize()
	err := d.validate()
	if err != nil {
		return nil, err
	}
	return d, nil
}

// normalize normalizes the path string
func (d *DirPath) normalize() {
	// Unify delimiters
	path := strings.ReplaceAll(d.path, "\\", "/")

	// Remove delimiters at both ends
	path = strings.Trim(path, "/")

	// Remove redundant delimiters
	re := regexp.MustCompile(`/+`)
	path = re.ReplaceAllString(path, "/")

	d.path = path
}

// Depth returns the depth of the directory hierarchy for the given path
func (d *DirPath) Depth() int {
	return strings.Count(d.path, "/") + 1
}

// Parents returns a list of all paths up to the Directory hierarchy
// The list does not include path itself
func (d *DirPath) Parents() []*DirPath {
	depth := d.Depth()
	parts := strings.Split(d.path, "/")
	parents := []*DirPath{}
	for i := 1; i < depth; i++ {
		path := &DirPath{path: strings.Join(parts[:i], "/")}
		parents = append(parents, path)
	}
	return parents
}

func (d *DirPath) String() string {
	return d.path
}

func (d *DirPath) validate() error {
	// TODO: Max depth is 100 ?

	if d.path == "" {
		return errors.New("path string must not be empty")
	}

	if len(d.path) > MaxPathLength {
		return fmt.Errorf("path is too long. max length is %d. got %d", MaxPathLength, len(d.path))
	}

	parts := strings.Split(d.path, "/")
	for _, part := range parts {
		if strings.HasPrefix(part, ".") {
			return fmt.Errorf("path contains dotted directory: %q", part)
		}
		if strings.Contains(part, " ") {
			return fmt.Errorf("path contains whitespace name: %q", part)
		}
	}

	return nil
}
