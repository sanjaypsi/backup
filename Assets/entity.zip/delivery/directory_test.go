package delivery

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/PolygonPictures/central30-web/front/testutil"
	"github.com/PolygonPictures/central30-web/front/usecase"
)

func TestDirectory_SQLite(t *testing.T) {
	const studio = "ppidev"
	const project = "potoodev"
	const wantPathMySQL = "shared/publish/assets/testMySQL"
	const wantPathSQLite = "shared/publish/assets/testSQLite"

	tests := map[string]struct {
		url      string
		wantPath string
	}{
		"Use SQLite": {
			url:      "/projects/potoodev/directories?sqlite=1",
			wantPath: wantPathSQLite,
		},
		"Not Use SQLite": {
			url:      "/projects/potoodev/directories?sqlite=0",
			wantPath: wantPathMySQL,
		},
		"Default": {
			url:      "/projects/potoodev/directories",
			wantPath: wantPathMySQL,
		},
	}

	depth := func(path string) int {
		return len(strings.Split(path, "/"))
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			// MySQLのt_directoryテーブルにレコードを作成
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.CreateProjectInfo(t, testDB, studio, project)
			testDB.Exec(`
			INSERT INTO t_directory (
				project, path, depth, status
			) VALUES (
				?, ?, ?, ?
			)`, project, wantPathMySQL, depth(wantPathMySQL), "active")

			// SQLiteのt_directoryテーブルにレコードを作成
			sqliteDBPathPrefix := t.TempDir()
			t.Setenv("PPI_SQLITE_PATH_PREFIX", sqliteDBPathPrefix)
			sqliteDBPath := filepath.Join(sqliteDBPathPrefix, project, ".sys/db/directory.ppidb")
			require.Nil(t, os.MkdirAll(filepath.Dir(sqliteDBPath), 0700))
			sqliteDB, err := gorm.Open(sqlite.Open(sqliteDBPath), &gorm.Config{})
			require.Nil(t, err)
			sqliteDB.Exec(`CREATE TABLE t_directory (
				id              INTEGER NOT NULL PRIMARY KEY,
				project         TEXT NOT NULL,
				path            TEXT NOT NULL,
				depth           INTEGER NOT NULL,
				status          TEXT NOT NULL,
				created_at_utc  DATETIME,
				modified_at_utc DATETIME,
				created_by      TEXT,
				modified_by     TEXT
			)`)
			sqliteDB.Exec(`INSERT INTO t_directory (
				id, project, path, depth, status
			) VALUES (
				?, ?, ?, ?, ?
			)`, 1, project, wantPathSQLite, depth(wantPathSQLite), "active")

			// テスト用のリクエストを送信
			d := newDirectoryForTest(t, testDB)
			recorder := httptest.NewRecorder()
			_, router := gin.CreateTestContext(recorder)
			router.GET("/projects/:project/directories", d.List)
			req, err := http.NewRequest("GET", test.url, nil)
			require.Nil(t, err)
			router.ServeHTTP(recorder, req)

			// レスポンスを確認
			assert.Equal(t, recorder.Code, http.StatusOK)

			var res map[string]any
			require.Nil(t, json.Unmarshal([]byte(recorder.Body.String()), &res))

			gotTotal := int(res["total"].(float64))
			assert.Equal(t, 1, gotTotal)

			gotPath := res["directories"].([]any)[0].(map[string]any)["path"].(string)
			assert.Equal(t, test.wantPath, gotPath)
		})
	}
}

func TestDirectory_GroupDir(t *testing.T) {
	const studio = "ppidev"
	const project = "potoodev"
	const pathDir = "shared/publish/assets/testDir"
	const pathGroupDir = "shared/publish/assets/testGroupDir"

	depth := func(path string) int {
		return len(strings.Split(path, "/"))
	}

	groupDepth := func(path string) int {
		return len(strings.Split(path, "/")[3:])
	}

	root := func(path string) string {
		return strings.Split(path, "/")[2]
	}

	tests := []struct {
		name, url, want string
	}{
		{
			name: "From t_directory",
			url:  "/projects/potoodev/directories",
			want: pathDir,
		},
		{
			name: "From t_group_directory",
			url:  "/projects/potoodev/directories?group_dir=1",
			want: pathGroupDir,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.CreateProjectInfo(t, testDB, studio, project)

			// t_directoryテーブルにレコードを作成
			result := testDB.Exec(`
			INSERT INTO t_directory (
				project, path, depth, status
			) VALUES (
				?, ?, ?, ?
			)`, project, pathDir, depth(pathDir), "active")
			require.Nil(t, result.Error)

			// t_group_directoryテーブルにレコードを作成
			result = testDB.Exec(`
			INSERT INTO t_group_directory (
				project, root, path, depth, group_depth, status
			) VALUES (
				?, ?, ?, ?, ?, ?
			)`, project, root(pathGroupDir), pathGroupDir, depth(pathGroupDir), groupDepth(pathGroupDir), "active")
			require.Nil(t, result.Error)

			// テスト用のリクエストを送信
			d := newDirectoryForTest(t, testDB)
			recorder := httptest.NewRecorder()
			_, router := gin.CreateTestContext(recorder)
			router.GET("/projects/:project/directories", d.List)
			req, err := http.NewRequest("GET", test.url, nil)
			require.Nil(t, err)
			router.ServeHTTP(recorder, req)

			assert.Equal(t, recorder.Code, http.StatusOK)

			var res map[string]any
			require.Nil(t, json.Unmarshal([]byte(recorder.Body.String()), &res))

			total := int(res["total"].(float64))
			assert.Equal(t, 1, total)

			got := res["directories"].([]any)[0].(map[string]any)["path"].(string)
			assert.Equal(t, test.want, got)
		})
	}
}

func TestDirectory_GroupDir_EncodedFieldsSameAsDirectory(t *testing.T) {
	const id = 1
	const studio = "ppidev"
	const project = "potoodev"
	const root = "assets"
	const depth = 4
	const path = "shared/publish/assets/testHero"
	const groupDepth = 1
	const status = "active"
	const deleted = 0
	createdBy := "testuser"
	now := time.Now().UTC()

	dirEntity := (&model.Directory{
		ID:            id,
		Project:       project,
		Path:          path,
		Depth:         depth,
		Status:        status,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		CreatedBy:     &createdBy,
		ModifiedBy:    &createdBy,
		Deleted:       deleted,
	}).Entity(false)

	groupDirEntity := (&model.GroupDirectory{
		ID:            id,
		Project:       project,
		Root:          root,
		Depth:         depth,
		Path:          path,
		GroupDepth:    groupDepth,
		Status:        status,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		CreatedBy:     &createdBy,
		ModifiedBy:    &createdBy,
		Deleted:       deleted,
	}).Entity()

	dirOut := &bytes.Buffer{}
	json.NewEncoder(dirOut).Encode(dirEntity)

	groupDirOut := &bytes.Buffer{}
	json.NewEncoder(groupDirOut).Encode(groupDirEntity)

	assert.Equal(t, dirOut.Bytes(), groupDirOut.Bytes())
}

func TestDirectory_GroupDir_UnsupportedParameter(t *testing.T) {
	const studio = "ppidev"
	const project = "potoodev"

	tests := []struct {
		key, value string
	}{
		{
			key:   "modified_since",
			value: time.Now().UTC().Format(time.RFC3339),
		}, {
			key:   "sqlite",
			value: "1",
		},
	}

	for _, test := range tests {
		t.Run(test.key, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.CreateProjectInfo(t, testDB, studio, project)

			d := newDirectoryForTest(t, testDB)
			recorder := httptest.NewRecorder()
			_, router := gin.CreateTestContext(recorder)
			router.GET("/projects/:project/directories", d.List)

			u, err := url.ParseRequestURI("/projects/potoodev/directories")
			require.Nil(t, err)
			q := u.Query()
			q.Add(test.key, test.value)
			q.Add("group_dir", "1")
			u.RawQuery = q.Encode()

			req, err := http.NewRequest("GET", u.String(), nil)
			require.Nil(t, err)
			router.ServeHTTP(recorder, req)

			assert.Equal(t, http.StatusBadRequest, recorder.Code)
		})
	}
}

func newDirectoryForTest(t *testing.T, db *gorm.DB) *Directory {
	t.Helper()

	drepo, err := repository.NewDirectory(db)
	require.Nil(t, err)

	ddirepo, err := repository.NewDirectoryDeletionInfo(db)
	require.Nil(t, err)

	psmrepo, err := repository.NewProjectStudioMap(db)
	require.Nil(t, err)

	pjrepo, err := repository.NewProjectInfo(db, psmrepo)
	require.Nil(t, err)

	sdrepo, err := repository.NewStudioInfo(db)
	require.Nil(t, err)

	psrepo, err := repository.NewPipelineSetting(db)
	require.Nil(t, err)

	gdrepo, err := repository.NewGroupDirectory(db)
	require.Nil(t, err)

	readTimeout := 1 * time.Second
	writeTimeout := 1 * time.Second
	return NewDirectory(usecase.NewDirectory(
		drepo,
		pjrepo,
		sdrepo,
		ddirepo,
		psrepo,
		gdrepo,
		readTimeout,
		writeTimeout,
	))
}
