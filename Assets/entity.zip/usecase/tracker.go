package usecase

import (
	"context"
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Tracker struct {
	repo *repository.Tracker
}

func NewTracker(repo *repository.Tracker) *Tracker {
	return &Tracker{
		repo: repo,
	}
}

func (u *Tracker) GetColumns(ctx context.Context, project string, root string) ([]entity.TrackerColumn, error) {
	return u.repo.GetColumns(ctx, project, root)
}

func (u *Tracker) CreateColumn(ctx context.Context, req entity.CreateColumnRequest) error {
	col := entity.TrackerColumn{
		ID:              primitive.NewObjectID(),
		Project:         req.Project,
		Root:            req.Root,
		Scope:           req.Scope,
		ExcludeProjects: req.ExcludeProjects,
		IsSystem:        req.IsSystem,
		Key:             req.Key,
		DisplayName:     req.DisplayName,
		DataType:        req.DataType,
		Config:          req.Config,
		Visibled:        req.Visibled,
		Deleted:         "0",
		CreatedAtUTC:    time.Now().UTC(),
		ModifiedAtUTC:   time.Now().UTC(),
		CreatedBy:       req.User,
		ModifiedBy:      req.User,
	}

	if col.IsSystem {
		col.Scope = "global"
		col.ExcludeProjects = nil
	}

	if col.Scope == "" {
		col.Scope = "project"
	}
	if col.Scope == "project" && col.Project == "" {
		return errors.New("project id required for project scope")
	}

	return u.repo.CreateColumn(ctx, col)
}

func (u *Tracker) UpdateColumn(ctx context.Context, idHex string, req entity.UpdateColumnRequest) error {
	id, _ := primitive.ObjectIDFromHex(idHex)

	col := entity.TrackerColumn{
		ID:              id,
		DisplayName:     req.DisplayName,
		DataType:        req.DataType,
		Config:          req.Config,
		Visibled:        req.Visibled,
		Scope:           req.Scope,
		ExcludeProjects: req.ExcludeProjects,
		IsSystem:        req.IsSystem,
		ModifiedAtUTC:   time.Now().UTC(),
		ModifiedBy:      req.User,
	}

	if col.IsSystem {
		col.Scope = "global"
		col.ExcludeProjects = nil
	}
	if col.Scope == "" {
		col.Scope = "project"
	}

	return u.repo.UpdateColumn(ctx, col)
}

func (u *Tracker) SearchEntities(ctx context.Context, req entity.SearchRequest) ([]entity.TrackerEntity, error) {
	return u.repo.SearchEntities(ctx, req)
}

func (u *Tracker) CreateEntity(ctx context.Context, req entity.CreateEntityRequest) error {
	ent := entity.TrackerEntity{
		ID:            primitive.NewObjectID(),
		Project:       req.Project,
		Root:          req.Root,
		Group:         req.Group,
		Data:          req.Data,
		CreatedAtUTC:  time.Now().UTC(),
		ModifiedAtUTC: time.Now().UTC(),
		CreatedBy:     req.User,
		ModifiedBy:    req.User,
		Deleted:       "0",
	}
	return u.repo.CreateEntity(ctx, ent)
}

func (u *Tracker) UpdateEntity(ctx context.Context, idHex string, req entity.UpdateEntityRequest) error {
	id, _ := primitive.ObjectIDFromHex(idHex)

	current, err := u.repo.GetEntityByID(ctx, id)
	if err != nil {
		return err
	}

	history := entity.History{
		ID:            primitive.NewObjectID(),
		Project:       current.Project,
		Studio:        req.Studio,
		EntityID:      current.ID,
		ModifiedAtUTC: time.Now().UTC(),
		ModifiedBy:    req.User,
		Snapshot:      *current,
	}
	if err := u.repo.CreateHistory(ctx, history); err != nil {
		return err
	}

	current.Root = req.Root
	current.Group = req.Group
	current.ModifiedAtUTC = time.Now().UTC()
	current.ModifiedBy = req.User

	if current.Data == nil {
		current.Data = make(map[string]interface{})
	}
	for k, v := range req.Data {
		current.Data[k] = v
	}

	return u.repo.UpdateEntity(ctx, *current)
}

func (u *Tracker) DeleteEntity(ctx context.Context, idHex string) error {
	id, _ := primitive.ObjectIDFromHex(idHex)
	return u.repo.SoftDeleteEntity(ctx, id)
}

func (u *Tracker) GetHistories(ctx context.Context, entityIDHex string) ([]entity.History, error) {
	id, _ := primitive.ObjectIDFromHex(entityIDHex)
	return u.repo.GetHistories(ctx, id)
}

func (u *Tracker) RollbackEntity(ctx context.Context, entityIDHex string, req entity.RollbackRequest) error {
	entID, _ := primitive.ObjectIDFromHex(entityIDHex)
	histID, _ := primitive.ObjectIDFromHex(req.HistoryID)

	targetHistory, err := u.repo.GetHistoryByID(ctx, histID)
	if err != nil {
		return err
	}
	if targetHistory.EntityID != entID {
		return errors.New("history does not belong to this entity")
	}

	current, err := u.repo.GetEntityByID(ctx, entID)
	if err == nil {
		backupHistory := entity.History{
			ID:            primitive.NewObjectID(),
			Project:       current.Project,
			Studio:        req.Studio,
			EntityID:      entID,
			ModifiedAtUTC: time.Now().UTC(),
			ModifiedBy:    req.User,
			Snapshot:      *current,
		}
		u.repo.CreateHistory(ctx, backupHistory)
	}

	restoredEntity := targetHistory.Snapshot
	restoredEntity.ModifiedAtUTC = time.Now().UTC()
	restoredEntity.ModifiedBy = req.User

	return u.repo.RestoreEntity(ctx, restoredEntity)
}
