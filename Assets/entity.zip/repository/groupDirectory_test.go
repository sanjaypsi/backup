package repository

import (
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/PolygonPictures/central30-web/front/testutil"
	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGroupDirectoryAutoMigrate(t *testing.T) {
	_, err := NewGroupDirectory(testDB)
	require.Nil(t, err)
	assert.True(t, testDB.Migrator().HasTable("t_group_directory"))
}

func TestGroupDirectory_Create(t *testing.T) {
	const project = "potoodev"

	tests := map[string]struct {
		root   string
		groups string
		path   string
		want   []*model.GroupDirectory
	}{
		"Single group": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero",
			want: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     "active",
				},
			},
		},
		"Multiple group all": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01",
			want: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      5,
					Path:       "shared/publish/shots/ep01/sq01",
					GroupDepth: 2,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      6,
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					GroupDepth: 3,
					Status:     "active",
				},
			},
		},
		"Multiple group partial": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01",
			want: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      5,
					Path:       "shared/publish/shots/ep01/sq01",
					GroupDepth: 2,
					Status:     "active",
				},
			},
		},
		"Revision path": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01/com/cmp/_org/20250724071724144616.s001r0004",
			want: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      5,
					Path:       "shared/publish/shots/ep01/sq01",
					GroupDepth: 2,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      6,
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					GroupDepth: 3,
					Status:     "active",
				},
			},
		},
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			prefKey := fmt.Sprintf("/ppip/roots/%s/groups", test.root)
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.AddProjectPreference(t, testDB, project, prefKey, &test.groups)

			var got []*model.GroupDirectory
			got, err = repo.Create(testDB, project, test.path)
			require.Nil(t, err)
			assert.Empty(t, cmp.Diff(test.want, got, diffOpt))
		})
	}
}

func TestGroupDirectory_Create_FailedToParseToGroupPath(t *testing.T) {
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	testutil.SetupTablesWithCleanup(t, testDB)

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.Nil(t, got)
	assert.ErrorContains(t, err, "failed to parse to group-path: no preference key:")
}

func TestGroupDirectory_Create_NoGroupPath(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const path = "shared/publish/assets"
	groups := "asset"

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.Nil(t, got)
	assert.Nil(t, err)
}

func TestGroupDirectory_Create_FailedToFindExistingRecords(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const path = "shared/publish/assets/testHero"
	groups := "asset"

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)
	testDB.Exec("DROP TABLE t_group_directory")

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.Nil(t, got)
	assert.ErrorContains(t, err, "table not found: t_group_directory")
}

func TestGroupDirectory_Create_DifferOnlyLetterCase(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const path = "shared/publish/assets/testHero"
	groups := "asset"
	preset := []*model.GroupDirectory{
		{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       "shared/publish/assets/testhero",
			GroupDepth: 1,
			Status:     "active",
		},
	}

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	for _, m := range preset {
		require.Nil(t, testDB.Create(m).Error)
	}

	// pathカラムのcollationを変更して大文字・小文字の違いが無視されるように
	// する。
	//
	// 理由: CentralWebではMySQLのデフォルトのcollationである
	// utf8mb4_0900_ai_ciが使用されるため、文字列比較では大文字・小文字の違
	// いは無視されるが、テストで使用するgo-mysql-serverのデフォルトの
	// collationであるutf8mb4_0900_binでは区別されるため。
	//
	//     https://docs.dolthub.com/sql-reference/sql-support/collations-and-charsets
	//
	// ちなみに
	//
	//     db.Set("gorm:table_options", "COLLATE=utf8mb4_0900_ai_ci").AutoMigrate()
	//
	// などとしてテーブル作成時にテーブルのcollationを変更する方法も試してみ
	// たが、collationは変わらなかった。そのため、カラムのcollationを変更し
	// ている。
	testDB.Exec("ALTER TABLE t_group_directory MODIFY COLUMN `path` varchar(1000) COLLATE utf8mb4_0900_ai_ci")

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.Nil(t, got)
	assert.ErrorContains(t, err, "group directory differing")
}

func TestGroupDirectory_Create_IgnoreRecordedPath(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const path = "shared/publish/assets/testHero"
	groups := "asset"
	preset := []*model.GroupDirectory{
		{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       "shared/publish/assets/testHero",
			GroupDepth: 1,
			Status:     "active",
		},
	}

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	for _, m := range preset {
		require.Nil(t, testDB.Create(m).Error)
	}

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.Nil(t, got)
	assert.Nil(t, err)
}

func TestGroupDirectory_Create_DeletedPath(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const path = "shared/publish/assets/testHero"
	groups := "asset"
	preset := []*model.GroupDirectory{
		{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       "shared/publish/assets/testHero",
			GroupDepth: 1,
			Status:     "deleted",
			Deleted:    1,
		},
	}

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	for _, m := range preset {
		require.Nil(t, testDB.Create(m).Error)
	}

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.NotNil(t, got)
	assert.Nil(t, err)

	want := []*model.GroupDirectory{
		{
			Project:    "potoodev",
			Root:       "assets",
			Depth:      4,
			Path:       "shared/publish/assets/testHero",
			GroupDepth: 1,
			Status:     "active",
		},
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(t, cmp.Diff(want, got, diffOpt))
}

func TestGroupDirectory_Create_FailedToCreate(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const path = "shared/publish/assets/testHero"
	groups := "asset"

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)
	testDB.Exec("ALTER TABLE t_group_directory ADD CONSTRAINT check_1 CHECK(status='foo')")

	var got []*model.GroupDirectory
	got, err = repo.Create(testDB, project, path)
	assert.Nil(t, got)
	assert.ErrorContains(t, err, "Check constraint \"check_1\" violated")
}

func TestGroupDirectory_updateStatus(t *testing.T) {
	const project = "potoodev"
	const before = entity.Active
	const after = entity.ToDelete

	tests := map[string]struct {
		root, groups, path string
		preset             []*model.GroupDirectory
		want               int
	}{
		"single": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero",
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     before.String(),
				},
			},
			want: 1,
		},
		"with children": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01",
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     before.String(),
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      5,
					Path:       "shared/publish/shots/ep01/sq01",
					GroupDepth: 2,
					Status:     before.String(),
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      6,
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					GroupDepth: 3,
					Status:     before.String(),
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      5,
					Path:       "shared/publish/shots/ep01/sq02",
					GroupDepth: 2,
					Status:     before.String(),
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      6,
					Path:       "shared/publish/shots/ep01/sq02/sh01",
					GroupDepth: 3,
					Status:     before.String(),
				},
			},
			want: 5,
		},
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			prefKey := fmt.Sprintf("/ppip/roots/%s/groups", test.root)
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.AddProjectPreference(t, testDB, project, prefKey, &test.groups)
			for _, m := range test.preset {
				require.Nil(t, testDB.Create(m).Error)
			}

			repo, err := NewGroupDirectory(testDB)
			require.Nil(t, err)

			count, err := repo.updateStatus(testDB, project, test.path, before, after)
			require.Nil(t, err)
			assert.Equal(t, test.want, count)
		})
	}
}

func TestGroupDirectory_updateStatus_NoShared(t *testing.T) {
	const project = "potoodev"
	const before = entity.Active
	const after = entity.ToDelete
	paths := []string{"", "shared", "shared/publish", "shared/tools", "unshared/publish"}

	for _, path := range paths {
		t.Run(path, func(t *testing.T) {
			repo, err := NewGroupDirectory(testDB)
			require.Nil(t, err)

			buf := testutil.CaptureLog(t)
			count, err := repo.updateStatus(testDB, project, path, before, after)
			require.Nil(t, err)
			assert.Zero(t, count)
			assert.Contains(t, buf.String(), "`path` not starts with 'shared/publish/':")
		})
	}
}

func TestGroupDirectory_updateStatus_NoRoot(t *testing.T) {
	const project = "potoodev"
	const before = entity.Active
	const after = entity.ToDelete

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	buf := testutil.CaptureLog(t)
	count, err := repo.updateStatus(testDB, project, "shared/publish//testHero", before, after)
	require.Nil(t, err)
	assert.Zero(t, count)
	assert.Contains(t, buf.String(), "`path` not contains root:")
}

func TestGroupDirectory_updateStatus_NoNumGroups(t *testing.T) {
	const project = "potoodev"
	const before = entity.Active
	const after = entity.ToDelete

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	testutil.SetupTablesWithCleanup(t, testDB)

	count, err := repo.updateStatus(testDB, project, "shared/publish/assets/testHero", before, after)
	require.NotNil(t, err)
	assert.Zero(t, count)
	assert.ErrorContains(t, err, "failed to get number of groups:")
}

func TestGroupDirectory_updateStatus_UnderGroup(t *testing.T) {
	tests := map[string]struct {
		root, groups, path string
	}{
		"asset relation": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero/com",
		},
		"asset phase": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero/com/mdl",
		},
		"asset component": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero/com/mdl/_org",
		},
		"asset revision": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero/com/mdl/_org/20250724071724144616.s001r0004",
		},
		"shot relation": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01/com",
		},
		"shot phase": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01/com/cmp",
		},
		"shot component": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01/com/cmp/_org",
		},
		"shot revision": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01/com/cmp/_org/20250724071724144616.s001r0004",
		},
	}

	const project = "potoodev"
	const before = entity.Active
	const after = entity.ToDelete

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			prefKey := fmt.Sprintf("/ppip/roots/%s/groups", test.root)
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.AddProjectPreference(t, testDB, project, prefKey, &test.groups)

			repo, err := NewGroupDirectory(testDB)
			require.Nil(t, err)

			buf := testutil.CaptureLog(t)
			count, err := repo.updateStatus(testDB, project, test.path, before, after)
			require.Nil(t, err)
			assert.Zero(t, count)
			assert.Contains(t, buf.String(), "`path` is under group hierarchy:")
		})
	}
}

func TestGroupDirectory_ToDelete(t *testing.T) {
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	const prefKey = "/ppip/roots/assets/groups"
	groups := "asset"
	preset := []*model.GroupDirectory{
		{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       path,
			GroupDepth: 1,
			Status:     "active",
		},
	}

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	for _, m := range preset {
		require.Nil(t, testDB.Create(m).Error)
	}

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	count, err := repo.ToDelete(testDB, project, path)
	require.Nil(t, err)
	assert.Equal(t, 1, count)

	var ms []*model.GroupDirectory
	testDB.Where("project = ? AND path = ?", project, path).Find(&ms)
	assert.Equal(t, 1, len(ms))

	m := ms[0]
	assert.Equal(t, entity.ToDelete.String(), m.Status)
	assert.Equal(t, int32(0), m.Deleted)
}

func TestGroupDirectory_Deleted(t *testing.T) {
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	const prefKey = "/ppip/roots/assets/groups"
	groups := "asset"
	preset := []*model.GroupDirectory{
		{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       path,
			GroupDepth: 1,
			Status:     "to_delete",
		},
	}

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	for _, m := range preset {
		require.Nil(t, testDB.Create(m).Error)
	}

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	count, err := repo.Deleted(testDB, project, path)
	require.Nil(t, err)
	assert.Equal(t, 1, count)

	var ms []*model.GroupDirectory
	testDB.Where("project = ? AND path = ?", project, path).Find(&ms)
	assert.Equal(t, 1, len(ms))

	m := ms[0]
	assert.Equal(t, entity.Deleted.String(), m.Status)
	assert.Equal(t, m.ID, m.Deleted)
}

func TestGroupDirectory_ListWithDirectoryParams(t *testing.T) {
	const project = "potoodev"

	tests := []struct {
		name   string
		params *entity.ListDirectoryParams
		preset []*model.GroupDirectory
		want   []*entity.GroupDirectory
	}{
		{
			name: "Find by project",
			params: &entity.ListDirectoryParams{
				Project: project,
			},
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     "active",
				},
			},
			want: []*entity.GroupDirectory{
				{
					Project: project,
					Path:    "shared/publish/assets/testHero",
					Depth:   4,
					Status:  entity.Active,
				},
			},
		},
		{
			name: "Find by project and path",
			params: &entity.ListDirectoryParams{
				Project:    project,
				PathPrefix: testutil.Ptr("shared/publish/assets/"),
			},
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
			},
			want: []*entity.GroupDirectory{
				{
					Project: project,
					Path:    "shared/publish/assets/testHero",
					Depth:   4,
					Status:  entity.Active,
				},
			},
		},
		{
			name: "Find by project, path and depth",
			params: &entity.ListDirectoryParams{
				Project:    project,
				PathPrefix: testutil.Ptr("shared/publish/shots/"),
				Depth:      testutil.Ptr(int32(4)),
			},
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      5,
					Path:       "shared/publish/shots/ep01/sq01",
					GroupDepth: 2,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      6,
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					GroupDepth: 3,
					Status:     "active",
				},
			},
			want: []*entity.GroupDirectory{
				{
					Project: project,
					Path:    "shared/publish/shots/ep01",
					Depth:   4,
					Status:  entity.Active,
				},
			},
		},
		{
			name: "Find by project and status",
			params: &entity.ListDirectoryParams{
				Project: project,
				Status:  testutil.Ptr(entity.ToDelete),
			},
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero1",
					GroupDepth: 1,
					Status:     "to_delete",
				},
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero2",
					GroupDepth: 1,
					Status:     "active",
				},
			},
			want: []*entity.GroupDirectory{
				{
					Project: project,
					Path:    "shared/publish/assets/testHero1",
					Depth:   4,
					Status:  entity.ToDelete,
				},
			},
		},
		{
			name: "Find by project and multiple paths",
			params: &entity.ListDirectoryParams{
				Project: project,
				Paths:   []string{"shared/publish/assets/testHero", "shared/publish/shots/ep01"},
			},
			preset: []*model.GroupDirectory{
				{
					Project:    project,
					Root:       "assets",
					Depth:      4,
					Path:       "shared/publish/assets/testHero",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "shots",
					Depth:      4,
					Path:       "shared/publish/shots/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
				{
					Project:    project,
					Root:       "edits",
					Depth:      4,
					Path:       "shared/publish/edits/ep01",
					GroupDepth: 1,
					Status:     "active",
				},
			},
			want: []*entity.GroupDirectory{
				{
					Project: project,
					Path:    "shared/publish/assets/testHero",
					Depth:   4,
					Status:  entity.Active,
				},
				{
					Project: project,
					Path:    "shared/publish/shots/ep01",
					Depth:   4,
					Status:  entity.Active,
				},
			},
		},
	}

	diffOpt := cmpopts.IgnoreFields(
		entity.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			testutil.SetupTablesWithCleanup(t, testDB)
			for _, m := range test.preset {
				require.Nil(t, testDB.Create(m).Error)
			}

			repo, err := NewGroupDirectory(testDB)
			require.Nil(t, err)

			got, _, err := repo.ListWithDirectoryParams(testDB, test.params)
			require.Nil(t, err)

			assert.Empty(t, cmp.Diff(test.want, got, diffOpt))
		})
	}
}

func TestGroupDirectory_ListWithDirectoryParams_UnsupportedParameter(t *testing.T) {
	tests := []struct {
		name      string
		params    *entity.ListDirectoryParams
		errString string
	}{
		{
			name: "ModifiedSince",
			params: &entity.ListDirectoryParams{
				ModifiedSince: testutil.Ptr(time.Now().UTC()),
			},
			errString: "ModifiedSince parameter is not supported:",
		},
		{
			name: "SQLite",
			params: &entity.ListDirectoryParams{
				SQLite: true,
			},
			errString: "SQLite parameter is not supported:",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			repo, err := NewGroupDirectory(testDB)
			require.Nil(t, err)

			entities, count, err := repo.ListWithDirectoryParams(testDB, test.params)
			assert.Nil(t, entities)
			assert.Zero(t, count)
			assert.True(t, errors.Is(err, entity.ErrBadRequest))
			assert.ErrorContains(t, err, test.errString)
		})
	}
}

func TestGroupDirectory_ListWithDirectoryParams_FastPath(t *testing.T) {
	params := &entity.ListDirectoryParams{
		Project:    "potoodev",
		PathPrefix: testutil.Ptr("shared/publish/assets/"),
		Depth:      testutil.Ptr(int32(4)),
	}

	testutil.SetupTablesWithCleanup(t, testDB)

	repo, err := NewGroupDirectory(testDB)
	require.Nil(t, err)

	buf := testutil.CaptureGORMLog(t, testDB)
	_, _, err = repo.ListWithDirectoryParams(testDB, params)
	require.Nil(t, err)

	wantSQL := "SELECT * FROM `t_group_directory` WHERE `project` = 'potoodev' AND `root` = 'assets' AND `depth` = 4 AND `path` LIKE"
	assert.Contains(t, buf.String(), wantSQL)
}
