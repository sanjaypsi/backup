package model

import (
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/stretchr/testify/assert"

	"github.com/PolygonPictures/central30-web/front/entity"
)

func TestNewGroupDirectory(t *testing.T) {
	assert := assert.New(t)

	const project = "potoodev"
	const root = "assets"
	const depth = 4
	const path = "shared/publish/assets/testHero"
	const groupDepth = 1
	const createdBy = ""

	got := NewGroupDirectory(project, root, depth, path, groupDepth, createdBy)

	now := time.Now().UTC()
	want := &GroupDirectory{
		ID:            0,
		Project:       project,
		Root:          root,
		Depth:         depth,
		Path:          path,
		GroupDepth:    groupDepth,
		Status:        "active",
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
	}

	diffOpts := []cmp.Option{
		cmpopts.IgnoreFields(GroupDirectory{}, "CreatedBy", "ModifiedBy"),
		cmpopts.EquateApproxTime(1 * time.Second),
	}

	assert.Empty(cmp.Diff(want, got, diffOpts...))
	assert.Equal("", *got.CreatedBy)
	assert.Equal("", *got.ModifiedBy)
}

func TestGroupDirectory_Entity(t *testing.T) {
	ptr := func(s string) *string { return &s }
	now := time.Now().UTC()

	m := &GroupDirectory{
		ID:            1,
		Project:       "potoodev",
		Root:          "assets",
		Depth:         4,
		Path:          "shared/publish/assets/testHero",
		GroupDepth:    1,
		Status:        "active",
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		CreatedBy:     ptr("testuser"),
		ModifiedBy:    ptr("testuser"),
		Deleted:       0,
	}
	got := m.Entity()

	want := &entity.GroupDirectory{
		ID:            1,
		Project:       "potoodev",
		Path:          "shared/publish/assets/testHero",
		Depth:         4,
		Status:        entity.Active,
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		CreatedBy:     ptr("testuser"),
		ModifiedBy:    ptr("testuser"),
	}

	assert.Empty(t, cmp.Diff(want, got))
}
