package groupDirectory

import (
	"errors"
	"fmt"
	"slices"
	"strings"

	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/repository/model"
)

const (
	publishDepth = 2
	rootDepth    = 3
)

type GroupPath struct {
	Path       string
	Root       string
	Depth      int
	GroupDepth int
}

// ParseToGroupPaths parses a directory path and returns a slice of pointers
// to GroupPath.
func ParseToGroupPaths(db *gorm.DB, project, path string) ([]*GroupPath, error) {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	depth := len(parts)

	if depth >= publishDepth && !slices.Equal(parts[:publishDepth], []string{"shared", "publish"}) {
		return nil, nil
	}

	if depth <= rootDepth {
		return nil, nil
	}

	root := parts[rootDepth-1]
	numGroups, err := GetNumGroups(db, project, root)
	if err != nil {
		return nil, err
	}

	var groupPaths []*GroupPath
	for i := rootDepth+1; i <= depth && i <= rootDepth+numGroups; i++ {
		path := strings.Join(parts[:i], "/")
		groupPath := &GroupPath{
			Path:       path,
			Root:       root,
			Depth:      i,
			GroupDepth: i - rootDepth,
		}
		groupPaths = append(groupPaths, groupPath)
	}

	return groupPaths, nil
}

// GetNumGroups gets a number of groups for the root.
func GetNumGroups(db *gorm.DB, project string, root string) (int, error) {
	prefKey := fmt.Sprintf("/ppip/roots/%s/groups", root)
	var pref *model.PreferenceEntry

	stmt := db.Session(&gorm.Session{NewDB: true}).Where(
		"`section_type` = ?", "project",
	).Where(
		"`section_name` = ?", project,
	).Where(
		"`key` = ?", prefKey,
	).Where(
		"`deleted` = ?", 0,
	)

	if result := stmt.Take(&pref); errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return 0, fmt.Errorf("no preference key: key=%s", prefKey)
	}

	if pref.Value == nil {
		return 0, fmt.Errorf("no preference value: key=%s", prefKey)
	}

	if *pref.Value == "" {
		return 0, fmt.Errorf("empty preference value: key=%s", prefKey)
	}

	return len(strings.Split(*pref.Value, ",")), nil
}
