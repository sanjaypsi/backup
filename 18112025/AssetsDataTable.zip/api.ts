import { AuthorizationError } from '../../auth/types';
import { getAuthHeader, setNewToken } from '../../auth/util';
import { Asset, ReviewInfo } from './types';
import { Project } from '../types'; // whatever your project type is

type ReviewInfoListResponse = {
  reviews: ReviewInfo[],
  next: string | null,
  total: number,
};

export type AssetsResponse = {
  assets: Asset[],
  total: number,
};

export type AssetPivot = {
  root: string;
  project: string;
  group_1: string;
  relation: string;

  mdl_work_status?: string | null;
  mdl_approval_status?: string | null;
  mdl_submitted_at_utc?: string | null;

  rig_work_status?: string | null;
  rig_approval_status?: string | null;
  rig_submitted_at_utc?: string | null;

  bld_work_status?: string | null;
  bld_approval_status?: string | null;
  bld_submitted_at_utc?: string | null;

  dsn_work_status?: string | null;
  dsn_approval_status?: string | null;
  dsn_submitted_at_utc?: string | null;

  ldv_work_status?: string | null;
  ldv_approval_status?: string | null;
  ldv_submitted_at_utc?: string | null;
};

export type AssetsPivotResponse = {
  assets: AssetPivot[];
  total: number;
  page: number;
  per_page: number;
  sort: string;
  dir: string;
};

export const fetchAssetsPivot = async (
  project: string,
  page: number,
  rowsPerPage: number,
  sortKey: string,
  sortDir: string,   // we'll receive 'asc' | 'desc'
  phase: string,     // 'mdl' | 'rig' | 'bld' | 'dsn' | 'ldv' | 'none' | ''
  assetNameKey: string,
  approvalStatuses: string[],
  workStatuses: string[],
  signal?: AbortSignal | null,
): Promise<AssetsPivotResponse> => {
  const headers = getAuthHeader();
  let url = `/api/projects/${encodeURIComponent(project)}/reviews/assets/pivot`;

  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));

  if (sortKey) {
    params.set('sort', sortKey);
  }

  const dirLower = (sortDir || '').toLowerCase();
  if (dirLower === 'asc' || dirLower === 'desc') {
    params.set('dir', dirLower.toUpperCase());
  }

  if (phase && phase !== 'none') {
    params.set('phase', phase);
  }

  const trimmed = (typeof assetNameKey === 'string' ? assetNameKey : '').trim();
  if (trimmed) {
    params.set('name', trimmed);
  }

  if (Array.isArray(workStatuses)) {
    workStatuses
      .map(s => s && s.trim())
      .filter(Boolean)
      .forEach(s => params.append('work_status', s as string));
  }

  if (Array.isArray(approvalStatuses)) {
    approvalStatuses
      .map(s => s && s.trim())
      .filter(Boolean)
      .forEach(s => params.append('approval_status', s as string));
  }

  url += `?${params.toString()}`;

  const res = await fetch(url, {
    method: 'GET',
    headers,
    mode: 'cors',
    signal: signal || undefined,
  });

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch pivoted assets.');

  setNewToken(res);
  const json = (await res.json()) as AssetsPivotResponse;
  return json;
};

export const fetchAssets = async (
  project: string,
  page: number,
  rowsPerPage: number,
  signal?: AbortSignal | null,
): Promise<AssetsResponse> => {
  const headers = getAuthHeader();

  // keep your route; encode project
  let url: string = `/api/projects/${encodeURIComponent(project)}/reviews/assets`;

  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  url += `?${params.toString()}`;

  const res = await fetch(url, {
    method: 'GET',
    headers,
    mode: 'cors',
    signal: signal || undefined,
  });

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch parameters.');

  setNewToken(res);
  const json: AssetsResponse = await res.json();
  return json;
};

export const fetchAssetReviewInfos = async (
  project: string,
  asset: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<ReviewInfoListResponse> => {
  // keep your route names; just encode
  const url =
    `/api/projects/${encodeURIComponent(project)}` +
    `/assets/${encodeURIComponent(asset)}` +
    `/relations/${encodeURIComponent(relation)}/reviewInfos`;

  const headers = getAuthHeader();
  const res = await fetch(url, {
    method: 'GET',
    headers,
    mode: 'cors',
    signal: signal || undefined,
  });

  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch review infos.');

  setNewToken(res);
  const json = await res.json();
  // Basic validation to ensure expected structure
  if (!json || !Array.isArray(json.reviews) || typeof json.total !== 'number') {
    throw new Error('Invalid response format for review infos.');
  }
  return json as ReviewInfoListResponse;
};

export const fetchAssetThumbnail = async (
  project: string,
  asset: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  // keep your route name; just encode
  const url =
    `/api/projects/${encodeURIComponent(project)}` +
    `/assets/${encodeURIComponent(asset)}` +
    `/relations/${encodeURIComponent(relation)}/reviewthumbnail`;

  const headers = getAuthHeader();
  const res = await fetch(url, {
    method: 'GET',
    headers,
    mode: 'cors',
    signal: signal || undefined,
  });

  if (res.status === 204) return null;
  if (res.status === 401) throw new AuthorizationError();
  if (!res.ok) throw new Error('Failed to fetch thumbnail.');

  setNewToken(res);
  return res;
};