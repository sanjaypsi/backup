import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  TableSortLabel,
} from "@material-ui/core";
import {
  AssetRowProps,
  AssetsDataTableProps,
  Colors,
  Column,
  RecordTableHeadProps,
  SortDir,
  AssetPhaseSummary,
} from "./types";
import { useFetchAssetThumbnails } from "./hooks";

/* ──────────────────────────────────────────────────────────────────────────
 * Phase colors
 * ────────────────────────────────────────────────────────────────────────── */
const ASSET_PHASES: { [key: string]: Colors } = {
  mdl: { lineColor: "#3295fd", backgroundColor: "#354d68" },
  rig: { lineColor: "#c061fd", backgroundColor: "#5e3568" },
  bld: { lineColor: "#fc2f8c", backgroundColor: "#5a0028" },
  dsn: { lineColor: "#98f2fb", backgroundColor: "#045660" },
  ldv: { lineColor: "#fe5cff", backgroundColor: "#683566" },
};

type Status = Readonly<{ displayName: string; color: string }>;

const APPROVAL_STATUS: { [key: string]: Status } = {
  check: { displayName: "Check", color: "#ca25ed" },
  clientReview: { displayName: "Client Review", color: "#005fbd" },
  dirReview: { displayName: "Dir Review", color: "#007fff" },
  epdReview: { displayName: "EPD Review", color: "#4fa7ff" },
  clientOnHold: { displayName: "Client On Hold", color: "#d69b00" },
  dirOnHold: { displayName: "Dir On Hold", color: "#ffcc00" },
  epdOnHold: { displayName: "EPD On Hold", color: "#ffdd55" },
  execRetake: { displayName: "Exec Retake", color: "#a60000" },
  clientRetake: { displayName: "Client Retake", color: "#c60000" },
  dirRetake: { displayName: "Dir Retake", color: "#ff0000" },
  epdRetake: { displayName: "EPD Retake", color: "#ff4f4f" },
  clientApproved: { displayName: "Client Approved", color: "#1d7c39" },
  dirApproved: { displayName: "Dir Approved", color: "#27ab4f" },
  epdApproved: { displayName: "EPD Approved", color: "#5cda82" },
  other: { displayName: "Other", color: "#9a9a9a" },
  omit: { displayName: "Omit", color: "#646464" },
};

const WORK_STATUS: { [key: string]: Status } = {
  check: { displayName: "Check", color: "#e287f5" },
  cgsvOnHold: { displayName: "CGSV On Hold", color: "#ffdd55" },
  svOnHold: { displayName: "SV On Hold", color: "#ffe373" },
  leadOnHold: { displayName: "Lead On Hold", color: "#fff04f" },
  cgsvRetake: { displayName: "CGSV Retake", color: "#ff4f4f" },
  svRetake: { displayName: "SV Retake", color: "#ff8080" },
  leadRetake: { displayName: "Lead Retake", color: "#ffbbbb" },
  cgsvApproved: { displayName: "CGSV Approved", color: "#5cda82" },
  svApproved: { displayName: "SV Approved", color: "#83e29f" },
  leadApproved: { displayName: "Lead Approved", color: "#b9eec9" },
  svOther: { displayName: "SV Other", color: "#9a9a9a" },
  leadOther: { displayName: "Lead Other", color: "#dbdbdb" },
};

/* ──────────────────────────────────────────────────────────────────────────
 * Column metadata
 *  - uses "flex" weights; widths are computed as % of visible flex sum
 * ────────────────────────────────────────────────────────────────────────── */
export const columns: (Column & { flex?: number })[] = [
  { id: "thumbnail", label: "Thumbnail", flex: 1.0 },
  { id: "group_1_name", label: "Name", sortable: true, sortKey: "group_1", flex: 1.4 },

  { id: "mdl_work_status", label: "MDL WORK", colors: ASSET_PHASES["mdl"], sortable: true, sortKey: "mdl_work", flex: 1.1 },
  { id: "mdl_approval_status", label: "MDL APPR", colors: ASSET_PHASES["mdl"], sortable: true, sortKey: "mdl_appr", flex: 1.1 },
  { id: "mdl_submitted_at", label: "MDL Submitted At", colors: ASSET_PHASES["mdl"], sortable: true, sortKey: "mdl_submitted", flex: 1.3 },

  { id: "rig_work_status", label: "RIG WORK", colors: ASSET_PHASES["rig"], sortable: true, sortKey: "rig_work", flex: 1.1 },
  { id: "rig_approval_status", label: "RIG APPR", colors: ASSET_PHASES["rig"], sortable: true, sortKey: "rig_appr", flex: 1.1 },
  { id: "rig_submitted_at", label: "RIG Submitted At", colors: ASSET_PHASES["rig"], sortable: true, sortKey: "rig_submitted", flex: 1.3 },

  { id: "bld_work_status", label: "BLD WORK", colors: ASSET_PHASES["bld"], sortable: true, sortKey: "bld_work", flex: 1.1 },
  { id: "bld_approval_status", label: "BLD APPR", colors: ASSET_PHASES["bld"], sortable: true, sortKey: "bld_appr", flex: 1.1 },
  { id: "bld_submitted_at", label: "BLD Submitted At", colors: ASSET_PHASES["bld"], sortable: true, sortKey: "bld_submitted", flex: 1.3 },

  { id: "dsn_work_status", label: "DSN WORK", colors: ASSET_PHASES["dsn"], sortable: true, sortKey: "dsn_work", flex: 1.1 },
  { id: "dsn_approval_status", label: "DSN APPR", colors: ASSET_PHASES["dsn"], sortable: true, sortKey: "dsn_appr", flex: 1.1 },
  { id: "dsn_submitted_at", label: "DSN Submitted At", colors: ASSET_PHASES["dsn"], sortable: true, sortKey: "dsn_submitted", flex: 1.3 },

  /* ✅ LDV triplet that was missing */
  { id: "ldv_work_status", label: "LDV WORK", colors: ASSET_PHASES["ldv"], sortable: true, sortKey: "ldv_work", flex: 1.1 },
  { id: "ldv_approval_status", label: "LDV APPR", colors: ASSET_PHASES["ldv"], sortable: true, sortKey: "ldv_appr", flex: 1.1 },
  { id: "ldv_submitted_at", label: "LDV Submitted At", colors: ASSET_PHASES["ldv"], sortable: true, sortKey: "ldv_submitted", flex: 1.3 },

  { id: "relation", label: "Relation", sortable: true, sortKey: "relation", flex: 1.0 },
];

/* compute percent width per visible column */
const percentWidths = (visible: typeof columns) => {
  const sum = visible.reduce((acc, c) => acc + (c.flex || 1), 0);
  const map = new Map<string, string>();
  visible.forEach((c) => {
    const pct = ((c.flex || 1) / sum) * 100;
    map.set(c.id, `${pct}%`);
  });
  return map;
};

/* ──────────────────────────────────────────────────────────────────────────
 * Header
 * ────────────────────────────────────────────────────────────────────────── */
const RecordTableHead: React.FC<
  RecordTableHeadProps & {
    onSortChange: (sortKey: string) => void;
    currentSortKey: string;
    currentSortDir: SortDir;
    widthPct: Map<string, string>;
  }
> = ({ columns, onSortChange, currentSortKey, currentSortDir, widthPct }) => {
  const getSortDir = (id: string, activeSortKey: string, activeSortDir: SortDir): SortDir =>
    activeSortKey === id ? activeSortDir : "none";

  const createSortHandler = (id: string) => () => onSortChange(id);

  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => {
          const borderLineStyle = column.colors ? `solid 3px ${column.colors.lineColor}` : "none";
          const borderTopStyle = column.colors ? borderLineStyle : "none";
          const borderLeftStyle = column.id.indexOf("work_status") !== -1 ? borderLineStyle : "none";
          const borderRightStyle = column.id.indexOf("submitted_at") !== -1 ? borderLineStyle : "none";

          const columnSortKey = column.sortKey || column.id;
          const sortDir = getSortDir(columnSortKey, currentSortKey, currentSortDir);

          return (
            <TableCell
              key={column.id}
              style={{
                backgroundColor: column.colors ? column.colors.backgroundColor : undefined,
                borderTop: borderTopStyle,
                borderLeft: borderLeftStyle,
                borderRight: borderRightStyle,
                width: widthPct.get(column.id),
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {column.sortable ? (
                <TableSortLabel
                  active={sortDir !== "none"}
                  hideSortIcon
                  direction={sortDir === "desc" ? "desc" : "asc"}
                  onClick={createSortHandler(columnSortKey)}
                  IconComponent={() => (
                    <span
                      style={{
                        fontSize: "16px",
                        fontWeight: 750,
                        lineHeight: "24px",
                        marginLeft: "10px",
                        userSelect: "none",
                      }}
                    >
                      {sortDir === "desc" ? "▼" : "▲"}
                    </span>
                  )}
                >
                  {column.label}
                </TableSortLabel>
              ) : (
                column.label
              )}
            </TableCell>
          );
        })}
      </TableRow>
    </TableHead>
  );
};

/* ──────────────────────────────────────────────────────────────────────────
 * Body row
 * ────────────────────────────────────────────────────────────────────────── */
const MultiLineTooltipTableCell: React.FC<{
  tooltipText: string;
  status: Status | undefined;
  leftBorderStyle: string;
  rightBorderStyle: string;
  bottomBorderStyle?: string;
  width: string;
}> = ({ tooltipText, status, leftBorderStyle, rightBorderStyle, bottomBorderStyle = "none", width }) => {
  const [open, setOpen] = React.useState(false);
  const hasTooltip = !!(tooltipText && tooltipText.trim().length > 0);
  const statusText = status != null ? status["displayName"] : "-";

  return (
    <TableCell
      style={{
        color: status != null ? status["color"] : "",
        fontStyle: tooltipText === "" ? "normal" : "oblique",
        borderLeft: leftBorderStyle,
        borderRight: rightBorderStyle,
        borderBottom: bottomBorderStyle,
        width,
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
      }}
      onClick={hasTooltip ? () => setOpen(true) : undefined}
    >
      {hasTooltip ? (
        <Tooltip
          title={<div style={{ fontSize: "0.8rem", whiteSpace: "pre-wrap" }}>{tooltipText}</div>}
          onClose={() => setOpen(false)}
          open={open}
          arrow
        >
          <span>{statusText}</span>
        </Tooltip>
      ) : (
        <span>{statusText}</span>
      )}
    </TableCell>
  );
};

const AssetRow: React.FC<
  AssetRowProps & { hiddenColumns: Set<string>; widthPct: Map<string, string> }
> = ({ asset, thumbnails, dateTimeFormat, isLastRow, hiddenColumns, widthPct }) => {
  const getPhaseData = (phase: string) => {
    const workStatusKey = `${phase}_work_status` as keyof AssetPhaseSummary;
    const approvalStatusKey = `${phase}_approval_status` as keyof AssetPhaseSummary;
    const submittedAtKey = `${phase}_submitted_at_utc` as keyof AssetPhaseSummary;

    const tooltipText = "";
    const workStatusValue = asset[workStatusKey];
    const approvalStatusValue = asset[approvalStatusKey];
    const submittedAtValue = asset[submittedAtKey];

    const workStatus: Status | undefined = workStatusValue
      ? WORK_STATUS[String(workStatusValue).toLowerCase()]
      : undefined;
    const approvalStatus: Status | undefined = approvalStatusValue
      ? APPROVAL_STATUS[String(approvalStatusValue).toLowerCase()]
      : undefined;

    const submittedAt = submittedAtValue ? new Date(submittedAtValue as string) : null;
    const localTimeText = submittedAt ? dateTimeFormat.format(submittedAt) : "-";

    return { workStatus, approvalStatus, localTimeText, tooltipText };
  };

  return (
    <TableRow>
      {!hiddenColumns.has("thumbnail") && (
        <TableCell
          style={{
            width: widthPct.get("thumbnail"),
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {thumbnails[`${asset.group_1}-${asset.relation}`] ? (
            <img
              src={thumbnails[`${asset.group_1}-${asset.relation}`]}
              alt={`${asset.group_1} thumbnail`}
              style={{ width: "100%", maxWidth: 100, height: "auto" }}
            />
          ) : (
            <span>No Thumbnail</span>
          )}
        </TableCell>
      )}

      {!hiddenColumns.has("group_1_name") && (
        <TableCell
          style={{
            width: widthPct.get("group_1_name"),
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {asset.group_1}
        </TableCell>
      )}

      {Object.entries(ASSET_PHASES).map(([phase, { lineColor }]) => {
        const { workStatus, approvalStatus, localTimeText, tooltipText } = getPhaseData(phase);
        const borderLineStyle = `solid 3px ${lineColor}`;

        const workId = `${phase}_work_status`;
        const apprId = `${phase}_approval_status`;
        const subId = `${phase}_submitted_at`;

        return (
          <React.Fragment key={`${asset.group_1}-${asset.relation}-${phase}-triplet`}>
            {!hiddenColumns.has(workId) && (
              <MultiLineTooltipTableCell
                tooltipText={tooltipText}
                status={workStatus}
                leftBorderStyle={borderLineStyle}
                rightBorderStyle={"none"}
                bottomBorderStyle={isLastRow ? borderLineStyle : "none"}
                width={widthPct.get(workId) || "auto"}
              />
            )}
            {!hiddenColumns.has(apprId) && (
              <MultiLineTooltipTableCell
                tooltipText={tooltipText}
                status={approvalStatus}
                leftBorderStyle={"none"}
                rightBorderStyle={"none"}
                bottomBorderStyle={isLastRow ? borderLineStyle : "none"}
                width={widthPct.get(apprId) || "auto"}
              />
            )}
            {!hiddenColumns.has(subId) && (
              <TableCell
                style={{
                  borderLeft: "none",
                  borderRight: borderLineStyle,
                  borderBottom: isLastRow ? borderLineStyle : "none",
                  width: widthPct.get(subId),
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                {localTimeText}
              </TableCell>
            )}
          </React.Fragment>
        );
      })}

      {!hiddenColumns.has("relation") && (
        <TableCell
          style={{
            width: widthPct.get("relation"),
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {asset.relation}
        </TableCell>
      )}
    </TableRow>
  );
};

/* ──────────────────────────────────────────────────────────────────────────
 * Table (fits container — no horizontal page scrollbar)
 * ────────────────────────────────────────────────────────────────────────── */
const AssetsDataTable: React.FC<
  AssetsDataTableProps & {
    currentSortKey: string;
    currentSortDir: SortDir;
    onSortChange: (sortKey: string) => void;
    hiddenColumns: Set<string>;
  }
> = ({
  project,
  assets,
  tableFooter,
  dateTimeFormat,
  onSortChange,
  currentSortKey,
  currentSortDir,
  hiddenColumns,
}) => {
  if (project == null) return null;

  const { thumbnails } = useFetchAssetThumbnails(
    project,
    assets.map((a) => ({ name: a.group_1, relation: a.relation }))
  );

  // Same visible columns for head & rows; compute % widths from them
  const visibleColumns = columns.filter(
    (c) => !hiddenColumns.has(c.id) || c.id === "thumbnail" || c.id === "group_1_name"
  );
  const widthPct = percentWidths(visibleColumns);

  return (
    <Table
      stickyHeader
      size="small"
      style={{ tableLayout: "fixed", width: "100%" }}
    >
      <RecordTableHead
        key="asset-data-table-head"
        columns={visibleColumns}
        onSortChange={onSortChange}
        currentSortKey={currentSortKey}
        currentSortDir={currentSortDir}
        widthPct={widthPct}
      />
      <TableBody>
        {assets.map((asset, index) => (
          <AssetRow
            key={`${asset.group_1}-${asset.relation}-${index}`}
            asset={asset}
            thumbnails={thumbnails}
            dateTimeFormat={dateTimeFormat}
            isLastRow={index === assets.length - 1}
            hiddenColumns={hiddenColumns}
            widthPct={widthPct}
          />
        ))}
      </TableBody>
      {tableFooter || null}
    </Table>
  );
};

export default AssetsDataTable;