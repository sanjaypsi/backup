from typing import Any, TypedDict

from .tableData import Entity


class CsvEntityData(TypedDict):
    entity: Entity
    changes: dict[str, dict[str, str | Any]]
    isNew: bool
