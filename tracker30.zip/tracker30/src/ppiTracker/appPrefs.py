from typing import Any, Dict

from ppilib.utils.compat.pathlib import Path
from ppilib.utils.serialize import readJson, writeJson


class AppPrefs(object):
    __slots__ = ('_appPrefsPath',)

    @classmethod
    def loadFromFile(cls, filePath: Path) -> 'AppPrefs':
        _: Dict[str, Any] = readJson(filePath) if filePath.exists() else {}
        return cls(filePath)

    def __init__(self, filePath: Path) -> None:
        self._appPrefsPath = filePath

    def asDict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        return data

    def saveToFile(self, filePath: Path | None = None) -> None:
        _filePath = filePath
        if _filePath is None:
            _filePath = self._appPrefsPath
        _filePath.parent.mkdir(exist_ok=True, parents=True)
        writeJson(_filePath, self.asDict())
