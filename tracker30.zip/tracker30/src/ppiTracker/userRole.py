from enum import Enum, IntEnum
from getpass import getuser
from collections import OrderedDict

from ppilib.desktop.setting import DesktopPipelineSetting


class Role(IntEnum):
    keyName: str
    displayName: str

    def __new__(cls, value: int, keyName: str, displayName: str):
        obj = int.__new__(cls, value)
        obj._value_ = value
        obj.keyName = keyName
        obj.displayName = displayName
        return obj

    Guest = (0, 'guest', 'Guest')
    Artist = (1, 'artist', 'Artist')
    Supervisor = (2, 'supervisor', 'Supervisor')
    Manager = (3, 'manager', 'Manager')
    Admin = (4, 'admin', 'Admin')


class Permission(Enum):
    # Columns
    CanSeeColumns = 'can_see_columns'
    CanEditColumns = 'can_edit_columns'
    CanAddColumns = 'can_add_columns'
    CanRemoveColumns = 'can_remove_columns'
    # Parameters
    CanSeeParameters = 'can_see_parameters'
    CanEditParameters = 'can_edit_parameters'
    # Roles
    CanEditRoles = 'can_edit_roles'


PERMISSION_RULE = {
    Permission.CanSeeColumns: Role.Artist,
    Permission.CanEditColumns: Role.Manager,
    Permission.CanAddColumns: Role.Manager,
    Permission.CanRemoveColumns: Role.Manager,
    Permission.CanSeeParameters: Role.Guest,
    Permission.CanEditParameters: Role.Supervisor,
    Permission.CanEditRoles: Role.Admin,
}


class RoleManager:
    def __init__(self, pipelineSetting: DesktopPipelineSetting, role: Role = Role.Guest):
        self._pipelineSetting = pipelineSetting
        self._preference = self._pipelineSetting.preference()
        self._preferenceKey = '/ppiBreakdown/roles'
        self._currentRole = role
        self._name = getuser()
        self._roleData: OrderedDict[Role, list[str]] = OrderedDict()
        self._resetRoleData()

    def _isAdmin(self):
        return self._currentRole.value >= Role.Admin.value

    def _resetRoleData(self):
        self._roleData = OrderedDict()
        for r in Role:
            users: list[str] = self._preference.get(f'{self._preferenceKey}/{r.keyName}', [])
            self._roleData[r] = users
        self.currentRole(self._name)

    def currentRole(self, name: str) -> Role:
        for role, users in self._roleData.items():
            if name in users:
                self._currentRole = role
                break
        return self._currentRole

    def hasPermission(self, permission: Permission) -> bool:
        requiredRole = PERMISSION_RULE.get(permission, Role.Admin)
        return self._currentRole.value >= requiredRole.value

    def userName(self) -> str:
        return self._name

    def currentRoleName(self) -> str:
        return self._currentRole.displayName

    # TODO: Adminユーザーのみがユーザーの追加・削除を行えるようにする
    # def addUserForRole(self, role: Role, name: str):
    #     if not self._isAdmin():
    #         return
    #     if name not in self._roleData[role]:
    #         self._roleData[role].append(name)
    #         # TODO: CentralClient.updatePreferenceで変更をPipelineSettingに反映させるようにする
    #         self._preference[f'{self._preferenceKey}/{role.keyName}'] = self._roleData[role]

    # def removeUserFromRole(self, role: Role, name: str):
    #     if not self._isAdmin():
    #         return
    #     if name in self._roleData[role]:
    #         self._roleData[role].remove(name)
    #         # TODO: CentralClient.updatePreferenceで変更をPipelineSettingに反映させるようにする
    #         self._preference[f'{self._preferenceKey}/{role.keyName}'] = self._roleData[role]
