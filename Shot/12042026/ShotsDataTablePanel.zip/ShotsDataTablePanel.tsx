import React, {
    FC,
    useEffect,
    useMemo,
    useRef,
    useState,
} from 'react';
import { RouteComponentProps } from "react-router-dom";
import { CircularProgress, Container, Paper, styled } from '@material-ui/core';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import { useShotsPivot, useFetchPipelineSettingShotComponents } from './hooks';
import { PageProps, ShotPivot } from './types';
import ShotsDataTable from './ShotsDataTable';
import ShotsDataTableFooter from './ShotsDataTableFooter';
import { useCurrentProject } from '../../hooks';
import { useCurrentStudio } from '../../../studio/hooks';
import { queryConfig } from '../../../new-pipeline-setting/api';
import ShotDataTableToolbar, {
    ViewMode,
    ColumnState,
    DEFAULT_COLUMN_STATE,
} from './ShotDataTableToolbar';

import ShotsDataTableGroup, { getShotSortValue } from './ShotsDataTableGroup';


/* ── Styled Components ─────────────────────────────────────────────────── */
const StyledContainer = styled(Container)(({ theme }) => ({
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    padding: 0,
    '& > *': {
        display: 'flex',
        overflow: 'hidden',
        padding: theme.spacing(1),
        paddingBottom: 0,
    },
    '& > *:last-child': {
        paddingBottom: theme.spacing(1),
    },
}));

const StyledPaper = styled(Paper)({
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'auto',
    flex: '1 1 auto',
});

const StyledContentDiv = styled('div')(({ theme }) => ({
    backgroundColor: theme.palette.background.paper,
    display: 'flex',
    flexDirection: 'row',
    gap: theme.spacing(2),
    width: 'fit-content',
    minWidth: '100%',
}));

const StyledTableDiv = styled('div')({
    paddingBottom: 8,
    overflowX: 'auto',
    width: '100%',
    flex: '1 1 auto',
    height: '100%',
});

const ToolBarWrapper = styled('div')(({ theme }) => ({
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(1),
}));

const FooterWrapper = styled('div')(({ theme }) => ({
    display:         'flex',
    justifyContent:  'flex-end',
    width:           '100%',
    backgroundColor: theme.palette.background.paper,
    paddingRight:  theme.spacing(25),
}));

/* ── Types ─────────────────────────────────────────────────────────────── */

type Filters = {
    shotGroups:     string[];
    approvalStatus: string[];
    workStatus:     string[];
};

/* ── Main Component ─────────────────────────────────────────────────────── */

const ShotsDataTablePanel: FC<RouteComponentProps> = () => {
    const [viewMode,     setViewMode]     = useState<ViewMode>('list');
    const [searchValue,  setSearchValue]  = useState<string>('');
    const [columnsState, setColumnsState] = useState<ColumnState>(DEFAULT_COLUMN_STATE);
    const [filters,      setFilters]      = useState<Filters>({
        shotGroups:     [],
        approvalStatus: [],
        workStatus:     [],
    });
    const [pageProps, setPageProps] = useState<PageProps>({
        page:        0,
        rowsPerPage: 15,
    });

    const { currentProject } = useCurrentProject();
    const { phaseComponents } = useFetchPipelineSettingShotComponents(currentProject);

    // reset page when search or filters change
    const prevSearchRef   = useRef(searchValue);
    const prevApprovalRef = useRef(JSON.stringify(filters.approvalStatus));
    const prevWorkRef     = useRef(JSON.stringify(filters.workStatus));

    const searchOrFilterChanged =
        prevSearchRef.current   !== searchValue ||
        prevApprovalRef.current !== JSON.stringify(filters.approvalStatus) ||
        prevWorkRef.current     !== JSON.stringify(filters.workStatus);

    const effectivePage = searchOrFilterChanged ? 0 : pageProps.page;

    useEffect(() => {
        if (searchOrFilterChanged) {
            prevSearchRef.current   = searchValue;
            prevApprovalRef.current = JSON.stringify(filters.approvalStatus);
            prevWorkRef.current     = JSON.stringify(filters.workStatus);
            setPageProps(prev => ({ ...prev, page: 0 }));
        }
    }, [
        searchValue,
        JSON.stringify(filters.approvalStatus),
        JSON.stringify(filters.workStatus),
        JSON.stringify(filters.shotGroups),
    ]);


    const [sortKey, setSortKey]   = useState<string>('group1_only');
    const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

    const isGroupView    = viewMode === 'group';
    const backendPage    = isGroupView ? 1 : effectivePage + 1;  // API is 1-based
    const backendPerPage = isGroupView ? 10000 : pageProps.rowsPerPage;

    // new pivot hook
    const { shots, total, groupCounts, loading } = useShotsPivot({
        project:        currentProject,
        page:           backendPage,
        perPage:        backendPerPage,
        nameKey:        searchValue,
        approvalStatus: filters.approvalStatus,
        workStatus:     filters.workStatus,
        orderKey:       isGroupView ? 'group1_only' : sortKey,
        direction:      isGroupView ? 'ASC' : sortDir.toUpperCase(),
        shotsGroups:    filters.shotGroups,
    });


    /* ── Sort ALL shots into canonical hierarchical order ──────────────
    Order: NAME 1 (alpha) → NAME 2 (smart) → NAME 3 (by sortDir).
    The flat list is then sliced page-by-page in pagedShots.
    This produces the behavior:
        - NAME 1 / NAME 2 order is fixed
        - NAME 3 inside each NAME 2 subgroup flips with asc/desc
        - Pages flow forward through the sorted list; long groups
        can span multiple pages.
    ─────────────────────────────────────────────────────────────────── */
    const sortedAllShots = useMemo(() => {
        if (!isGroupView || !shots || shots.length === 0) return shots || [];

        // Guard against stale shorter responses while a bigger one is in flight
        if (shots.length < total) return [];

        // NAME 2 smart sort: numeric first, then alphabetic (matches buildGroupedData)
        const smartCmp = (a: string, b: string) => {
            const isNumA = /^\d+$/.test(a);
            const isNumB = /^\d+$/.test(b);
            if (isNumA && isNumB) return parseInt(a, 10) - parseInt(b, 10);
            if (isNumA) return -1;
            if (isNumB) return 1;
            return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
        };

        const arr = [...shots];
        arr.sort((a, b) => {
            // 1. NAME 1 alphabetical (always)
            const g1 = a.group_1.toLowerCase().localeCompare(b.group_1.toLowerCase());
            if (g1 !== 0) return g1;

            // 2. NAME 2 smart sort (always)
            const g2 = smartCmp(a.group_2, b.group_2);
            if (g2 !== 0) return g2;

            // 3. NAME 3 (or phase column) by sortDir
            const aVal = getShotSortValue(a, sortKey);
            const bVal = getShotSortValue(b, sortKey);

            const aEmpty = aVal === null || aVal === undefined || aVal === '' || aVal === 0;
            const bEmpty = bVal === null || bVal === undefined || bVal === '' || bVal === 0;
            if (aEmpty && bEmpty) return 0;
            if (aEmpty) return 1;
            if (bEmpty) return -1;

            if (aVal === bVal) return 0;
            return sortDir === 'asc'
                ? (aVal > bVal ? 1 : -1)
                : (aVal < bVal ? 1 : -1);
        });
        return arr;
    }, [shots, total, isGroupView, sortKey, sortDir]);

    const pagedShots: ShotPivot[] = useMemo(() => {
        if (!isGroupView) return shots;
        const start = effectivePage * pageProps.rowsPerPage;
        const end   = start + pageProps.rowsPerPage;
        return sortedAllShots.slice(start, end);
    }, [isGroupView, sortedAllShots, shots, effectivePage, pageProps.rowsPerPage]);

    // For the footer count: in group view, total = full dataset length; in list view, total = backend total.
    const displayTotal = isGroupView ? total : total;


    // Keep last non-empty groupCounts so filter menu doesn't empty during reload
    const stableGroupCounts = useRef<{ [key: string]: number }>({});
    if (Object.keys(groupCounts).length > 0) {
        stableGroupCounts.current = groupCounts;
    }

    const name1Options = useMemo(() => {
        const entries = Object.entries(stableGroupCounts.current || {})
            .filter(([key]) => key !== 'Ungrouped');

        // sort by count descending only — no selected-first logic
        const sorted = entries.sort((a, b) => b[1] - a[1]);

        return sorted.map(([key, count]) => ({
            id: key,
            label: `${key} (${count})`,
        }));
    }, [stableGroupCounts.current, filters.shotGroups]);

    const handleSortChange = (key: string) => {
        console.log('🔄 Sort change triggered:', {
            key,
            currentSortKey: sortKey,
            currentSortDir: sortDir
        });

        if (sortKey === key) {
            const newDir = sortDir === 'asc' ? 'desc' : 'asc';
            setSortDir(newDir);
        } else {
            setSortKey(key);
            setSortDir('asc');
        }
        // setPageProps(prev => ({ ...prev, page: 0 }));
    };

    // timezone
    const { currentStudio } = useCurrentStudio();
    const [timeZone, setTimeZone] = useState<string | undefined>();

    useEffect(() => {
        if (currentStudio == null) return;
        const controller = new AbortController();
        (async () => {
            try {
                const res: string | null = await queryConfig(
                    'studio',
                    currentStudio.key_name,
                    'timezone',
                ).catch(e => {
                    if (e.name === 'AbortError') return;
                    throw e;
                });
                if (res != null) setTimeZone(res);
            } catch (e) {
                console.error(e);
            }
        })();
        return () => controller.abort();
    }, [currentStudio]);

    const dateTimeFormat = new Intl.DateTimeFormat(
        undefined,
        {
            timeZone,
            dateStyle: 'medium',
            timeStyle: 'medium',
        },
    );

    const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
        setPageProps({ page: 0, rowsPerPage: parseInt(event.target.value) });
    };

    const handlePageChange: TablePaginationProps['onChangePage'] = (_, newPage) => {
        setPageProps(prev => ({ ...prev, page: newPage }));
    };

    const tableFooter = (
        <ShotsDataTableFooter
            count={displayTotal}
            page={effectivePage}
            rowsPerPage={pageProps.rowsPerPage}
            onChangePage={handlePageChange}
            onChangeRowsPerPage={handleRowsPerPageChange}
        />
    );

    return (
        <StyledContainer maxWidth="xl">
            <ToolBarWrapper>
                <ShotDataTableToolbar
                    viewMode={viewMode}
                    onViewChange={(mode: ViewMode) => setViewMode(mode)}
                    searchValue={searchValue}
                    onSearchChange={(value: string) => setSearchValue(value)}
                    filters={filters}
                    onFilterChange={(newFilters: Filters) => setFilters(newFilters)}
                    columnsState={columnsState}
                    onColumnsChange={setColumnsState}
                    shotGroupOptions={name1Options}
                />
            </ToolBarWrapper>

            <StyledTableDiv>
                <StyledPaper>
                    {loading ? (
                        <div style={{ 
                            padding: 20,
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                        }}>
                            <CircularProgress />

                        </div>
                    ) : (

                    <StyledContentDiv>
                        {viewMode === 'group' ? (
                            <ShotsDataTableGroup
                                project={currentProject}
                                shots={pagedShots}
                                total={groupCounts}
                                phaseComponents={phaseComponents}
                                dateTimeFormat={dateTimeFormat}
                                columnsState={columnsState}
                                tableFooter={<></>}
                                sortKey={sortKey}
                                sortDir={sortDir}
                                onSortChange={handleSortChange}
                            />
                        ) : (
                        <ShotsDataTable
                            project={currentProject}
                            shots={shots}
                            total={groupCounts}
                            phaseComponents={phaseComponents}
                            tableFooter={<></>}
                            dateTimeFormat={dateTimeFormat}
                            columnsState={columnsState}
                            sortKey={sortKey}
                            sortDir={sortDir}
                            onSortChange={handleSortChange}
                        />
                        )}
                    </StyledContentDiv>
                    )}
                </StyledPaper>
            </StyledTableDiv>

            <FooterWrapper>
                {tableFooter}
            </FooterWrapper>

        </StyledContainer>
    );
};

export default ShotsDataTablePanel;