import React from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
} from "@material-ui/core";
import { ShotPivot, Colors, Column, ShotsDataTableProps, RecordTableHeadProps } from "./types";
import { useFetchShotThumbnails, useFetchLatestShotComponents } from './hooks';

/* ──────────────────────────────────────────────────────────────────────────
   Phase Colors
   ────────────────────────────────────────────────────────────────────────── */
const SHOT_PHASES: { [key: string]: Colors } = {
    lay:        { lineColor: '#3295FD', backgroundColor: '#004288' },
    anm:        { lineColor: '#FD5E63', backgroundColor: '#5c0003' },
    gnz:        { lineColor: '#C061FD', backgroundColor: '#340055' },
    mat:        { lineColor: '#FE7DB3', backgroundColor: '#5f0028' },
    matnuke:    { lineColor: '#FE7DB3', backgroundColor: '#3d0019' },
    fx:         { lineColor: '#FDCD44', backgroundColor: '#CCA537' },
    cmp:        { lineColor: '#D5F762', backgroundColor: '#4a6101' },
    dsp:        { lineColor: '#FFD35D', backgroundColor: '#FFB54C' },
    cloth:      { lineColor: '#FE9880', backgroundColor: '#FE8359' },
    cfxhair:    { lineColor: '#FDA342', backgroundColor: '#FD8D03' },
    crd:        { lineColor: '#FF8C12', backgroundColor: '#E88600' },
    drw:        { lineColor: '#FDC0FF', backgroundColor: '#FDAFFB' },
    rtcgnz:     { lineColor: '#D38AFF', backgroundColor: '#C061FD' },
    rtcmat:     { lineColor: '#FFA3C5', backgroundColor: '#FE7DB3' },
    rtcmatnuke: { lineColor: '#FFC4B4', backgroundColor: '#FEAD92' },
    rtcdrw:     { lineColor: '#FFC3FC', backgroundColor: '#FDAFFB' },
};

const DEFAULT_PHASE_COLORS: Colors = { lineColor: '#888', backgroundColor: '#444' };

const getPhaseColors = (phase: string): Colors => {
    return SHOT_PHASES[phase.toLowerCase()] || DEFAULT_PHASE_COLORS;
};

const getOrderedPhases = (phaseComponents: { [key: string]: string[] }): string[] => {
    const knownOrder    = Object.keys(SHOT_PHASES);
    const settingPhases = Object.keys(phaseComponents || {});
    const settingByLower: { [key: string]: string } = {};
    settingPhases.forEach(s => { settingByLower[s.toLowerCase()] = s; });

    const ordered: string[] = [];
    knownOrder.forEach(p => {
        if (settingByLower[p]) ordered.push(settingByLower[p]);
        else ordered.push(p);
    });
    settingPhases.forEach(s => {
        if (!knownOrder.includes(s.toLowerCase())) ordered.push(s);
    });
    return ordered;
};

/* Component IDs for a phase, filtered to exclude entries that share the
   phase's own name (those would render as a redundant "ANM SUBMITTED"
   inside the ANM phase, etc.). */
const getPhaseComponentIds = (
    phase: string,
    phaseComponents: { [key: string]: string[] },
): string[] => {
    const ids = (phaseComponents && phaseComponents[phase]) || [];
    return ids.filter(id => id.toLowerCase() !== phase.toLowerCase());
};

/* ──────────────────────────────────────────────────────────────────────────
   Status Maps
   ────────────────────────────────────────────────────────────────────────── */
type Status = Readonly<{ displayName: string; color: string }>;

const APPROVAL_STATUS: { [key: string]: Status } = {
    check:          { displayName: 'Check',           color: '#ca25ed' },
    clientReview:   { displayName: 'Client Review',   color: '#005fbd' },
    dirReview:      { displayName: 'Dir Review',      color: '#007fff' },
    epdReview:      { displayName: 'EPD Review',      color: '#4fa7ff' },
    clientOnHold:   { displayName: 'Client On Hold',  color: '#d69b00' },
    dirOnHold:      { displayName: 'Dir On Hold',     color: '#ffcc00' },
    epdOnHold:      { displayName: 'EPD On Hold',     color: '#ffdd55' },
    execRetake:     { displayName: 'Exec Retake',     color: '#a60000' },
    clientRetake:   { displayName: 'Client Retake',   color: '#c60000' },
    dirRetake:      { displayName: 'Dir Retake',      color: '#ff0000' },
    epdRetake:      { displayName: 'EPD Retake',      color: '#ff4f4f' },
    clientApproved: { displayName: 'Client Approved', color: '#1d7c39' },
    dirApproved:    { displayName: 'Dir Approved',    color: '#27ab4f' },
    epdApproved:    { displayName: 'EPD Approved',    color: '#5cda82' },
    svApproved:     { displayName: 'SV Approved',     color: '#83e29f' },
    other:          { displayName: 'Other',           color: '#9a9a9a' },
    omit:           { displayName: 'Omit',            color: '#646464' },
};

const WORK_STATUS: { [key: string]: Status } = {
    check:        { displayName: 'Check',         color: '#e287f5' },
    cgsvOnHold:   { displayName: 'CGSV On Hold',  color: '#ffdd55' },
    svOnHold:     { displayName: 'SV On Hold',    color: '#ffe373' },
    leadOnHold:   { displayName: 'Lead On Hold',  color: '#fff04f' },
    cgsvRetake:   { displayName: 'CGSV Retake',   color: '#ff4f4f' },
    svRetake:     { displayName: 'SV Retake',     color: '#ff8080' },
    leadRetake:   { displayName: 'Lead Retake',   color: '#ffbbbb' },
    cgsvApproved: { displayName: 'CGSV Approved', color: '#5cda82' },
    svApproved:   { displayName: 'SV Approved',   color: '#83e29f' },
    leadApproved: { displayName: 'Lead Approved', color: '#b9eec9' },
    svOther:      { displayName: 'SV Other',      color: '#9a9a9a' },
    leadOther:    { displayName: 'Lead Other',    color: '#dbdbdb' },
};

/* ──────────────────────────────────────────────────────────────────────────
   Build Columns
   ────────────────────────────────────────────────────────────────────────── */
const buildColumns = (phaseComponents: { [key: string]: string[] }): Column[] => {
    const fixed: Column[] = [
        { id: 'thumbnail',    label: 'THUMBNAIL', fixed: true },
        { id: 'group_1_name', label: 'NAME 1',    fixed: true },
        { id: 'group_2_name', label: 'NAME 2',    fixed: true },
        { id: 'group_3_name', label: 'NAME 3',    fixed: true },
    ];

    const orderedPhases = getOrderedPhases(phaseComponents);

    const phaseCols: Column[] = orderedPhases.flatMap(p => {
        const colors  = getPhaseColors(p);
        const label   = p.toUpperCase();
        const colBase = p.toLowerCase();

        const base: Column[] = [
            { id: `${colBase}_work_status`,     label: `${label} WORK`, colors },
            { id: `${colBase}_approval_status`, label: `${label} APPR`, colors },
            { id: `${colBase}_take`,            label: `${label} TAKE`, colors },
        ];

        const componentIds = getPhaseComponentIds(p, phaseComponents);

        if (componentIds.length === 0) {
            // Fallback: phase has no pipeline components, show phase-level submitted_at
            base.push({
                id:    `${colBase}_submitted_at`,
                label: `${label} SUBMITTED`,
                colors,
            });
        }

        const compCols: Column[] = componentIds.map(id => ({
            id,
            label: `${id.toUpperCase()} SUBMITTED`,
            colors,
        }));

        return [...base, ...compCols];
    });

    return [...fixed, ...phaseCols, { id: 'relation', label: 'RELATION' }];
};

/* ──────────────────────────────────────────────────────────────────────────
   MultiLineTooltipTableCell
   ────────────────────────────────────────────────────────────────────────── */
type TooltipTableCellProps = {
    status:            Status | undefined;
    leftBorderStyle:   string;
    rightBorderStyle:  string;
    bottomBorderStyle: string;
};

const MultiLineTooltipTableCell: React.FC<TooltipTableCellProps> = ({
    status,
    leftBorderStyle,
    rightBorderStyle,
    bottomBorderStyle = 'none',
}) => {
    const statusText = status != null ? status.displayName : '-';

    return (
        <TableCell
            style={{
                color:        status != null ? status.color : '',
                borderLeft:   leftBorderStyle,
                borderRight:  rightBorderStyle,
                borderBottom: bottomBorderStyle,
                whiteSpace:   'nowrap',
            }}
        >
            <span>{statusText}</span>
        </TableCell>
    );
};

/* ──────────────────────────────────────────────────────────────────────────
   Table Head
   ────────────────────────────────────────────────────────────────────────── */
const getOrderKey = (colId: string): string | null => {
    if (colId === 'group_1_name') return 'group1_only';
    if (colId === 'group_2_name') return 'group2_only';
    if (colId === 'group_3_name') return 'group3_only';
    if (colId === 'relation')     return 'relation_only';

    if (colId.endsWith('_work_status'))     return colId.replace('_work_status', '_work');
    if (colId.endsWith('_approval_status')) return colId.replace('_approval_status', '_appr');
    if (colId.endsWith('_submitted_at'))    return colId.replace('_submitted_at', '_submitted');
    if (colId.endsWith('_take'))            return colId;

    return null;
};

const RecordTableHead: React.FC<RecordTableHeadProps> = ({
    columns,
    columnsState,
    sortKey,
    sortDir,
    onSortChange,
}) => (
    <TableHead>
        <TableRow>
            {columns.map((col) => {
                const lineColor   = col.colors && col.colors.lineColor;
                const borderLine  = lineColor ? `solid 3px ${lineColor}` : 'none';
                const isWork      = col.id.endsWith('_work_status');
                const orderKey    = getOrderKey(col.id);
                const isActive    = orderKey === sortKey;

                const getSortIcon = () => {
                    if (!isActive) return null;
                    return sortDir === 'asc' ? ' ↑' : ' ↓';
                };

                const handleSortClick = () => {
                    if (orderKey) {
                        onSortChange(orderKey);
                    }
                };

                return (
                    <TableCell
                        key={col.id}
                        onClick={handleSortClick}
                        style={{
                            backgroundColor: (col.colors && col.colors.backgroundColor) || undefined,
                            borderTop:  lineColor ? borderLine : 'none',
                            borderLeft: isWork && lineColor ? borderLine : 'none',
                            whiteSpace: 'nowrap',
                            cursor:     orderKey ? 'pointer' : 'default',
                            fontWeight: isActive ? 'bold' : 'normal',
                            userSelect: orderKey ? 'none' : 'auto',
                        }}
                        title={orderKey ? `Click to sort ${sortDir === 'asc' ? 'descending' : 'ascending'}` : ''}
                    >
                        {col.label}
                        {getSortIcon()}
                    </TableCell>
                );
            })}
        </TableRow>
    </TableHead>
);

/* ──────────────────────────────────────────────────────────────────────────
   Shot Row
   ────────────────────────────────────────────────────────────────────────── */
type ShotRowProps = {
    shot:             ShotPivot;
    thumbnails:       { [key: string]: string };
    dateTimeFormat:   Intl.DateTimeFormat;
    isLastRow:        boolean;
    columnsState:     { [key: string]: boolean };
    phaseComponents:  { [key: string]: string[] };
    latestComponents: { [key: string]: any[] };
};

const ShotRow: React.FC<ShotRowProps> = ({
    shot,
    thumbnails,
    dateTimeFormat,
    isLastRow,
    columnsState,
    phaseComponents,
    latestComponents,
}) => {
    const thumbKey = `${shot.group_1}-${shot.group_2}-${shot.group_3}-${shot.relation}`;
    const compKey  = `${shot.group_1}-${shot.group_2}-${shot.group_3}-${shot.relation}`;

    const orderedPhases = getOrderedPhases(phaseComponents);

    return (
        <TableRow>
            {/* Thumbnail */}
            <TableCell>
                {thumbnails[thumbKey] ? (
                    <img
                        src={thumbnails[thumbKey]}
                        alt=""
                        style={{ width: 100, height: 'auto' }}
                    />
                ) : (
                    <span style={{ fontSize: 10, color: '#bdbdbd' }}>No Thumbnail</span>
                )}
            </TableCell>

            {/* Name columns */}
            <TableCell>{shot.group_1}</TableCell>
            <TableCell>{shot.group_2}</TableCell>
            <TableCell>{shot.group_3}</TableCell>

            {/* Phase columns (dynamic) */}
            {orderedPhases.map((phase, phaseIdx) => {
                const colors      = getPhaseColors(phase);
                const lineColor   = colors.lineColor;
                const borderLine  = `solid 3px ${lineColor}`;
                const bottomLine  = isLastRow ? borderLine : 'none';
                const isLastPhase = phaseIdx === orderedPhases.length - 1;

                const phaseData =
                    (shot.phases && shot.phases[phase]) ||
                    (shot.phases && shot.phases[phase.toLowerCase()]);

                const colBase      = phase.toLowerCase();
                const workCol      = `${colBase}_work_status`;
                const apprCol      = `${colBase}_approval_status`;
                const takeCol      = `${colBase}_take`;
                const submittedCol = `${colBase}_submitted_at`;

                const workStatus =
                    phaseData && phaseData.work_status && phaseData.work_status !== '-'
                        ? WORK_STATUS[phaseData.work_status]
                        : undefined;

                const approvalStatus =
                    phaseData && phaseData.approval_status && phaseData.approval_status !== '-'
                        ? APPROVAL_STATUS[phaseData.approval_status]
                        : undefined;

                const componentIds  = getPhaseComponentIds(phase, phaseComponents);
                const hasComponents = componentIds.length > 0;

                return (
                    <React.Fragment key={phase}>
                        {/* Work Status */}
                        {columnsState[workCol] !== false && (
                            <MultiLineTooltipTableCell
                                status={workStatus}
                                leftBorderStyle={borderLine}
                                rightBorderStyle={'none'}
                                bottomBorderStyle={bottomLine}
                            />
                        )}

                        {/* Approval Status */}
                        {columnsState[apprCol] !== false && (
                            <MultiLineTooltipTableCell
                                status={approvalStatus}
                                leftBorderStyle={'none'}
                                rightBorderStyle={'none'}
                                bottomBorderStyle={bottomLine}
                            />
                        )}

                        {/* Take */}
                        {columnsState[takeCol] !== false && (
                            <TableCell
                                style={{
                                    whiteSpace:   'nowrap',
                                    borderBottom: bottomLine,
                                }}
                            >
                                {(phaseData && phaseData.take) || '–'}
                            </TableCell>
                        )}

                        {/* Fallback Submitted At — only when phase has no pipeline components */}
                        {!hasComponents && columnsState[submittedCol] !== false && (
                            <TableCell
                                style={{
                                    whiteSpace:   'nowrap',
                                    borderBottom: bottomLine,
                                    borderRight:  isLastPhase ? borderLine : 'none',
                                }}
                            >
                                {phaseData && phaseData.submitted_at_utc
                                    ? dateTimeFormat.format(new Date(phaseData.submitted_at_utc))
                                    : '–'}
                            </TableCell>
                        )}

                        {/* Dynamic component columns from pipeline settings */}
                        {componentIds.map((componentId, compIdx) => {
                            if (columnsState[componentId] === false) return null;

                            const componentList =
                                (latestComponents && latestComponents[compKey]) || [];

                            const item =
                                componentList.find(
                                    (x: any) => x.component === componentId,
                                ) ||
                                componentList.find(
                                    (x: any) =>
                                        x.component &&
                                        x.component.toLowerCase() ===
                                            componentId.toLowerCase(),
                                );

                            const submittedAt =
                                item &&
                                item.latest_document &&
                                item.latest_document.submitted_at_utc;

                            const text = submittedAt
                                ? dateTimeFormat.format(new Date(submittedAt))
                                : '–';

                            const isLastComponentOfLastPhase =
                                isLastPhase && compIdx === componentIds.length - 1;

                            return (
                                <TableCell
                                    key={componentId}
                                    style={{
                                        whiteSpace:   'nowrap',
                                        borderBottom: bottomLine,
                                        borderRight:
                                            isLastComponentOfLastPhase ? borderLine : 'none',
                                    }}
                                >
                                    {text}
                                </TableCell>
                            );
                        })}
                    </React.Fragment>
                );
            })}

            {/* Relation */}
            {columnsState['relation'] !== false && (
                <TableCell>{shot.relation}</TableCell>
            )}
        </TableRow>
    );
};

/* ──────────────────────────────────────────────────────────────────────────
   Main Table
   ────────────────────────────────────────────────────────────────────────── */
const ShotsDataTable: React.FC<ShotsDataTableProps> = ({
    project,
    shots,
    tableFooter,
    dateTimeFormat,
    columnsState,
    sortKey,
    sortDir,
    onSortChange,
    phaseComponents,
}) => {
    if (project == null) return null;

    const shotsForThumbnail = shots.map(s => ({
        groups:   [s.group_1, s.group_2, s.group_3],
        relation: s.relation,
    }));

    const { thumbnails }       = useFetchShotThumbnails(project, shotsForThumbnail);
    const { latestComponents } = useFetchLatestShotComponents(
        project, shotsForThumbnail, phaseComponents,
    );

    const allColumns     = buildColumns(phaseComponents);
    const visibleColumns = allColumns.filter(col =>
        col.fixed || columnsState[col.id] !== false,
    );

    return (
        <Table stickyHeader style={{ tableLayout: 'fixed', width: 'auto' }}>
            <RecordTableHead
                columns={visibleColumns}
                phaseComponents={phaseComponents}
                latestComponents={latestComponents}
                columnsState={columnsState}
                sortKey={sortKey}
                sortDir={sortDir}
                onSortChange={onSortChange}
            />
            <TableBody>
                {shots.map((shot, index) => (
                    <ShotRow
                        key={`${shot.group_1}-${shot.group_2}-${shot.group_3}-${shot.relation}-${index}`}
                        shot={shot}
                        thumbnails={thumbnails}
                        dateTimeFormat={dateTimeFormat}
                        isLastRow={index === shots.length - 1}
                        columnsState={columnsState}
                        phaseComponents={phaseComponents}
                        latestComponents={latestComponents}
                    />
                ))}
            </TableBody>
            {tableFooter}
        </Table>
    );
};

export default ShotsDataTable;