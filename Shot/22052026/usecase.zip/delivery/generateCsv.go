package delivery

import (
	"encoding/csv"
	"fmt"
	"log"
	"net/http"
	"slices"
	"sort"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type GenerateCsv struct {
	uc *usecase.GenerateCsv
}

func NewGenerateCsv(uc *usecase.GenerateCsv) *GenerateCsv {
	return &GenerateCsv{
		uc: uc,
	}
}

func (gc *GenerateCsv) GenerateAssetsCsv(c *gin.Context) {
	params := &entity.GenerateTrackerCsvParams{
		Project: c.Param("project"),
	}

	rc := http.NewResponseController(c.Writer)
	if err := rc.SetWriteDeadline(time.Now().Add(gc.uc.ReadTimeout)); err != nil {
		log.Printf("ERROR: failed to set the deadline for the writing response: method=%s, url=%s, err=%s", c.Request.Method, c.Request.URL, err)
	}

	groupCategoryData, err := gc.uc.ListAssetsGroupCategory(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	AllBldReviewData, err := gc.uc.ListAllBldReviews(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	commentsData, err := gc.uc.ListComments(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	shotAssetsAllData, err := gc.uc.ListShotAssetsAll(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	bldDocumentData, err := gc.uc.ListBldAnmBldRendDocuments(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	publishOperationInfoData, err := gc.uc.ListPublishOperationInfos(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	latestReviewInfoData, err := gc.uc.ListLatestAssetsReviews(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	generateData := entity.GenerateAssetData{
		ReviewInfo:            latestReviewInfoData,
		GroupCategories:       groupCategoryData,
		LatestDocuments:       bldDocumentData,
		Comments:              commentsData,
		ShotAssetsAlls:        shotAssetsAllData,
		PublishOperationInfos: publishOperationInfoData,
		ComponentReviewInfos:  AllBldReviewData,
	}

	records := generateAssetRecords(&generateData)
	c.Writer.Header().Set("Content-Type", "text/csv")
	c.Writer.Header().Set("Content-Disposition", "attachment;filename=asset_data.csv")
	writer := csv.NewWriter(c.Writer)
	defer writer.Flush()
	if err := writer.WriteAll(records); err != nil {
		c.String(http.StatusInternalServerError, "Failed to generate CSV")
		return
	}
}

func toStrSlice(v interface{}) []string {
	if v == nil {
		return nil
	}
	switch val := v.(type) {
	case []string:
		return val
	case primitive.A: // MongoDBの配列型
		var res []string
		for _, item := range val {
			if s, ok := item.(string); ok {
				res = append(res, s)
			}
		}
		return res
	case []interface{}:
		var res []string
		for _, item := range val {
			if s, ok := item.(string); ok {
				res = append(res, s)
			}
		}
		return res
	}
	return nil
}

func toMapSlice(v interface{}) []map[string]interface{} {
	if v == nil {
		return nil
	}
	switch val := v.(type) {
	case []map[string]interface{}:
		return val
	case primitive.A:
		var res []map[string]interface{}
		for _, item := range val {
			if m, ok := item.(map[string]interface{}); ok {
				res = append(res, m)
			} else if m, ok := item.(primitive.M); ok {
				res = append(res, (map[string]interface{})(m))
			}
		}
		return res
	case []interface{}:
		var res []map[string]interface{}
		for _, item := range val {
			if m, ok := item.(map[string]interface{}); ok {
				res = append(res, m)
			}
		}
		return res
	}
	return nil
}

func toTimeStrFromInterface(v interface{}) string {
	if v == nil {
		return ""
	}
	switch val := v.(type) {
	case string:
		// 文字列の場合はそのまま返す（必要であればフォーマットチェックを入れる）
		return val
	case time.Time:
		return val.Format(time.RFC3339)
	case primitive.DateTime:
		return val.Time().Format(time.RFC3339)
	default:
		return ""
	}
}

func collectAssetRowData(gd *entity.GenerateAssetData) map[string]*entity.AssetRowData {
	var assetRowsData = make(map[string]*entity.AssetRowData)

	// ReviewInfo
	for _, ri := range gd.ReviewInfo {
		assetRelation := ri.Group1 + "/" + ri.Relation
		assetRowData, ok := assetRowsData[assetRelation]
		if !ok {
			assetRowData = &entity.AssetRowData{
				MdlData: &entity.PhaseRowData{},
				RigData: &entity.PhaseRowData{},
				LdvData: &entity.PhaseRowData{},
			}
			assetRowsData[assetRelation] = assetRowData
		}

		switch ri.Phase {
		case "mdl":
			assetRowData.MdlData.WorkStatus = ri.WorkStatus
			assetRowData.MdlData.ApprovalStatus = ri.ApprovalStatus
		case "rig":
			assetRowData.RigData.WorkStatus = ri.WorkStatus
			assetRowData.RigData.ApprovalStatus = ri.ApprovalStatus
		case "ldv":
			assetRowData.LdvData.WorkStatus = ri.WorkStatus
			assetRowData.LdvData.ApprovalStatus = ri.ApprovalStatus
		}
	}

	// GroupCategory
	for _, gc := range gd.GroupCategories {
		categoryParts := strings.Split(gc.CategoryPath, "/")
		if len(categoryParts) < 2 {
			continue
		}
		for key, assetRowData := range assetRowsData {
			keyParts := strings.Split(key, "/")
			if keyParts[0] == gc.GroupPath {
				assetRowData.AssetTypes = append(assetRowData.AssetTypes, categoryParts[0])
				assetRowData.AssetGroups = append(assetRowData.AssetGroups, categoryParts[1])
			}
		}
	}

	// bld Latest Publish Operation Info
	for _, ld := range gd.LatestDocuments {
		rawGroups, okGroups := (*ld)["groups"]
		relation, okRelation := (*ld)["relation"]
		submittedAtUtc, okSubmittedAtUtc := (*ld)["submitted_at_utc"]

		groups := toStrSlice(rawGroups)

		if !okGroups || !okRelation || !okSubmittedAtUtc || len(groups) == 0 {
			continue
		}
		assetRelation := groups[0] + "/" + relation.(string)
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]

		dateStr := toTimeStrFromInterface(submittedAtUtc)
		switch (*ld)["component"].(string) {
		case "bldAnm":
			if assetRowData.BldAnmReleaseDate != "" {
				continue
			}
			assetRowData.BldAnmReleaseDate = dateStr
		case "bldRend":
			if assetRowData.BldRendReleaseDate != "" {
				continue
			}
			assetRowData.BldRendReleaseDate = dateStr
		}
	}

	// Comment
	for _, comment := range gd.Comments {
		rawGroups, okGroups := (*comment)["groups"]
		relation, okRelation := (*comment)["relation"]
		rawCommentsData, okCommentsData := (*comment)["comment_data"]
		phase, okPhase := (*comment)["phase"]

		if !okGroups || !okRelation || !okCommentsData || !okPhase {
			continue
		}

		groups := toStrSlice(rawGroups)
		commentsData := toMapSlice(rawCommentsData)

		if len(groups) == 0 || len(commentsData) == 0 {
			continue
		}

		assetRelation := groups[0] + "/" + relation.(string)
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]

		for _, cd := range commentsData {
			language, okLanguage := cd["language"]
			role, okRole := cd["responsible_person_role"]
			text, okText := cd["text"]
			if !okLanguage || !okRole || !okText {
				continue
			}
			switch phase.(string) {
			case "mdl":
				assignCommentToPhaseRowData(assetRowData.MdlData, language, role, text)
			case "rig":
				assignCommentToPhaseRowData(assetRowData.RigData, language, role, text)
			case "ldv":
				assignCommentToPhaseRowData(assetRowData.LdvData, language, role, text)
			}
		}
	}

	// Shot AssetsAll
	for _, sa := range gd.ShotAssetsAlls {
		rawComponentInfos, okComponentInfos := (*sa)["component_info"]
		rawGroups, okGroups := (*sa)["groups"]

		groups := toStrSlice(rawGroups)
		componentInfos := toMapSlice(rawComponentInfos)

		if !okComponentInfos || !okGroups || len(groups) == 0 {
			continue
		}
		groupsPath := strings.Join(groups, "/")
		for _, componentInfo := range componentInfos {
			rawSceneAssets, okSceneAssets := componentInfo["scene_assets"]
			if !okSceneAssets {
				continue
			}

			sceneAssets := toMapSlice(rawSceneAssets)

			for _, sceneAsset := range sceneAssets {
				group, okGroup := sceneAsset["group"]
				relation, okRelation := sceneAsset["relation"]
				if !okGroup || !okRelation {
					continue
				}
				assetRelation := group.(string) + "/" + relation.(string)
				if _, ok := assetRowsData[assetRelation]; !ok {
					continue
				}
				assetRowData := assetRowsData[assetRelation]
				assetRowData.ShotAssetsAll = append(assetRowData.ShotAssetsAll, groupsPath)
			}
		}
	}

	// PublishOperationInfo
	for _, poi := range gd.PublishOperationInfos {
		phase, okPhase := (*poi)["phase"]
		revision, okRevision := (*poi)["revision"]
		submittedUser, okSubmittedUser := (*poi)["submitted_user"]
		submittedAtUtc, okSubmittedAtUtc := (*poi)["submitted_at_utc"]
		rawGroups, okGroups := (*poi)["groups"]
		relation, okRelation := (*poi)["relation"]

		if !okPhase || !okRevision || !okSubmittedUser || !okSubmittedAtUtc || !okGroups || !okRelation {
			continue
		}

		groups := toStrSlice(rawGroups)

		if len(groups) == 0 {
			continue
		}

		assetRelation := groups[0] + "/" + relation.(string)
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]
		dateStr := toTimeStrFromInterface(submittedAtUtc)
		switch phase.(string) {
		case "mdl":
			assetRowData.MdlData.Versions = append(assetRowData.MdlData.Versions, revision.(string))
			assetRowData.MdlData.LatestPublisher = submittedUser.(string)
			assetRowData.MdlData.LatestPublishAt = dateStr
		case "rig":
			assetRowData.RigData.Versions = append(assetRowData.RigData.Versions, revision.(string))
			assetRowData.RigData.LatestPublisher = submittedUser.(string)
			assetRowData.RigData.LatestPublishAt = dateStr
		case "ldv":
			assetRowData.LdvData.Versions = append(assetRowData.LdvData.Versions, revision.(string))
			assetRowData.LdvData.LatestPublisher = submittedUser.(string)
			assetRowData.LdvData.LatestPublishAt = dateStr
		}
	}

	// bldAnm, bldRend Status
	for i := len(gd.ComponentReviewInfos) - 1; i >= 0; i-- {
		bri := gd.ComponentReviewInfos[i]
		assetRelation := bri.Group1 + "/" + bri.Relation
		if _, ok := assetRowsData[assetRelation]; !ok {
			continue
		}
		assetRowData := assetRowsData[assetRelation]

		if slices.Contains(bri.TargetComponents, "bldAnm") {
			if assetRowData.BldAnmStatus != "" {
				continue
			}
			assetRowData.BldAnmStatus = bri.ApprovalStatus
		}
		if slices.Contains(bri.TargetComponents, "bldRend") {
			if assetRowData.BldRendStatus != "" {
				continue
			}
			assetRowData.BldRendStatus = bri.ApprovalStatus
		}
	}

	return assetRowsData
}

func generateAssetRow(assetRelation string, gd *entity.AssetRowData) []string {
	// Build Row
	row := []string{}
	// New, Episode, Thumbnail
	row = append(row, "", "", "")
	// Asset Type, Asset Group, Asset Name
	sort.Strings(gd.AssetTypes)
	sort.Strings(gd.AssetGroups)
	row = append(row, strings.Join(gd.AssetTypes, "\n"), strings.Join(gd.AssetGroups, "\n"), assetRelation)
	// Tags, Parent Asset, Description, Asset Info Jp, Asset Info En, Dir Notes Jp, Dir Notes En, CGSV Notes Jp, CGSV Notes En
	row = append(row, "", "", "", "", "", "", "", "", "")
	// shots <-> Assets All
	sort.Strings(gd.ShotAssetsAll)
	row = append(row, strings.Join(gd.ShotAssetsAll, "\n"))
	// row = append(row, "")
	// Model Status, Model Work Status, Model submitted at, Model Published artist, Model Pipeline Step, Model Task Name, Model Versions
	sort.Strings(gd.MdlData.Versions)
	row = append(row, gd.MdlData.ApprovalStatus, gd.MdlData.WorkStatus, gd.MdlData.LatestPublishAt, gd.MdlData.LatestPublisher, "mdl", "mdl", strings.Join(gd.MdlData.Versions, "\n"))
	// Model latest_comment_artist_ja, Model latest_comment_artist_en, Model latest_comment_supervisor_ja, Model latest_comment_supervisor_en, Model latest_comment_director_ja, Model latest_comment_director_en, Model latest_comment_client_ja, Model latest_comment_client_en
	row = append(row, gd.MdlData.LatestArtistCommentJa, gd.MdlData.LatestArtistCommentEn, gd.MdlData.LatestSupervisorCommentJa, gd.MdlData.LatestSupervisorCommentEn,
		gd.MdlData.LatestDirectorCommentJa, gd.MdlData.LatestDirectorCommentEn, gd.MdlData.LatestClientCommentJa, gd.MdlData.LatestClientCommentEn)
	// Model Note, Model Start Date, Model T1 Due Date, Model Due Date, Model Description, Model Bid, Model Assigned Studio, Model Assigned To
	row = append(row, "", "", "", "", "", "", "", "")
	// to Rig Jp, to Rig En, Elements Sim
	row = append(row, "", "", "")
	// Rig Status, Rig Work Status, Rig submitted at, Rig Published artist, Rig Pipeline Step, Rig Task Name, Rig Versions
	sort.Strings(gd.RigData.Versions)
	row = append(row, gd.RigData.ApprovalStatus, gd.RigData.WorkStatus, gd.RigData.LatestPublishAt, gd.RigData.LatestPublisher, "rig", "rig", strings.Join(gd.RigData.Versions, "\n"))
	// Rig latest_comment_artist_ja, Rig latest_comment_artist_en, Rig latest_comment_supervisor_ja, Rig latest_comment_supervisor_en, Rig latest_comment_director_ja, Rig latest_comment_director_en, Rig latest_comment_client_ja, Rig latest_comment_client_en
	row = append(row, gd.RigData.LatestArtistCommentJa, gd.RigData.LatestArtistCommentEn, gd.RigData.LatestSupervisorCommentJa, gd.RigData.LatestSupervisorCommentEn,
		gd.RigData.LatestDirectorCommentJa, gd.RigData.LatestDirectorCommentEn, gd.RigData.LatestClientCommentJa, gd.RigData.LatestClientCommentEn)
	// Rig Note, Rig Start Date, Rig T1 Due Date, Rig Due Date, Rig Description, Rig Bid, Rig Assigned Studio, Rig Assigned To
	row = append(row, "", "", "", "", "", "", "", "")
	// to LookDev Jp, to LookDev En
	row = append(row, "", "")
	// LookDev Status, LookDev Work Status, LookDev submitted at, LookDev Published artist, LookDev Pipeline Step, LookDev Task Name, LookDev Versions
	sort.Strings(gd.LdvData.Versions)
	row = append(row, gd.LdvData.ApprovalStatus, gd.LdvData.WorkStatus, gd.LdvData.LatestPublishAt, gd.LdvData.LatestPublisher, "ldv", "ldv", strings.Join(gd.LdvData.Versions, "\n"))
	// LookDev latest_comment_artist_ja, LookDev latest_comment_artist_en, LookDev latest_comment_supervisor_ja, LookDev latest_comment_supervisor_en, LookDev latest_comment_director_ja, LookDev latest_comment_director_en, LookDev latest_comment_client_ja, LookDev latest_comment_client_en
	row = append(row, gd.LdvData.LatestArtistCommentJa, gd.LdvData.LatestArtistCommentEn, gd.LdvData.LatestSupervisorCommentJa, gd.LdvData.LatestSupervisorCommentEn,
		gd.LdvData.LatestDirectorCommentJa, gd.LdvData.LatestDirectorCommentEn, gd.LdvData.LatestClientCommentJa, gd.LdvData.LatestClientCommentEn)
	// to Composite Jp, to Composite En
	row = append(row, "", "")
	// buildAnim Status, buildAnim Release Date
	row = append(row, gd.BldAnmStatus, gd.BldAnmReleaseDate)
	// buildRend Status, buildRend Release Date
	row = append(row, gd.BldRendStatus, gd.BldRendReleaseDate)

	return row
}

func generateAssetRecords(gds *entity.GenerateAssetData) [][]string {
	records := [][]string{}

	// Header
	header := []string{
		"New", "Episode", "Thumbnail",
		"Asset Type", "Asset Group", "Asset Name",
		"Tags", "Parent Asset", "Description", "Asset Info Jp", "Asset Info En", "Dir Notes Jp", "Dir Notes En", "CGSV Notes Jp", "CGSV Notes En",
		"shots <-> Assets All",
		"Model Status", "Model Work Status", "Model submitted at", "Model Published artist", "Model Pipeline Step", "Model Task Name", "Model Versions",
		"Model latest_comment_artist_ja", "Model latest_comment_artist_en", "Model latest_comment_supervisor_ja", "Model latest_comment_supervisor_en", "Model latest_comment_director_ja", "Model latest_comment_director_en", "Model latest_comment_client_ja", "Model latest_comment_client_en",
		"Model Note", "Model Start Date", "Model T1 Due Date", "Model Due Date", "Model Description", "Model Bid", "Model Assigned Studio", "Model Assigned To",
		"to Rig Jp", "to Rig En", "Elements Sim",
		"Rig Status", "Rig Work Status", "Rig submitted at", "Rig Published artist", "Rig Pipeline Step", "Rig Task Name", "Rig Versions",
		"Rig latest_comment_artist_ja", "Rig latest_comment_artist_en", "Rig latest_comment_supervisor_ja", "Rig latest_comment_supervisor_en", "Rig latest_comment_director_ja", "Rig latest_comment_director_en", "Rig latest_comment_client_ja", "Rig latest_comment_client_en",
		"Rig Note", "Rig Start Date", "Rig T1 Due Date", "Rig Due Date", "Rig Description", "Rig Bid", "Rig Assigned Studio", "Rig Assigned To",
		"to LookDev Jp", "to LookDev En",
		"LookDev Status", "LookDev Work Status", "LookDev submitted at", "LookDev Published artist", "LookDev Pipeline Step", "LookDev Task Name", "LookDev Versions",
		"LookDev latest_comment_artist_ja", "LookDev latest_comment_artist_en", "LookDev latest_comment_supervisor_ja", "LookDev latest_comment_supervisor_en", "LookDev latest_comment_director_ja", "LookDev latest_comment_director_en", "LookDev latest_comment_client_ja", "LookDev latest_comment_client_en",
		"LookDev Note", "LookDev Start Date", "LookDev T1 Due Date", "LookDev Due Date", "LookDev Description", "LookDev Bid", "LookDev Assigned Studio", "LookDev Assigned To",
		"to Composite Jp", "to Composite En",
		"buildAnim Status", "buildAnim Release Date",
		"buildRend Status", "buildRend Release Date",
	}
	records = append(records, header)

	// Data Rows
	rowsData := collectAssetRowData(gds)
	assetRelations := make([]string, 0, len(rowsData))
	for k := range rowsData {
		assetRelations = append(assetRelations, k)
	}
	sort.Strings(assetRelations)
	for _, assetRelation := range assetRelations {
		row := generateAssetRow(assetRelation, rowsData[assetRelation])
		records = append(records, row)
	}

	return records
}

func (gc *GenerateCsv) GenerateShotsCsv(c *gin.Context) {
	params := &entity.GenerateTrackerCsvParams{
		Project: c.Param("project"),
	}

	rc := http.NewResponseController(c.Writer)
	if err := rc.SetWriteDeadline(time.Now().Add(gc.uc.ReadTimeout)); err != nil {
		log.Printf("ERROR: failed to set the deadline for the writing response: method=%s, url=%s, err=%s", c.Request.Method, c.Request.URL, err)
	}

	commentsData, err := gc.uc.ListShotComments(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}

	publishOperationInfos, err := gc.uc.ListShotPublishOperationInfos(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}

	latestReviewInfos, err := gc.uc.ListLatestShotReviews(c.Request.Context(), params.Project)
	if err != nil {
		badRequest(c, err)
		return
	}
	generateData := entity.GenerateShotData{
		ReviewInfo:            latestReviewInfos,
		Comments:              commentsData,
		PublishOperationInfos: publishOperationInfos,
	}

	records := generateShotRecords(params.Project, &generateData)
	c.Writer.Header().Set("Content-Type", "text/csv")
	c.Writer.Header().Set("Content-Disposition", "attachment;filename=shot_data.csv")
	writer := csv.NewWriter(c.Writer)
	defer writer.Flush()
	for _, record := range records {
		if err := writer.Write(record); err != nil {
			log.Printf("ERROR: failed to write CSV record: %v", err)
		}
	}
}

func generateShotRow(project string, srd *entity.ShotRowData) []string {
	// Build Row
	row := []string{}
	// "Project", "Thumbnail", "Episodes", "Sequence", "Shot Name",
	row = append(row, project, "", srd.Episode, srd.Sequence, srd.ShotName)
	// "Cut Duration", "Original Duration", "Status", "DSP finish", "Master Comp Shot", "BJT board",
	row = append(row, srd.CutDuration, "", "", "", "", "")
	// "Version <-> Link", "Dialogue", "Description", "Description En", "Cam Same Position shot", "CamSamePosition",
	sort.Strings(srd.VersionLinks)
	row = append(row, strings.Join(srd.VersionLinks, "\n"), "", "", "", "", "")
	// "Cam Data Type", "BG Type", "Cam Work", "General Location", "Time Of Day", "SkyType",
	row = append(row, srd.CamDataType, "", "", "", "", "")
	// "Direction Notes Jp", "Direction Notes En", "CGSV Notes Jp", "CGSV Notes En",
	row = append(row, "", "", "", "")
	// "Assets All", "Assets Charas", "Assets Props Vehicles etc", "Assets Sets", "Assets FX", "cloth_clothAbc", "cfxCloth_cfxClothAbc",
	sort.Strings(srd.AssetsAll)
	row = append(row, strings.Join(srd.AssetsAll, "\n"), "", "", "", "", "", "")
	// "Bank Reuse", "publishInfo > Status",
	row = append(row, "", "")
	// "layout Status", "layout Work Status", "layout Pipeline Step", "layout Task Name", "layout submitted at", "layout published artist", "layout Versions",
	sort.Strings(srd.LayData.Versions)
	layVers := strings.Join(srd.LayData.Versions, "\n")
	row = append(row, srd.LayData.ApprovalStatus, srd.LayData.WorkStatus, "lay", "lay", srd.LayData.LatestPublishAt, srd.LayData.LatestPublisher, layVers)
	// "layout latest_comment_artist_ja", "layout latest_comment_artist_en", "layout latest_comment_supervisor_ja", "layout latest_comment_supervisor_en",
	row = append(row, srd.LayData.LatestArtistCommentJa, srd.LayData.LatestArtistCommentEn, srd.LayData.LatestSupervisorCommentJa, srd.LayData.LatestSupervisorCommentEn)
	// "layout latest_comment_director_ja", "layout latest_comment_director_en", "layout latest_comment_client_ja", "layout latest_comment_client_en",
	row = append(row, srd.LayData.LatestDirectorCommentJa, srd.LayData.LatestDirectorCommentEn, srd.LayData.LatestClientCommentJa, srd.LayData.LatestClientCommentEn)
	// "layout Start Date", "layout T1 Due Date", "layout Due Date", "layout Duration", "layout Bid", "layout Assigned Studio", "layout Assigned To",
	row = append(row, "", "", "", "", "", "", "")
	// "animation Status", "animation Work Status", "animation Pipeline Step", "animation Task Name", "animation submitted at", "animation published artist", "animation Versions",
	sort.Strings(srd.AnmData.Versions)
	anmVers := strings.Join(srd.AnmData.Versions, "\n")
	row = append(row, srd.AnmData.ApprovalStatus, srd.AnmData.WorkStatus, "anm", "anm", srd.AnmData.LatestPublishAt, srd.AnmData.LatestPublisher, anmVers)
	// "animation latest_comment_artist_ja", "animation latest_comment_artist_en", "animation latest_comment_supervisor_ja", "animation latest_comment_supervisor_en",
	row = append(row, srd.AnmData.LatestArtistCommentJa, srd.AnmData.LatestArtistCommentEn, srd.AnmData.LatestSupervisorCommentJa, srd.AnmData.LatestSupervisorCommentEn)
	// "animation latest_comment_director_ja", "animation latest_comment_director_en", "animation latest_comment_client_ja", "animation latest_comment_client_en",
	row = append(row, srd.AnmData.LatestDirectorCommentJa, srd.AnmData.LatestDirectorCommentEn, srd.AnmData.LatestClientCommentJa, srd.AnmData.LatestClientCommentEn)
	// "animation Start Date", "animation T1 Due Date", "animation Due Date", "animation Duration", "animation Bid", "animation Assigned Studio", "animation Assigned To",
	row = append(row, "", "", "", "", "", "", "")
	// "genzu Status", "genzu Work Status", "genzu Pipeline Step", "genzu Task Name", "genzu submitted at", "genzu published artist", "genzu Versions",
	sort.Strings(srd.GnzData.Versions)
	genzuVers := strings.Join(srd.GnzData.Versions, "\n")
	row = append(row, srd.GnzData.ApprovalStatus, srd.GnzData.WorkStatus, "gnz", "gnz", srd.GnzData.LatestPublishAt, srd.GnzData.LatestPublisher, genzuVers)
	// "genzu latest_comment_artist_ja", "genzu latest_comment_artist_en", "genzu latest_comment_supervisor_ja", "genzu latest_comment_supervisor_en",
	row = append(row, srd.GnzData.LatestArtistCommentJa, srd.GnzData.LatestArtistCommentEn, srd.GnzData.LatestSupervisorCommentJa, srd.GnzData.LatestSupervisorCommentEn)
	// "genzu latest_comment_director_ja", "genzu latest_comment_director_en", "genzu latest_comment_client_ja", "genzu latest_comment_client_en",
	row = append(row, srd.GnzData.LatestDirectorCommentJa, srd.GnzData.LatestDirectorCommentEn, srd.GnzData.LatestClientCommentJa, srd.GnzData.LatestClientCommentEn)
	// "genzu Start Date", "genzu T1 Due Date", "genzu Due Date", "genzu Duration", "genzu Bid", "genzu Assigned Studio", "genzu Assigned To",
	row = append(row, "", "", "", "", "", "", "")
	// "fx Status", "fx Work Status", "fx Pipeline Step", "fx Task Name", "fx submitted at", "fx published artist", "fx Versions",
	sort.Strings(srd.FxData.Versions)
	fxVers := strings.Join(srd.FxData.Versions, "\n")
	row = append(row, srd.FxData.ApprovalStatus, srd.FxData.WorkStatus, "fx", "fx", srd.FxData.LatestPublishAt, srd.FxData.LatestPublisher, fxVers)
	// "fx latest_comment_artist_ja", "fx latest_comment_artist_en", "fx latest_comment_supervisor_ja", "fx latest_comment_supervisor_en",
	row = append(row, srd.FxData.LatestArtistCommentJa, srd.FxData.LatestArtistCommentEn, srd.FxData.LatestSupervisorCommentJa, srd.FxData.LatestSupervisorCommentEn)
	// "fx latest_comment_director_ja", "fx latest_comment_director_en", "fx latest_comment_client_ja", "fx latest_comment_client_en",
	row = append(row, srd.FxData.LatestDirectorCommentJa, srd.FxData.LatestDirectorCommentEn, srd.FxData.LatestClientCommentJa, srd.FxData.LatestClientCommentEn)
	// "fx Start Date", "fx T1 Due Date", "fx Due Date", "fx Duration", "fx Bid", "fx Assigned Studio", "fx Assigned To",
	row = append(row, "", "", "", "", "", "", "")
	// "display Status", "display Work Status", "display Pipeline Step", "display Task Name", "display submitted at", "display published artist", "display Versions",
	sort.Strings(srd.DspData.Versions)
	dspVers := strings.Join(srd.DspData.Versions, "\n")
	row = append(row, srd.DspData.ApprovalStatus, srd.DspData.WorkStatus, "dsp", "dsp", srd.DspData.LatestPublishAt, srd.DspData.LatestPublisher, dspVers)
	// "display latest_comment_artist_ja", "display latest_comment_artist_en", "display latest_comment_supervisor_ja", "display latest_comment_supervisor_en",
	row = append(row, srd.DspData.LatestArtistCommentJa, srd.DspData.LatestArtistCommentEn, srd.DspData.LatestSupervisorCommentJa, srd.DspData.LatestSupervisorCommentEn)
	// "display latest_comment_director_ja", "display latest_comment_director_en", "display latest_comment_client_ja", "display latest_comment_client_en",
	row = append(row, srd.DspData.LatestDirectorCommentJa, srd.DspData.LatestDirectorCommentEn, srd.DspData.LatestClientCommentJa, srd.DspData.LatestClientCommentEn)
	// "display Start Date", "display T1 Due Date", "display Due Date", "display Duration", "display Bid", "display Assigned Studio", "display Assigned To",
	row = append(row, "", "", "", "", "", "", "")
	// "compositing Status", "compositing Work Status", "compositing Pipeline Step", "compositing Task Name", "compositing submitted at", "compositing published artist", "compositing Versions",
	sort.Strings(srd.CmpData.Versions)
	cmpVers := strings.Join(srd.CmpData.Versions, "\n")
	row = append(row, srd.CmpData.ApprovalStatus, srd.CmpData.WorkStatus, "cmp", "cmp", srd.CmpData.LatestPublishAt, srd.CmpData.LatestPublisher, cmpVers)
	// "compositing latest_comment_artist_ja", "compositing latest_comment_artist_en", "compositing latest_comment_supervisor_ja", "compositing latest_comment_supervisor_en",
	row = append(row, srd.CmpData.LatestArtistCommentJa, srd.CmpData.LatestArtistCommentEn, srd.CmpData.LatestSupervisorCommentJa, srd.CmpData.LatestSupervisorCommentEn)
	// "compositing latest_comment_director_ja", "compositing latest_comment_director_en", "compositing latest_comment_client_ja", "compositing latest_comment_client_en",
	row = append(row, srd.CmpData.LatestDirectorCommentJa, srd.CmpData.LatestDirectorCommentEn, srd.CmpData.LatestClientCommentJa, srd.CmpData.LatestClientCommentEn)
	// "compositing Start Date", "compositing T1 Due Date", "compositing Due Date", "compositing Duration", "compositing Bid", "compositing Assigned Studio", "compositing Assigned To",
	row = append(row, "", "", "", "", "", "", "")
	// "matteNuke Status", "matte Status", "cfxCloth Status", "cfxHair Status", "retouch Status", "drawing Status", "colorPalette Status",
	row = append(row, srd.MatNukeData.ApprovalStatus, srd.MatData.ApprovalStatus, srd.CfxClothData.ApprovalStatus, srd.CfxHairData.ApprovalStatus, srd.RtcData.ApprovalStatus, srd.DrwData.ApprovalStatus, srd.ClpData.ApprovalStatus)
	// "Elements FX", "Elements cFX", "Element Crowd", "Elements Retouch", "Elements Drawing", "Elements Display",
	row = append(row, "", "", "", "", "", "", "")
	// "toLayout Jp", "toLayout En", "Layout Note Jp", "Layout Note En",
	row = append(row, "", "", "", "")
	// "toAnimation Jp", "toAnimation En", "Animation Note Jp", "Animation Note En",
	row = append(row, "", "", "", "")
	// "toGenzu Jp", "toGenzu En", "Genzu Note Jp", "Genzu Note En",
	row = append(row, "", "", "", "")
	// "toMatte Jp", "toMatte En", "Matte Note Jp", "Matte Note En",
	row = append(row, "", "", "", "")
	// "toFX Jp", "toFX En", "FX Note Jp", "FX Note En",
	row = append(row, "", "", "", "")
	// "toRetouch En", "toRetouch Jp", "toDrawing Jp", "toDrawing En",
	row = append(row, "", "", "", "")
	// "toDisplay Jp", "toDisplay En", "Display Note Jp", "Display Note En",
	row = append(row, "", "", "", "")
	// "toComposite Jp","toComposite En", "Composite Note Jp", "Composite Note En",
	row = append(row, "", "", "", "")
	// "toEdit Jp", "toEdit En", "Edit Note Jp", "Edit Note En",
	row = append(row, "", "", "", "")
	// "Color Palatte", "Color Palatte Notes JP", "Color Palatte Notes En",
	row = append(row, "", "", "")

	return row
}

func generateShotRecords(project string, gds *entity.GenerateShotData) [][]string {
	records := [][]string{}

	// Header
	header := []string{
		"Project", "Thumbnail", "Episodes", "Sequence", "Shot Name",
		"Cut Duration", "Original Duration", "Status", "DSP finish", "Master Comp Shot", "BJT board",
		"Version <-> Link", "Dialogue", "Description", "Description En", "Cam Same Position shot", "CamSamePosition",
		"Cam Data Type", "BG Type", "Cam Work", "General Location", "Time Of Day", "SkyType",
		"Direction Notes Jp", "Direction Notes En", "CGSV Notes Jp", "CGSV Notes En",
		"Assets All", "Assets Charas", "Assets Props Vehicles etc", "Assets Sets", "Assets FX", "cloth_clothAbc", "cfxCloth_cfxClothAbc",
		"Bank Reuse", "publishInfo > Status",
		"layout Status", "layout Work Status", "layout Pipeline Step", "layout Task Name", "layout submitted at", "layout published artist", "layout Versions",
		"layout latest_comment_artist_ja", "layout latest_comment_artist_en", "layout latest_comment_supervisor_ja", "layout latest_comment_supervisor_en",
		"layout latest_comment_director_ja", "layout latest_comment_director_en", "layout latest_comment_client_ja", "layout latest_comment_client_en",
		"layout Start Date", "layout T1 Due Date", "layout Due Date", "layout Duration", "layout Bid", "layout Assigned Studio", "layout Assigned To",
		"animation Status", "animation Work Status", "animation Pipeline Step", "animation Task Name", "animation submitted at", "animation published artist", "animation Versions",
		"animation latest_comment_artist_ja", "animation latest_comment_artist_en", "animation latest_comment_supervisor_ja", "animation latest_comment_supervisor_en",
		"animation latest_comment_director_ja", "animation latest_comment_director_en", "animation latest_comment_client_ja", "animation latest_comment_client_en",
		"animation Start Date", "animation T1 Due Date", "animation Due Date", "animation Duration", "animation Bid", "animation Assigned Studio", "animation Assigned To",
		"genzu Status", "genzu Work Status", "genzu Pipeline Step", "genzu Task Name", "genzu submitted at", "genzu published artist", "genzu Versions",
		"genzu latest_comment_artist_ja", "genzu latest_comment_artist_en", "genzu latest_comment_supervisor_ja", "genzu latest_comment_supervisor_en",
		"genzu latest_comment_director_ja", "genzu latest_comment_director_en", "genzu latest_comment_client_ja", "genzu latest_comment_client_en",
		"genzu Start Date", "genzu T1 Due Date", "genzu Due Date", "genzu Duration", "genzu Bid", "genzu Assigned Studio", "genzu Assigned To",
		"fx Status", "fx Work Status", "fx Pipeline Step", "fx Task Name", "fx submitted at", "fx published artist", "fx Versions",
		"fx latest_comment_artist_ja", "fx latest_comment_artist_en", "fx latest_comment_supervisor_ja", "fx latest_comment_supervisor_en",
		"fx latest_comment_director_ja", "fx latest_comment_director_en", "fx latest_comment_client_ja", "fx latest_comment_client_en",
		"fx Start Date", "fx T1 Due Date", "fx Due Date", "fx Duration", "fx Bid", "fx Assigned Studio", "fx Assigned To",
		"display Status", "display Work Status", "display Pipeline Step", "display Task Name", "display submitted at", "display published artist", "display Versions",
		"display latest_comment_artist_ja", "display latest_comment_artist_en", "display latest_comment_supervisor_ja", "display latest_comment_supervisor_en",
		"display latest_comment_director_ja", "display latest_comment_director_en", "display latest_comment_client_ja", "display latest_comment_client_en",
		"display Start Date", "display T1 Due Date", "display Due Date", "display Duration", "display Bid", "display Assigned Studio", "display Assigned To",
		"compositing Status", "compositing Work Status", "compositing Pipeline Step", "compositing Task Name", "compositing submitted at", "compositing published artist", "compositing Versions",
		"compositing latest_comment_artist_ja", "compositing latest_comment_artist_en", "compositing latest_comment_supervisor_ja", "compositing latest_comment_supervisor_en",
		"compositing latest_comment_director_ja", "compositing latest_comment_director_en", "compositing latest_comment_client_ja", "compositing latest_comment_client_en",
		"compositing Start Date", "compositing T1 Due Date", "compositing Due Date", "compositing Duration", "compositing Bid", "compositing Assigned Studio", "compositing Assigned To",
		"matteNuke Status", "matte Status", "cfxCloth Status", "cfxHair Status", "retouch Status", "drawing Status", "colorPalette Status",
		"Elements FX", "Elements cFX", "Element Crowd", "Elements Retouch", "Elements Drawing", "Elements Display",
		"toLayout Jp", "toLayout En", "Layout Note Jp", "Layout Note En",
		"toAnimation Jp", "toAnimation En", "Animation Note Jp", "Animation Note En",
		"toGenzu Jp", "toGenzu En", "Genzu Note Jp", "Genzu Note En",
		"toMatte Jp", "toMatte En", "Matte Note Jp", "Matte Note En",
		"toFX Jp", "toFX En", "FX Note Jp", "FX Note En",
		"toRetouch En", "toRetouch Jp", "toDrawing Jp", "toDrawing En",
		"toDisplay Jp", "toDisplay En", "Display Note Jp", "Display Note En",
		"toComposite Jp", "toComposite En", "Composite Note Jp", "Composite Note En",
		"toEdit Jp", "toEdit En", "Edit Note Jp", "Edit Note En",
		"Color Palatte", "Color Palatte Notes JP", "Color Palatte Notes En",
	}
	records = append(records, header)

	// Data Rows
	rowsData := collectShotRowData(gds)
	shotPaths := make([]string, 0, len(rowsData))
	for k := range rowsData {
		shotPaths = append(shotPaths, k)
	}
	sort.Strings(shotPaths)
	for _, shotPath := range shotPaths {
		row := generateShotRow(project, rowsData[shotPath])
		records = append(records, row)
	}

	return records
}

func assignCommentToPhaseRowData(phaseRowData *entity.PhaseRowData, language interface{}, role interface{}, text interface{}) {
	switch language.(string) {
	case "ja":
		switch role.(string) {
		case "artist":
			if phaseRowData.LatestArtistCommentJa != "" {
				return
			}
			phaseRowData.LatestArtistCommentJa = text.(string)
		case "supervisor":
			if phaseRowData.LatestSupervisorCommentJa != "" {
				return
			}
			phaseRowData.LatestSupervisorCommentJa = text.(string)
		case "director":
			if phaseRowData.LatestDirectorCommentJa != "" {
				return
			}
			phaseRowData.LatestDirectorCommentJa = text.(string)
		case "client":
			if phaseRowData.LatestClientCommentJa != "" {
				return
			}
			phaseRowData.LatestClientCommentJa = text.(string)
		}
	case "en":
		switch role.(string) {
		case "artist":
			if phaseRowData.LatestArtistCommentEn != "" {
				return
			}
			phaseRowData.LatestArtistCommentEn = text.(string)
		case "supervisor":
			if phaseRowData.LatestSupervisorCommentEn != "" {
				return
			}
			phaseRowData.LatestSupervisorCommentEn = text.(string)
		case "director":
			if phaseRowData.LatestDirectorCommentEn != "" {
				return
			}
			phaseRowData.LatestDirectorCommentEn = text.(string)
		case "client":
			if phaseRowData.LatestClientCommentEn != "" {
				return
			}
			phaseRowData.LatestClientCommentEn = text.(string)
		}
	}
}

func sortDocsByObjectID(docs []*entity.DocumentInfo, desc bool) {
	sort.Slice(docs, func(i, j int) bool {
		if docs[i] == nil && docs[j] == nil {
			return false
		}
		if docs[i] == nil {
			return false
		}
		if docs[j] == nil {
			return true
		}

		idI, okI := (*docs[i])["_id"].(primitive.ObjectID)
		idJ, okJ := (*docs[j])["_id"].(primitive.ObjectID)

		if okI && okJ {
			if desc {
				// DESC
				return idI.Hex() > idJ.Hex()
			}
			// ASC
			return idI.Hex() < idJ.Hex()
		}

		if okI && !okJ {
			return true
		}
		if !okI && okJ {
			return false
		}
		return false
	})
}

func getNestedValue(m map[string]interface{}, keys ...string) interface{} {
	if len(keys) == 0 {
		return nil
	}

	var current interface{} = m
	for i, key := range keys {
		currentMap, ok := current.(map[string]interface{})
		if !ok {
			return nil
		}

		val, exists := currentMap[key]
		if !exists {
			return nil
		}

		current = val
		if i == len(keys)-1 {
			return current
		}
	}
	return nil
}

func collectShotRowData(gd *entity.GenerateShotData) map[string]*entity.ShotRowData {
	var shotRowsData = make(map[string]*entity.ShotRowData)

	// ReviewInfo
	for _, ri := range gd.ReviewInfo {
		shotPath := ri.Group1 + "/" + ri.Group2 + "/" + ri.Group3 + "/" + ri.Relation
		shotRowData, ok := shotRowsData[shotPath]
		if !ok {
			shotRowData = &entity.ShotRowData{
				Episode:      ri.Group1,
				Sequence:     ri.Group2,
				ShotName:     ri.Group3,
				LayData:      &entity.PhaseRowData{},
				AnmData:      &entity.PhaseRowData{},
				GnzData:      &entity.PhaseRowData{},
				FxData:       &entity.PhaseRowData{},
				DspData:      &entity.PhaseRowData{},
				CmpData:      &entity.PhaseRowData{},
				MatData:      &entity.PhaseRowData{},
				MatNukeData:  &entity.PhaseRowData{},
				CfxClothData: &entity.PhaseRowData{},
				CfxHairData:  &entity.PhaseRowData{},
				RtcData:      &entity.PhaseRowData{},
				DrwData:      &entity.PhaseRowData{},
				ClpData:      &entity.PhaseRowData{},
			}
			shotRowsData[shotPath] = shotRowData
		}

		switch ri.Phase {
		case "lay":
			shotRowData.LayData.WorkStatus = ri.WorkStatus
			shotRowData.LayData.ApprovalStatus = ri.ApprovalStatus
		case "anm":
			shotRowData.AnmData.WorkStatus = ri.WorkStatus
			shotRowData.AnmData.ApprovalStatus = ri.ApprovalStatus
		case "gnz":
			shotRowData.GnzData.WorkStatus = ri.WorkStatus
			shotRowData.GnzData.ApprovalStatus = ri.ApprovalStatus
		case "fx":
			shotRowData.FxData.WorkStatus = ri.WorkStatus
			shotRowData.FxData.ApprovalStatus = ri.ApprovalStatus
		case "dsp":
			shotRowData.DspData.WorkStatus = ri.WorkStatus
			shotRowData.DspData.ApprovalStatus = ri.ApprovalStatus
		case "cmp":
			shotRowData.CmpData.WorkStatus = ri.WorkStatus
			shotRowData.CmpData.ApprovalStatus = ri.ApprovalStatus
		case "mat":
			shotRowData.MatData.WorkStatus = ri.WorkStatus
			shotRowData.MatData.ApprovalStatus = ri.ApprovalStatus
		case "matNuke":
			shotRowData.MatNukeData.WorkStatus = ri.WorkStatus
			shotRowData.MatNukeData.ApprovalStatus = ri.ApprovalStatus
		case "cfxCloth":
			shotRowData.CfxClothData.WorkStatus = ri.WorkStatus
			shotRowData.CfxClothData.ApprovalStatus = ri.ApprovalStatus
		case "cfxHair":
			shotRowData.CfxHairData.WorkStatus = ri.WorkStatus
			shotRowData.CfxHairData.ApprovalStatus = ri.ApprovalStatus
		case "rtc":
			shotRowData.RtcData.WorkStatus = ri.WorkStatus
			shotRowData.RtcData.ApprovalStatus = ri.ApprovalStatus
		case "drw":
			shotRowData.DrwData.WorkStatus = ri.WorkStatus
			shotRowData.DrwData.ApprovalStatus = ri.ApprovalStatus
		case "clp":
			shotRowData.ClpData.WorkStatus = ri.WorkStatus
			shotRowData.ClpData.ApprovalStatus = ri.ApprovalStatus
		}
	}

	// Comment
	for _, comment := range gd.Comments {
		rawGroups, okGroups := (*comment)["groups"]
		relation, okRelation := (*comment)["relation"]
		rawCommentsData, okCommentsData := (*comment)["comment_data"]
		phase, okPhase := (*comment)["phase"]

		if !okGroups || !okRelation || !okCommentsData || !okPhase {
			continue
		}

		groups := toStrSlice(rawGroups)
		commentsData := toMapSlice(rawCommentsData)

		if len(groups) == 0 || len(groups) < 3 || len(commentsData) == 0 {
			continue
		}

		shotPath := groups[0] + "/" + groups[1] + "/" + groups[2] + "/" + relation.(string)
		if _, ok := shotRowsData[shotPath]; !ok {
			continue
		}
		shotRowData := shotRowsData[shotPath]

		for _, cd := range commentsData {
			language, okLanguage := cd["language"]
			role, okRole := cd["responsible_person_role"]
			text, okText := cd["text"]
			if !okLanguage || !okRole || !okText {
				continue
			}
			switch phase.(string) {
			case "lay":
				assignCommentToPhaseRowData(shotRowData.LayData, language, role, text)
			case "anm":
				assignCommentToPhaseRowData(shotRowData.AnmData, language, role, text)
			case "gnz":
				assignCommentToPhaseRowData(shotRowData.GnzData, language, role, text)
			case "fx":
				assignCommentToPhaseRowData(shotRowData.FxData, language, role, text)
			case "dsp":
				assignCommentToPhaseRowData(shotRowData.DspData, language, role, text)
			case "cmp":
				assignCommentToPhaseRowData(shotRowData.CmpData, language, role, text)
			}
		}
	}

	// PublishOperationInfo
	for _, poi := range gd.PublishOperationInfos {
		phase, okPhase := (*poi)["phase"]
		revision, okRevision := (*poi)["revision"]
		submittedUser, okSubmittedUser := (*poi)["submitted_user"]
		submittedAtUtc, okSubmittedAtUtc := (*poi)["submitted_at_utc"]
		rawGroups, okGroups := (*poi)["groups"]
		relation, okRelation := (*poi)["relation"]

		if !okPhase || !okRevision || !okSubmittedUser || !okSubmittedAtUtc || !okGroups || !okRelation {
			continue
		}

		groups := toStrSlice(rawGroups)

		if len(groups) == 0 || len(groups) < 3 {
			continue
		}

		shotPath := groups[0] + "/" + groups[1] + "/" + groups[2] + "/" + relation.(string)
		if _, ok := shotRowsData[shotPath]; !ok {
			continue
		}
		shotRowData := shotRowsData[shotPath]
		dateStr := toTimeStrFromInterface(submittedAtUtc)
		switch phase.(string) {
		case "lay":
			shotRowData.LayData.Versions = append(shotRowData.LayData.Versions, revision.(string))
			shotRowData.LayData.LatestPublisher = submittedUser.(string)
			shotRowData.LayData.LatestPublishAt = dateStr
		case "anm":
			shotRowData.AnmData.Versions = append(shotRowData.AnmData.Versions, revision.(string))
			shotRowData.AnmData.LatestPublisher = submittedUser.(string)
			shotRowData.AnmData.LatestPublishAt = dateStr
		case "gnz":
			shotRowData.GnzData.Versions = append(shotRowData.GnzData.Versions, revision.(string))
			shotRowData.GnzData.LatestPublisher = submittedUser.(string)
			shotRowData.GnzData.LatestPublishAt = dateStr
		case "fx":
			shotRowData.FxData.Versions = append(shotRowData.FxData.Versions, revision.(string))
			shotRowData.FxData.LatestPublisher = submittedUser.(string)
			shotRowData.FxData.LatestPublishAt = dateStr
		case "dsp":
			shotRowData.DspData.Versions = append(shotRowData.DspData.Versions, revision.(string))
			shotRowData.DspData.LatestPublisher = submittedUser.(string)
			shotRowData.DspData.LatestPublishAt = dateStr
		case "cmp":
			shotRowData.CmpData.Versions = append(shotRowData.CmpData.Versions, revision.(string))
			shotRowData.CmpData.LatestPublisher = submittedUser.(string)
			shotRowData.CmpData.LatestPublishAt = dateStr
		}

		// Cut Duration
		lastFrame := getNestedValue(*poi, "component_info", "timerange", "last_frame")
		firstFrame := getNestedValue(*poi, "component_info", "timerange", "first_frame")
		if lastFrame != nil && firstFrame != nil {
			shotRowData.CutDuration = fmt.Sprintf("%d", int(lastFrame.(float64)-firstFrame.(float64)+1))
		}

		// CamDataType
		camDataType := getNestedValue(*poi, "component_info", "cam_data_type")
		if camDataType != nil {
			shotRowData.CamDataType = camDataType.(string)
		}

		// Assets All
		assetsAll := getNestedValue(*poi, "component_info", "scene_assets")
		if assetsAll != nil {
			switch assetsAll.(type) {
			case []interface{}:
				for _, asset := range assetsAll.([]interface{}) {
					group := getNestedValue(asset.(map[string]interface{}), "group")
					if group != nil {
						shotRowData.AssetsAll = append(shotRowData.AssetsAll, group.(string))
					}
				}
			}
		}

		// Version - Link
		dotIndex := strings.LastIndex(revision.(string), ".")
		if dotIndex != -1 {
			version := revision.(string)[dotIndex+1:]
			versionLink := groups[0] + "_" + groups[1] + "_" + groups[2] + "_" + phase.(string) + "_" + version
			if slices.Contains(shotRowData.VersionLinks, versionLink) {
				continue
			}
			shotRowData.VersionLinks = append(shotRowData.VersionLinks, versionLink)
		}
	}
	return shotRowsData
}
