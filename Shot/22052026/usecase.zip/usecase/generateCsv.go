package usecase

import (
	"context"
	"fmt"
	"time"

	"github.com/PolygonPictures/central30-web/front/database"
	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/libs"
	"github.com/PolygonPictures/central30-web/front/repository"
	"go.mongodb.org/mongo-driver/bson"
)

type GenerateCsv struct {
	repo                 *repository.GenerateCsv
	reviewInfoRepo       *repository.ReviewInfo
	groupCategoryRepo    *repository.GroupCategory
	pubOperationInfoRepo *repository.PublishOperationInfo
	mongoRepo            entity.DocumentRepository
	ReadTimeout          time.Duration
}

func NewGenerateCsv(
	repo *repository.GenerateCsv,
	reviewInfoRepo *repository.ReviewInfo,
	groupCategoryRepo *repository.GroupCategory,
	pubOperationInfoRepo *repository.PublishOperationInfo,
	mongoRepo entity.DocumentRepository,
	readTimeout time.Duration,
) *GenerateCsv {
	return &GenerateCsv{
		repo:                 repo,
		reviewInfoRepo:       reviewInfoRepo,
		groupCategoryRepo:    groupCategoryRepo,
		pubOperationInfoRepo: pubOperationInfoRepo,
		mongoRepo:            mongoRepo,
		ReadTimeout:          readTimeout,
	}
}

func (gc *GenerateCsv) ListAssetsGroupCategory(
	ctx context.Context,
	project string,
) ([]*entity.GroupPathInfo, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListAssetsGroupCategory(db, project)
}

func (gc *GenerateCsv) ListAllBldReviews(
	ctx context.Context,
	project string,
) ([]*entity.BldComponentReviewInfo, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListAllBldReviews(db, project)
}

func (gc *GenerateCsv) ListComments(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	mongo_repo := gc.mongoRepo.(*database.MongoRepository)
	filterPath := "^shared/publish/assets/[^/]+/[^/]+/(mdl|rig|ldv)/_review"
	commentParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root": "assets",
			"path": bson.M{"$regex": filterPath},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
		Projection: []string{mongo_repo.MetaKey, "groups", "relation", "comment_data", "phase"},
	}
	comments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "comment", commentParam)
	if err != nil {
		return nil, fmt.Errorf("listComments query failed: %w", err)
	}
	return comments, nil
}

func (gc *GenerateCsv) ListShotAssetsAll(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	mongo_repo := gc.mongoRepo.(*database.MongoRepository)
	shotAssetsAllParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "shots",
			"phase":     "anm",
			"component": "anm",
		},
		Projection: []string{mongo_repo.MetaKey, "component_info.scene_assets", "groups"},
	}
	shotAssetsAllInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "publishOperationInfo", shotAssetsAllParam)
	if err != nil {
		return nil, fmt.Errorf("listShotAssetsAll query failed: %w", err)
	}
	return shotAssetsAllInfos, nil
}

func (gc *GenerateCsv) ListBldAnmBldRendDocuments(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	mongo_repo := gc.mongoRepo.(*database.MongoRepository)
	bldDocumentsParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "assets",
			"phase":     "bld",
			"component": bson.M{"$in": []string{"bldAnm", "bldRend"}},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
		Projection: []string{mongo_repo.MetaKey, "groups", "relation", "submitted_at_utc", "component"},
	}
	bldDocuments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "publishOperationInfo", bldDocumentsParam)
	if err != nil {
		return nil, fmt.Errorf("list bldAnm bldRend Documents query failed: %w", err)
	}
	return bldDocuments, nil
}

func (gc *GenerateCsv) ListPublishOperationInfos(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	mongo_repo := gc.mongoRepo.(*database.MongoRepository)
	publishOperationInfoParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "assets",
			"phase":     bson.M{"$in": []string{"mdl", "rig", "ldv"}},
			"component": bson.M{"$regex": "^(mdl|rig|ldv)"},
		},
		Projection: []string{mongo_repo.MetaKey, "phase", "revision", "submitted_user", "submitted_at_utc", "groups", "relation"},
	}
	publishOperationInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "publishOperationInfo", publishOperationInfoParam)
	if err != nil {
		return nil, fmt.Errorf("list PublishOperationInfos query failed: %w", err)
	}
	return publishOperationInfos, nil
}

func (gc *GenerateCsv) ListLatestAssetsReviews(
	ctx context.Context,
	project string,
) ([]*entity.AssetReviewInfoCsv, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListLatestAssetsReviews(db, project)
}

func (gc *GenerateCsv) ListShotComments(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	mongo_repo := gc.mongoRepo.(*database.MongoRepository)
	commentParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root": "shots",
			"path": bson.M{"$in": []string{"lay", "anm"}},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
		Projection: []string{mongo_repo.MetaKey, "groups", "relation", "comment_data", "phase"},
	}
	layAnmComments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "comment", commentParam)
	if err != nil {
		return nil, fmt.Errorf("listComments [lay, anm] query failed: %w", err)
	}

	commentParam = &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root": "shots",
			"path": bson.M{"$in": []string{"gnz", "fx"}},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
		Projection: []string{mongo_repo.MetaKey, "groups", "relation", "comment_data", "phase"},
	}
	gnzFxComments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "comment", commentParam)
	if err != nil {
		return nil, fmt.Errorf("listComments [gnz, fx] query failed: %w", err)
	}

	commentParam = &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root": "shots",
			"path": bson.M{"$in": []string{"dsp", "cmp"}},
		},
		OrderBy: []*libs.OrderColumn{
			{Name: "_id", Direction: libs.Desc},
		},
		Projection: []string{mongo_repo.MetaKey, "groups", "relation", "comment_data", "phase"},
	}
	dspCmpComments, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, "comment", commentParam)
	if err != nil {
		return nil, fmt.Errorf("listComments [dsp, cmp] query failed: %w", err)
	}
	return append(append(layAnmComments, gnzFxComments...), dspCmpComments...), nil
}

func (gc *GenerateCsv) ListShotPublishOperationInfos(
	ctx context.Context,
	project string,
) ([]*entity.DocumentInfo, error) {
	mongo_repo := gc.mongoRepo.(*database.MongoRepository)
	collectionName := "publishOperationInfo"
	publishOperationInfoParam := &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "shots",
			"phase":     bson.M{"$in": []string{"lay", "anm"}},
			"component": bson.M{"$regex": "^(lay|anm)"},
		},
		Projection: []string{mongo_repo.MetaKey, "phase", "revision", "submitted_user", "submitted_at_utc", "groups", "relation", "component_info.timerange", "component_info.cam_data_type", "component_info.scene_assets"},
	}
	layAnmPublishOperationInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, collectionName, publishOperationInfoParam)
	if err != nil {
		return nil, fmt.Errorf("list [lay, anm] PublishOperationInfos query failed: %w", err)
	}

	publishOperationInfoParam = &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "shots",
			"phase":     bson.M{"$in": []string{"gnz", "fx"}},
			"component": bson.M{"$regex": "^(gnz|fx)"},
		},
		Projection: []string{mongo_repo.MetaKey, "phase", "revision", "submitted_user", "submitted_at_utc", "groups", "relation", "component_info.timerange", "component_info.cam_data_type", "component_info.scene_assets"},
	}
	gnzFxPublishOperationInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, collectionName, publishOperationInfoParam)
	if err != nil {
		return nil, fmt.Errorf("list [gnz, fx] PublishOperationInfos query failed: %w", err)
	}

	publishOperationInfoParam = &entity.QueryDocumentsParam{
		Filters: map[string]interface{}{
			"root":      "shots",
			"phase":     bson.M{"$in": []string{"dsp", "cmp"}},
			"component": bson.M{"$regex": "^(dsp|cmp)"},
		},
		Projection: []string{mongo_repo.MetaKey, "phase", "revision", "submitted_user", "submitted_at_utc", "groups", "relation", "component_info.timerange", "component_info.cam_data_type", "component_info.scene_assets"},
	}
	dspCmpPublishOperationInfos, _, err := gc.mongoRepo.GetDocumentsByFields(ctx, project, collectionName, publishOperationInfoParam)
	if err != nil {
		return nil, fmt.Errorf("list [dsp, cmp] PublishOperationInfos query failed: %w", err)
	}
	return append(append(layAnmPublishOperationInfos, gnzFxPublishOperationInfos...), dspCmpPublishOperationInfos...), nil
}

func (gc *GenerateCsv) ListLatestShotReviews(
	ctx context.Context,
	project string,
) ([]*entity.ShotReviewInfoCsv, error) {
	timeoutCtx, cancel := context.WithTimeout(ctx, gc.ReadTimeout)
	defer cancel()
	db := gc.repo.WithContext(timeoutCtx)
	return gc.repo.ListLatestShotReviews(db, project)
}
