package repository

import (
	"context"
	"fmt"
	"slices"

	"github.com/PolygonPictures/central30-web/front/entity"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type Tracker struct {
	db *mongo.Database
}

func NewTracker(db *mongo.Database) *Tracker {
	return &Tracker{
		db: db,
	}
}

// --- Column ---

func (r *Tracker) GetColumns(ctx context.Context, project string, root string) ([]entity.TrackerColumn, error) {
	scopeFilter := bson.M{
		"$or": []bson.M{
			{"scope": "global"},
			{"project": project, "scope": "project"},
			{"scope": bson.M{"$exists": false}, "project": project},
		},
	}

	filter := bson.M{
		"deleted": "0",
		"$and": []bson.M{
			scopeFilter,
		},
	}

	if root != "" {
		rootFilter := bson.M{
			"root": bson.M{"$in": []string{root, ""}},
		}
		filter["$and"] = append(filter["$and"].([]bson.M), rootFilter)
	}

	cursor, err := r.db.Collection(entity.ColTrackerColumns).Find(ctx, filter)
	if err != nil {
		return nil, err
	}
	var rawColumns []entity.TrackerColumn
	if err = cursor.All(ctx, &rawColumns); err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	columnMap := make(map[string]entity.TrackerColumn)

	for _, col := range rawColumns {
		if col.Scope == "global" {
			if col.IsSystem {
				columnMap[col.Key] = col
			} else {
				isExcluded := false
				for _, p := range col.ExcludeProjects {
					if p == project {
						isExcluded = true
						break
					}
				}
				if !isExcluded {
					columnMap[col.Key] = col
				}
			}
		}
	}

	for _, col := range rawColumns {
		if col.Scope == "project" || col.Scope == "" {
			if col.Project == project {
				columnMap[col.Key] = col
			}
		}
	}

	var result = []entity.TrackerColumn{}
	for _, col := range columnMap {
		result = append(result, col)
	}

	return result, nil
}

func (r *Tracker) CreateColumn(ctx context.Context, col entity.TrackerColumn) error {
	_, err := r.db.Collection(entity.ColTrackerColumns).InsertOne(ctx, col)
	return err
}

func (r *Tracker) UpdateColumn(ctx context.Context, col entity.TrackerColumn) error {
	update := bson.M{
		"$set": bson.M{
			"display_name":     col.DisplayName,
			"data_type":        col.DataType,
			"config":           col.Config,
			"visibled":         col.Visibled,
			"scope":            col.Scope,
			"exclude_projects": col.ExcludeProjects,
			"is_system":        col.IsSystem,
			"modified_at_utc":  col.ModifiedAtUTC,
			"modified_by":      col.ModifiedBy,
		},
	}
	_, err := r.db.Collection(entity.ColTrackerColumns).UpdateOne(ctx, bson.M{"_id": col.ID}, update)
	return err
}

// --- Entity ---

func (r *Tracker) SearchEntities(ctx context.Context, req entity.SearchRequest) ([]entity.TrackerEntity, error) {
	filter := bson.M{
		"project": req.Project,
		"deleted": "0",
	}

	defaultFields := []string{"_id", "project", "root", "group", "created_at_utc", "modified_at_utc", "created_by", "modified_by", "deleted"}

	for _, f := range req.Filters {
		dbKey := f.Key
		if !slices.Contains(defaultFields, dbKey) {
			dbKey = "data." + f.Key
		}

		switch f.Operator {
		case "eq":
			filter[dbKey] = bson.M{"$eq": f.Value}
		case "contains":
			filter[dbKey] = bson.M{"$regex": primitive.Regex{Pattern: fmt.Sprintf("%v", f.Value), Options: "i"}}
		case "gt":
			filter[dbKey] = bson.M{"$gt": f.Value}
		case "lt":
			filter[dbKey] = bson.M{"$lt": f.Value}
		}
	}

	opts := options.Find()
	if len(req.Fields) > 0 {
		projection := bson.M{}
		for _, field := range req.Fields {
			key := field
			if !slices.Contains(defaultFields, key) {
				key = "data." + key
			}
			projection[key] = 1
		}
		opts.SetProjection(projection)
	}

	if len(req.Sorts) > 0 {
		sortD := bson.D{}
		for _, s := range req.Sorts {
			key := s.Key
			if !slices.Contains(defaultFields, key) {
				key = "data." + key
			}
			sortD = append(sortD, bson.E{Key: key, Value: s.Direction})
		}
		opts.SetSort(sortD)
	} else {
		opts.SetSort(bson.D{{Key: "group", Value: -1}})
	}

	cursor, err := r.db.Collection(entity.ColTrackerEntities).Find(ctx, filter, opts)
	if err != nil {
		return nil, err
	}
	var results = []entity.TrackerEntity{}
	if err = cursor.All(ctx, &results); err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)
	return results, nil
}

func (r *Tracker) GetEntityByID(ctx context.Context, id primitive.ObjectID) (*entity.TrackerEntity, error) {
	var ent entity.TrackerEntity
	err := r.db.Collection(entity.ColTrackerEntities).FindOne(ctx, bson.M{"_id": id}).Decode(&ent)
	if err != nil {
		return nil, err
	}
	return &ent, nil
}

func (r *Tracker) CreateEntity(ctx context.Context, ent entity.TrackerEntity) error {
	_, err := r.db.Collection(entity.ColTrackerEntities).InsertOne(ctx, ent)
	return err
}

func (r *Tracker) UpdateEntity(ctx context.Context, ent entity.TrackerEntity) error {
	update := bson.M{
		"$set": bson.M{
			"root":            ent.Root,
			"group":           ent.Group,
			"data":            ent.Data,
			"modified_at_utc": ent.ModifiedAtUTC,
			"modified_by":     ent.ModifiedBy,
		},
	}
	_, err := r.db.Collection(entity.ColTrackerEntities).UpdateOne(ctx, bson.M{"_id": ent.ID}, update)
	return err
}

func (r *Tracker) RestoreEntity(ctx context.Context, ent entity.TrackerEntity) error {
	_, err := r.db.Collection(entity.ColTrackerEntities).ReplaceOne(ctx, bson.M{"_id": ent.ID}, ent)
	return err
}

func (r *Tracker) SoftDeleteEntity(ctx context.Context, id primitive.ObjectID) error {
	update := bson.M{"$set": bson.M{"deleted": id.String()}}
	_, err := r.db.Collection(entity.ColTrackerEntities).UpdateOne(ctx, bson.M{"_id": id}, update)
	return err
}

// --- History ---

func (r *Tracker) CreateHistory(ctx context.Context, h entity.History) error {
	_, err := r.db.Collection(entity.ColTrackerHistories).InsertOne(ctx, h)
	return err
}

func (r *Tracker) GetHistories(ctx context.Context, entityID primitive.ObjectID) ([]entity.History, error) {
	opts := options.Find().SetSort(bson.D{{Key: "modified_at_utc", Value: -1}})
	cursor, err := r.db.Collection(entity.ColTrackerHistories).Find(ctx, bson.M{"entity_id": entityID}, opts)
	if err != nil {
		return nil, err
	}
	var histories []entity.History
	if err = cursor.All(ctx, &histories); err != nil {
		return nil, err
	}
	return histories, nil
}

func (r *Tracker) GetHistoryByID(ctx context.Context, id primitive.ObjectID) (*entity.History, error) {
	var h entity.History
	err := r.db.Collection(entity.ColTrackerHistories).FindOne(ctx, bson.M{"_id": id}).Decode(&h)
	if err != nil {
		return nil, err
	}
	return &h, nil
}

// --- Index ---

func (r *Tracker) EnsureIndexes(ctx context.Context) error {
	// Column Collection Indexes
	colColumns := r.db.Collection(entity.ColTrackerColumns)
	_, err := colColumns.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "root", Value: 1},
				{Key: "scope", Value: 1},
				{Key: "deleted", Value: 1},
			},
			Options: options.Index().SetName("idx_proj_scope_del"),
		},
	})
	if err != nil {
		return err
	}

	// Entity Collection Indexes
	colEntities := r.db.Collection(entity.ColTrackerEntities)
	_, err = colEntities.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "deleted", Value: 1},
			},
			Options: options.Index().SetName("idx_proj_del"),
		},
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "group", Value: 1},
			},
			Options: options.Index().SetName("idx_proj_group"),
		},
		{
			Keys: bson.D{
				{Key: "data.$**", Value: 1},
			},
			Options: options.Index().SetName("idx_wildcard_data"),
		},
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "modified_at_utc", Value: -1},
			},
			Options: options.Index().SetName("idx_proj_modified"),
		},
	})
	if err != nil {
		return err
	}

	//History Collection Indexes
	colHistory := r.db.Collection(entity.ColTrackerHistories)
	_, err = colHistory.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "entity_id", Value: 1},
				{Key: "modified_at_utc", Value: -1},
			},
			Options: options.Index().SetName("idx_entity_modified"),
		},
	})
	if err != nil {
		return err
	}
	return nil
}
