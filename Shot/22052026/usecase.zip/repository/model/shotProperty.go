package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

// ShotProperty represents a shot property information record.
type ShotProperty struct {
	Project   string         `gorm:"size:30;not null;index:ix_shot_property_1;index:ix_shot_property_2"`
	Path      string         `gorm:"size:765;not null;index:ix_shot_property_1"`
	Root      string         `gorm:"size:30;not null;index:ix_shot_property_2"`
	Group_1   string         `gorm:"size:255;not null;index:ix_shot_property_2"`
	Group_2   string         `gorm:"size:255;not null;index:ix_shot_property_2"`
	Group_3   string         `gorm:"size:255;not null;index:ix_shot_property_2"`
	Group_4   string         `gorm:"size:255;not null;index:ix_shot_property_2"`
	Group_5   string         `gorm:"size:255;not null;index:ix_shot_property_2"`
	Relation  string         `gorm:"size:100"`
	Phase     string         `gorm:"size:100"`
	Component string         `gorm:"size:100"`
	Revision  string         `gorm:"size:30"`
	Data      GormJSONObject `gorm:"type:json"`

	CreatedAtUTC  time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC time.Time `gorm:"type:datetime(6)"`
	Deleted       int32     `gorm:"not null;default:0;index:ix_shot_property_1;index:ix_shot_property_2"`
	ModifiedBy    string    `gorm:"size:100"`
	CreatedBy     string    `gorm:"size:100"`
	ID            int32     `gorm:"primaryKey"`
}

func NewShotProperty(
	p *entity.CreateShotPropertyParams,
) *ShotProperty {
	now := time.Now().UTC()
	var createdBy string
	if p.CreatedBy != nil {
		createdBy = *p.CreatedBy
	}
	return &ShotProperty{
		Project:   p.Project,
		Path:      p.Path,
		Root:      p.Root,
		Group_1:   p.Group_1,
		Group_2:   p.Group_2,
		Group_3:   p.Group_3,
		Group_4:   p.Group_4,
		Group_5:   p.Group_5,
		Relation:  p.Relation,
		Phase:     p.Phase,
		Component: p.Component,
		Revision:  p.Revision,
		Data:      GormJSONObject(p.Data),

		CreatedAtUTC:  now,
		ModifiedAtUTC: now,
		ModifiedBy:    createdBy,
		CreatedBy:     createdBy,
	}
}

func (m *ShotProperty) Entity(showDeleted bool) *entity.ShotProperty {
	e := &entity.ShotProperty{
		Project:   m.Project,
		Path:      m.Path,
		Root:      m.Root,
		Group_1:   m.Group_1,
		Group_2:   m.Group_2,
		Group_3:   m.Group_3,
		Group_4:   m.Group_4,
		Group_5:   m.Group_5,
		Relation:  m.Relation,
		Phase:     m.Phase,
		Component: m.Component,
		Revision:  m.Revision,
		Data:      entity.JSONObject(m.Data),

		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		ModifiedBy:    m.ModifiedBy,
		CreatedBy:     m.CreatedBy,
		ID:            m.ID,
	}
	if showDeleted {
		e.Deleted = &m.Deleted
	}

	return e
}
