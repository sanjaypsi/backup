package entity

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"reflect"
	"strings"

	"github.com/PolygonPictures/central30-web/front/libs"
)

type scanner interface {
	Scan(dest ...interface{}) error
}

// DocumentInfo represents document information.
type DocumentInfo map[string]interface{}

// ProjectInfo represents project information.
type ProjectInfo struct {
	Name string `json:"name"`
	libs.BaseInfo
}

// Scan scans the Scanner.
func (i *ProjectInfo) Scan(s scanner) error {
	return s.Scan(
		&i.Name,
		&i.CreatedAtUtc,
		&i.ModifiedAtUtc,
		&i.Deleted,
		&i.ModifiedBy,
		&i.CreatedBy,
		&i.ID,
	)
}

// StudioInfo represents studio information.
type StudioInfo struct {
	Name string `json:"name"`
	libs.BaseInfo
}

// Scan scans the Scanner.
func (i *StudioInfo) Scan(s scanner) error {
	return s.Scan(
		&i.Name,
		&i.CreatedAtUtc,
		&i.ModifiedAtUtc,
		&i.Deleted,
		&i.ModifiedBy,
		&i.CreatedBy,
		&i.ID,
	)
}

// DeletionState represents the deletion state.
type DeletionState int

const (
	// Active is the active state.
	Active DeletionState = iota + 1
	// ToDelete is scheduled for deletion.
	ToDelete
	// Deleted is the deleted state.
	Deleted
)

var deletionStateStringMap = map[DeletionState]string{
	Active:   "active",
	ToDelete: "to_delete",
	Deleted:  "deleted",
}

func ParseDeletionStats(s string) (DeletionState, error) {
	for key, val := range deletionStateStringMap {
		if strings.ToLower(val) == s {
			return key, nil
		}
	}
	return 0, fmt.Errorf("failed to parse deletion status %q", s)
}

func (s DeletionState) String() string {
	str, ok := deletionStateStringMap[s]
	if !ok {
		return "unknown"
	}
	return str
}

func (s DeletionState) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

// QueryDocumentsParam represents query parameters of Document.
type QueryDocumentsParam struct {
	OrderBy    []*libs.OrderColumn
	Page       *int
	PerPage    *int
	Filters    map[string]interface{}
	Projection []string
	IsIdSort   *bool `default:"true"`
	IndexHint  string
}

// ParseOrderBy parses OrderBy.
func (p *QueryDocumentsParam) ParseOrderBy(columns string) error {
	var cols []*libs.OrderColumn
	for _, field := range strings.Split(columns, ",") {
		direction := libs.Asc
		if strings.HasPrefix(field, "-") {
			direction = libs.Desc
			field = field[1:]
		}
		cols = append(cols, &libs.OrderColumn{Name: field, Direction: direction})
	}
	p.OrderBy = cols
	return nil
}

func (p QueryDocumentsParam) IsIdSortOrDefault() bool {
	if p.IsIdSort != nil {
		return *p.IsIdSort
	}

	t := reflect.TypeOf(p)
	field, _ := t.FieldByName("IsIdSort")
	return field.Tag.Get("default") == "true"

}

// DocumentRepository is a interface for the document repository.
type DocumentRepository interface {
	CreateDocument(
		ctx context.Context,
		project string,
		collection string,
		params map[string]interface{},
	) (*DocumentInfo, error)

	GetDocumentByID(
		ctx context.Context,
		project string,
		collection string,
		id string,
	) (*DocumentInfo, error)

	GetDocumentsByFields(
		ctx context.Context,
		project string,
		collection string,
		param *QueryDocumentsParam,
	) ([]*DocumentInfo, int, error)

	GetDocumentsByOfficialRevisionFilters(
		ctx context.Context,
		project string,
		collection string,
		param *QueryDocumentsParam,
		fields *map[string]interface{},
	) ([]*DocumentInfo, int, error)

	UpdateDocument(
		ctx context.Context,
		project string,
		collection string,
		id string,
		params map[string]interface{},
	) (*DocumentInfo, error)

	DeleteDocument(
		ctx context.Context,
		project string,
		collection string,
		id string,
	) error
}

// InfoRepository is a interface for the info repository.
type InfoRepository interface {
	// Project

	GetProjectByName(
		ctx context.Context,
		name string,
	) (*ProjectInfo, error)

	// Studio

	GetStudiosByProject(
		ctx context.Context,
		project string,
	) ([]*StudioInfo, error)

	// Transaction

	BeginTx(
		ctx context.Context,
		opts *sql.TxOptions,
	) (*sql.Tx, error)
}
