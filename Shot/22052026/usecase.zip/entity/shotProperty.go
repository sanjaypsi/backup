package entity

import (
	"time"
)

type ShotProperty struct {
	Project       string       `json:"project"`
	Path          string       `json:"path"` // TODO: Remove the "Path" property after the tool migration is complete
	Root          string       `json:"root"`
	Group_1       string       `json:"group_1"`
	Group_2       string       `json:"group_2"`
	Group_3       string       `json:"group_3"`
	Group_4       string       `json:"group_4"`
	Group_5       string       `json:"group_5"`
	Relation      string       `json:"relation"`
	Phase         string       `json:"phase"`
	Component     string       `json:"component"`
	Revision      string       `json:"revision"`
	Data          JSONObject   `json:"data"`

	CreatedAtUTC  time.Time    `json:"created_at_utc"`
	ModifiedAtUTC time.Time    `json:"modified_at_utc"`
	Deleted       *int32       `json:"deleted,omitempty"`
	ModifiedBy    string       `json:"modified_by"`
	CreatedBy     string       `json:"created_by"`
	ID            int32        `json:"id"`
}

type ListShotPropertyParams struct {
	Project       string     `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path          string     `binding:"required"`
	Root          string     `binding:"omitempty,min=1,max=30"`
	Group_1       string     `binding:"max=5,dive,max=100"`
	Group_2       string     `binding:"max=5,dive,max=100"`
	Group_3       string     `binding:"max=5,dive,max=100"`
	Group_4       string     `binding:"max=5,dive,max=100"`
	Group_5       string     `binding:"max=5,dive,max=100"`
	Relation      string     `binding:"omitempty,dive,max=100"`
	Phase         string     `binding:"omitempty,dive,max=100"`
	Component     string     `binding:"omitempty,min=1,max=100"`
	Revision      string     `binding:"omitempty,len=30"`
	ModifiedSince *time.Time ``
	*BaseListParams
}

type GetShotPropertyParams struct {
	Project string `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Path    string `binding:"required"`
}

type CreateShotPropertyParams struct {
	Project   string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	CreatedBy *string `binding:"omitempty,min=1,max=100"`

	Path          string              `binding:"required"`
	Root          string              `binding:"min=1"`
	Group_1       string              `binding:"min=1"`
	Group_2       string              `binding:"min=1"`
	Group_3       string              `binding:"min=1"`
	Group_4       string              `binding:"min=1"`
	Group_5       string              `binding:"min=1"`
	Relation      string              `binding:"min=1"`
	Phase         string              `binding:"min=1"`
	Component     string              `binding:"min=1"`
	Revision      string              `binding:"len=30"`
	Data          JSONObject          `binding:"required"`
}
