package entity

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	ColTrackerColumns   = "tracker_column"
	ColTrackerEntities  = "tracker_entity"
	ColTrackerHistories = "tracker_history"
)

// Column
type TrackerColumn struct {
	ID              primitive.ObjectID  `bson:"_id,omitempty" json:"id"`
	Project         string              `bson:"project" json:"project" binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root            string              `bson:"root" json:"root"`
	Scope           string              `bson:"scope" json:"scope"`
	ExcludeProjects []string            `bson:"exclude_projects" json:"exclude_projects"`
	IsSystem        bool                `bson:"is_system" json:"is_system"`
	Key             string              `bson:"key" json:"key"`
	DisplayName     string              `bson:"display_name" json:"display_name"`
	DataType        string              `bson:"data_type" json:"data_type"`
	Config          TrackerColumnConfig `bson:"config" json:"config"`
	Visibled        bool                `bson:"visibled" json:"visibled"`
	Deleted         string              `bson:"deleted" json:"deleted"`
	CreatedAtUTC    time.Time           `bson:"created_at_utc" json:"created_at_utc"`
	ModifiedAtUTC   time.Time           `bson:"modified_at_utc" json:"modified_at_utc"`
	CreatedBy       string              `bson:"created_by" json:"created_by"`
	ModifiedBy      string              `bson:"modified_by" json:"modified_by"`
}

type TrackerColumnConfig struct {
	Options     []string `bson:"options" json:"options"`
	MultiSelect bool     `bson:"multi_select" json:"multi_select"`
}

// Entity
type TrackerEntity struct {
	ID            primitive.ObjectID     `bson:"_id,omitempty" json:"id"`
	Project       string                 `bson:"project" json:"project" binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root          string                 `bson:"root" json:"root"`
	Group         string                 `bson:"group" json:"group"`
	Data          map[string]interface{} `bson:"data" json:"data"`
	CreatedAtUTC  time.Time              `bson:"created_at_utc" json:"created_at_utc"`
	ModifiedAtUTC time.Time              `bson:"modified_at_utc" json:"modified_at_utc"`
	CreatedBy     string                 `bson:"created_by" json:"created_by"`
	ModifiedBy    string                 `bson:"modified_by" json:"modified_by"`
	Deleted       string                 `bson:"deleted" json:"deleted"`
}

// History
type History struct {
	ID            primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	Project       string             `bson:"project" json:"project" binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio        string             `bson:"studio" json:"studio"`
	EntityID      primitive.ObjectID `bson:"entity_id" json:"entity_id"`
	ModifiedAtUTC time.Time          `bson:"modified_at_utc" json:"modified_at_utc"`
	ModifiedBy    string             `bson:"modified_by" json:"modified_by"`
	Snapshot      TrackerEntity      `bson:"snapshot" json:"snapshot"`
}

// API
type SearchRequest struct {
	Project string   `json:"project"`
	Filters []Filter `json:"filters"`
	Sorts   []Sort   `json:"sorts"`
	Fields  []string `json:"fields"`
}

type Filter struct {
	Key      string      `json:"key"` // e.g. "root", "group", "data.status"
	Operator string      `json:"operator"`
	Value    interface{} `json:"value"`
}

type Sort struct {
	Key       string `json:"key"`
	Direction int    `json:"direction"` // 1 asc, -1 desc
}

type RollbackRequest struct {
	HistoryID string `json:"history_id"`
	User      string `json:"user"`
	Studio    string `json:"studio"` // Added for history tracking
}

type CreateColumnRequest struct {
	Project         string              `json:"project" binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root            string              `json:"root"`
	Scope           string              `json:"scope"`
	ExcludeProjects []string            `json:"exclude_projects"`
	IsSystem        bool                `json:"is_system"`
	Key             string              `json:"key"`
	DisplayName     string              `json:"display_name"`
	DataType        string              `json:"data_type"`
	Config          TrackerColumnConfig `json:"config"`
	Visibled        bool                `json:"visibled"`
	User            string              `json:"user"`
}

type UpdateColumnRequest struct {
	DisplayName     string              `json:"display_name"`
	DataType        string              `json:"data_type"`
	Config          TrackerColumnConfig `json:"config"`
	Visibled        bool                `json:"visibled"`
	Scope           string              `json:"scope"`
	ExcludeProjects []string            `json:"exclude_projects"`
	IsSystem        bool                `json:"is_system"`
	User            string              `json:"user"`
}

type CreateEntityRequest struct {
	Project string                 `json:"project" binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Root    string                 `json:"root"`
	Group   string                 `json:"group"`
	Data    map[string]interface{} `json:"data"`
	User    string                 `json:"user"`
}

type UpdateEntityRequest struct {
	Root   string                 `json:"root"`
	Group  string                 `json:"group"`
	Data   map[string]interface{} `json:"data"`
	User   string                 `json:"user"`
	Studio string                 `json:"studio"` // Needed for history
}
