package entity

type GenerateTrackerCsvParams struct {
	Project string `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
}

type AssetReviewInfoCsv struct {
	Project        string `gorm:"column:project"`
	Root           string `gorm:"column:root"`
	Relation       string `gorm:"column:relation"`
	Phase          string `gorm:"column:phase"`
	WorkStatus     string `gorm:"column:work_status"`
	ApprovalStatus string `gorm:"column:approval_status"`
	Group1         string `gorm:"column:group_1"`
}

func (AssetReviewInfoCsv) TableName() string {
	return "t_review_info"
}

type GroupPathInfo struct {
	GroupPath            string
	CategoryPath         string
	GroupCategoryGroupID int64
	GroupCategoryID      int64
}

type BldComponentReviewInfo struct {
	TargetComponents []string `gorm:"column:target_components"`
	Group1           string   `gorm:"column:group_1"`
	Relation         string   `gorm:"column:relation"`
	ApprovalStatus   string   `gorm:"column:approval_status"`
}

func (BldComponentReviewInfo) TableName() string {
	return "t_review_info"
}

type GenerateAssetData struct {
	ReviewInfo            []*AssetReviewInfoCsv
	GroupCategories       []*GroupPathInfo
	LatestDocuments       []*DocumentInfo
	Comments              []*DocumentInfo
	ShotAssetsAlls        []*DocumentInfo
	PublishOperationInfos []*DocumentInfo
	ComponentReviewInfos  []*BldComponentReviewInfo
}

type PhaseRowData struct {
	ApprovalStatus            string
	WorkStatus                string
	LatestPublishAt           string
	LatestPublisher           string
	Versions                  []string
	LatestArtistCommentJa     string
	LatestArtistCommentEn     string
	LatestSupervisorCommentJa string
	LatestSupervisorCommentEn string
	LatestDirectorCommentJa   string
	LatestDirectorCommentEn   string
	LatestClientCommentJa     string
	LatestClientCommentEn     string
}

type AssetRowData struct {
	AssetTypes         []string
	AssetGroups        []string
	AssetName          string
	ShotAssetsAll      []string
	MdlData            *PhaseRowData
	RigData            *PhaseRowData
	LdvData            *PhaseRowData
	BldAnmStatus       string
	BldAnmReleaseDate  string
	BldRendStatus      string
	BldRendReleaseDate string
}

type ShotReviewInfoCsv struct {
	Project        string `gorm:"column:project"`
	Root           string `gorm:"column:root"`
	Relation       string `gorm:"column:relation"`
	Phase          string `gorm:"column:phase"`
	WorkStatus     string `gorm:"column:work_status"`
	ApprovalStatus string `gorm:"column:approval_status"`
	Group1         string `gorm:"column:group_1"`
	Group2         string `gorm:"column:group_2"`
	Group3         string `gorm:"column:group_3"`
}

func (ShotReviewInfoCsv) TableName() string {
	return "t_review_info"
}

type GenerateShotData struct {
	ReviewInfo            []*ShotReviewInfoCsv
	Comments              []*DocumentInfo
	PublishOperationInfos []*DocumentInfo
}

type ShotRowData struct {
	Episode           string
	Sequence          string
	ShotName          string
	CutDuration       string
	VersionLinks      []string
	CamDataType       string
	AssetsAll         []string
	PublishInfoStatus []string
	LayData           *PhaseRowData
	AnmData           *PhaseRowData
	GnzData           *PhaseRowData
	FxData            *PhaseRowData
	DspData           *PhaseRowData
	CmpData           *PhaseRowData
	MatData           *PhaseRowData
	MatNukeData       *PhaseRowData
	CfxClothData      *PhaseRowData
	CfxHairData       *PhaseRowData
	RtcData           *PhaseRowData
	DrwData           *PhaseRowData
	ClpData           *PhaseRowData
}
