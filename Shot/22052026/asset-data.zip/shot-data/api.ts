import { AuthorizationError } from '../../../auth/types';
import { getAuthHeader, setNewToken } from '../../../auth/util';
import { LatestShotComponentDocumentsResponse, ReviewInfo, Shot, ShotPivotResponse } from './types';

type ReviewInfoListResponse = {
  reviews: ReviewInfo[],
  next: string | null,
  total: number,
};

export type ShotsResponse = {
  shots: Shot[],
  total: number,
};

export const fetchShots = async (
  project: string,
  page: number,
  rowsPerPage: number,
  search?: string,
  approvalStatus?: string[],
  workStatus?: string[],
  signal?: AbortSignal | null,
): Promise<ShotsResponse> => {
  const headers = getAuthHeader();
  let url: string | null = `/api/projects/${project}/publishOperationInfo/shots`;
  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));

  if (search && search.trim().length >= 3) {
    params.set('search', search.trim());
    console.log('Search param added:', search.trim());
  }
  
  if (approvalStatus && approvalStatus.length > 0) {
    console.log('Adding approval_status params:', approvalStatus);
    approvalStatus.forEach(s => {
      params.append('approval_status', s);
      console.log(`Added approval_status: ${s}`);
    });
  }
  
  if (workStatus && workStatus.length > 0) {
    console.log('Adding work_status params:', workStatus);
    workStatus.forEach(s => {
      params.append('work_status', s);
      console.log(`Added work_status: ${s}`);
    });
  }
  
  url += `?${params}`;
  console.log('Final URL:', url);
  console.log('Final Params:', params.toString());
  
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    const errorText = await res.text();
    console.error('API Error Response:', errorText);
    throw new Error('Failed to fetch parameters.');
  }
  setNewToken(res);
  const json: ShotsResponse = await res.json();
  console.log('API Response:', json);
  return json;
};

export const fetchShotReviewInfos = async (
  project: string,
  shot: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<ReviewInfoListResponse> => {
  let url = `/api/projects/${project}/shots/reviewInfos`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('groups', String(shot));
  params.set('relation', String(relation));
  url += `?${params}`;
  
  try {
    const res = await fetch(
      url,
      {
        method: 'GET',
        headers,
        mode: 'cors',
        signal,
      },
    );
    if (res.status === 401) {
      throw new AuthorizationError();
    }
    if (!res.ok) {
      throw new Error('Failed to fetch review infos.');
    }
    setNewToken(res);
    const json: ReviewInfoListResponse = await res.json();
    return json;
    
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      console.log('Review infos request aborted');
      return { reviews: [], next: null, total: 0 };
    }
    throw error;
  }
};

export const fetchShotThumbnail = async (
  project: string,
  shots: string[],
  relation: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  let url = `/api/projects/${project}/shots/reviewthumbnail`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('group1', shots[0]);
  params.set('group2', shots[1]);
  params.set('group3', shots[2]);
  params.set('relation', String(relation));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 204) {
    return null;
  }
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch thumbnail.');
  }
  setNewToken(res);
  return res;
};

export const fetchLatestShotComponents = async (
  project: string,
  shots: string[],
  relation: string,
  components: string[],
  signal?: AbortSignal | null,
): Promise<LatestShotComponentDocumentsResponse[]> => {
  let url = `/api/projects/${project}/latestShotsOperationInfos`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('group1', shots[0]);
  params.set('group2', shots[1]);
  params.set('group3', shots[2]);
  params.set('relation', relation);
  components.forEach(component => params.append('component', component));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch latest asset components.');
  }
  setNewToken(res);
  const json: LatestShotComponentDocumentsResponse[] = await res.json();
  return json;
};

// Add new pivot fetch
export type ShotsPivotParams = {
  project: string;
  page: number;
  perPage: number;
  orderKey?: string;
  direction?: string;
  phase?: string;
  nameKey?: string;
  approvalStatus?: string[];
  workStatus?: string[];
  group1?: string[];
  signal?: AbortSignal | null;
};

export const fetchShotsPivot = async ({
  project,
  page,
  perPage,
  orderKey = 'group1_only',
  direction = 'ASC',
  phase = '',
  nameKey = '',
  approvalStatus = [],
  workStatus = [],
  group1 = [],
  signal,
}: ShotsPivotParams): Promise<ShotPivotResponse> => {
  const headers = getAuthHeader();
  const params = new URLSearchParams();

  params.set('page',      String(page));
  params.set('perPage',   String(perPage));
  params.set('orderKey',  orderKey);
  params.set('direction', direction);

  console.log(' API Request Details:', {
    url: `/api/projects/${project}/reviews/shots/pivot`,
    params: {
      page,
      perPage,
      orderKey,
      direction,
      phase,
      nameKey,
      approvalStatus,
      workStatus
    }
  });

  if (phase)   params.set('phase',   phase);
  if (nameKey) params.set('nameKey', nameKey);

  approvalStatus.forEach(s => params.append('approvalStatus', s));
  workStatus.forEach(s     => params.append('workStatus',     s));

  // add group filters
  group1.forEach(g => params.append('group1', g));

  const url = `/api/projects/${project}/reviews/shots/pivot?${params.toString()}`;
  console.log(' Full URL:', url);

  // ADD TRY-CATCH BLOCK HERE
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    });

    if (res.status === 401) throw new AuthorizationError();
    if (!res.ok) {
      const errorText = await res.text();
      console.error(' API Error:', errorText);
      throw new Error('Failed to fetch shots pivot.');
    }

    setNewToken(res);
    const data = await res.json();
    console.log(' API Response:', { 
      total: data.total, 
      itemsCount: data.items && data.items.length,
      firstItemSortValue: data.items && data.items[0] && data.items[0].group_1
    });
    return data;
    
  } catch (error) {
    // Handle AbortError specifically - don't treat as error
    if (error instanceof Error && error.name === 'AbortError') {
      // console.log('Fetch shots pivot request aborted');
    }
      throw error;  // Don't throw, just return empty data
    }

};

export const fetchGenerateShotCsv = async (
  project: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  const encodedProject = encodeURIComponent(project);
  let url = `/api/projects/${encodedProject}/shots/generateCsv`;

  console.log('fetchGenerateShotCsv URL:', url);

  const headers = getAuthHeader();
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    console.error('401 Unauthorized for CSV generation:', url);
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to generate CSV.');
  }
  setNewToken(res);
  return res;
};
