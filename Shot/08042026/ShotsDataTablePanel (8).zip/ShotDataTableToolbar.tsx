import React from "react";
import {
    Toolbar,
    Typography,
    IconButton,
    Box,
    List,
    ListItem,
    ListItemText,
    Divider,
    Collapse,
    Checkbox,
    Button,
    Drawer,
} from "@material-ui/core";
import { styled } from "@material-ui/core/styles";
import ViewListIcon from "@material-ui/icons/ViewList";
import ViewModuleIcon from "@material-ui/icons/ViewModule";
import FilterListIcon from "@material-ui/icons/FilterList";
import ExpandLessIcon from "@material-ui/icons/ExpandLess";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ViewColumnIcon from "@material-ui/icons/ViewColumn";
import RestoreIcon from "@material-ui/icons/Restore";

/* ------------------------------
   Styled Components
-------------------------------- */

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderBottom: `1px solid ${theme.palette.divider}`,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding: theme.spacing(1, 2),
  minHeight: 34,
}));

const LeftSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 12,
});

const RightSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 8,
});

/* Toggle */
const ToggleContainer = styled(Box)({
  display: "flex",
  borderRadius: 4,
});

/* Search */
const SearchContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  backgroundColor: theme.palette.background.default,
  borderRadius: 6,
  padding: "4px 12px",
  border: `1px solid ${theme.palette.divider}`,
  height: 30,
  width: 200,
}));

const StyledInput = styled("input")({
  color: "inherit",
  backgroundColor: "transparent",
  border: "none",
  outline: "none",
  width: 200,
  fontSize: 14,
  "&::placeholder": {
    color: "#999",
    opacity: 1,
  },
});

/* Control Buttons */
const ControlButton = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  gap: 4,
  padding: theme.spacing(0.5, 1),
  borderRadius: 4,
  cursor: "pointer",
  height: 36,
  border: `1px solid transparent`,
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
    borderColor: theme.palette.divider,
  },
}));

/* Reset Button */
const ResetButton = styled(Button)(({ theme }) => ({
  height: 36,
  padding: theme.spacing(0.5, 1.5),
  color: theme.palette.text.secondary,
  borderColor: theme.palette.divider,
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
    borderColor: theme.palette.text.secondary,
  },
}));

/* ------------------------------
   Types
-------------------------------- */

type Filters = {
  shotGroups: string[];
  approvalStatus: string[];
  workStatus: string[];
};

export type ViewMode = "list" | "group";

type ColumnItem = {
  id: string;
  label: string;
  group: string;
};

export type ColumnState = {
  [key: string]: boolean;
};

type Props = {
  viewMode: ViewMode;
  onViewChange: (mode: ViewMode) => void;
  searchValue: string;
  onSearchChange: (value: string) => void;
  filters: Filters;
  onFilterChange: (newFilters: Filters) => void;
  columnsState: ColumnState;
  onColumnsChange: (newColumns: ColumnState) => void;
  onReset?: () => void;
  shotGroupOptions: { id: string; label: string }[];
};

/* ------------------------------
   Filter Menu (Drawer Version)
-------------------------------- */

const FilterContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  backgroundColor: theme.palette.background.paper,
}));

const FilterHeader = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottom: `1px solid ${theme.palette.divider}`,
  flexShrink: 0,
  backgroundColor: 'transparent',
}));

const FilterScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflowY: 'auto',
  minHeight: 0,
  padding: theme.spacing(1, 0),
  backgroundColor: 'transparent',
  
  '&::-webkit-scrollbar': {
    width: 6,
  },
  '&::-webkit-scrollbar-track': {
    background: '#f1f1f1',
    borderRadius: 3,
  },
  '&::-webkit-scrollbar-thumb': {
    background: '#999',
    borderRadius: 3,
    '&:hover': {
      background: '#666',
    },
  },
}));

const FilterFooter = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  borderTop: `1px solid ${theme.palette.divider}`,
  backgroundColor: 'transparent',
  flexShrink: 0,
  display: 'flex',
  justifyContent: 'flex-end',
  alignItems: 'center',
}));

const FilterSection = styled(Box)({
  width: '100%',
});

const FilterSectionHeader = styled(ListItem)(({ theme }) => ({
  backgroundColor: theme.palette.action.hover,
  '&:hover': {
    backgroundColor: theme.palette.action.selected,
  },
}));

const FilterMenu: React.FC<{
  filters: Filters;
  onChange: (newFilters: Filters) => void;
  shotGroupOptions: { id: string; label: string }[];
}> = ({ filters, onChange, shotGroupOptions }) => {
  const [open, setOpen] = React.useState(false);
  const [openSections, setOpenSections] = React.useState<string[]>(['approvalStatus', 'workStatus']);

  const handleFilterChange = (section: keyof Filters, optionId: string) => {
    console.log(`🔧 Toggle filter - Section: ${section}, Option: ${optionId}`);
    console.log('📊 Current filters before change:', filters);
    
    // Get current array for this section
    const currentArray = filters[section] as string[] || [];
    console.log(`📊 Current ${section} array:`, currentArray);
    
    // Toggle the value
    const newArray = currentArray.includes(optionId)
      ? currentArray.filter(v => v !== optionId)
      : [...currentArray, optionId];
    
    console.log(`📊 New ${section} array:`, newArray);
    
    // Create updated filters object
    const updatedFilters = {
      ...filters,
      [section]: newArray
    };
    
    console.log('📊 Applying filters immediately:', updatedFilters);
    
    // Apply filters immediately
    onChange(updatedFilters);
  };

  const handleClearAll = () => {
    console.log('🧹 Clearing all filters');
    const clearedFilters = {
      shotGroups: [],
      approvalStatus: [],
      workStatus: [],
    };
    onChange(clearedFilters);
  };

  const handleHideAll = () => {
    console.log('👻 Hiding drawer');
    setOpen(false);
  };

  const activeFilterCount = Object.values(filters).flat().length;

  const toggleSection = (section: string) => {
    setOpenSections(prev =>
      prev.includes(section)
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const getSectionDisplayName = (section: string) => {
    if (section === 'shotGroups') return 'Shot Groups';
    if (section === 'approvalStatus') return 'Approval Status';
    if (section === 'workStatus') return 'Work Status';
    return section.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  };

  const isChildSelected = (section: string, childId: string) => {
    return (filters[section as keyof Filters] as string[] || []).includes(childId);
  };

  // Approval Status options organized by phase
  const approvalStatusOptions = [
    // Review Phase
    { id: "check", label: "Check", phase: "Review" },
    { id: "clientReview", label: "Client Review", phase: "Review" },
    { id: "dirReview", label: "Dir Review", phase: "Review" },
    { id: "epdReview", label: "EPD Review", phase: "Review" },
    
    // Hold Phase
    { id: "clientOnHold", label: "Client On Hold", phase: "Hold" },
    { id: "dirOnHold", label: "Dir On Hold", phase: "Hold" },
    { id: "epdOnHold", label: "EPD On Hold", phase: "Hold" },
    
    // Retake Phase
    { id: "execRetake", label: "Exec Retake", phase: "Retake" },
    { id: "clientRetake", label: "Client Retake", phase: "Retake" },
    { id: "dirRetake", label: "Dir Retake", phase: "Retake" },
    { id: "epdRetake", label: "EPD Retake", phase: "Retake" },
    
    // Approved Phase
    { id: "clientApproved", label: "Client Approved", phase: "Approved" },
    { id: "dirApproved", label: "Dir Approved", phase: "Approved" },
    { id: "epdApproved", label: "EPD Approved", phase: "Approved" },
    
    // Other Phase
    { id: "other", label: "Other", phase: "Other" },
    { id: "omit", label: "Omit", phase: "Other" },
  ];

  // Work Status options organized by phase
  const workStatusOptions = [
    // Review Phase
    { id: "check", label: "Check", phase: "Review" },
    
    // Hold Phase
    { id: "cgsvOnHold", label: "CGSV On Hold", phase: "Hold" },
    { id: "svOnHold", label: "SV On Hold", phase: "Hold" },
    { id: "leadOnHold", label: "Lead On Hold", phase: "Hold" },
    
    // Retake Phase
    { id: "cgsvRetake", label: "CGSV Retake", phase: "Retake" },
    { id: "svRetake", label: "SV Retake", phase: "Retake" },
    { id: "leadRetake", label: "Lead Retake", phase: "Retake" },
    
    // Approved Phase
    { id: "cgsvApproved", label: "CGSV Approved", phase: "Approved" },
    { id: "svApproved", label: "SV Approved", phase: "Approved" },
    { id: "leadApproved", label: "Lead Approved", phase: "Approved" },
    
    // Other Phase
    { id: "svOther", label: "SV Other", phase: "Other" },
    { id: "leadOther", label: "Lead Other", phase: "Other" },
  ];

  // Shot Groups options
  // const shotGroupsOptions = [
  //   { id: "buildings", label: "Buildings" },
  //   { id: "vehicles", label: "Vehicles" },
  //   { id: "characters", label: "Characters" },
  //   { id: "environment", label: "Environment" },
  // ];

  // Group options by phase for display
  const getOptionsByPhase = (options: Array<{ id: string; label: string; phase?: string }>) => {
    const phases: { [key: string]: typeof options } = {};
    
    options.forEach(option => {
      const phase = option.phase || 'Other';
      if (!phases[phase]) {
        phases[phase] = [];
      }
      phases[phase].push(option);
    });
    
    return phases;
  };

  // Render filter items for a section
  const renderFilterItems = (section: string, options: Array<{ id: string; label: string; phase?: string }>) => {
    if (section === 'approvalStatus' || section === 'workStatus') {
      const optionsByPhase = getOptionsByPhase(options);
      const phaseOrder = ['Review', 'Hold', 'Retake', 'Approved', 'Other'];
      
      return phaseOrder.map(phase => {
        const phaseOptions = optionsByPhase[phase] || [];
        if (phaseOptions.length === 0) return null;
        
        return (
          <Box key={phase}>
            {phaseOptions.map(option => (
              <ListItem
                key={option.id}
                button
                dense
                onClick={(e) => {
                  e.stopPropagation();
                  console.log(`👆 Clicked: ${section} - ${option.label} (${option.id})`);
                  handleFilterChange(section as keyof Filters, option.id);
                }}
                style={{
                  paddingTop: 2,
                  paddingBottom: 2,
                  paddingLeft: 16,
                }}
              >
                <Checkbox
                  edge="start"
                  checked={isChildSelected(section, option.id)}
                  size="small"
                  disableRipple
                  style={{ padding: 4 }}
                />
                <ListItemText
                  primary={option.label}
                  primaryTypographyProps={{ variant: 'body2' }}
                />
              </ListItem>
            ))}
          </Box>
        );
      });
    } else {
      // For shotGroups or other simple sections
      return options.map(option => (
        <ListItem
          key={option.id}
          button
          dense
          onClick={(e) => {
            e.stopPropagation();
            console.log(`👆 Clicked: ${section} - ${option.label} (${option.id})`);
            handleFilterChange(section as keyof Filters, option.id);
          }}
          style={{
            paddingTop: 2,
            paddingBottom: 2,
            paddingLeft: 16,
          }}
        >
          <Checkbox
            edge="start"
            checked={isChildSelected(section, option.id)}
            size="small"
            disableRipple
            style={{ padding: 4 }}
          />
          <ListItemText
            primary={option.label}
            primaryTypographyProps={{ variant: 'body2' }}
          />
        </ListItem>
      ));
    }
  };

  return (
    <>
      <ControlButton onClick={() => setOpen(true)}>
        <FilterListIcon fontSize="small" />
        <Typography variant="body2">Filter</Typography>
        {activeFilterCount > 0 && (
          <Box
            component="span"
            style={{
              backgroundColor: "#1976d2",
              color: "#fff",
              borderRadius: "50%",
              width: 18,
              height: 18,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              marginLeft: 4,
            }}
          >
            {activeFilterCount}
          </Box>
        )}
      </ControlButton>

      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          style: {
            width: 320,
            maxHeight: '80vh',
            marginTop: '150px',
            marginRight: '200px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            overflow: 'hidden',
            backgroundColor: 'transparent',
          }
        }}
      >
        <FilterContainer>
          <FilterHeader>
            <Typography variant="h6">Filters</Typography>
            <Button
              size="small"
              onClick={handleClearAll}
              disabled={activeFilterCount === 0}
              style={{ minWidth: 'auto' }}
            >
              CLEAR ALL
            </Button>
          </FilterHeader>

          <FilterScrollArea>
            {/* Shot Groups Section */}
            <FilterSection>
              <FilterSectionHeader
                button
                onClick={() => toggleSection('shotGroups')}
              >
                <ListItemText
                  primary="Shot Groups"
                  secondary={`${filters.shotGroups.length}/${shotGroupOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                {openSections.includes('shotGroups') ? (
                  <ExpandLessIcon fontSize="small" />
                ) : (
                  <ExpandMoreIcon fontSize="small" />
                )}
              </FilterSectionHeader>
              <Collapse in={openSections.includes('shotGroups')} timeout="auto">
                <Box style={{ backgroundColor: '#070707d7' }}>
                  {renderFilterItems('shotGroups', shotGroupOptions)}
                </Box>
              </Collapse>
            </FilterSection>

            <Divider />

            {/* Approval Status Section */}
            <FilterSection>
              <FilterSectionHeader
                button
                onClick={() => toggleSection('approvalStatus')}
              >
                <ListItemText
                  primary="Approval Status"
                  secondary={`${filters.approvalStatus.length}/${approvalStatusOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                {openSections.includes('approvalStatus') ? (
                  <ExpandLessIcon fontSize="small" />
                ) : (
                  <ExpandMoreIcon fontSize="small" />
                )}
              </FilterSectionHeader>
              <Collapse in={openSections.includes('approvalStatus')} timeout="auto">
                <Box style={{ backgroundColor: '#070707d7' }}>
                  {renderFilterItems('approvalStatus', approvalStatusOptions)}
                </Box>
              </Collapse>
            </FilterSection>

            <Divider />

            {/* Work Status Section */}
            <FilterSection>
              <FilterSectionHeader
                button
                onClick={() => toggleSection('workStatus')}
              >
                <ListItemText
                  primary="Work Status"
                  secondary={`${filters.workStatus.length}/${workStatusOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                {openSections.includes('workStatus') ? (
                  <ExpandLessIcon fontSize="small" />
                ) : (
                  <ExpandMoreIcon fontSize="small" />
                )}
              </FilterSectionHeader>
              <Collapse in={openSections.includes('workStatus')} timeout="auto">
                <Box style={{ backgroundColor: '#070707d7' }}>
                  {renderFilterItems('workStatus', workStatusOptions)}
                </Box>
              </Collapse>
            </FilterSection>
          </FilterScrollArea>

          <FilterFooter>
            <Button
              size="small"
              onClick={handleHideAll}
              variant="outlined"
              style={{
                borderColor: '#ddd',
                color: '#666'
              }}
            >
              HIDE ALL
            </Button>
          </FilterFooter>
        </FilterContainer>
      </Drawer>
    </>
  );
};

/* ------------------------------
   Column Selector
-------------------------------- */
const ALL_COLUMNS: ColumnItem[] = [
    // Fixed columns
    { id: 'thumbnail',    label: 'Thumbnail', group: 'Fixed' },
    { id: 'group_1_name', label: 'Name 1',    group: 'Fixed' },
    { id: 'group_2_name', label: 'Name 2',    group: 'Fixed' },
    { id: 'group_3_name', label: 'Name 3',    group: 'Fixed' },

    // LAY
    { id: 'lay_work_status',     label: 'LAY WORK',      group: 'Layout' },
    { id: 'lay_approval_status', label: 'LAY APPR',      group: 'Layout' },
    { id: 'lay_take',            label: 'LAY TAKE',      group: 'Layout' },
    { id: 'lay_submitted_at',    label: 'LAY SUBMITTED', group: 'Layout' },

    // ANM
    { id: 'anm_work_status',     label: 'ANM WORK',      group: 'Animation' },
    { id: 'anm_approval_status', label: 'ANM APPR',      group: 'Animation' },
    { id: 'anm_take',            label: 'ANM TAKE',      group: 'Animation' },
    { id: 'anm_submitted_at',    label: 'ANM SUBMITTED', group: 'Animation' },

    // GNZ
    { id: 'gnz_work_status',     label: 'GNZ WORK',      group: 'GNZ' },
    { id: 'gnz_approval_status', label: 'GNZ APPR',      group: 'GNZ' },
    { id: 'gnz_take',            label: 'GNZ TAKE',      group: 'GNZ' },
    { id: 'gnz_submitted_at',    label: 'GNZ SUBMITTED', group: 'GNZ' },

    // CLOTH
    { id: 'cloth_work_status',     label: 'CLOTH WORK',      group: 'Cloth' },
    { id: 'cloth_approval_status', label: 'CLOTH APPR',      group: 'Cloth' },
    { id: 'cloth_take',            label: 'CLOTH TAKE',      group: 'Cloth' },
    { id: 'cloth_submitted_at',    label: 'CLOTH SUBMITTED', group: 'Cloth' },

    // DSP
    { id: 'dsp_work_status',     label: 'DSP WORK',      group: 'DSP' },
    { id: 'dsp_approval_status', label: 'DSP APPR',      group: 'DSP' },
    { id: 'dsp_take',            label: 'DSP TAKE',      group: 'DSP' },
    { id: 'dsp_submitted_at',    label: 'DSP SUBMITTED', group: 'DSP' },

    // CRD
    { id: 'crd_work_status',     label: 'CRD WORK',      group: 'CRD' },
    { id: 'crd_approval_status', label: 'CRD APPR',      group: 'CRD' },
    { id: 'crd_take',            label: 'CRD TAKE',      group: 'CRD' },
    { id: 'crd_submitted_at',    label: 'CRD SUBMITTED', group: 'CRD' },

    // DRW
    { id: 'drw_work_status',     label: 'DRW WORK',      group: 'DRW' },
    { id: 'drw_approval_status', label: 'DRW APPR',      group: 'DRW' },
    { id: 'drw_take',            label: 'DRW TAKE',      group: 'DRW' },
    { id: 'drw_submitted_at',    label: 'DRW SUBMITTED', group: 'DRW' },

    // MAT
    { id: 'mat_work_status',     label: 'MAT WORK',      group: 'Materials' },
    { id: 'mat_approval_status', label: 'MAT APPR',      group: 'Materials' },
    { id: 'mat_take',            label: 'MAT TAKE',      group: 'Materials' },
    { id: 'mat_submitted_at',    label: 'MAT SUBMITTED', group: 'Materials' },

    // MATNUKE
    { id: 'matnuke_work_status',     label: 'MATNUKE WORK',      group: 'Materials' },
    { id: 'matnuke_approval_status', label: 'MATNUKE APPR',      group: 'Materials' },
    { id: 'matnuke_take',            label: 'MATNUKE TAKE',      group: 'Materials' },
    { id: 'matnuke_submitted_at',    label: 'MATNUKE SUBMITTED', group: 'Materials' },

    // FX
    { id: 'fx_work_status',     label: 'FX WORK',      group: 'Effects' },
    { id: 'fx_approval_status', label: 'FX APPR',      group: 'Effects' },
    { id: 'fx_take',            label: 'FX TAKE',      group: 'Effects' },
    { id: 'fx_submitted_at',    label: 'FX SUBMITTED', group: 'Effects' },

    // CMP
    { id: 'cmp_work_status',     label: 'CMP WORK',      group: 'Composite' },
    { id: 'cmp_approval_status', label: 'CMP APPR',      group: 'Composite' },
    { id: 'cmp_take',            label: 'CMP TAKE',      group: 'Composite' },
    { id: 'cmp_submitted_at',    label: 'CMP SUBMITTED', group: 'Composite' },

    // RTCGNZ
    { id: 'rtcgnz_work_status',     label: 'RTCGNZ WORK',      group: 'RTC' },
    { id: 'rtcgnz_approval_status', label: 'RTCGNZ APPR',      group: 'RTC' },
    { id: 'rtcgnz_take',            label: 'RTCGNZ TAKE',      group: 'RTC' },
    { id: 'rtcgnz_submitted_at',    label: 'RTCGNZ SUBMITTED', group: 'RTC' },

    // RTCMAT
    { id: 'rtcmat_work_status',     label: 'RTCMAT WORK',      group: 'RTC' },
    { id: 'rtcmat_approval_status', label: 'RTCMAT APPR',      group: 'RTC' },
    { id: 'rtcmat_take',            label: 'RTCMAT TAKE',      group: 'RTC' },
    { id: 'rtcmat_submitted_at',    label: 'RTCMAT SUBMITTED', group: 'RTC' },

    // RTCMATNUKE
    { id: 'rtcmatnuke_work_status',     label: 'RTCMATNUKE WORK',      group: 'RTC' },
    { id: 'rtcmatnuke_approval_status', label: 'RTCMATNUKE APPR',      group: 'RTC' },
    { id: 'rtcmatnuke_take',            label: 'RTCMATNUKE TAKE',      group: 'RTC' },
    { id: 'rtcmatnuke_submitted_at',    label: 'RTCMATNUKE SUBMITTED', group: 'RTC' },

    // RTCDRW
    { id: 'rtcdrw_work_status',     label: 'RTCDRW WORK',      group: 'RTC' },
    { id: 'rtcdrw_approval_status', label: 'RTCDRW APPR',      group: 'RTC' },
    { id: 'rtcdrw_take',            label: 'RTCDRW TAKE',      group: 'RTC' },
    { id: 'rtcdrw_submitted_at',    label: 'RTCDRW SUBMITTED', group: 'RTC' },

    // CFXHAIR
    { id: 'cfxhair_work_status',     label: 'CFXHAIR WORK',      group: 'CFX' },
    { id: 'cfxhair_approval_status', label: 'CFXHAIR APPR',      group: 'CFX' },
    { id: 'cfxhair_take',            label: 'CFXHAIR TAKE',      group: 'CFX' },
    { id: 'cfxhair_submitted_at',    label: 'CFXHAIR SUBMITTED', group: 'CFX' },

    // Other
    { id: 'relation', label: 'Relation', group: 'Other' },
];

// Filter out fixed columns from toggle UI
const TOGGLEABLE_COLUMNS = ALL_COLUMNS.filter(col =>
    !['thumbnail', 'group_1_name', 'group_2_name', 'group_3_name'].includes(col.id)
);

export const DEFAULT_COLUMN_STATE: ColumnState = {
    ...TOGGLEABLE_COLUMNS.reduce((acc, col) => {
        acc[col.id] = true;
        return acc;
    }, {} as ColumnState)
};

/* -----------------------------
Styles for Column Selector Drawer
----------------------------- */

const DrawerContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  backgroundColor: theme.palette.background.paper,
}));

const ScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflowY: 'auto',
  minHeight: 0,
  padding: theme.spacing(1, 0),
  backgroundColor: 'transparent',
  
  '&::-webkit-scrollbar': {
    width: 6,
  },
  '&::-webkit-scrollbar-track': {
    background: '#f1f1f1',
    borderRadius: 3,
  },
  '&::-webkit-scrollbar-thumb': {
    background: '#999',
    borderRadius: 3,
    '&:hover': {
      background: '#666',
    },
  },
}));

const Footer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  borderTop: `1px solid ${theme.palette.divider}`,
  backgroundColor: 'transparent',
  flexShrink: 0,
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
}));

/* -----------------------------
Column Selector Component
----------------------------- */

const ColumnSelector: React.FC<{
  columnState: ColumnState;
  onChange: (state: ColumnState) => void;
}> = ({ columnState, onChange }) => {
  const [open, setOpen] = React.useState(false);
  const [openGroups, setOpenGroups] = React.useState<string[]>([]);

  const grouped = React.useMemo(() => {
    return TOGGLEABLE_COLUMNS.reduce((acc, col) => {
      if (!acc[col.group]) acc[col.group] = [];
      acc[col.group].push(col);
      return acc;
    }, {} as Record<string, ColumnItem[]>);
  }, []);

  const activeColumnCount = TOGGLEABLE_COLUMNS.filter(col => columnState[col.id]).length;
  const totalToggleable   = TOGGLEABLE_COLUMNS.length;
  const allHidden         = activeColumnCount === 0;

  const handleHideAll = () => {
    if (allHidden) {
      // Show all toggleable columns
      const newState = { ...columnState };
      TOGGLEABLE_COLUMNS.forEach(col => {
        newState[col.id] = true;
      });
      onChange(newState);
    } else {
      // Hide all toggleable columns
      const newState = { ...columnState };
      TOGGLEABLE_COLUMNS.forEach(col => {
        newState[col.id] = false;
      });
      onChange(newState);
    }
  };

  React.useEffect(() => {
    if (open) {
      setOpenGroups(Object.keys(grouped));
    }
  }, [open, grouped]);

  return (
    <>
      <ControlButton onClick={() => setOpen(true)}>
        <ViewColumnIcon fontSize="small" />
        <Typography 
          variant="body2"
          style={{color: "#1976d2", fontWeight: 600}}
        >
          Columns ({activeColumnCount + 4}/{ALL_COLUMNS.length})
        </Typography>
      </ControlButton>

      <Drawer 
        anchor="right" 
        open={open} 
        onClose={() => setOpen(false)}
        PaperProps={{ 
          style: { 
            width: 320,
            maxHeight: '80vh',
            marginTop: '150px',
            marginRight: '150px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            overflow: 'hidden',
            backgroundColor: '#444242af',
          } 
        }}
      >
        <DrawerContainer>
          <ScrollArea>
            {Object.entries(grouped).map(([group, cols], index) => (
              <React.Fragment key={group}>
                {index !== 0 && <Divider />}
                <ListItem
                  button
                  onClick={() =>
                    setOpenGroups(prev =>
                      prev.includes(group)
                        ? prev.filter(g => g !== group)
                        : [...prev, group]
                    )
                  }
                  style={{ backgroundColor: '#444242af' }}
                >
                  <ListItemText 
                    primary={group.substring(0, 3).toUpperCase()}
                  />
                  {openGroups.includes(group) ? (
                    <ExpandLessIcon fontSize="small" />
                  ) : (
                    <ExpandMoreIcon fontSize="small" />
                  )}
                </ListItem>

                <Collapse in={openGroups.includes(group)} timeout="auto">
                  <Box>
                    {cols.map(col => (
                      <ListItem
                        key={col.id}
                        button
                        dense
                        style={{ 
                          paddingTop: 2, 
                          paddingBottom: 2,
                          paddingLeft: 32,
                          backgroundColor: '#070707d7'
                        }}
                        onClick={() =>
                          onChange({
                            ...columnState,
                            [col.id]: !columnState[col.id],
                          })
                        }
                      >
                        <Checkbox
                          checked={columnState[col.id] || false}
                          size="small"
                          edge="start"
                          disableRipple
                          style={{ padding: 4, color: '#dbe1e7' }}
                        />
                        <ListItemText 
                          primary={col.label} 
                          primaryTypographyProps={{ variant: 'body2', style: { color: '#dbe1e7' } }}
                        />
                      </ListItem>
                    ))}
                  </Box>
                </Collapse>
              </React.Fragment>
            ))}
          </ScrollArea>

          <Footer>
            <Button 
              size="small" 
              onClick={handleHideAll}
              variant="outlined"
              style={{ borderColor: '#ddd', color: '#666' }}
            >
              {allHidden ? "SHOW ALL" : "HIDE ALL"}
            </Button>
            <Button 
              size="small" 
              onClick={() => setOpen(false)}
              variant="contained"
              style={{ 
                backgroundColor: '#1976d2', 
                color: '#fff',
                marginLeft: 8
              }}
            >
              SAVE
            </Button>
          </Footer>
        </DrawerContainer>
      </Drawer>
    </>
  );
};

/* ------------------------------
   View Toggle
-------------------------------- */

const ViewToggle: React.FC<{
  viewMode: ViewMode;
  onChange: (mode: ViewMode) => void;
}> = ({ viewMode, onChange }) => (
  <ToggleContainer>
    <IconButton
      onClick={() => onChange("list")}
      size="small"
      style={{ padding: 8 }}
      title="List View"
    >
      <ViewListIcon color={viewMode === "list" ? "primary" : "action"} />
    </IconButton>
    <IconButton
      onClick={() => onChange("group")}
      size="small"
      style={{ padding: 8 }}
      title="Group View"
    >
      <ViewModuleIcon color={viewMode === "group" ? "primary" : "action"} />
    </IconButton>
  </ToggleContainer>
);

/* ------------------------------
   Main Toolbar
-------------------------------- */

const ShotDataTableToolbar: React.FC<Props> = ({
  viewMode,
  onViewChange,
  searchValue,
  onSearchChange,
  filters,
  onFilterChange,
  columnsState,
  onColumnsChange,
  onReset,
  shotGroupOptions,
}) => {

  const DEFAULT_FILTERS: Filters = {
    shotGroups: [],
    approvalStatus: [],
    workStatus: [],
  };

  const handleReset = () => {
    onSearchChange("");
    onFilterChange(DEFAULT_FILTERS);
    
    // Reset only toggleable columns to true
    const resetColumnsState = { ...DEFAULT_COLUMN_STATE };
    onColumnsChange(resetColumnsState);
    
    if (onReset) {
      onReset();
    }
  };

  const hasChanges = 
    searchValue !== "" ||
    Object.values(filters).flat().length > 0 ||
    // Compare only toggleable columns
    Object.entries(columnsState)
      .filter(([id]) => !['thumbnail', 'group_1_name', 'group_2_name', 'group_3_name'].includes(id))
      .some(([id, value]) => value !== DEFAULT_COLUMN_STATE[id]);

  return (
    <StyledToolbar>
      <LeftSection>
        <ViewToggle viewMode={viewMode} onChange={onViewChange} />
      </LeftSection>

      <RightSection>
        <SearchContainer>
          <StyledInput
            value={searchValue}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search groups..."
          />
        </SearchContainer>

        <FilterMenu
          filters={filters}
          onChange={onFilterChange}
          shotGroupOptions={shotGroupOptions}
        />

        <ColumnSelector
          columnState={columnsState}
          onChange={onColumnsChange}
        />

          <ResetButton
            variant="outlined"
            size="small"
            startIcon={<RestoreIcon />}
            onClick={handleReset}
            disabled={!hasChanges}
          >
            Reset
          </ResetButton>
      </RightSection>
    </StyledToolbar>
  );
};

export default ShotDataTableToolbar;