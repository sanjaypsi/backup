import React from "react";
import {
    Toolbar,
    Typography,
    IconButton,
    Box,
    List,
    ListItem,
    ListItemText,
    Divider,
    Collapse,
    Checkbox,
    Button,
    Drawer,
} from "@material-ui/core";
import { styled } from "@material-ui/core/styles";
import ViewListIcon from "@material-ui/icons/ViewList";
import ViewModuleIcon from "@material-ui/icons/ViewModule";
import FilterListIcon from "@material-ui/icons/FilterList";
import ExpandLessIcon from "@material-ui/icons/ExpandLess";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ViewColumnIcon from "@material-ui/icons/ViewColumn";
import RestoreIcon from "@material-ui/icons/Restore";
import { theme } from "../../../theme";

/* ------------------------------
   Styled Components
-------------------------------- */

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderBottom: `1px solid ${theme.palette.divider}`,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding: theme.spacing(1, 2),
  minHeight: 34,
}));

const LeftSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 12,
});

const RightSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 8,
});

const ToggleContainer = styled(Box)({
  display: "flex",
  borderRadius: 4,
});

const SearchContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  backgroundColor: theme.palette.background.default,
  borderRadius: 6,
  padding: "4px 12px",
  border: `1px solid ${theme.palette.divider}`,
  height: 30,
  width: 200,
}));

const StyledInput = styled("input")({
  color: "inherit",
  backgroundColor: "transparent",
  border: "none",
  outline: "none",
  width: 200,
  fontSize: 14,
  "&::placeholder": {
    color: "#999",
    opacity: 1,
  },
});

const ControlButton = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  gap: 4,
  padding: theme.spacing(0.5, 1),
  borderRadius: 4,
  cursor: "pointer",
  height: 36,
  border: `1px solid transparent`,
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
    borderColor: theme.palette.divider,
  },
}));

const ResetButton = styled(Button)(({ theme }) => ({
  height: 36,
  padding: theme.spacing(0.5, 1.5),
  color: theme.palette.text.secondary,
  borderColor: theme.palette.divider,
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
    borderColor: theme.palette.text.secondary,
  },
}));

/* ------------------------------
   Types
-------------------------------- */

type Filters = {
  shotGroups: string[];
  approvalStatus: string[];
  workStatus: string[];
};

export type ViewMode = "list" | "group";

type ColumnItem = {
  id: string;
  label: string;
  group: string;
};

export type ColumnState = {
  [key: string]: boolean;
};

type Props = {
  viewMode: ViewMode;
  onViewChange: (mode: ViewMode) => void;
  searchValue: string;
  onSearchChange: (value: string) => void;
  filters: Filters;
  onFilterChange: (newFilters: Filters) => void;
  columnsState: ColumnState;
  onColumnsChange: (newColumns: ColumnState) => void;
  onReset?: () => void;
  shotGroupOptions: { id: string; label: string }[];
  groupSortDir: 'asc' | 'desc';
  onGroupSortToggle: () => void;
  phaseComponents: { [key: string]: string[] };   // ← new
};

/* ------------------------------
   Dynamic Column Builder
-------------------------------- */

// Known phase order — mirrors SHOT_PHASES in ShotsDataTable / ShotsDataTableGroup
const KNOWN_PHASE_ORDER = [
    'lay', 'anm', 'gnz', 'mat', 'matnuke', 'fx', 'cmp',
    'dsp', 'cloth', 'cfxhair', 'crd', 'drw',
    'rtcgnz', 'rtcmat', 'rtcmatnuke', 'rtcdrw',
];

const getPhaseComponentIds = (
    phase: string,
    phaseComponents: { [key: string]: string[] },
): string[] => {
    const ids = (phaseComponents && phaseComponents[phase]) || [];
    return ids.filter(id => id.toLowerCase() !== phase.toLowerCase());
};

const getOrderedPhases = (phaseComponents: { [key: string]: string[] }): string[] => {
    const settingPhases = Object.keys(phaseComponents || {});
    const settingByLower: { [key: string]: string } = {};
    settingPhases.forEach(s => { settingByLower[s.toLowerCase()] = s; });

    const ordered: string[] = [];
    KNOWN_PHASE_ORDER.forEach(p => {
        if (settingByLower[p]) ordered.push(settingByLower[p]);
        else ordered.push(p);
    });
    settingPhases.forEach(s => {
        if (!KNOWN_PHASE_ORDER.includes(s.toLowerCase())) ordered.push(s);
    });
    return ordered;
};

/* Build the full column list dynamically from pipeline phase components. */
const buildAllColumns = (
    phaseComponents: { [key: string]: string[] } = {},
): ColumnItem[] => {
    const fixed: ColumnItem[] = [
        { id: 'thumbnail',    label: 'Thumbnail', group: 'Fixed' },
        { id: 'group_1_name', label: 'Name 1',    group: 'Fixed' },
        { id: 'group_2_name', label: 'Name 2',    group: 'Fixed' },
        { id: 'group_3_name', label: 'Name 3',    group: 'Fixed' },
    ];

    const orderedPhases = getOrderedPhases(phaseComponents);

    const phaseCols: ColumnItem[] = orderedPhases.flatMap(phase => {
        const colBase = phase.toLowerCase();
        const label   = phase.toUpperCase();
        const groupId = label;

        const base: ColumnItem[] = [
            { id: `${colBase}_work_status`,     label: `${label} WORK`, group: groupId },
            { id: `${colBase}_approval_status`, label: `${label} APPR`, group: groupId },
            { id: `${colBase}_take`,            label: `${label} TAKE`, group: groupId },
        ];

        const componentIds = getPhaseComponentIds(phase, phaseComponents);

        if (componentIds.length === 0) {
            // Fallback: phase-level submitted_at column
            base.push({
                id:    `${colBase}_submitted_at`,
                label: `${label} SUBMITTED`,
                group: groupId,
            });
        }

        const compCols: ColumnItem[] = componentIds.map(id => ({
            id,
            label: `${id.toUpperCase()} SUBMITTED`,
            group: groupId,
        }));

        return [...base, ...compCols];
    });

    return [
        ...fixed,
        ...phaseCols,
        { id: 'relation', label: 'Relation', group: 'Other' },
    ];
};

const FIXED_IDS = ['thumbnail', 'group_1_name', 'group_2_name', 'group_3_name'];

/* Build the default column state (all toggleable columns visible). */
export const buildDefaultColumnState = (
    phaseComponents: { [key: string]: string[] } = {},
): ColumnState => {
    const all = buildAllColumns(phaseComponents);
    const toggleable = all.filter(col => !FIXED_IDS.includes(col.id));
    return toggleable.reduce((acc, col) => {
        acc[col.id] = true;
        return acc;
    }, {} as ColumnState);
};

/* ------------------------------
   Filter Menu (unchanged)
-------------------------------- */

const FilterContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  backgroundColor: theme.palette.background.paper,
}));

const FilterHeader = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottom: `1px solid ${theme.palette.divider}`,
  flexShrink: 0,
  backgroundColor: 'transparent',
}));

const FilterScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflowY: 'auto',
  minHeight: 0,
  padding: theme.spacing(1, 0),
  backgroundColor: 'transparent',
  '&::-webkit-scrollbar': { width: 6 },
  '&::-webkit-scrollbar-track': { background: '#f1f1f1', borderRadius: 3 },
  '&::-webkit-scrollbar-thumb': {
    background: '#999',
    borderRadius: 3,
    '&:hover': { background: '#666' },
  },
}));

const FilterFooter = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  borderTop: `1px solid ${theme.palette.divider}`,
  backgroundColor: 'transparent',
  flexShrink: 0,
  display: 'flex',
  justifyContent: 'flex-end',
  alignItems: 'center',
}));

const FilterSection = styled(Box)({
  width: '100%',
});

const FilterSectionHeader = styled(ListItem)(({ theme }) => ({
  backgroundColor: theme.palette.action.hover,
  '&:hover': {
    backgroundColor: theme.palette.action.selected,
  },
}));

const FilterMenu: React.FC<{
  filters: Filters;
  onChange: (newFilters: Filters) => void;
  shotGroupOptions: { id: string; label: string }[];
}> = ({ filters, onChange, shotGroupOptions }) => {
  const [open, setOpen] = React.useState(false);
  const [openSections, setOpenSections] = React.useState<string[]>(['approvalStatus', 'workStatus']);

  const handleFilterChange = (section: keyof Filters, optionId: string) => {
    const currentArray = filters[section] as string[] || [];
    const newArray = currentArray.includes(optionId)
      ? currentArray.filter(v => v !== optionId)
      : [...currentArray, optionId];
    onChange({ ...filters, [section]: newArray });
  };

  const handleClearAll = () => {
    onChange({ shotGroups: [], approvalStatus: [], workStatus: [] });
  };

  const handleHideAll = () => setOpen(false);

  const activeFilterCount = Object.values(filters).flat().length;

  const toggleSection = (section: string) => {
    setOpenSections(prev =>
      prev.includes(section) ? prev.filter(s => s !== section) : [...prev, section]
    );
  };

  const isChildSelected = (section: string, childId: string) => {
    return (filters[section as keyof Filters] as string[] || []).includes(childId);
  };

  const approvalStatusOptions = [
    { id: "check", label: "Check", phase: "Review" },
    { id: "clientReview", label: "Client Review", phase: "Review" },
    { id: "dirReview", label: "Dir Review", phase: "Review" },
    { id: "epdReview", label: "EPD Review", phase: "Review" },
    { id: "clientOnHold", label: "Client On Hold", phase: "Hold" },
    { id: "dirOnHold", label: "Dir On Hold", phase: "Hold" },
    { id: "epdOnHold", label: "EPD On Hold", phase: "Hold" },
    { id: "execRetake", label: "Exec Retake", phase: "Retake" },
    { id: "clientRetake", label: "Client Retake", phase: "Retake" },
    { id: "dirRetake", label: "Dir Retake", phase: "Retake" },
    { id: "epdRetake", label: "EPD Retake", phase: "Retake" },
    { id: "clientApproved", label: "Client Approved", phase: "Approved" },
    { id: "dirApproved", label: "Dir Approved", phase: "Approved" },
    { id: "epdApproved", label: "EPD Approved", phase: "Approved" },
    { id: "other", label: "Other", phase: "Other" },
    { id: "omit", label: "Omit", phase: "Other" },
  ];

  const workStatusOptions = [
    { id: "check", label: "Check", phase: "Review" },
    { id: "cgsvOnHold", label: "CGSV On Hold", phase: "Hold" },
    { id: "svOnHold", label: "SV On Hold", phase: "Hold" },
    { id: "leadOnHold", label: "Lead On Hold", phase: "Hold" },
    { id: "cgsvRetake", label: "CGSV Retake", phase: "Retake" },
    { id: "svRetake", label: "SV Retake", phase: "Retake" },
    { id: "leadRetake", label: "Lead Retake", phase: "Retake" },
    { id: "cgsvApproved", label: "CGSV Approved", phase: "Approved" },
    { id: "svApproved", label: "SV Approved", phase: "Approved" },
    { id: "leadApproved", label: "Lead Approved", phase: "Approved" },
    { id: "svOther", label: "SV Other", phase: "Other" },
    { id: "leadOther", label: "Lead Other", phase: "Other" },
  ];

  const getOptionsByPhase = (options: Array<{ id: string; label: string; phase?: string }>) => {
    const phases: { [key: string]: typeof options } = {};
    options.forEach(option => {
      const phase = option.phase || 'Other';
      if (!phases[phase]) phases[phase] = [];
      phases[phase].push(option);
    });
    return phases;
  };

  const renderFilterItems = (section: string, options: Array<{ id: string; label: string; phase?: string }>) => {
    if (section === 'approvalStatus' || section === 'workStatus') {
      const optionsByPhase = getOptionsByPhase(options);
      const phaseOrder = ['Review', 'Hold', 'Retake', 'Approved', 'Other'];

      return phaseOrder.map(phase => {
        const phaseOptions = optionsByPhase[phase] || [];
        if (phaseOptions.length === 0) return null;

        return (
          <Box key={phase}>
            {phaseOptions.map(option => (
              <ListItem
                key={option.id}
                button
                dense
                onClick={(e) => {
                  e.stopPropagation();
                  handleFilterChange(section as keyof Filters, option.id);
                }}
                style={{ paddingTop: 2, paddingBottom: 2, paddingLeft: 16 }}
              >
                <Checkbox
                  edge="start"
                  checked={isChildSelected(section, option.id)}
                  size="small"
                  disableRipple
                  style={{ padding: 4 }}
                />
                <ListItemText
                  primary={option.label}
                  primaryTypographyProps={{ variant: 'body2' }}
                />
              </ListItem>
            ))}
          </Box>
        );
      });
    } else {
      return options.map(option => (
        <ListItem
          key={option.id}
          button
          dense
          onClick={(e) => {
            e.stopPropagation();
            handleFilterChange(section as keyof Filters, option.id);
          }}
          style={{ paddingTop: 2, paddingBottom: 2, paddingLeft: 16 }}
        >
          <Checkbox
            edge="start"
            checked={isChildSelected(section, option.id)}
            size="small"
            disableRipple
            style={{ padding: 4 }}
          />
          <ListItemText
            primary={option.label}
            primaryTypographyProps={{ variant: 'body2' }}
          />
        </ListItem>
      ));
    }
  };

  return (
    <>
      <ControlButton onClick={() => setOpen(true)}>
        <FilterListIcon fontSize="small" />
        <Typography variant="body2">Filter</Typography>
        {activeFilterCount > 0 && (
          <Box
            component="span"
            style={{
              backgroundColor: "#1976d2",
              color: "#fff",
              borderRadius: "50%",
              width: 18,
              height: 18,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              marginLeft: 4,
            }}
          >
            {activeFilterCount}
          </Box>
        )}
      </ControlButton>

      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          style: {
            width: 320,
            maxHeight: '80vh',
            marginTop: '150px',
            marginRight: '200px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            overflow: 'hidden',
            backgroundColor: 'transparent',
          }
        }}
      >
        <FilterContainer>
          <FilterHeader>
            <Typography variant="h6">Filters</Typography>
            <Button
              size="small"
              onClick={handleClearAll}
              disabled={activeFilterCount === 0}
              style={{ minWidth: 'auto' }}
            >
              CLEAR ALL
            </Button>
          </FilterHeader>

          <FilterScrollArea>
            <FilterSection>
              <FilterSectionHeader button onClick={() => toggleSection('shotGroups')}>
                <ListItemText
                  primary="Shot Groups"
                  secondary={`${filters.shotGroups.length}/${shotGroupOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                {openSections.includes('shotGroups')
                  ? <ExpandLessIcon fontSize="small" />
                  : <ExpandMoreIcon fontSize="small" />}
              </FilterSectionHeader>
              <Collapse in={openSections.includes('shotGroups')} timeout="auto">
                <Box style={{ backgroundColor: '#070707d7' }}>
                  {renderFilterItems('shotGroups', shotGroupOptions)}
                </Box>
              </Collapse>
            </FilterSection>

            <Divider />

            <FilterSection>
              <FilterSectionHeader button onClick={() => toggleSection('approvalStatus')}>
                <ListItemText
                  primary="Approval Status"
                  secondary={`${filters.approvalStatus.length}/${approvalStatusOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                {openSections.includes('approvalStatus')
                  ? <ExpandLessIcon fontSize="small" />
                  : <ExpandMoreIcon fontSize="small" />}
              </FilterSectionHeader>
              <Collapse in={openSections.includes('approvalStatus')} timeout="auto">
                <Box style={{ backgroundColor: '#070707d7' }}>
                  {renderFilterItems('approvalStatus', approvalStatusOptions)}
                </Box>
              </Collapse>
            </FilterSection>

            <Divider />

            <FilterSection>
              <FilterSectionHeader button onClick={() => toggleSection('workStatus')}>
                <ListItemText
                  primary="Work Status"
                  secondary={`${filters.workStatus.length}/${workStatusOptions.length}`}
                  secondaryTypographyProps={{ variant: 'caption' }}
                />
                {openSections.includes('workStatus')
                  ? <ExpandLessIcon fontSize="small" />
                  : <ExpandMoreIcon fontSize="small" />}
              </FilterSectionHeader>
              <Collapse in={openSections.includes('workStatus')} timeout="auto">
                <Box style={{ backgroundColor: '#070707d7' }}>
                  {renderFilterItems('workStatus', workStatusOptions)}
                </Box>
              </Collapse>
            </FilterSection>
          </FilterScrollArea>

          <FilterFooter>
            <Button
              size="small"
              onClick={handleHideAll}
              variant="outlined"
              style={{ borderColor: '#ddd', color: '#666' }}
            >
              HIDE ALL
            </Button>
          </FilterFooter>
        </FilterContainer>
      </Drawer>
    </>
  );
};

/* ------------------------------
   Column Selector
-------------------------------- */

const DrawerContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  backgroundColor: theme.palette.background.paper,
}));

const ScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflowY: 'auto',
  minHeight: 0,
  padding: theme.spacing(1, 0),
  backgroundColor: 'transparent',
  '&::-webkit-scrollbar': { width: 6 },
  '&::-webkit-scrollbar-track': { background: '#f1f1f1', borderRadius: 3 },
  '&::-webkit-scrollbar-thumb': {
    background: '#999',
    borderRadius: 3,
    '&:hover': { background: '#666' },
  },
}));

const Footer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1.5, 2),
  borderTop: `1px solid ${theme.palette.divider}`,
  backgroundColor: 'transparent',
  flexShrink: 0,
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
}));

const ColumnSelector: React.FC<{
  columnState:     ColumnState;
  onChange:        (state: ColumnState) => void;
  phaseComponents: { [key: string]: string[] };
}> = ({ columnState, onChange, phaseComponents }) => {
  const [open, setOpen] = React.useState(false);
  const [openGroups, setOpenGroups] = React.useState<string[]>([]);

  const allColumns = React.useMemo(
    () => buildAllColumns(phaseComponents),
    [phaseComponents],
  );

  const toggleableColumns = React.useMemo(
    () => allColumns.filter(col => !FIXED_IDS.includes(col.id)),
    [allColumns],
  );

  const grouped = React.useMemo(() => {
    return toggleableColumns.reduce((acc, col) => {
      if (!acc[col.group]) acc[col.group] = [];
      acc[col.group].push(col);
      return acc;
    }, {} as Record<string, ColumnItem[]>);
  }, [toggleableColumns]);

  const activeColumnCount = toggleableColumns.filter(col => columnState[col.id]).length;
  const allHidden         = activeColumnCount === 0;

  const handleHideAll = () => {
    const newState = { ...columnState };
    toggleableColumns.forEach(col => {
      newState[col.id] = allHidden ? true : false;
    });
    onChange(newState);
  };

  React.useEffect(() => {
    if (open) setOpenGroups(Object.keys(grouped));
  }, [open, grouped]);

  return (
    <>
      <ControlButton onClick={() => setOpen(true)}>
        <ViewColumnIcon fontSize="small" />
        <Typography
          variant="body2"
          color="primary"
          style={{
            backgroundColor: theme.palette.action.hover,
            color: '#00b7ff',
            borderColor: '#00b7ff',
            fontWeight: 400,
            marginLeft: 4,
            paddingInlineStart: 4,
          }}
        >
          Columns ({activeColumnCount + 4}/{allColumns.length})
        </Typography>
      </ControlButton>

      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          style: {
            width: 320,
            maxHeight: '80vh',
            marginTop: '150px',
            marginRight: '150px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            overflow: 'hidden',
            backgroundColor: '#444242af',
          }
        }}
      >
        <DrawerContainer>
          <ScrollArea>
            {Object.entries(grouped).map(([group, cols], index) => (
              <React.Fragment key={group}>
                {index !== 0 && <Divider />}
                <ListItem
                  button
                  onClick={() =>
                    setOpenGroups(prev =>
                      prev.includes(group)
                        ? prev.filter(g => g !== group)
                        : [...prev, group]
                    )
                  }
                  style={{ backgroundColor: '#444242af' }}
                >
                  <ListItemText primary={group.substring(0, 3).toUpperCase()} />
                  {openGroups.includes(group)
                    ? <ExpandLessIcon fontSize="small" />
                    : <ExpandMoreIcon fontSize="small" />}
                </ListItem>

                <Collapse in={openGroups.includes(group)} timeout="auto">
                  <Box>
                    {cols.map(col => (
                      <ListItem
                        key={col.id}
                        button
                        dense
                        style={{
                          paddingTop: 2,
                          paddingBottom: 2,
                          paddingLeft: 32,
                          backgroundColor: '#070707d7',
                        }}
                        onClick={() =>
                          onChange({
                            ...columnState,
                            [col.id]: !columnState[col.id],
                          })
                        }
                      >
                        <Checkbox
                          checked={columnState[col.id] || false}
                          size="small"
                          edge="start"
                          disableRipple
                          style={{ padding: 4, color: '#dbe1e7' }}
                        />
                        <ListItemText
                          primary={col.label}
                          primaryTypographyProps={{ variant: 'body2', style: { color: '#dbe1e7' } }}
                        />
                      </ListItem>
                    ))}
                  </Box>
                </Collapse>
              </React.Fragment>
            ))}
          </ScrollArea>

          <Footer>
            <Button
              size="small"
              onClick={handleHideAll}
              variant="outlined"
              style={{ borderColor: '#ddd', color: '#666' }}
            >
              {allHidden ? "SHOW ALL" : "HIDE ALL"}
            </Button>
            <Button
              size="small"
              onClick={() => setOpen(false)}
              variant="contained"
              style={{
                backgroundColor: '#1976d2',
                color: '#fff',
                marginLeft: 8
              }}
            >
              SAVE
            </Button>
          </Footer>
        </DrawerContainer>
      </Drawer>
    </>
  );
};

/* ------------------------------
   View Toggle
-------------------------------- */

const ViewToggle: React.FC<{
  viewMode: ViewMode;
  onChange: (mode: ViewMode) => void;
}> = ({ viewMode, onChange }) => (
  <ToggleContainer>
    <IconButton
      onClick={() => onChange("list")}
      size="small"
      style={{ padding: 8 }}
      title="List View"
    >
      <ViewListIcon color={viewMode === "list" ? "primary" : "action"} />
    </IconButton>
    <IconButton
      onClick={() => onChange("group")}
      size="small"
      style={{ padding: 8 }}
      title="Group View"
    >
      <ViewModuleIcon color={viewMode === "group" ? "primary" : "action"} />
    </IconButton>
  </ToggleContainer>
);

/* ------------------------------
   Main Toolbar
-------------------------------- */

const ShotDataTableToolbar: React.FC<Props> = ({
  viewMode,
  onViewChange,
  searchValue,
  onSearchChange,
  filters,
  onFilterChange,
  columnsState,
  onColumnsChange,
  onReset,
  shotGroupOptions,
  groupSortDir,
  onGroupSortToggle,
  phaseComponents,
}) => {

  const DEFAULT_FILTERS: Filters = {
    shotGroups: [],
    approvalStatus: [],
    workStatus: [],
  };

  const defaultColumnState = React.useMemo(
    () => buildDefaultColumnState(phaseComponents),
    [phaseComponents],
  );

  const handleReset = () => {
    onSearchChange("");
    onFilterChange(DEFAULT_FILTERS);
    onColumnsChange({ ...defaultColumnState });
    if (onReset) onReset();
  };

  const hasChanges =
    searchValue !== "" ||
    Object.values(filters).flat().length > 0 ||
    Object.entries(columnsState)
      .filter(([id]) => !FIXED_IDS.includes(id))
      .some(([id, value]) => value !== defaultColumnState[id]);

  return (
    <StyledToolbar>
      <LeftSection>
        <ViewToggle viewMode={viewMode} onChange={onViewChange} />
        {viewMode === "group" && (
          <Box display="flex" alignItems="center" ml={2} style={{ gap: 8 }}>
            <Typography variant="caption" style={{ color: '#aaa', fontSize: 11 }}>
              Sort Groups:
            </Typography>
            <Button
              size="small"
              variant="outlined"
              onClick={onGroupSortToggle}
              style={{
                height: 24,
                fontSize: 11,
                minWidth: 80,
                padding: '0 6px',
                color: '#00b7ff',
                borderColor: '#00b7ff',
              }}
            >
              Name {groupSortDir === 'asc' ? 'A-Z ↑' : 'Z-A ↓'}
            </Button>
          </Box>
        )}
      </LeftSection>

      <RightSection>
        <SearchContainer>
          <StyledInput
            value={searchValue}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search groups..."
          />
        </SearchContainer>

        <FilterMenu
          filters={filters}
          onChange={onFilterChange}
          shotGroupOptions={shotGroupOptions}
        />

        <ColumnSelector
          columnState={columnsState}
          onChange={onColumnsChange}
          phaseComponents={phaseComponents}
        />

        <ResetButton
          variant="outlined"
          size="small"
          startIcon={<RestoreIcon />}
          onClick={handleReset}
          disabled={!hasChanges}
        >
          Reset
        </ResetButton>
      </RightSection>
    </StyledToolbar>
  );
};

export default ShotDataTableToolbar;