import React from "react";
import {
    Toolbar,
    Typography,
    IconButton,
    Box,
    Menu,
    List,
    ListItem,
    ListItemText,
    Divider,
    Collapse,
    Popover,
    Checkbox,
    Button,
} from "@material-ui/core";
import { styled } from "@material-ui/core/styles";
import ViewListIcon from "@material-ui/icons/ViewList";
import ViewModuleIcon from "@material-ui/icons/ViewModule";
import FilterListIcon from "@material-ui/icons/FilterList";
import ExpandLessIcon from "@material-ui/icons/ExpandLess";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ViewColumnIcon from "@material-ui/icons/ViewColumn";
import RestoreIcon from "@material-ui/icons/Restore";

/* ------------------------------
   Styled Components
-------------------------------- */

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderBottom: `1px solid ${theme.palette.divider}`,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding: theme.spacing(1, 2),
  minHeight: 56,
}));

const LeftSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 12,
});

const RightSection = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: 8,
});

/* Toggle */
const ToggleContainer = styled(Box)({
  display: "flex",
  borderRadius: 4,
});

/* Search */
const SearchContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  backgroundColor: theme.palette.background.default,
  borderRadius: 6,
  padding: "4px 12px",
  border: `1px solid ${theme.palette.divider}`,
  height: 36,
}));

const StyledInput = styled("input")({
  color: "inherit",
  backgroundColor: "transparent",
  border: "none",
  outline: "none",
  width: 200,
  fontSize: 14,
  "&::placeholder": {
    color: "#999",
    opacity: 1,
  },
});

/* Control Buttons */
const ControlButton = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  gap: 4,
  padding: theme.spacing(0.5, 1),
  borderRadius: 4,
  cursor: "pointer",
  height: 36,
  border: `1px solid transparent`,
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
    borderColor: theme.palette.divider,
  },
}));

/* Reset Button */
const ResetButton = styled(Button)(({ theme }) => ({
  height: 36,
  padding: theme.spacing(0.5, 1.5),
  marginLeft: theme.spacing(1),
  color: theme.palette.text.secondary,
  borderColor: theme.palette.divider,
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
    borderColor: theme.palette.text.secondary,
  },
}));

/* ------------------------------
   Types
-------------------------------- */

type Filters = {
  assetGroups: string[];
  approvalStatus: string[];
  workStatus: string[];
};

export type ViewMode = "list" | "group";

type ColumnItem = {
  id: string;
  label: string;
  group: string;
};

type ColumnState = {
  [key: string]: boolean;
};

type Props = {
  viewMode: ViewMode;
  onViewChange: (mode: ViewMode) => void;
  searchValue: string;
  onSearchChange: (value: string) => void;
  filters: Filters;
  onFilterChange: (newFilters: Filters) => void;
  columnsState: ColumnState;
  onColumnsChange: (newColumns: ColumnState) => void;
  onReset?: () => void; // Optional reset handler
};

/* ------------------------------
   Filter Menu
-------------------------------- */

const FilterPanel = styled(Box)({
  display: "flex",
  flexDirection: "column",
  gap: 8,
});

const FilterMenu: React.FC<{
  filters: Filters;
  onChange: (newFilters: Filters) => void;
}> = ({ filters, onChange }) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const filterOptions = {
    assetGroups: ["Buildings", "Vehicles", "Characters", "Environment"],
    approvalStatus: ["Approved", "Pending", "Changes Requested"],
    workStatus: ["Not Started", "In Progress", "Complete", "Blocked"],
  };

  const [openSection, setOpenSection] = React.useState<string | null>(null);

  const handleFilterChange = (section: string, value: string) => {
    const currentValues = filters[section as keyof Filters] as string[];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    
    onChange({
      ...filters,
      [section]: newValues,
    });
  };

  const activeFilterCount = Object.values(filters).flat().length;

  return (
    <>
      <ControlButton onClick={(e) => setAnchorEl(e.currentTarget)}>
        <FilterListIcon fontSize="small" />
        <Typography variant="body2">Filter</Typography>
        {activeFilterCount > 0 && (
          <Box
            component="span"
            style={{
              backgroundColor: "#1976d2", // primary.main
              color: "#fff", // primary.contrastText
              borderRadius: "50%",
              width: 18,
              height: 18,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              marginLeft: 4,
            }}
          >
            {activeFilterCount}
          </Box>
        )}
      </ControlButton>

      <Menu
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        PaperProps={{ style: { width: 250, maxHeight: 400 } }}
      >
        <FilterPanel>
          <List dense>
            <ListItem button onClick={() => {
              onChange({
                assetGroups: [],
                approvalStatus: [],
                workStatus: [],
              });
              setAnchorEl(null);
            }}>
              <ListItemText primary="Clear all filters" />
            </ListItem>

            <Divider />

            {Object.entries(filterOptions).map(([section, options]) => (
              <React.Fragment key={section}>
                <ListItem button onClick={() =>
                  setOpenSection(openSection === section ? null : section)
                }>
                  <ListItemText 
                    primary={section.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} 
                  />
                  <Box display="flex" alignItems="center" style={{ gap: 8 }}>
                    {filters[section as keyof Filters].length > 0 && (
                      <Typography variant="caption" color="primary">
                        ({filters[section as keyof Filters].length})
                      </Typography>
                    )}
                    {openSection === section ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                  </Box>
                </ListItem>

                <Collapse in={openSection === section} timeout="auto" unmountOnExit>
                  <Box pl={2} pr={1} pb={1} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {options.map(option => (
                      <ListItem 
                        key={option} 
                        button 
                        onClick={() => handleFilterChange(section, option)}
                        dense
                      >
                        <Checkbox
                          edge="start"
                          checked={filters[section as keyof Filters].includes(option)}
                          size="small"
                          disableRipple
                        />
                        <ListItemText primary={option} />
                      </ListItem>
                    ))}
                  </Box>
                </Collapse>
              </React.Fragment>
            ))}
          </List>
        </FilterPanel>
      </Menu>
    </>
  );
};

/* ------------------------------
   Column Selector
-------------------------------- */

const ALL_COLUMNS: ColumnItem[] = [
  { id: "shotName", label: "Shot Name", group: "Basic Info" },
  { id: "assetGroup", label: "Asset Group", group: "Basic Info" },
  { id: "approvalStatus", label: "Approval Status", group: "Status" },
  { id: "workStatus", label: "Work Status", group: "Status" },
];

// Default column state (all columns visible)
const DEFAULT_COLUMN_STATE: ColumnState = ALL_COLUMNS.reduce((acc, col) => ({
  ...acc,
  [col.id]: true,
}), {});

const ColumnsPanel = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: theme.spacing(1, 0),
  minWidth: 240,
}));

const ColumnSelector: React.FC<{
  columnState: ColumnState;
  onChange: (columnState: ColumnState) => void;
}> = ({ columnState, onChange }) => {

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [openGroups, setOpenGroups] = React.useState<string[]>([]);

  const grouped = ALL_COLUMNS.reduce((acc, col) => {
    if (!acc[col.group]) acc[col.group] = [];
    acc[col.group].push(col);
    return acc;
  }, {} as Record<string, ColumnItem[]>);

  const activeColumnCount = Object.values(columnState).filter(Boolean).length;

  const handleResetColumns = () => {
    onChange(DEFAULT_COLUMN_STATE);
  };

  return (
    <>
      <ControlButton onClick={(e) => setAnchorEl(e.currentTarget)}>
        <ViewColumnIcon fontSize="small" />
        <Typography variant="body2">Columns</Typography>
        {activeColumnCount > 0 && activeColumnCount < ALL_COLUMNS.length && (
          <Box
            component="span"
            style={{
              backgroundColor: "#1976d2", // primary.main
              color: "#fff", // primary.contrastText
              borderRadius: "50%",
              width: 18,
              height: 18,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              marginLeft: 4,
            }}
          >
            {activeColumnCount}
          </Box>
        )}
      </ControlButton>

      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        PaperProps={{ style: { maxHeight: 400 } }}
      >
        <ColumnsPanel>
          <Box px={2} py={1} display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="subtitle2">Show Columns</Typography>
            <Button 
              size="small" 
              onClick={handleResetColumns}
              disabled={activeColumnCount === ALL_COLUMNS.length}
            >
              Reset
            </Button>
          </Box>
          <Divider />
          {Object.entries(grouped).map(([group, cols], index) => (
            <React.Fragment key={group}>
              <ListItem button onClick={() =>
                setOpenGroups(prev =>
                  prev.includes(group)
                    ? prev.filter(g => g !== group)
                    : [...prev, group]
                )
              }>
                <ListItemText primary={group} />
                {openGroups.includes(group) ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </ListItem>

              <Collapse in={openGroups.includes(group)} timeout="auto" unmountOnExit>
                <Box pl={2}>
                  {cols.map(col => (
                    <ListItem
                      key={col.id}
                      button
                      onClick={() =>
                        onChange({
                          ...columnState,
                          [col.id]: !columnState[col.id],
                        })
                      }
                      dense
                    >
                      <Checkbox
                        edge="start"
                        checked={!!columnState[col.id]}
                        size="small"
                        disableRipple
                      />
                      <ListItemText primary={col.label} />
                    </ListItem>
                  ))}
                </Box>
              </Collapse>
            </React.Fragment>
          ))}
        </ColumnsPanel>
      </Popover>
    </>
  );
};

/* ------------------------------
   View Toggle
-------------------------------- */

const ViewToggle: React.FC<{
  viewMode: ViewMode;
  onChange: (mode: ViewMode) => void;
}> = ({ viewMode, onChange }) => (
  <ToggleContainer>
    <IconButton
      onClick={() => onChange("list")}
      size="small"
      style={{ padding: 8 }}
    >
      <ViewListIcon color={viewMode === "list" ? "primary" : "action"} />
    </IconButton>
    <IconButton
      onClick={() => onChange("group")}
      size="small"
      style={{ padding: 8 }}
    >
      <ViewModuleIcon color={viewMode === "group" ? "primary" : "action"} />
    </IconButton>
  </ToggleContainer>
);

/* ------------------------------
   Main Toolbar
-------------------------------- */

const ShotDataTableToolbar: React.FC<Props> = ({
  viewMode,
  onViewChange,
  searchValue,
  onSearchChange,
  filters,
  onFilterChange,
  columnsState,
  onColumnsChange,
  onReset,
}) => {

  const DEFAULT_FILTERS: Filters = {
    assetGroups: [],
    approvalStatus: [],
    workStatus: [],
  };

  const handleReset = () => {
    // Reset to defaults
    onSearchChange("");
    onFilterChange(DEFAULT_FILTERS);
    onColumnsChange(DEFAULT_COLUMN_STATE);
    
    // Call custom reset handler if provided
    if (onReset) {
      onReset();
    }
  };

  // Check if any customizations are active
  const hasChanges = 
    searchValue !== "" ||
    Object.values(filters).flat().length > 0 ||
    Object.values(columnsState).filter(Boolean).length !== ALL_COLUMNS.length;

  return (
    <StyledToolbar>

      {/* LEFT */}
      <LeftSection>
        <ViewToggle viewMode={viewMode} onChange={onViewChange} />
      </LeftSection>

      {/* RIGHT */}
      <RightSection>
        <SearchContainer>
          <StyledInput
            value={searchValue}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search shots..."
          />
        </SearchContainer>

        <FilterMenu filters={filters} onChange={onFilterChange} />

        <ColumnSelector
          columnState={columnsState}
          onChange={onColumnsChange}
        />

        {hasChanges && (
          <ResetButton
            variant="outlined"
            size="small"
            startIcon={<RestoreIcon />}
            onClick={handleReset}
          >
            Reset
          </ResetButton>
        )}
      </RightSection>

    </StyledToolbar>
  );
};

export default ShotDataTableToolbar;