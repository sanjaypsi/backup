import { useEffect, useState, useReducer } from 'react';
import { LatestComponents, ReviewInfo, Shot } from './types';
import {
  fetchLatestShotComponents,
  fetchShots,
  fetchShotReviewInfos,
  fetchShotThumbnail,
} from './api';
import {
  fetchPipelineSettingComponentsCommon,
  fetchPipelineSettingComponentsProject
} from '../api';
import { Project } from '../../types';

export function useFetchShots(
  project: Project | null | undefined,
  page: number,
  rowsPerPage: number,
): { shots: Shot[], total: number } {
  const [shots, setShots] = useState<Shot[]>([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    if (project == null) {
      return;
    }
    const controller = new AbortController();

    (async () => {
      const res = await fetchShots(
        project.key_name,
        page,
        rowsPerPage,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err)
      });
      if (res != null) {
        setShots(res.shots);
        setTotal(res.total);
      }
    })();
    return () => controller.abort();
  }, [project, page, rowsPerPage]);

  return { shots, total };
};

function reducer(
  state: { [key: string]: ReviewInfo },
  action: { shot: Shot, reviewInfos: ReviewInfo[] },
): { [key: string]: ReviewInfo } {
  const data: { [key: string]: ReviewInfo } = {};
  for (const reviewInfo of action.reviewInfos) {
    data[`${action.shot.groups[0]}-${action.shot.groups[1]}-${action.shot.groups[2]}-${reviewInfo.phase}`] = reviewInfo;
  }
  return { ...state, ...data };
};

export function useFetchShotReviewInfos(
  project: Project,
  shots: Shot[],
): { reviewInfos: { [key: string]: ReviewInfo } } {
  const [reviewInfos, dispatch] = useReducer(reducer, {});
  const controller = new AbortController();

  useEffect(() => {
    const loadShotReviewInfos = async (shot: Shot) => {
      try {
        const shotPath = shot.groups.join('/');
        const res = await fetchShotReviewInfos(
          project.key_name,
          shotPath,
          shot.relation,
          controller.signal,
        );
        const data = res.reviews;
        if (data.length > 0) {
          dispatch({ shot, reviewInfos: data });
        }
      } catch (err) {
        console.error('Failed to fetch shot review infos:', err);
      }
    };

    for (const shot of shots) {
      loadShotReviewInfos(shot);
    }

    return () => controller.abort();
  }, [project, shots]);

  return { reviewInfos };
};

function shotThumbnailReducer(
  state: { [key: string]: string },
  action: { shot: Shot, responseResult: string },
): { [key: string]: string } {
  const data: { [key: string]: string } = {};
  const shotPath = action.shot.groups.join('/');
  data[`${shotPath}-${action.shot.relation}`] = action.responseResult;
  return { ...state, ...data };
};

export function useFetchShotThumbnails(
  project: Project,
  shots: Shot[],
): { thumbnails: { [key: string]: string } } {
  const [thumbnails, dispatch] = useReducer(shotThumbnailReducer, {});
  const controller = new AbortController();

  useEffect(() => {
    const loadShotThumbnails = async (shot: Shot) => {
      if (shot.groups.length !== 3) {
        return;
      }
      try {
        const res = await fetchShotThumbnail(
          project.key_name,
          shot.groups,
          shot.relation,
          controller.signal,
        );
        if (res != null && res.ok) {
          const reader = new FileReader();
          const blob = await res.blob();
          reader.onload = () => {
            dispatch({ shot, responseResult: reader.result as string });
          };
          reader.readAsDataURL(blob);
        }
      } catch (err) {
        console.error(err);
      }
    };

    for (const shot of shots) {
      loadShotThumbnails(shot);
    }

    return () => controller.abort();
  }, [project, shots]);

  return { thumbnails };
};

export function useFetchPipelineSettingShotComponents(
  project: Project | null | undefined,
): { phaseComponents: { [key: string]: string[] } } {
  const [phaseComponents, setPhaseComponents] = useState<{ [key: string]: string[] }>({});

  useEffect(() => {
    if (project == null) {
      return;
    }
    const controller = new AbortController();
    (async () => {
      const _phaseComponents: { [key: string]: string[] } = {};
      const resCommon = await fetchPipelineSettingComponentsCommon(
        'shots',
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (resCommon != null) {
        for (const value of resCommon.values) {
          const keys = value.key.split('/');
          const phase = keys[keys.length - 1];
          _phaseComponents[phase] = value.value as string[];
        }
      }

      const resProject = await fetchPipelineSettingComponentsProject(
        project.key_name,
        'shots',
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (resProject != null) {
        for (const value of resProject.values) {
          const keys = value.key.split('/');
          const phase = keys[keys.length - 1];
          _phaseComponents[phase] = value.value as string[];
        }
      }
      setPhaseComponents(_phaseComponents);
    })();
    return () => controller.abort();
  }, [project]);

  return { phaseComponents };
};

export function useFetchLatestShotComponents(
  project: Project | null | undefined,
  shots: Shot[],
  components: { [key: string]: string[]; },
): { latestComponents: LatestComponents } {
  const [latestComponents, setLatestComponents] = useState<LatestComponents>({});

  useEffect(() => {
    if (project == null) {
      return;
    }
    const controller = new AbortController();
    const _components = Object.values(components).flat();

    const loadLatestShotComponents = async () => {
      const fetchPromises = shots.map(shot => {
        if (shot.groups.length !== 3) {
          return Promise.resolve([]);
        }
        return fetchLatestShotComponents(
          project.key_name,
          shot.groups,
          shot.relation,
          _components,
          controller.signal,
        );
      });

      try {
        // Promise.all を使用してすべての非同期処理が完了するのを待つ
        const results = await Promise.all(fetchPromises);

        const _latestComponents: LatestComponents = {};
        results.forEach((res, index) => {
          if (res.length > 0) {
            _latestComponents[`${shots[index].groups.join('-')}-${shots[index].relation}`] = res;
          }
        });
        setLatestComponents(_latestComponents);
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          return;
        }
        console.error('Failed to fetch latest asset components:', err);
      }
    };

    loadLatestShotComponents();

    return () => {
      controller.abort();
    };
  }, [project, shots, components]);

  return { latestComponents };
};
