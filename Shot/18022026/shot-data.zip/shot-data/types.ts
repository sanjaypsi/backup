import { TableCellProps } from "@material-ui/core/TableCell";
import { ReactElement } from "react";
import { Project } from '../../types';

export type ShotsDataTableProps = {
  project: Project | null | undefined,
  shots: Shot[],
  phaseComponents: { [key: string]: string[] },
  latestComponents: LatestComponents,
  tableFooter: ReactElement,
  dateTimeFormat: Intl.DateTimeFormat,
};

export type RecordTableHeadProps = {
  columns: Column[],
  phaseComponents: { [key: string]: string[] },
};

export type Colors = Readonly<{
  lineColor: string,
  backgroundColor: string,
}>;

export type Column = Readonly<{
  id: string,
  label: string,
  colors?: Colors,
  align?: TableCellProps['align'],
}>;

export type PageProps = Readonly<{
  page: number,
  rowsPerPage: number,
}>;

export type ReviewInfo = {
  task_id: string,
  project: string,
  take_path: string,
  root: string,
  relation: string,
  phase: string,
  component: string,
  take: string,
  approval_status: string,
  work_status: string,
  submitted_at_utc: string,
  submitted_user: string,
  modified_at_utc: string,
  id: number,
  groups: string[],
  group_1: string,
  review_comments: ReviewComment[],
};

type ReviewComment = {
  text: string,
  language: string,
  attachments: string[],
  is_translated: boolean,
  need_translation: boolean
};

export type Shot = Readonly<{
  groups: string[],
  relation: string,
}>;

export type FilterProps = Readonly<{
  assetNameKey: string,
  applovalStatues: string[],
  workStatues: string[],
}>;

export type ChipDeleteFunction = (value: string) => void;

export type ShotRowProps = Readonly<{
  shot: Shot,
  reviewInfos: { [key: string]: ReviewInfo },
  thumbnails: { [key: string]: string },
  phaseComponents: { [key: string]: string[] },
  latestComponents: LatestComponents,
  dateTimeFormat: Intl.DateTimeFormat,
  isLastRow: boolean,
}>;

export type LatestShotComponentDocument = Readonly<{
  component: string,
  groups: string[],
  phase: string,
  submitted_at_utc: string,
}>;

type LatestComponent = Readonly<{
  component: string,
  latest_document: LatestShotComponentDocument,
}>

export type LatestComponents = {
  [key: string]: LatestComponent[],
};

export type LatestShotComponentDocumentsResponse = Readonly<{
  component: string,
  latest_document: LatestShotComponentDocument,
}>;
