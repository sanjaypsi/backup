import { AuthorizationError } from '../../../auth/types';
import { getAuthHeader, setNewToken } from '../../../auth/util';
import { LatestShotComponentDocumentsResponse, ReviewInfo, Shot } from './types';

type ReviewInfoListResponse = {
  reviews: ReviewInfo[],
  next: string | null,
  total: number,
};

export type ShotsResponse = {
  shots: Shot[],
  total: number,
};

export const fetchShots = async (
  project: string,
  page: number,
  rowsPerPage: number,
  signal?: AbortSignal | null,
): Promise<ShotsResponse> => {
  const headers = getAuthHeader();
  let url: string | null = `/api/projects/${project}/publishOperationInfo/shots`
  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  params.set('page', String(page + 1));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch parameters.');
  }
  setNewToken(res);
  const json: ShotsResponse = await res.json();
  return json;
};

export const fetchShotReviewInfos = async (
  project: string,
  shot: string,
  relation: string,
  signal?: AbortSignal | null,
): Promise<ReviewInfoListResponse> => {
  let url = `/api/projects/${project}/shots/reviewInfos`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('groups', String(shot));
  params.set('relation', String(relation));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch review infos.');
  }
  setNewToken(res);
  const json: ReviewInfoListResponse = await res.json();
  return json;
};

export const fetchShotThumbnail = async (
  project: string,
  shots: string[],
  relation: string,
  signal?: AbortSignal | null,
): Promise<Response | null> => {
  let url = `/api/projects/${project}/shots/reviewthumbnail`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('group1', shots[0]);
  params.set('group2', shots[1]);
  params.set('group3', shots[2]);
  params.set('relation', String(relation));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 204) {
    return null; // 204 is allowed, it means the thumbnail does not exist.
  }
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch thumbnail.');
  }
  setNewToken(res);
  return res;
};

export const fetchLatestShotComponents = async (
  project: string,
  shots: string[],
  relation: string,
  components: string[],
  signal?: AbortSignal | null,
): Promise<LatestShotComponentDocumentsResponse[]> => {
  let url = `/api/projects/${project}/latestShotsOperationInfos`;
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('group1', shots[0]);
  params.set('group2', shots[1]);
  params.set('group3', shots[2]);
  params.set('relation', relation);
  components.forEach(component => params.append('component', component));
  url += `?${params}`;
  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch latest asset components.');
  }
  setNewToken(res);
  const json: LatestShotComponentDocumentsResponse[] = await res.json();
  return json;
};
