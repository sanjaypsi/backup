import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
} from "@material-ui/core";
import {
  ShotRowProps,
  ShotsDataTableProps,
  Colors,
  Column,
  RecordTableHeadProps,
} from "./types";
import { useFetchShotReviewInfos, useFetchShotThumbnails } from './hooks';


const SHOT_PHASES: { [key: string]: Colors } = {
  lay: {
    lineColor: '#3295FD',
    backgroundColor: '#004288',
  },
  anm: {
    lineColor: '#FD5E63',
    backgroundColor: '#5c0003',
  },
  gnz: {
    lineColor: '#C061FD',
    backgroundColor: '#340055',
  },
  mat: {
    lineColor: '#FE7DB3',
    backgroundColor: '#5f0028',
  },
  fx: {
    lineColor: '#FDCD44',
    backgroundColor: '#CCA537',
  },
  cmp: {
    lineColor: '#D5F762',
    backgroundColor: '#4a6101',
  },
};

type Status = Readonly<{
  displayName: string,
  color: string,
}>;

const APPROVAL_STATUS: { [key: string]: Status } = {
  check: {
    displayName: 'Check',
    color: '#ca25ed',
  },
  clientReview: {
    displayName: 'Client Review',
    color: '#005fbd',
  },
  dirReview: {
    displayName: 'Dir Review',
    color: '#007fff',
  },
  epdReview: {
    displayName: 'EPD Review',
    color: '#4fa7ff',
  },
  clientOnHold: {
    displayName: 'Client On Hold',
    color: '#d69b00',
  },
  dirOnHold: {
    displayName: 'Dir On Hold',
    color: '#ffcc00',
  },
  epdOnHold: {
    displayName: 'EPD On Hold',
    color: '#ffdd55',
  },
  execRetake: {
    displayName: 'Exec Retake',
    color: '#a60000',
  },
  clientRetake: {
    displayName: 'Client Retake',
    color: '#c60000',
  },
  dirRetake: {
    displayName: 'Dir Retake',
    color: '#ff0000',
  },
  epdRetake: {
    displayName: 'EPD Retake',
    color: '#ff4f4f',
  },
  clientApproved: {
    displayName: 'Client Approved',
    color: '#1d7c39',
  },
  dirApproved: {
    displayName: 'Dir Approved',
    color: '#27ab4f',
  },
  epdApproved: {
    displayName: 'EPD Approved',
    color: '#5cda82',
  },
  other: {
    displayName: 'Other',
    color: '#9a9a9a',
  },
  omit: {
    displayName: 'Omit',
    color: '#646464',
  },
};

const WORK_STATUS: { [key: string]: Status } = {
  check: {
    displayName: 'Check',
    color: '#e287f5',
  },
  cgsvOnHold: {
    displayName: 'CGSV On Hold',
    color: '#ffdd55',
  },
  svOnHold: {
    displayName: 'SV On Hold',
    color: '#ffe373',
  },
  leadOnHold: {
    displayName: 'Lead On Hold',
    color: '#fff04f',
  },
  cgsvRetake: {
    displayName: 'CGSV Retake',
    color: '#ff4f4f',
  },
  svRetake: {
    displayName: 'SV Retake',
    color: '#ff8080',
  },
  leadRetake: {
    displayName: 'Lead Retake',
    color: '#ffbbbb',
  },
  cgsvApproved: {
    displayName: 'CGSV Approved',
    color: '#5cda82',
  },
  svApproved: {
    displayName: 'SV Approved',
    color: '#83e29f',
  },
  leadApproved: {
    displayName: 'Lead Approved',
    color: '#b9eec9',
  },
  svOther: {
    displayName: 'SV Other',
    color: '#9a9a9a',
  },
  leadOther: {
    displayName: 'Lead Other',
    color: '#dbdbdb',
  },
};

const columns: Column[] = [
  {
    id: 'thumbnail',
    label: 'Thumbnail',
  },
  {
    id: 'group_1_name',
    label: 'Name 1',
  },
  {
    id: 'group_2_name',
    label: 'Name 2',
  },
  {
    id: 'group_3_name',
    label: 'Name 3',
  },
  {
    id: 'lay_work_status',
    label: 'LAY WORK',
    colors: SHOT_PHASES['lay'],
  },
  {
    id: 'lay_approval_status',
    label: 'LAY APPR',
    colors: SHOT_PHASES['lay'],
  },
  {
    id: 'lay_submitted_at',
    label: '_lay_ Submitted At',
    colors: SHOT_PHASES['lay'],
  },
  {
    id: 'anm_work_status',
    label: 'ANM WORK',
    colors: SHOT_PHASES['anm'],
  },
  {
    id: 'anm_approval_status',
    label: 'ANM APPR',
    colors: SHOT_PHASES['anm'],
  },
  {
    id: 'anm_submitted_at',
    label: '_anm_ Submitted At',
    colors: SHOT_PHASES['anm'],
  },
  {
    id: 'gnz_work_status',
    label: 'GNZ WORK',
    colors: SHOT_PHASES['gnz'],
  },
  {
    id: 'gnz_approval_status',
    label: 'GNZ APPR',
    colors: SHOT_PHASES['gnz'],
  },
  {
    id: 'gnz_submitted_at',
    label: '_gnz_ Submitted At',
    colors: SHOT_PHASES['gnz'],
  },
  {
    id: 'mat_work_status',
    label: 'MAT WORK',
    colors: SHOT_PHASES['mat'],
  },
  {
    id: 'mat_approval_status',
    label: 'MAT APPR',
    colors: SHOT_PHASES['mat'],
  },
  {
    id: 'mat_submitted_at',
    label: '_mat_ Submitted At',
    colors: SHOT_PHASES['mat'],
  },
  {
    id: 'fx_work_status',
    label: 'FX WORK',
    colors: SHOT_PHASES['fx'],
  },
  {
    id: 'fx_approval_status',
    label: 'FX APPR',
    colors: SHOT_PHASES['fx'],
  },
  {
    id: 'fx_submitted_at',
    label: '_fx_ Submitted At',
    colors: SHOT_PHASES['fx'],
  },
  {
    id: 'cmp_work_status',
    label: 'CMP WORK',
    colors: SHOT_PHASES['cmp'],
  },
  {
    id: 'cmp_approval_status',
    label: 'CMP APPR',
    colors: SHOT_PHASES['cmp'],
  },
  {
    id: 'cmp_submitted_at',
    label: '_cmp_ Submitted At',
    colors: SHOT_PHASES['cmp'],
  },
  {
    id: 'relation',
    label: 'Relation',
  },
];

type TooltipTableCellProps = {
  tooltipText: string,
  status: Status | undefined,
  leftBorderStyle: string,
  rightBorderStyle: string,
  bottomBorderStyle: string,
};

const MultiLineTooltipTableCell: React.FC<TooltipTableCellProps> = (
  { tooltipText, status, leftBorderStyle, rightBorderStyle, bottomBorderStyle = 'none' }
) => {
  const [open, setOpen] = React.useState(false);
  const isTooltipTextEmpty = tooltipText && tooltipText.trim().length > 0;

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const handleTooltipOpen = () => {
    setOpen(true);
  };

  const statusText = (status != null) ? status['displayName'] : '-';

  return (
    <TableCell
      style={{
        color: (status != null) ? status['color'] : '',
        fontStyle: (tooltipText === '') ? 'normal' : 'oblique',
        borderLeft: leftBorderStyle,
        borderRight: rightBorderStyle,
        borderBottom: bottomBorderStyle,
      }}
      onClick={isTooltipTextEmpty ? handleTooltipOpen : undefined}
    >
      {isTooltipTextEmpty ? (
        <Tooltip
          title={
            <div
              style={{ fontSize: '0.8rem', whiteSpace: 'pre-wrap' }}>
              {tooltipText}
            </div>
          }
          onClose={handleTooltipClose}
          open={open}
          arrow
        >
          <span>{statusText}</span>
        </Tooltip>
      ) : (
        <span>{statusText}</span>
      )}
    </TableCell >
  );
};

const RecordTableHead: React.FC<RecordTableHeadProps> = ({
  columns,
  phaseComponents,
}) => {
  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => {
          const borderLineStyle = column.colors ? `solid 3px ${column.colors.lineColor}` : 'none';
          const borderTopStyle = column.colors ? borderLineStyle : 'none';
          const borderLeftStyle = (column.id.indexOf('work_status') !== -1) ? borderLineStyle : 'none';
          const borderRightStyle = (column.id.indexOf('approval_status') !== -1) ? borderLineStyle : 'none';
          if (column.id.indexOf('submitted_at') === -1) {
            return (
              <TableCell
                key={column.id}
                style={
                  {
                    backgroundColor: column.colors ? column.colors.backgroundColor : 'none',
                    borderTop: borderTopStyle,
                    borderLeft: borderLeftStyle,
                    borderRight: borderRightStyle,
                  }
                }
              >
                {column.label}
              </TableCell>
            );
          } else {
            const phase = column.id.replace('_submitted_at', '');
            const components = phaseComponents[phase] || [];
            return components.map((component) => {
              const id = component.toLowerCase() + '_submitted_at';
              const label = column.label.replace(`_${phase}_`, `${component}`);
              return (
                <TableCell
                  key={id}
                  style={
                    {
                      backgroundColor: column.colors ? column.colors.backgroundColor : 'none',
                    }
                  }
                >
                  {label}
                </TableCell>
              );
            });
          }
        })}
      </TableRow>
    </TableHead>
  );
};

const ShotRow: React.FC<ShotRowProps> = ({
  shot,
  reviewInfos,
  thumbnails,
  phaseComponents,
  latestComponents,
  dateTimeFormat,
  isLastRow
}) => {
  const shotPath = shot.groups.join('/');
  return (
    <TableRow>
      <TableCell>
        {thumbnails[`${shotPath}-${shot.relation}`] ? (
          <img
            src={thumbnails[`${shotPath}-${shot.relation}`]}
            alt={`${shotPath} thumbnail`}
            style={{ width: '100px', height: 'auto' }}
          />
        ) : (
          <span>No Thumbnail</span>
        )}
      </TableCell>
      <TableCell key={`${shot.groups[0]}-group-0-${shot.relation}`}>{shot.groups[0]}</TableCell>
      <TableCell key={`${shot.groups[1]}-group-1-${shot.relation}`}>{shot.groups[1]}</TableCell>
      <TableCell key={`${shot.groups[2]}-group-2-${shot.relation}`}>{shot.groups[2]}</TableCell>
      {Object.entries(SHOT_PHASES).map(([phase, { lineColor }]) => {
        const reviewInfoName = `${shot.groups[0]}-${shot.groups[1]}-${shot.groups[2]}-${phase}`;
        const info = reviewInfos[reviewInfoName];
        const workStatus: Status | undefined = info && WORK_STATUS[info.work_status];
        const approvalStatus: Status | undefined = info && APPROVAL_STATUS[info.approval_status];
        const tooltipText: string = info && info.review_comments
          .filter(reviewComment => reviewComment.text !== '')
          .map(reviewComment => `${reviewComment.language}:\n${reviewComment.text}`)
          .join('\n') || '';
        const borderLineStyle = `solid 3px ${lineColor}`;
        const shotsKey = `${shot.groups[0]}-${shot.groups[1]}-${shot.groups[2]}-${shot.relation}`;
        const latestDocuments = latestComponents[shotsKey] || [];

        return (
          <React.Fragment key={`${reviewInfoName}-work-appr`}>
            <MultiLineTooltipTableCell
              tooltipText={tooltipText}
              status={workStatus}
              leftBorderStyle={borderLineStyle}
              rightBorderStyle={'none'}
              bottomBorderStyle={isLastRow ? borderLineStyle : 'none'}
            />
            <MultiLineTooltipTableCell
              tooltipText={tooltipText}
              status={approvalStatus}
              leftBorderStyle={'none'}
              rightBorderStyle={borderLineStyle}
              bottomBorderStyle={isLastRow ? borderLineStyle : 'none'}
            />
            {(phase in phaseComponents ? phaseComponents[phase] : []).map((component) => {
              const latestDocument = latestDocuments.find(doc => doc.component === component);

              return (
                <TableCell key={`${reviewInfoName}-${component}`}>
                  {latestDocument ? dateTimeFormat.format(new Date(latestDocument.latest_document.submitted_at_utc)) : '-'}
                </TableCell>
              );
            })}
          </React.Fragment>
        );
      })}
      <TableCell>{shot.relation}</TableCell>
    </TableRow>
  );
};

const ShotsDataTable: React.FC<ShotsDataTableProps> = ({
  project,
  shots,
  phaseComponents,
  latestComponents,
  tableFooter,
  dateTimeFormat,
}) => {
  if (project == null) {
    return null;
  }
  const { reviewInfos } = useFetchShotReviewInfos(project, shots);
  const { thumbnails } = useFetchShotThumbnails(project, shots);

  return (
    <Table stickyHeader>
      <RecordTableHead
        key='shot-data-table-head'
        columns={columns}
        phaseComponents={phaseComponents}
      />
      <TableBody>
        {shots.map((shot, index) => (
          <ShotRow
            key={`${shot.groups.join('/')}-${shot.relation}-${index}`}
            shot={shot}
            reviewInfos={reviewInfos}
            thumbnails={thumbnails}
            phaseComponents={phaseComponents}
            latestComponents={latestComponents}
            dateTimeFormat={dateTimeFormat}
            isLastRow={(index === shots.length - 1)}
          />
        ))}
      </TableBody>
      {tableFooter || null}
    </Table>
  );
};

export default ShotsDataTable;
