import React, { useMemo, useState } from "react";
import { ColumnState, ShotPivot, ShotsDataTableProps } from "./types";
import { Project } from "../../types";
import TableRow from "@material-ui/core/TableRow/TableRow";
import TableCell from "@material-ui/core/TableCell/TableCell";
import Table from "@material-ui/core/Table/Table";
import { TableBody } from "@material-ui/core";



type ShotsDataTableGroupProps = ShotsDataTableProps & {
    project:        Project | null | undefined;
    shots:          ShotPivot[];
    total:           number; //  add group view
    groupCounts:    { [key: string]: number };
    dateTimeFormat: Intl.DateTimeFormat;
    columnsState:   ColumnState;
};

const buildGroupedData = (shots: ShotPivot[]) => {
    const grouped: { [key: string]: ShotPivot[] } = {};

    shots.forEach(shot => {
        const groupKey = shot.group_1; // Assuming group_1 is the field to group by
        if (!grouped[groupKey]) {
            grouped[groupKey] = [];
        }
        grouped[groupKey].push(shot);

    });
    return grouped;
};

interface Group1HeaderRowProps {
    groupKey: string;
    allShots: ShotPivot[];
    total: number;
    groupCounts: { [key: string]: number };
    isExpanded: boolean;
    onToggle: () => void;
    columnsState: ColumnState;
    visibleColumns: number;
}


const Group1HeaderRow: React.FC<Group1HeaderRowProps> = ({
    groupKey,
    allShots,
    total,
    isExpanded,
    onToggle,
    columnsState,
    visibleColumns,
    groupCounts
}) => {
    const [project, phase] = groupKey.split("_");
    return (
        <TableRow 
        onClick={onToggle} 
        style={{ 
            cursor: 'pointer', 
            backgroundColor: '#3f3b3b' 
            }}>

            <TableCell 
            colSpan={visibleColumns} 
            style={{ fontWeight: 'bold' }}>
                {groupKey} ({allShots.length} / {groupCounts[groupKey] || 0})

            </TableCell>
        </TableRow>
    )
};

const ShotsDataTableGroup: React.FC<ShotsDataTableGroupProps> = ({
    project,
    shots,
    total,
    groupCounts,
    dateTimeFormat,
    columnsState,
}) => {
    if (project === null) return null;

    const grouped = useMemo(() => {
        console.log("Grouping shots...", shots.slice()); // Log first 5 shots for verification
        return buildGroupedData(shots);
    }, [shots]);

    const [expandedGroups, setExpandedGroups] = useState<{ [key: string]: boolean }>({});

    const isExpanded = (groupKey: string) => expandedGroups[groupKey];

    const toggleGroup = (groupKey: string) => {
        setExpandedGroups(prev => ({
            ...prev,
            [groupKey]: !prev[groupKey]
        }));
    };


    return (
        <Table>
            <TableBody>
                {Object.entries(grouped).map(([groupKey, groupShots]) => (
                    <Group1HeaderRow
                        key={groupKey}
                        groupKey={groupKey}
                        allShots={groupShots}
                        total={total}
                        groupCounts={groupCounts}
                        isExpanded={isExpanded(groupKey)}
                        onToggle={() => {
                            toggleGroup(groupKey);
                        }}
                        columnsState={columnsState}
                        visibleColumns={Object.keys(columnsState)
                            .filter(key => columnsState[key])
                            .length}
                    />
            ))}
            </TableBody>
        </Table>
    );
};

export default ShotsDataTableGroup;