package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type PublishOperationInfo struct {
	repo        *repository.PublishOperationInfo
	readTimeout time.Duration
	reviewRepo  *repository.ReviewInfo // Add this field
	mysqlDB     *gorm.DB               // Add this field, replace 'interface{}' with the actual type if known
}

func NewPublishOperationInfo(
	repo *repository.PublishOperationInfo,
	readTimeout time.Duration,
	reviewRepo *repository.ReviewInfo, // Add this parameter
	mysqlDB *gorm.DB, // Add this parameter, replace 'interface{}' with the actual type if known
) *PublishOperationInfo {
	return &PublishOperationInfo{
		repo:        repo,
		readTimeout: readTimeout,
		reviewRepo:  reviewRepo, // Initialize the field
		mysqlDB:     mysqlDB,    // Initialize the field
	}
}

func (uc *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	params *entity.LatestAssetComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestAssetDocuments(timeoutCtx, params)
}

// func (uc *PublishOperationInfo) ListShots(
// 	ctx context.Context,
// 	params *entity.ShotListParams,
// ) ([]*entity.ShotDocument, int64, error) {
// 	if err := binding.Validator.ValidateStruct(params); err != nil {
// 		return nil, 0, err
// 	}
// 	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
// 	defer cancel()
// 	return uc.repo.ListShots(timeoutCtx, params)
// }

func (uc *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
) ([]*entity.ShotDocument, int64, error) {

	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()

	var filteredShots []*entity.ShotDocument
	var err error

	// Call MySQL filtering ONLY if filters exist
	if len(params.ApprovalStatus) > 0 || len(params.WorkStatus) > 0 {

		filteredShots, err = uc.reviewRepo.ListFilteredShots(
			uc.mysqlDB,
			params.Project,
			params.ApprovalStatus,
			params.WorkStatus,
		)

		if err != nil {
			return nil, 0, err
		}
	}

	// Call Mongo repository
	return uc.repo.ListShots(
		timeoutCtx,
		params,
		filteredShots,
	)
}

func (uc *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	params *entity.LatestShotComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestShotDocuments(timeoutCtx, params)
}
