package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type PublishOperationInfo struct {
	repo        *repository.PublishOperationInfo
	readTimeout time.Duration
	reviewRepo  *repository.ReviewInfo // Add this field
	mysqlDB     *gorm.DB               // Add this field, replace 'interface{}' with the actual type if known
}

func NewPublishOperationInfo(
	repo *repository.PublishOperationInfo,
	readTimeout time.Duration,
	reviewRepo *repository.ReviewInfo, // Add this parameter
	mysqlDB *gorm.DB, // Add this parameter, replace 'interface{}' with the actual type if known
) *PublishOperationInfo {
	return &PublishOperationInfo{
		repo:        repo,
		readTimeout: readTimeout,
		reviewRepo:  reviewRepo, // Initialize the field
		mysqlDB:     mysqlDB,    // Initialize the field
	}
}

func (uc *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	params *entity.LatestAssetComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestAssetDocuments(timeoutCtx, params)
}

func (uc *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
) ([]*entity.ShotDocument, int64, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListShots(timeoutCtx, params)
}

////================================================================
// Below is the original ListShots method that includes MySQL filtering before MongoDB query.
// This is commented out to show the previous implementation, which can be useful for reference or if you want to revert back to it in the future.
// func (uc *PublishOperationInfo) ListShots(
// 	ctx context.Context,
// 	params *entity.ShotListParams,
// ) ([]*entity.ShotDocument, int64, error) {

// 	if err := binding.Validator.ValidateStruct(params); err != nil {
// 		return nil, 0, err
// 	}

// 	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
// 	defer cancel()

// 	var filteredShots []*entity.ShotDocument
// 	var err error

// 	// Get filtered shots from MySQL
// 	filteredShots, err = uc.reviewRepo.ListFilteredShots(
// 		uc.mysqlDB,
// 		params.Project,
// 		params.ApprovalStatus,
// 		params.WorkStatus,
// 	)

// 	if err != nil {
// 		return nil, 0, err
// 	}

// 	total := int64(len(filteredShots))

// 	// Pagination before Mongo query ONLY if search is empty
// 	if params.Search == nil || *params.Search == "" {

// 		start := (params.GetPage() - 1) * params.GetPerPage()
// 		end := start + params.GetPerPage()

// 		if start > len(filteredShots) {
// 			filteredShots = []*entity.ShotDocument{}
// 		} else {
// 			if end > len(filteredShots) {
// 				end = len(filteredShots)
// 			}
// 			filteredShots = filteredShots[start:end]
// 		}
// 	}

// 	// Query Mongo
// 	documents, _, err := uc.repo.ListShots(
// 		timeoutCtx,
// 		params,
// 		filteredShots,
// 	)

// 	if err != nil {
// 		return nil, 0, err
// 	}

// 	// If search is used, Mongo already filtered results
// 	if params.Search != nil && *params.Search != "" {
// 		total = int64(len(documents))
// 	}

// 	return documents, total, nil
// }

func (uc *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	params *entity.LatestShotComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestShotDocuments(timeoutCtx, params)
}
