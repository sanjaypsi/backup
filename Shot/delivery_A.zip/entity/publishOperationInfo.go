package entity

import "time"

type LatestAssetComponentParams struct {
	Project   string   `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Asset     string   `binding:"required,min=1,max=100,alphanumunderscore"`
	Relation  string   `binding:"required,min=1,max=30,alphanumunderscore"`
	Component []string `binding:"required,dive,max=100"`
}

type ComponentDocument struct {
	Groups         []string  `bson:"groups" json:"groups"`
	SubmittedAtUTC time.Time `bson:"submitted_at_utc" json:"submitted_at_utc"`
	Phase          string    `bson:"phase" json:"phase"`
	Component      string    `bson:"component" json:"component"`
}

type LatestComponentDocuments struct {
	Component      string            `bson:"_id" json:"component"`
	LatestDocument ComponentDocument `bson:"latest_document" json:"latest_document"`
}

type ShotListParams struct {
	Project string  `binding:"min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Studio  *string `binding:"omitempty,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Search  *string `form:"search"`

	ApprovalStatus []string `form:"approval_status"`
	WorkStatus     []string `form:"work_status"`

	*BaseListParams
}

type ShotDocument struct {
	Relation string   `bson:"relation" json:"relation"`
	Groups   []string `bson:"groups" json:"groups"`
}

type ShotListResponse struct {
	Documents []*ShotDocument `json:"shots"`
	Total     int64           `json:"total"`
}

type LatestShotComponentParams struct {
	Project   string   `binding:"required,min=1,max=30,alphanum,lowercase,startsnotwithdigit"`
	Group1    string   `binding:"required,min=1,max=100,alphanumunderscore"`
	Group2    string   `binding:"required,min=1,max=100,alphanumunderscore"`
	Group3    string   `binding:"required,min=1,max=100,alphanumunderscore"`
	Relation  string   `binding:"required,min=1,max=30,alphanumunderscore"`
	Component []string `binding:"required,dive,max=100"`
}
