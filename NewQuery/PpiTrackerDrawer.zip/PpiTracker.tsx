import React from 'react';
import { styled } from '@material-ui/core';
import { RouteComponentProps, Switch, Redirect, useRouteMatch } from 'react-router';
import PpiTrackerDrawer from './PpiTrackerDrawer';
import AssetsDataTablePanel from './asset-data/AssetsDataTablePanel';
import ShotsDataTablePanel from './shot-data/ShotsDataTablePanel';
import { Route } from 'react-router-dom';

const StyledDiv = styled('div')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  overflow: 'hidden',
}));

type PpiTrackerProps = {
  location: RouteComponentProps['location'],
};

const PpiTracker: React.FC<PpiTrackerProps> = ({ location }) => {
  const { path, url } = useRouteMatch();

  return (
    <StyledDiv>
      <PpiTrackerDrawer location={location} />

      <Switch>
        <Redirect
          from={path}
          exact
          to={`${url}/assetsdata${location.search}`}
        />
        <Route path={`${url}/assetsdata/`} component={AssetsDataTablePanel} />
        <Route path={`${url}/shotsdata/`} component={ShotsDataTablePanel} />
      </Switch>
    </StyledDiv>
  )
};

export default PpiTracker;
