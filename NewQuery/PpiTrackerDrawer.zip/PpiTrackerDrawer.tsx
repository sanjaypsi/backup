import React from 'react';
import { Drawer, List, ListItemText, makeStyles, Theme } from '@material-ui/core';
import { RouteComponentProps, useRouteMatch } from 'react-router';
import NavLinkListItem from '../../NavLinkListItem';

const drawerWidth = 200;

const useStyles = makeStyles<Theme>(theme => ({
  drawerPaper: {
    position: 'relative',
    width: drawerWidth,
    backgroundColor: '#4a4a4a',
    zIndex: theme.zIndex.appBar - 1,
    borderRight: 0,
  },
}));

type Props = {
  location: RouteComponentProps['location'],
};

const PpiTrackerDrawer: React.FC<Props> = ({ location }) => {
  const classes = useStyles();
  const { url } = useRouteMatch();

  return (
    <Drawer
      variant="permanent"
      classes={{
        paper: classes.drawerPaper,
      }}
    >
      <List>
        <NavLinkListItem to={`${url}/assetsdata${location.search}`}>
          <ListItemText primary="Assets Data" />
        </NavLinkListItem>
        <NavLinkListItem to={`${url}/shotsdata${location.search}`}>
          <ListItemText primary="Shots Data" />
        </NavLinkListItem>
      </List>
    </Drawer>
  );
};

export default PpiTrackerDrawer;
