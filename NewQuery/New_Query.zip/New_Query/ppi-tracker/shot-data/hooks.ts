import { useEffect, useState, useReducer } from 'react';
import { LatestComponents, ReviewInfo, Shot, ShotPivot, ShotPivotResponse } from './types';
import {
  fetchLatestShotComponents,
  fetchShots,
  fetchShotReviewInfos,
  fetchShotThumbnail,
  fetchShotsPivot,
  fetchShotCamDataTypes,
} from './api';
import {
  fetchPipelineSettingComponentsCommon,
  fetchPipelineSettingComponentsProject
} from '../api';
import { Project } from '../../types';

export function useFetchShots(
  project: Project | null | undefined,
  page: number,
  rowsPerPage: number,
  search?: string,
  approvalStatus?: string[],
  workStatus?: string[],
): { shots: Shot[], total: number } {
  const [shots, setShots] = useState<Shot[]>([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    console.log(' useFetchShots useEffect triggered with:', {
      project,
      page,
      rowsPerPage,
      search,
      approvalStatus,
      workStatus
    });

    if (project == null) {
      return;
    }
    const controller = new AbortController();

    (async () => {
      const res = await fetchShots(
        project.key_name,
        page,
        rowsPerPage,
        search,
        approvalStatus,
        workStatus,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setShots(res.shots);
        setTotal(res.total);
      }
    })();
    return () => controller.abort();
  }, [project, page, rowsPerPage, search, JSON.stringify(approvalStatus), JSON.stringify(workStatus)]);

  return { shots, total };
}

function reducer(
  state: { [key: string]: ReviewInfo },
  action: { shot: Shot, reviewInfos: ReviewInfo[] },
): { [key: string]: ReviewInfo } {
  const data: { [key: string]: ReviewInfo } = {};
  for (const reviewInfo of action.reviewInfos) {
    data[`${action.shot.groups[0]}-${action.shot.groups[1]}-${action.shot.groups[2]}-${reviewInfo.phase}`] = reviewInfo;
  }
  return { ...state, ...data };
};

export function useFetchShotReviewInfos(
  project: Project,
  shots: Shot[],
): { reviewInfos: { [key: string]: ReviewInfo } } {
  const [reviewInfos, dispatch] = useReducer(reducer, {});
  const controller = new AbortController();

  useEffect(() => {
    const loadShotReviewInfos = async (shot: Shot) => {
      try {
        const shotPath = shot.groups.join('/');
        const res = await fetchShotReviewInfos(
          project.key_name,
          shotPath,
          shot.relation,
          controller.signal,
        );
        const data = res.reviews;
        if (data.length > 0) {
          dispatch({ shot, reviewInfos: data });
        }
      } catch (err) {
        // FIX: Don't log AbortError as an error
        if (err instanceof Error && err.name === 'AbortError') {
          return; // Silently ignore
        }
        console.error('Failed to fetch shot review infos:', err);
      }
    };

    for (const shot of shots) {
      loadShotReviewInfos(shot);
    }

    return () => controller.abort();
  }, [project, shots]);

  return { reviewInfos };
};

function shotThumbnailReducer(
  state: { [key: string]: string },
  action: { shot: Shot, responseResult: string },
): { [key: string]: string } {
  const data: { [key: string]: string } = {};
  const shotPath = action.shot.groups.join('/');
  data[`${shotPath}-${action.shot.relation}`] = action.responseResult;
  return { ...state, ...data };
};

export function useFetchShotThumbnails(
  project: Project,
  shots: Shot[],
): { thumbnails: { [key: string]: string } } {
  const [thumbnails, dispatch] = useReducer(shotThumbnailReducer, {});
  const controller = new AbortController();

  useEffect(() => {
    const loadShotThumbnails = async (shot: Shot) => {
      if (shot.groups.length !== 3) {
        return;
      }
      try {
        const res = await fetchShotThumbnail(
          project.key_name,
          shot.groups,
          shot.relation,
          controller.signal,
        );
        if (res != null && res.ok) {
          const reader = new FileReader();
          const blob = await res.blob();
          reader.onload = () => {
            dispatch({ shot, responseResult: reader.result as string });
          };
          reader.readAsDataURL(blob);
        }
      } catch (err) {
        // FIX: Don't log AbortError as an error
        if (err instanceof Error && err.name === 'AbortError') {
          // Silently ignore abort errors (caused by filter changes)
          return;
        }
        console.error('Failed to load thumbnail:', err);
      }
    };

    for (const shot of shots) {
      loadShotThumbnails(shot);
    }

    return () => controller.abort();
  }, [project, JSON.stringify(shots)]);

  return { thumbnails };
};

export function useFetchPipelineSettingShotComponents(
  project: Project | null | undefined,
): { phaseComponents: { [key: string]: string[] } } {
  const [phaseComponents, setPhaseComponents] = useState<{ [key: string]: string[] }>({});

  useEffect(() => {
    if (project == null) {
      return;
    }
    const controller = new AbortController();
    (async () => {
      const _phaseComponents: { [key: string]: string[] } = {};
      const resCommon = await fetchPipelineSettingComponentsCommon(
        'shots',
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (resCommon != null) {
        for (const value of resCommon.values) {
          const keys = value.key.split('/');
          const phase = keys[keys.length - 1];
          _phaseComponents[phase] = value.value as string[];
        }
      }

      const resProject = await fetchPipelineSettingComponentsProject(
        project.key_name,
        'shots',
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (resProject != null) {
        for (const value of resProject.values) {
          const keys = value.key.split('/');
          const phase = keys[keys.length - 1];
          _phaseComponents[phase] = value.value as string[];
        }
      }
      setPhaseComponents(_phaseComponents);
    })();
    return () => controller.abort();
  }, [project]);

  return { phaseComponents };
};

export function useFetchLatestShotComponents(
  project: Project | null | undefined,
  shots: Shot[],
  components: { [key: string]: string[]; },
): { latestComponents: LatestComponents } {
  const [latestComponents, setLatestComponents] = useState<LatestComponents>({});

  useEffect(() => {
    if (project == null) {
      return;
    }
    const controller = new AbortController();
    const _components = Object.values(components).flat();

    const loadLatestShotComponents = async () => {
      const fetchPromises = shots.map(shot => {
        if (shot.groups.length !== 3) {
          return Promise.resolve([]);
        }
        return fetchLatestShotComponents(
          project.key_name,
          shot.groups,
          shot.relation,
          _components,
          controller.signal,
        );
      });

      try {
        // Promise.all を使用してすべての非同期処理が完了するのを待つ
        const results = await Promise.all(fetchPromises);

        const _latestComponents: LatestComponents = {};
        results.forEach((res, index) => {
          if (res.length > 0) {
            _latestComponents[`${shots[index].groups.join('-')}-${shots[index].relation}`] = res;
          }
        });
        setLatestComponents(_latestComponents);
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          return;
        }
        console.error('Failed to fetch latest asset components:', err);
      }
    };

    loadLatestShotComponents();

    return () => {
      controller.abort();
    };
  }, [project, JSON.stringify(shots), JSON.stringify(components)]);

  return { latestComponents };
};

export type UseShotsPivotParams = {
    project:        Project | null | undefined;
    page:           number;
    perPage:        number;
    orderKey?:      string;
    direction?:     string;
    phase?:         string;
    nameKey?:       string;
    approvalStatus?: string[];
    workStatus?:    string[];
    groups1?:       string[];
    shotsGroups?:   string[];
};

export function useShotsPivot({
    project,
    page,
    perPage,
    orderKey       = 'group1_only',
    direction      = 'ASC',
    phase          = '',
    nameKey        = '',
    approvalStatus = [],
    workStatus     = [],
    shotsGroups     = [],
}: UseShotsPivotParams): {
    shots:    ShotPivot[];
    total:    number;
    pageLast: number;
    hasNext:  boolean;
    hasPrev:  boolean;
    loading:  boolean;
    groupCounts: { [key: string]: number };
} {
    const [shots,    setShots]    = useState<ShotPivot[]>([]);
    const [total,    setTotal]    = useState(0);
    const [pageLast, setPageLast] = useState(0);
    const [hasNext,  setHasNext]  = useState(false);
    const [hasPrev,  setHasPrev]  = useState(false);
    const [loading,  setLoading]  = useState(false);
    const [groupCounts, setGroupCounts] = useState<{ [key: string]: number }>({});

    useEffect(() => {
        if (project == null) return;

        const controller = new AbortController();
        setLoading(true);

        (async () => {
            try {
                // Convert frontend 'asc'/'desc' to backend 'ASC'/'DESC'
                const backendDirection = direction.toUpperCase();
                // console.log('Fetching shots pivot:', { 
                //     orderKey, 
                //     direction: backendDirection,
                //     page,
                //     perPage,
                //     nameKey,
                //     approvalStatusCount: approvalStatus.length,
                //     workStatusCount: workStatus.length
                // });
                
                const res = await fetchShotsPivot({
                    project:       project.key_name,
                    page,
                    perPage,
                    orderKey,
                    direction: backendDirection,
                    phase,
                    nameKey,
                    approvalStatus,
                    workStatus,
                    group1: shotsGroups,  // Pass shot group filters to API
                    signal: controller.signal,
                });

                setShots(res.items);
                setTotal(res.total);
                setPageLast(res.pageLast);
                setHasNext(res.hasNext);
                setHasPrev(res.hasPrev);
                setGroupCounts(res.groupCounts);
                
            } catch (err) {
                if (err instanceof Error && err.name === 'AbortError') return;
                console.error('useShotsPivot error:', err);
            } finally {
                setLoading(false);
            }
        })();

        return () => controller.abort();
    }, [
        project,
        page,
        perPage,
        orderKey,
        direction,
        phase,
        nameKey,
        JSON.stringify(approvalStatus),
        JSON.stringify(workStatus),
        JSON.stringify(shotsGroups)
    ]);

    return { shots, total, pageLast, hasNext, hasPrev, loading, groupCounts };
}


export function useFetchShotCamDataTypes(
    project: Project | null | undefined,
    shots: ShotPivot[],
): { camDataTypes: { [shotKey: string]: string } } {
    const [camDataTypes, setCamDataTypes] =
        useState<{ [shotKey: string]: string }>({});

    useEffect(() => {
        if (project == null || shots.length === 0) {
            setCamDataTypes({});
            return;
        }

        const controller = new AbortController();

        const shotKeys = shots
            .filter(s => s.group_1 && s.group_2 && s.group_3 && s.relation)
            .map(s => `${s.group_1}/${s.group_2}/${s.group_3}/${s.relation}`);

        (async () => {
            try {
                const res = await fetchShotCamDataTypes(
                    project.key_name,
                    shotKeys,
                    controller.signal,
                );

                setCamDataTypes(res.items || {});
            } catch (err) {
                if (err instanceof Error && err.name === 'AbortError') {
                    return;
                }
                console.error('[CamDataType] ❌ Failed to fetch:', err);
            }
        })();

        return () => controller.abort();
    }, [project, JSON.stringify(shots)]);

    return { camDataTypes };
}
