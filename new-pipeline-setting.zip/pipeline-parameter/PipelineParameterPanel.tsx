import { Container, Tabs, Toolbar } from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import React, { useEffect, useMemo, useState } from 'react';
import { Redirect, Route, RouteComponentProps, Switch, useRouteMatch } from 'react-router';

import LinkTab from '../LinkTab';
import ParameterPanel from './ParameterPanel';
import LocationPanel from './LocationPanel';
import ValuePanel from './ValuePanel';

const StyledContainer = styled(Container)({
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
});

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  backgroundColor: theme.palette.primary.dark,
  color: 'white',
  padding: 0,
}));

const StyledDiv = styled('div')({
  flexGrow: 1,
  display: 'flex',
  overflow: 'hidden',
});

type PipelineParameterTypes = 'parameter' | 'location' | 'value';

type PipelineParameterPanelProps = {
  location: RouteComponentProps['location'],
};

const PipelineParameterPanel: React.FC<PipelineParameterPanelProps> = ({ location }) => {
  const [value, setValue] = useState<PipelineParameterTypes>('parameter');
  const [project, setProject] = useState('');
  const { path, url } = useRouteMatch();

  const re = useMemo(() => {
    return new RegExp(`^${url.replace('/', '\\/')}\/([a-zA-Z0-9]+)`);
  }, [url]);

  useEffect(() => {
    const matched = re.exec(location.pathname);
    if (matched != null) {
      switch (matched[1]) {
        case 'parameter':
        case 'location':
        case 'value':
          setValue(matched[1]);
          break;
      }
    }
  }, [location, re]);

  const handleChange = (event: React.ChangeEvent<{}>, newValue: any) => {
    setValue(newValue);
  };

  return (
    <StyledContainer maxWidth="xl">
      <StyledToolbar>
        <Tabs value={value} onChange={handleChange}>
          <LinkTab
            to={`${url}/parameter${location.search}`}
            label="Parameter"
            value="parameter"
          />
          <LinkTab
            to={`${url}/location${location.search}`}
            label="Location"
            value="location"
          />
          <LinkTab
            to={`${url}/value${location.search}`}
            label="Value"
            value="value"
          />
        </Tabs>
      </StyledToolbar>

      <StyledDiv>
        <Switch>
          <Redirect
            from={path}
            exact
            to={`${path}/parameter${location.search}`}
          />
          <Route
            path={`${path}/parameter`}
            render={() => <ParameterPanel />}
          />
          <Route
            path={`${path}/location`}
            render={() => (
              <LocationPanel project={project} setProject={setProject} />
            )}
          />
          <Route
            path={`${path}/value`}
            render={() => <ValuePanel />}
          />
        </Switch>
      </StyledDiv>
    </StyledContainer>
  );
};

export default PipelineParameterPanel;
