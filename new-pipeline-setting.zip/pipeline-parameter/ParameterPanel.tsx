import {
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Paper,
} from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { useSnackbar } from 'notistack';
import React, { useCallback, useEffect, useMemo, useState } from 'react';

import ActionCell from './ActionCell';
import AddFab from './AddFab';
import DeletionDialog from './DeletionDialog';
import DescriptionField from './Field/DescriptionField';
import DisplayNameField from './Field/DisplayNameField';
import KeyNameField from './Field/KeyNameField';
import SchemaFields from './Field/SchemaFields';
import RecordTable from './RecordTable';
import { createParameter, deleteParameter } from './api';
import { useParameters } from './hooks';
import { Column, JsonSchema, Parameter, PageProps } from './types';
import SettingTableFooter from './SettingTableFooter';
import { TablePaginationProps } from '@material-ui/core/TablePagination';

class ParameterData {
  readonly keyName: string;
  readonly schema: JsonSchema;
  readonly displayName?: string;
  readonly description?: string;

  static readonly SCHEMA_TYPES = [
    'boolean',
    'integer',
    'number',
    'string',
    'array',
    'object',
  ] as const;

  static readonly SCHEMA_ARRAY_TYPES = [
    'boolean',
    'integer',
    'number',
    'string',
  ] as const;

  constructor(
    keyName: string = '',
    schema: JsonSchema | null = null,
    displayName?: string,
    description?: string,
  ) {
    this.keyName = keyName;
    this.schema = schema || new JsonSchema();
    this.displayName = displayName;
    this.description = description;
  }

  withKeyName(keyName: string): ParameterData {
    return new ParameterData(keyName, this.schema, this.displayName, this.description);
  }

  withSchema(schema: JsonSchema): ParameterData {
    return new ParameterData(this.keyName, schema, this.displayName, this.description);
  }

  withDisplayName(displayName?: string): ParameterData {
    return new ParameterData(this.keyName, this.schema, displayName, this.description);
  }

  withDescription(description?: string): ParameterData {
    return new ParameterData(this.keyName, this.schema, this.displayName, description);
  }

  isValid(): boolean {
    if (this.keyName === '') {
      return false;
    }
    if (this.schema == null) {
      return false;
    }
    try {
      this.schema.validate();
    } catch (err) {
      return false;
    }
    return true;
  }
}

const StyledContainer = styled(Container)(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
});

const StyledDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'row',
}));

const StyledDialogContent = styled(DialogContent)({
  width: 600,
});

type CreationDialogProps = {
  open: boolean,
  onClose: () => void,
  onCreate: (parameter: Parameter) => void,
};

const CreationDialog: React.FC<CreationDialogProps> = ({ open, onClose, onCreate }) => {
  const [data, setData] = useState<ParameterData>(new ParameterData());
  const { enqueueSnackbar } = useSnackbar();

  const handleKeyNameChange = (value: string) => {
    setData(data.withKeyName(value));
  };

  const handleSchemaChange = (value: JsonSchema) => {
    setData(data.withSchema(value));
  };

  const handleDisplayNameChange = (value: string) => {
    setData(data.withDisplayName(value || undefined));
  };

  const handleDescriptionChange = (value: string) => {
    setData(data.withDescription(value || undefined));
  };

  const handleCreate = async () => {
    try {
      const res = await createParameter(
        data.keyName,
        data.schema.toObject(),
        data.displayName,
        data.description,
      );
      if (res == null) {
        return;
      }
      const message = `Parameter "${data.keyName}" created.`
      enqueueSnackbar(message, { variant: 'success' });
      console.log(message);
      onCreate(res);
      onClose();
      setData(new ParameterData());

    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
        console.log(err.message);
      }
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      area-labelledby="creation-dialog-title"
    >
      <DialogTitle id="creation-dialog-title">New Parameter</DialogTitle>
      <StyledDialogContent>
        <KeyNameField value={data.keyName} onChange={handleKeyNameChange} />
        <SchemaFields schema={data.schema} onSchemaChange={handleSchemaChange} />
        <DisplayNameField value={data.displayName} onChange={handleDisplayNameChange} />
        <DescriptionField value={data.description} onChange={handleDescriptionChange} />
      </StyledDialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleCreate} disabled={!data.isValid()}>Create</Button>
      </DialogActions>
    </Dialog>
  );
};

type ModificationDialogProps = {
  parameter: Parameter,
  onClose: () => void,
  onModify: (parameter: Parameter) => void,
};

const ModificationDialog: React.FC<ModificationDialogProps> = ({
  parameter,
  onClose,
  onModify,
}) => {
  const [data, setData] = useState<ParameterData>(new ParameterData());
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    setData(new ParameterData(
      parameter.key_name,
      new JsonSchema(parameter.schema),
      parameter.display_name || undefined,
      parameter.description || undefined,
    ));
  }, [parameter]);

  const handleSchemaChange = (value: JsonSchema) => {
    setData(data.withSchema(value));
  };

  const handleDisplayNameChange = (value: string) => {
    setData(data.withDisplayName(value || undefined));
  };

  const handleDescriptionChange = (value: string) => {
    setData(data.withDescription(value || undefined));
  };

  const handleModify = () => {
    // TODO: Implemente later
    const message = `Sorry, not implemented yet.`
    enqueueSnackbar(message, { variant: 'error' });
    onModify(parameter);
    onClose();
  };

  return (
    <Dialog
      open
      onClose={onClose}
      area-labelledby="modification-dialog-title"
    >
      <DialogTitle id="modification-dialog-title">Modify Parameter</DialogTitle>
      <StyledDialogContent>
        <KeyNameField value={data.keyName} />
        <SchemaFields schema={data.schema} onSchemaChange={handleSchemaChange} />
        <DisplayNameField value={data.displayName} onChange={handleDisplayNameChange} />
        <DescriptionField value={data.description} onChange={handleDescriptionChange} />
      </StyledDialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleModify} disabled={!data.isValid()}>Modify</Button>
      </DialogActions>
    </Dialog>
  );
};

const ParameterPanel: React.FC = () => {
  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };
  const [pageProps, setPageProps] = useState<PageProps>(initPageProps);
  const { enqueueSnackbar } = useSnackbar();
  const { parameters, total, setParameters, setTotal } = useParameters(
    pageProps.page,
    pageProps.rowsPerPage,
  );
  const [creationDialogOpen, setCreationDialogOpen] = useState(false);
  const [parameterToModify, setParameterToModify] = useState<Parameter | null>(null);
  const [parameterToDelete, setParameterToDelete] = useState<Parameter | null>(null);

  const columns = useMemo<Column<Parameter>[]>(() => [
    {
      id: 'id',
      label: 'ID',
      render: (parameter) => String(parameter.id),
      align: 'right',
    },
    {
      id: 'keyName',
      label: 'Key Name',
      render: (parameter) => parameter.key_name,
    },
    {
      id: 'displayName',
      label: 'Display Name',
      render: (parameter) => parameter.display_name,
    },
    {
      id: 'type',
      label: 'Type',
      render: (parameter) => {
        const { schema } = parameter;
        if (schema.type === 'array') {
          if (typeof schema.items === 'object' && schema.items.type != null) {
            return `Array<${schema.items.type}>`;
          }
          return 'Array';
        }
        return schema.type;
      },
    },
    {
      id: 'description',
      label: 'Description',
      render: (parameter) => parameter.description || '',
    },
    {
      id: 'actions',
      label: 'Actions',
      component: ActionCell,
    },
  ], []);

  const handleCreationDialogOpen = useCallback(() => {
    setCreationDialogOpen(true);
  }, [setCreationDialogOpen]);

  const handleCreationDialogClose = () => {
    setCreationDialogOpen(false);
  };

  const handleParameterCreate = (parameter: Parameter) => {
    setParameters([...parameters, parameter]);
    setTotal(total + 1);
  };

  const handleModificationDialogClose = () => {
    setParameterToModify(null);
  };

  const handleDeletionDialogClose = () => {
    setParameterToDelete(null);
  };

  const handleParameterModify = (parameter: Parameter) => {
    setParameters(parameters.map((p) => (p.id === parameter.id) ? parameter : p));
  };

  const handleParameterDelete = async (parameter: Parameter) => {
    const controller = new AbortController();
    try {
      await deleteParameter(parameter.key_name, controller.signal);
      const message = `Parameter "${parameter.key_name}" deleted.`
      enqueueSnackbar(message, { variant: 'success' });
      console.log(message);
      setParameters(parameters.filter((p) => p.id !== parameter.id));
      const lastPageIndex = Math.ceil(total / pageProps.rowsPerPage) - 1;
      const lastPageRows = total % pageProps.rowsPerPage;
      if (pageProps.page === lastPageIndex && lastPageRows === 1) {
        setPageProps({
          ...pageProps,
          page: Math.max(0, pageProps.page - 1),
        });
      }
    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
      }
      console.log(err);
    } finally {
      controller.abort();
    }
  };

  const handleEditButtonClick = useCallback((parameter: Parameter) => {
    setParameterToModify(parameter);
  }, [setParameterToModify]);

  const handleDeleteButtonClick = useCallback((parameter: Parameter) => {
    setParameterToDelete(parameter);
  }, [setParameterToDelete]);

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  const tableFooter = <SettingTableFooter
    count={total}
    page={pageProps.page}
    rowsPerPage={pageProps.rowsPerPage}
    onChangePage={handlePageChange}
    onChangeRowsPerPage={handleRowsPerPageChange}
  />;

  return (
    <StyledContainer maxWidth="xl">

      <div>
        <StyledPaper>
          <StyledDiv>
            <RecordTable
              columns={columns}
              records={parameters}
              onEditButtonClick={handleEditButtonClick}
              onDeleteButtonClick={handleDeleteButtonClick}
              tableFooter={tableFooter}
            />
          </StyledDiv>
        </StyledPaper>
      </div>

      <AddFab onClick={handleCreationDialogOpen} />

      <CreationDialog
        open={creationDialogOpen}
        onClose={handleCreationDialogClose}
        onCreate={handleParameterCreate}
      />

      {parameterToModify && (
        <ModificationDialog
          parameter={parameterToModify}
          onClose={handleModificationDialogClose}
          onModify={handleParameterModify}
        />
      )}

      {parameterToDelete && (
        <DeletionDialog
          title="Deletion Confirmation"
          contentText={
            `Are you sure you want to delete parameter "${parameterToDelete.key_name}"?`
          }
          onClose={handleDeletionDialogClose}
          onDelete={() => handleParameterDelete(parameterToDelete)}
        />
      )}
    </StyledContainer>
  );
};

export default ParameterPanel;
