import { getAuthHeader, setNewToken } from "../auth/util";
import { AuthorizationError } from "../auth/types";
import { Location, Parameter, Value } from "./types";

type ParameterListResponse = Readonly<{
  parameters: Parameter[],
  next: string | null,
  total: number,
}>;

export async function queryParameters(
  page: number,
  rowsPerPage: number,
  signal?: AbortSignal | null,
): Promise<ParameterListResponse> {
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  if (page !== 0) {
    params.set('page', String(page + 1));
  }
  let url: string | null = `/api/pipelineParameter/parameters?${params}`

  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch parameters.');
  }
  setNewToken(res);
  const json: ParameterListResponse = await res.json();
  return json
}

type LocationListResponse = Readonly<{
  locations: Location[],
  next: string | null,
  total: number,
}>;

export async function queryLocations(
  project: string,
  page: number,
  rowsPerPage: number,
  signal?: AbortSignal | null,
): Promise<LocationListResponse> {
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  if (page !== 0) {
    params.set('page', String(page + 1));
  }
  let url: string | null = `/api/pipelineParameter/projects/${project}/locations?${params}`;

  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch locations.');
  }
  const json: LocationListResponse = await res.json();
  setNewToken(res);

  return json;
}

type ValueListResponse = Readonly<{
  values: Value[],
  next: string | null,
  total: number,
}>;

export async function queryValues(
  page: number,
  rowsPerPage: number,
  parameterKey: string,
  locationKey: string,
  studioKey: string,
  projectKey: string,
  valueKey: string,
  signal?: AbortSignal | null,
): Promise<ValueListResponse> {
  const headers = getAuthHeader();
  const params = new URLSearchParams();
  params.set('per_page', String(rowsPerPage));
  if (page !== 0) {
    params.set('page', String(page + 1));
  }
  if (parameterKey != '') {
    params.set('filter_parameter', parameterKey);
  }
  if (locationKey != '') {
    params.set('filter_location', locationKey);
  }
  if (studioKey != '') {
    params.set('filter_studio', studioKey);
  }
  if (projectKey != '') {
    params.set('filter_project', projectKey);
  }
  if (valueKey != '') {
    params.set('filter_value', valueKey);
  }
  let url: string | null = `/api/pipelineParameter/values?${params}`;

  const res = await fetch(
    url,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    throw new Error('Failed to fetch values.');
  }
  const json: ValueListResponse = await res.json();
  setNewToken(res);
  return json;
}

type ParameterCreationData = {
  key_name: string,
  schema: { [k: string]: any },
  display_name?: string,
  description?: string,
};

export async function createParameter(
  keyName: string,
  schema: { [k: string]: any },
  displayName?: string,
  description?: string,
  signal?: AbortSignal | null,
): Promise<Parameter> {
  const headers = getAuthHeader();
  const data: ParameterCreationData = { key_name: keyName, schema };
  if (displayName != null) {
    data.display_name = displayName;
  }
  if (description != null) {
    data.description = description;
  }
  const res = await fetch(
    '/api/pipelineParameter/parameters',
    {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(data),
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    let message: string;
    try {
      const json: { message: string } = await res.json();
      message = json.message;
    } catch (err) {
      message = `Failed to create parameter. ${JSON.stringify(data)}`;
    }
    throw new Error(message);
  }
  setNewToken(res);
  return await res.json();
}

type LocationCreationData = {
  parameter: string,
  path: string,
};

export async function createLocation(
  project: string,
  parameter: string,
  path: string,
  signal?: AbortSignal | null,
): Promise<Location> {
  const headers = getAuthHeader();
  const data: LocationCreationData = { parameter, path };
  const res = await fetch(
    `/api/pipelineParameter/projects/${project}/locations`,
    {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(data),
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {

    let message: string;
    try {
      const json: { message: string } = await res.json();
      message = json.message;
    } catch (err) {
      message = `Failed to create location. ${JSON.stringify(data)}`;
    }
    throw new Error(message);
  }
  setNewToken(res);
  return await res.json();
}

type ValueCreationData = {
  parameter: string,
  location: string,
  value: any,
  studio?: string,
  project?: string,
};

export async function createValue(
  parameter: string,
  location: string,
  value: any,
  studio?: string,
  project?: string,
  signal?: AbortSignal | null,
): Promise<Value> {
  const headers = getAuthHeader();
  const data: ValueCreationData = { parameter, location, value, studio, project };

  const res = await fetch(
    '/api/pipelineParameter/values',
    {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(data),
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    let message: string;
    try {
      const json: { message: string } = await res.json();
      message = json.message;
    } catch (err) {
      message = `Failed to create value. ${JSON.stringify(data)}`;
    }
    throw new Error(message);
  }
  setNewToken(res);
  return await res.json();
}

export async function deleteParameter(
  keyName: string,
  signal?: AbortSignal | null,
): Promise<void> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/pipelineParameter/parameters/${keyName}`,
    {
      method: 'DELETE',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    let message: string;
    try {
      const json: { message: string } = await res.json();
      message = json.message;
    } catch (e) {
      message = `Failed to delete parameter: ${keyName}`;
    }
    throw new Error(message);
  }
  setNewToken(res);
}

export async function deleteLocation(
  project: string,
  id: number,
  signal?: AbortSignal | null,
): Promise<void> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/pipelineParameter/projects/${project}/locations/${id}`,
    {
      method: 'DELETE',
      headers,
      mode: 'cors',
      signal
    },
  );
  if (res.status === 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    let message: string;
    try {
      const json: { message: string } = await res.json();
      message = json.message;
    } catch (err) {
      message = `Failed to delete location with ID ${id}.`;
    }
    throw new Error(message);
  }
  setNewToken(res);
}

export async function deleteValue(id: number, signal?: AbortSignal | null): Promise<void> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/pipelineParameter/values/${id}`,
    {
      method: 'DELETE',
      headers,
      mode: 'cors',
      signal,
    },
  );
  if (res.status == 401) {
    throw new AuthorizationError();
  }
  if (!res.ok) {
    let message: string;
    try {
      const json: { message: string } = await res.json();
      message = json.message;
    } catch (err) {
      message = `Failed to delete value with ID ${id}.`;
    }
    throw new Error(message);
  }
  setNewToken(res);
}
