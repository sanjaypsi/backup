import { TextField } from '@material-ui/core';
import React from 'react';

type DescriptionFieldProps = {
  value?: string,
  onChange: (value: string) => void,
};

const DescriptionField: React.FC<DescriptionFieldProps> = ({ value, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <TextField
      value={value || ''}
      onChange={handleChange}
      margin="dense"
      id="description"
      label="Description"
      fullWidth
    />
  );
};

export default DescriptionField;
