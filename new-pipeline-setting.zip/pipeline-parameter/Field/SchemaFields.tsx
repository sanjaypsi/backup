import { Checkbox, FormControlLabel, MenuItem, TextField } from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import React from 'react';

import { JsonSchema } from '../types';

const StyledDiv = styled('div')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'row',
  gap: `${theme.spacing(2)}px`,
  '& > *': {
    flexGrow: 1,
  },
}));

const StyledTextField = styled(TextField)({
  '& textarea': {
    fontFamily: 'monospace',
  },
})

const StyledFormControlLabel = styled(FormControlLabel)({
  checkbox: {
    '& .MuiCheckbox-root': {
      padding: '4px 8px',
    },
    '& .MuiFormControlLabel-label': {
      fontSize: '.8rem',
    },
  },
});

type TypeFieldProps = {
  schema: JsonSchema,
  onChange: (value: string) => void,
};

const TypeField: React.FC<TypeFieldProps> = ({ schema, onChange }) => {
  const type = schema.getType();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <TextField
      id="schema-type"
      label="Type"
      value={type || ''}
      onChange={handleChange}
      select
      required
      fullWidth
    >
      <MenuItem value="">&nbsp;</MenuItem>
      {JsonSchema.SCHEMA_TYPES.map((schemaType) => (
        <MenuItem key={schemaType} value={schemaType}>{schemaType}</MenuItem>
      ))}
      {type === JsonSchema.UNKNOWN_TYPE && (
        <MenuItem value={JsonSchema.UNKNOWN_TYPE}>( unknown )</MenuItem>
      )}
    </TextField>
  );
};

type MinMaxFieldProps = {
  idSuffix?: string,
  labelSuffix?: string,
  minimumValue?: number,
  onMinimumChange: (value?: number) => void,
  maximumValue?: number,
  onMaximumChange: (value?: number) => void,
};

const MinMaxField: React.FC<MinMaxFieldProps> = ({
  idSuffix,
  labelSuffix,
  minimumValue,
  onMinimumChange,
  maximumValue,
  onMaximumChange,
}) => {
  const handleMinimumChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    onMinimumChange(value === '' ? undefined : Number(value));
  };

  const handleMaximumChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    onMaximumChange(value === '' ? undefined : Number(value));
  };

  return (
    <StyledDiv>
      <TextField
        id={idSuffix == null ? 'schema-minimum' : `schema-minimum-${idSuffix}`}
        label={labelSuffix == null ? 'Minimum' : `Minimum ${labelSuffix}`}
        value={minimumValue == null ? '' : minimumValue}
        onChange={handleMinimumChange}
        type="number"
      />
      <TextField
        id={idSuffix == null ? 'schema-maximum' : `schema-maximum-${idSuffix}`}
        label={labelSuffix == null ? 'Maximum' : `Maximum ${labelSuffix}`}
        value={maximumValue == null ? '' : maximumValue}
        onChange={handleMaximumChange}
        type="number"
      />
    </StyledDiv>
  );
};

type PatternFieldProps = {
  schema: JsonSchema,
  onChange: (value: string) => void,
};

const PatternField: React.FC<PatternFieldProps> = ({ schema, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  const message: string = (() => {
    try {
      schema.validatePattern();
      return '';
    } catch (err) {
      if (err instanceof Error) {
        return err.message;
      }
      return String(err);
    }
  })();

  return (
    <TextField
      id="schema-pattern"
      label="Pattern"
      value={schema.getPattern() || ''}
      onChange={handleChange}
      error={message !== ''}
      helperText={message}
      fullWidth
    />
  );
};

type ItemTypeFieldProps = {
  schema: JsonSchema,
  onChange: (value: string) => void,
};

const ItemTypeField: React.FC<ItemTypeFieldProps> = ({ schema, onChange }) => {
  const itemType = schema.getItemType();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <TextField
      id="schema-item-type"
      label="Item Type"
      value={itemType || ''}
      onChange={handleChange}
      select
      required
      fullWidth
    >
      {JsonSchema.SCHEMA_ITEM_TYPES.map((itemType) => (
        <MenuItem key={itemType} value={itemType}>{itemType}</MenuItem>
      ))}
      {itemType === JsonSchema.UNKNOWN_TYPE && (
        <MenuItem value={JsonSchema.UNKNOWN_TYPE}>( unknown )</MenuItem>
      )}
    </TextField>
  );
};

type UniqueItemCheckboxProps = {
  schema: JsonSchema,
  onChange: (checked: boolean) => void,
};

const UniqueItemCheckbox: React.FC<UniqueItemCheckboxProps> = ({ schema, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => {
    onChange(checked);
  };

  return (
    <StyledFormControlLabel
      control={(
        <Checkbox
          checked={schema.isUniqueItems() === true}
          onChange={handleChange}
          color="primary"
        />
      )}
      label="Unique Item"
    />
  );
};

type SchemaTextFieldProps = {
  schema: JsonSchema,
  onChange: (value: string) => void,
};

const SchemaTextField: React.FC<SchemaTextFieldProps> = ({ schema, onChange }) => {
  const message: string = (() => {
    if (schema.toString() === '') {
      return '';
    }
    try {
      schema.validate();
      return '';
    } catch (err) {
      if (err instanceof Error) {
        return err.message;
      }
      return String(err);
    }
  })();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <StyledTextField
      required
      value={schema.toString()}
      onChange={handleChange}
      error={message !== ''}
      helperText={message}
      margin="dense"
      id="schema-text"
      label="Schema"
      multiline
      rows={6}
      fullWidth
    />
  );
};

type SchemaEditProps = {
  schema: JsonSchema,
  onSchemaChange: (schema: JsonSchema) => void,
};

const SchemaFields: React.FC<SchemaEditProps> = ({ schema, onSchemaChange }) => {
  const handleTypeChange = (value: string) => {
    switch (value) {
      case JsonSchema.UNKNOWN_TYPE:
        return;
      case '':
        onSchemaChange(new JsonSchema());
        return;
      default:
        onSchemaChange(schema.withType(value));
    }
  };

  const handleMinimumChange = (value?: number) => {
    onSchemaChange(schema.withMinimum(value));
  };

  const handleMaximumChange = (value?: number) => {
    onSchemaChange(schema.withMaximum(value));
  };

  const handleMinLengthChange = (value?: number) => {
    onSchemaChange(schema.withMinLength(value));
  };

  const handleMaxLengthChange = (value?: number) => {
    onSchemaChange(schema.withMaxLength(value));
  };

  const handleMinItemsChange = (value?: number) => {
    onSchemaChange(schema.withMinItems(value));
  };

  const handleMaxItemsChange = (value?: number) => {
    onSchemaChange(schema.withMaxItems(value));
  };

  const handlePatternChange = (value: string) => {
    onSchemaChange(schema.withPattern(value));
  };

  const handleItemTypeChange = (value: string) => {
    onSchemaChange(schema.withItemType(value));
  };

  const handleUniqueItemsChange = (checked: boolean) => {
    onSchemaChange(schema.withUniqueItems(checked));
  };

  const handleSchemaChange = (value: string) => {
    onSchemaChange(new JsonSchema(value));
  };

  const shouldShowJsonSchemaField = (): boolean => {
    if (schema.toString() === '') {
      return false;
    }
    switch (schema.getType()) {
      case JsonSchema.UNKNOWN_TYPE:
      case 'object':
      case undefined:
        return true;
    }
    return false;
  };

  return (
    <>
      <TypeField schema={schema} onChange={handleTypeChange} />
      {(schema.getType() === 'integer' || schema.getType() === 'number') && (
        <MinMaxField
          minimumValue={schema.getMinimum()}
          onMinimumChange={handleMinimumChange}
          maximumValue={schema.getMaximum()}
          onMaximumChange={handleMaximumChange}
        />
      )}
      {schema.getType() === 'string' && (
        <>
          <PatternField schema={schema} onChange={handlePatternChange} />
          <MinMaxField
            idSuffix="length"
            labelSuffix="Length"
            minimumValue={schema.getMinLength()}
            onMinimumChange={handleMinLengthChange}
            maximumValue={schema.getMaxLength()}
            onMaximumChange={handleMaxLengthChange}
          />
        </>
      )}
      {schema.getType() === 'array' && (
        <>
          <ItemTypeField schema={schema} onChange={handleItemTypeChange} />
          <UniqueItemCheckbox schema={schema} onChange={handleUniqueItemsChange} />
          <MinMaxField
            idSuffix="items"
            labelSuffix="Items"
            minimumValue={schema.getMinItems()}
            onMinimumChange={handleMinItemsChange}
            maximumValue={schema.getMaxItems()}
            onMaximumChange={handleMaxItemsChange}
          />
        </>
      )}
      {shouldShowJsonSchemaField() && (
        <SchemaTextField schema={schema} onChange={handleSchemaChange} />
      )}
    </>
  );
};

export default SchemaFields;
