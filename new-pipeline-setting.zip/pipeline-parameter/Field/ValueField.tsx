import { TextField } from '@material-ui/core';
import React, { useMemo } from 'react';

type ValueFieldProps = {
  value: string,
  onChange: (value: string) => void,
  schema: { [k: string]: any } | null,
};

const ValueField: React.FC<ValueFieldProps> = ({ value, onChange, schema }) => {
  // TODO: Providing the appropriate input fields depending on the schema

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  const schemaType = useMemo((): string => {
    if (schema == null) {
      return '';
    }
    if (schema.type === 'array') {
      if (typeof schema.items === 'object' && schema.items.type != null) {
        return `Array<${schema.items.type}>`;
      }
      return 'Array';
    }
    return schema.type;
  }, [schema]);

  return (
    <TextField
      required
      value={value}
      onChange={handleChange}
      margin="dense"
      id="dialog-value"
      label={`Value ( ${schemaType} )`}
      multiline={schema != null && schema.type === 'object'}
      fullWidth
    />
  );
};

export default ValueField;
