import { MenuItem, TextField } from '@material-ui/core';
import React, { useMemo } from 'react';

import { useStudios } from '../../studio/hooks';
import { Studio } from '../../studio/types';

type StudioFieldProps = {
  value: string,
  onChange: (value: string) => void,
};

const StudioField: React.FC<StudioFieldProps> = ({ value, onChange }) => {
  const { studios } = useStudios();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  const studio = useMemo((): Studio | undefined => {
    if (value === '') {
      return;
    }
    return studios.find((s) => s.key_name === value);
  }, [value, studios]);

  return (
    <TextField
      value={studio != null ? studio.key_name : ''}
      onChange={handleChange}
      margin="dense"
      id="dialog-studio"
      label="Studio"
      select
      fullWidth
    >
      <MenuItem value="">( No Studio )</MenuItem>
      {studios.map((studio) => (
        <MenuItem key={studio.id} value={studio.key_name}>{studio.key_name}</MenuItem>
      ))}
    </TextField>

  );
};

export default StudioField;
