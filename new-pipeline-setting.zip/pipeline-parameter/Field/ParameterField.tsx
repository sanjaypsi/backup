import { MenuItem, TextField } from '@material-ui/core';
import React, { useMemo } from 'react';

import { useAllParameters } from '../hooks';
import { Parameter } from '../types';

type ParameterFieldProps = {
  value: Parameter | null,
  onChange: (value: Parameter | null) => void,
};

const ParameterField: React.FC<ParameterFieldProps> = ({ value, onChange }) => {
  const { parameters } = useAllParameters();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const parameter = parameters.find((p) => p.key_name === event.target.value);
    onChange(parameter || null);
  };

  const parameter = useMemo((): Parameter | undefined => {
    if (value == null) {
      return;
    }
    return parameters.find((p) => p.key_name === value.key_name);
  }, [value, parameters]);

  return (
    <TextField
      required
      value={parameter != null ? parameter.key_name : ''}
      onChange={handleChange}
      margin="dense"
      id="dialog-parameter"
      label="Parameter"
      select
      fullWidth
    >
      {parameters.map((parameter) => (
        <MenuItem key={parameter.id} value={parameter.key_name}>{parameter.key_name}</MenuItem>
      ))}
    </TextField>
  );
};

export default ParameterField;
