import { TextField } from '@material-ui/core';
import React from 'react';

type DisplayNameFieldProps = {
  value?: string,
  onChange: (value: string) => void,
};

const DisplayNameField: React.FC<DisplayNameFieldProps> = ({ value, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <TextField
      value={value || ''}
      onChange={handleChange}
      margin="dense"
      id="dialog-display-name"
      label="Display Name"
      fullWidth
    />
  );
};

export default DisplayNameField;
