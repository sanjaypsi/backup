import { TextField } from '@material-ui/core';
import React from 'react';

type KeyNameFieldProps = {
  value: string,
  onChange?: (value: string) => void,
}

const KeyNameField: React.FC<KeyNameFieldProps> = ({ value, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange && onChange(event.target.value);
  };

  return (
    <TextField
      required
      value={value}
      onChange={handleChange}
      margin="dense"
      id="dialog-key-name"
      label="Key Name"
      inputProps={{ readOnly: onChange == null }}
      fullWidth
    />
  );
};

export default KeyNameField;
