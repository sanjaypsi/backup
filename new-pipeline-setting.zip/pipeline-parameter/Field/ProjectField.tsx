import { MenuItem, TextField } from '@material-ui/core';
import React, { useMemo } from 'react';

import { useProjects } from '../../project/hooks';
import { Project } from '../../project/types';
import ProjectName from '../../project/ProjectName';

type ProjectFieldProps = {
  value: string,
  onChange: (value: string) => void,
};

const ProjectField: React.FC<ProjectFieldProps> = ({ value, onChange }) => {
  const { projects } = useProjects();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  const project = useMemo((): Project | undefined => {
    if (value === '') {
      return;
    }
    return projects.find((p) => p.key_name === value);
  }, [value, projects]);

  return (
    <TextField
      required
      id="dialog-project"
      label="Project"
      value={project != null ? project.key_name : ''}
      onChange={handleChange}
      select
      fullWidth
    >
      <MenuItem value="">( No Project )</MenuItem>
      {projects.map((project) => (
        <MenuItem key={project.id} value={project.key_name}>
          <ProjectName project={project} />
        </MenuItem>
      ))}
    </TextField>
  );
};

export default ProjectField;
