import { TextField } from '@material-ui/core';
import React from 'react';

type LocationFieldProps = {
  value: string,
  onChange: (value: string) => void,
};

const LocationField: React.FC<LocationFieldProps> = ({ value, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <TextField
      value={value}
      onChange={handleChange}
      margin="dense"
      id="dialog-location"
      label="Location"
      fullWidth
    />
  );
};

export default LocationField;
