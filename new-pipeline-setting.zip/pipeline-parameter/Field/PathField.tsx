import { TextField } from '@material-ui/core';
import React from 'react';

type PathFieldProps = {
  value: string,
  onChange: (value: string) => void,
};

const PathField: React.FC<PathFieldProps> = ({ value, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <TextField
      required
      value={value}
      onChange={handleChange}
      margin="dense"
      id="dialog-path"
      label="Path"
      fullWidth
    />
  );
};

export default PathField;
