import { Table, TableBody, TableCell, TableHead, TableRow } from '@material-ui/core';
import React, { ReactElement } from 'react';

import { Column, Record } from './types';

type RecordTableHeadProps<T extends Record> = {
  columns: Column<T>[],
};

type RecordTableHeadType = <T extends Record>(
  props: RecordTableHeadProps<T>,
) => React.ReactElement | null;

const RecordTableHead = React.memo<RecordTableHeadType>(({ columns }) => {
  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => <TableCell key={column.id}>{column.label}</TableCell>)}
      </TableRow>
    </TableHead>
  );
}) as RecordTableHeadType;

type RecordTableRowProps<T extends Record> = {
  columns: Column<T>[],
  record: T,
  onEditButtonClick: (record: T) => void,
  onDeleteButtonClick: (record: T) => void,
};

type RecordTableRowType = <T extends Record>(
  props: RecordTableRowProps<T>,
) => React.ReactElement | null;

const RecordTableRow = React.memo<RecordTableRowType>(({
  columns,
  record,
  onEditButtonClick,
  onDeleteButtonClick,
}) => {
  return (
    <TableRow>
      {columns.map((column) => {
        if (typeof column.component === 'function') {
          return (
            <column.component
              key={column.id}
              value={record}
              onEditButtonClick={onEditButtonClick}
              onDeleteButtonClick={onDeleteButtonClick}
            />
          );
        }
        return (
          <TableCell key={column.id} align={column.align}>
            {typeof column.render === 'function' && column.render(record)}
          </TableCell>
        );
      })}
    </TableRow>
  );
}) as RecordTableRowType;

type RecordTableProps<T extends Record> = {
  columns: Column<T>[],
  records: T[],
  onEditButtonClick: (record: T) => void,
  onDeleteButtonClick: (record: T) => void,
  tableFooter?: ReactElement | null,
};

const RecordTable: <T extends Record>(
  props: RecordTableProps<T>,
) => React.ReactElement | null = ({
  columns,
  records,
  onEditButtonClick,
  onDeleteButtonClick,
  tableFooter,
}) => {
    return (
      <Table size="small" stickyHeader>
        <RecordTableHead columns={columns} />
        <TableBody>
          {records.map((record) => (
            <RecordTableRow
              key={record.id}
              columns={columns}
              record={record}
              onEditButtonClick={onEditButtonClick}
              onDeleteButtonClick={onDeleteButtonClick}
            />
          ))}
        </TableBody>
        {tableFooter || null}
      </Table>
    );
  };

export default RecordTable;
