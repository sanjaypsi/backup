import { TableCellProps } from "@material-ui/core/TableCell";

export type Record = Readonly<{
  id: number,
  created_by: string,
  created_at_utc: string,
  modified_by: string,
  modified_at_utc: string,
}>;

export type Parameter = Readonly<{
  key_name: string,
  schema: { [k: string]: any },
  display_name: string | null,
  description: string | null,
}> & Record;

export type Location = Readonly<{
  project: string,
  parameter: string,
  path: string,
  depth: number,
}> & Record;

export type Value = Readonly<{
  parameter: string,
  location: string,
  depth: number,
  value: any,
  studio: string | null,
  project: string | null,
}> & Record;

export type ColumnComponentProps<T extends Record> = {
  value: T,
  onEditButtonClick: (value: T) => void,
  onDeleteButtonClick: (value: T) => void,
};

export type Column<T extends Record> = {
  id: string,
  label: string,
  render?: (value: T) => React.ReactNode,
  component?: (props: ColumnComponentProps<T>) => React.ReactElement | null,
  align?: TableCellProps['align'],
};

export type PageProps = Readonly<{
  page: number,
  rowsPerPage: number,
}>;

export type FilterProps = Readonly<{
  parameterKey: string,
  locationKey: string,
  studioKey: string,
  projectKey: string,
  valueKey: string,
}>;

// Reference: https://json-schema.org/understanding-json-schema/
export class JsonSchema {
  static readonly SCHEMA_TYPES = [
    'boolean',
    'integer',
    'number',
    'string',
    'array',
    'object',
  ] as const;

  static readonly SCHEMA_ITEM_TYPES = [
    'boolean',
    'integer',
    'number',
    'string',
  ] as const;

  static readonly UNKNOWN_TYPE = 'unknown' as const;

  private readonly _value: string;

  constructor(value?: string | { [k: string]: any }) {
    if (value == null) {
      this._value = '';
    } else if (typeof value === 'string') {
      this._value = value;
    } else {
      this._value = JSON.stringify(value, null, 2);
    }
  }

  getType(): typeof JsonSchema.SCHEMA_TYPES[number] | typeof JsonSchema.UNKNOWN_TYPE | undefined {
    try {
      const obj = this.toObject();
      if (typeof obj !== 'object' || obj.type == null) {
        return;
      }
      if (!JsonSchema.SCHEMA_TYPES.includes(obj.type)) {
        return JsonSchema.UNKNOWN_TYPE;
      }
      return obj.type;
    } catch (err) { }
  }

  getMinimum(): number | undefined {
    try {
      return this.toObject().minimum;
    } catch (err) { }
  }

  getMaximum(): number | undefined {
    try {
      return this.toObject().maximum;
    } catch (err) { }
  }

  getMinLength(): number | undefined {
    try {
      return this.toObject().minLength;
    } catch (err) { }
  }

  getMaxLength(): number | undefined {
    try {
      return this.toObject().maxLength;
    } catch (err) { }
  }

  getMinItems(): number | undefined {
    try {
      return this.toObject().minItems;
    } catch (err) { }
  }

  getMaxItems(): number | undefined {
    try {
      return this.toObject().maxItems;
    } catch (err) { }
  }

  getPattern(): string | undefined {
    try {
      return this.toObject().pattern;
    } catch (err) { }
  }

  getItemType(): typeof JsonSchema.SCHEMA_ITEM_TYPES[number] | typeof JsonSchema.UNKNOWN_TYPE | undefined {
    try {
      const obj = this.toObject();
      if (typeof obj !== 'object' || obj.items == null || obj.items.type == null) {
        return;
      }
      if (!JsonSchema.SCHEMA_ITEM_TYPES.includes(obj.items.type)) {
        return JsonSchema.UNKNOWN_TYPE;
      }
      return obj.items.type;
    } catch (err) { }
  }

  isUniqueItems(): boolean | undefined {
    try {
      return this.toObject().uniqueItems === true;
    } catch (err) { }
  }

  validate(): void {
    this.toObject();
    this.validateType();
    switch (this.getType()) {
      case 'string':
        this.validatePattern();
        break;
      case 'array':
        this.validateItemType();
        this.validateUniqueItems();
        break;
    }
  }

  validateType(): void {
    const type = this.getType();
    if (type == null) {
      throw new Error('"type" is required.');
    }
    if (type === JsonSchema.UNKNOWN_TYPE) {
      throw new Error(`Unknown type.`);
    }
    if (!(JsonSchema.SCHEMA_TYPES as readonly string[]).includes(type)) {
      throw new Error(`Invalid type "${type}"`);
    }
  }

  validatePattern(): void {
    const pattern = this.getPattern();
    if (pattern != null) {
      new RegExp(pattern);
    }
  }

  validateItemType(): void {
    const type = this.getType();
    if (type !== 'array') {
      return;
    }
    const itemType = this.getItemType();
    if (itemType == null) {
      throw new Error('"item.type" is required for array.');
    }
    if (!(JsonSchema.SCHEMA_ITEM_TYPES as readonly string[]).includes(itemType)) {
      throw new Error(`Invalid item type "${itemType}"."`);
    }
  }

  validateUniqueItems(): void {
    const obj = this.toObject();
    if (typeof obj !== 'object' || obj.uniqueItems == null) {
      return;
    }
    if (typeof obj.uniqueItems !== 'boolean') {
      throw new Error('"uniqueItems" should be the boolean type.');
    }
  }

  toString(): string {
    return this._value;
  }

  toObject(): any {
    return JSON.parse(this._value);
  }

  withType(type: string): JsonSchema {
    if (!(JsonSchema.SCHEMA_TYPES as readonly string[]).includes(type)) {
      throw new Error(`Invalid schema type "${type}".`);
    }

    let obj: { [k: string]: any } = {};
    try {
      obj = this.toObject();
      if (typeof obj !== 'object') {
        obj = {};
      }
    } catch (err) { }

    if (obj.type === type) {
      return this;
    }

    switch (type) {

      case 'boolean':
        obj = {
          type,
        };
        break;

      case 'integer':
        obj = {
          type,
          minimum: (typeof obj.minimum === 'number') ? obj.minimum | 0 : undefined,
          maximum: (typeof obj.maximum === 'number') ? obj.maximum | 0 : undefined,
        };
        break;

      case 'number':
        obj = {
          type,
          minimum: obj.minimum,
          maximum: obj.maximum,
        };
        break;

      case 'string':
        obj = {
          type,
          minLength: obj.minLength,
          maxLength: obj.maxLength,
          pattern: obj.pattern,
        };
        break;

      case 'array':
        obj = {
          type,
          items: obj.items,
          minItems: obj.minItems,
          maxItems: obj.maxItems,
          uniqueItems: obj.uniqueItems,
        };
        break;

      case 'object':
        obj = {
          type,
          properties: obj.properties || {},
          additionalProperties: obj.additionalProperties,
          required: obj.required,
        };
        break;
    }

    return new JsonSchema(obj);
  }

  withMinimum(value?: number): JsonSchema {
    const obj = this.toObject();
    obj.minimum = (value != null && obj.type === 'integer') ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withMaximum(value?: number): JsonSchema {
    const obj = this.toObject();
    obj.maximum = (value != null && obj.type === 'integer') ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withMinLength(value?: number): JsonSchema {
    const obj = this.toObject();
    obj.minLength = (value != null) ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withMaxLength(value?: number): JsonSchema {
    const obj = this.toObject();
    obj.maxLength = (value != null) ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withMinItems(value?: number): JsonSchema {
    const obj = this.toObject();
    obj.minItems = (value != null) ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withMaxItems(value?: number): JsonSchema {
    const obj = this.toObject();
    obj.maxItems = (value != null) ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withPattern(value: string): JsonSchema {
    const obj = this.toObject();
    obj.pattern = (value !== '') ? value : undefined;
    return new JsonSchema(obj);
  }

  withItemType(type: string): JsonSchema {
    if (!(JsonSchema.SCHEMA_ITEM_TYPES as readonly string[]).includes(type)) {
      throw new Error(`Invalid items type "${type}".`);
    }
    const obj = this.toObject();
    obj.items = obj.items || {};
    obj.items.type = type;
    return new JsonSchema(obj);
  }

  withUniqueItems(checked: boolean): JsonSchema {
    const obj = this.toObject();
    obj.uniqueItems = checked || undefined;
    return new JsonSchema(obj);
  }
};
