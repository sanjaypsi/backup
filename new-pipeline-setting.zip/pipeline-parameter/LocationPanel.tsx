import {
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Paper,
  TextField,
} from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { useSnackbar } from 'notistack';
import React, { useCallback, useMemo, useState } from 'react';

import { useProjects } from '../project/hooks';
import ProjectName from '../project/ProjectName';
import ActionCell from './ActionCell';
import AddFab from './AddFab';
import DeletionDialog from './DeletionDialog';
import ParameterField from './Field/ParameterField';
import PathField from './Field/PathField';
import ProjectField from './Field/ProjectField';
import RecordTable from './RecordTable';
import { createLocation, deleteLocation } from './api';
import { useLocations } from './hooks';
import { Column, Location, Parameter, PageProps } from './types';
import SettingTableFooter from './SettingTableFooter';
import { TablePaginationProps } from '@material-ui/core/TablePagination';

class LocationData {
  readonly project: string;
  readonly parameter: Parameter | null;
  readonly path: string;

  constructor(project: string = '', parameter: Parameter | null = null, path: string = '') {
    this.project = project;
    this.parameter = parameter;
    this.path = path;
  }

  withProject(project: string): LocationData {
    return new LocationData(project, this.parameter, this.path);
  }

  withParameter(parameter: Parameter | null): LocationData {
    return new LocationData(this.project, parameter, this.path);
  }

  withPath(path: string): LocationData {
    return new LocationData(this.project, this.parameter, path);
  }

  isValid(): boolean {
    if (this.project === '') {
      return false;
    }
    if (this.parameter == null) {
      return false;
    }
    if (this.path === '') {
      return false;
    }
    return true;
  }
};

const StyledContainer = styled(Container)(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
});

const InnerDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'row',
}));

const StyledForm = styled('form')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  '& .MuiTextField-root': {
    margin: theme.spacing(1),
    marginRight: 0,
  },
  '& .MuiTextField-root:last-child': {
    marginRight: theme.spacing(1),
  },
}));

const FilterDiv = styled('div')({
  minHeight: 70,
});

const StyledTextField = styled(TextField)({
  maxWidth: 200,
});

type CreationDialogProps = {
  open: boolean,
  onClose: () => void,
  onCreate: (location: Location) => void,
};

const CreationDialog: React.FC<CreationDialogProps> = ({
  open,
  onClose,
  onCreate,
}) => {
  const [data, setData] = useState<LocationData>(new LocationData());
  const { enqueueSnackbar } = useSnackbar();

  const handleProjectChange = (value: string) => {
    setData(data.withProject(value));
  };

  const handleParameterChange = (value: Parameter | null) => {
    setData(data.withParameter(value));
  };

  const handlePathChange = (value: string) => {
    setData(data.withPath(value));
  };

  const handleCreate = async () => {
    if (data.parameter == null) {
      return;
    }
    try {
      const res = await createLocation(data.project, data.parameter.key_name, data.path);
      onCreate(res);
      const message = `Location "${data.path}" created.`;
      enqueueSnackbar(message, { variant: 'success' });
      console.log(message);
      onClose();
      setData(new LocationData());
    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
        console.log(err.message);
      }
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      area-labelledby="form-dialog-title"
    >
      <DialogTitle id="form-dialog-title">New Location</DialogTitle>
      <DialogContent>
        <ProjectField value={data.project} onChange={handleProjectChange} />
        <ParameterField value={data.parameter} onChange={handleParameterChange} />
        <PathField value={data.path} onChange={handlePathChange} />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleCreate} disabled={!data.isValid()}>Create</Button>
      </DialogActions>
    </Dialog>
  );
};

type LocationPanelProps = {
  project: string,
  setProject: (project: string) => void,
};

const LocationPanel: React.FC<LocationPanelProps> = ({ project, setProject }) => {
  const { enqueueSnackbar } = useSnackbar();
  const { projects } = useProjects();
  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };
  const [pageProps, setPageProps] = useState<PageProps>(initPageProps);
  const { locations, total, setLocations, setTotal } = useLocations(
    project,
    pageProps.page,
    pageProps.rowsPerPage,
  );
  const [creationDialogOpen, setCreationDialogOpen] = useState(false);
  const [locationToModify, setLocationToModify] = useState<Location | null>(null);
  const [locationToDelete, setLocationToDelete] = useState<Location | null>(null);

  const columns = useMemo<Column<Location>[]>(() => [
    {
      id: 'id',
      label: 'ID',
      render: (location) => String(location.id),
      align: 'right',
    },
    {
      id: 'project',
      label: 'Project',
      render: (location) => location.project,
    },
    {
      id: 'parameter',
      label: 'Parameter',
      render: (location) => location.parameter,
    },
    {
      id: 'path',
      label: 'Path',
      render: (location) => location.path,
    },
    {
      id: 'depth',
      label: 'Depth',
      render: (location) => String(location.depth),
      align: 'right',
    },
    {
      id: 'actions',
      label: 'Actions',
      component: ActionCell,
    },
  ], []);

  const handleProjectChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setProject(event.target.value);
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  const handleCreationDialogOpen = useCallback(() => {
    setCreationDialogOpen(true);
  }, [setCreationDialogOpen]);

  const handleCreationDialogClose = () => {
    setCreationDialogOpen(false);
  };

  const handleLocationCreate = (location: Location) => {
    setLocations([...locations, location]);
    setTotal(total + 1);
  };

  const handleEditButtonClick = useCallback((location: Location) => {
    setLocationToModify(location);
  }, [setLocationToModify]);

  const handleDeleteButtonClick = useCallback((location: Location) => {
    setLocationToDelete(location);
  }, [setLocationToDelete]);

  const handleDeletionDialogClose = () => {
    setLocationToDelete(null);
  };

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  const tableFooter = <SettingTableFooter
    count={total}
    page={pageProps.page}
    rowsPerPage={pageProps.rowsPerPage}
    onChangePage={handlePageChange}
    onChangeRowsPerPage={handleRowsPerPageChange}
  />;

  const handleLocationDelete = async (location: Location) => {
    try {
      await deleteLocation(location.project, location.id);
      const message = `Location "${location.path}" deleted.`;
      enqueueSnackbar(message, { variant: 'success' });
      console.log(message);
      setLocations(locations.filter((l) => l.id !== location.id));
      const lastPageIndex = Math.ceil(total / pageProps.rowsPerPage) - 1;
      const lastPageRows = total % pageProps.rowsPerPage;
      if (pageProps.page === lastPageIndex && lastPageRows === 1) {
        setPageProps({
          ...pageProps,
          page: Math.max(0, pageProps.page - 1),
        });
      }
    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
        console.log(err.message);
      }
    }
  };

  return (
    <StyledContainer maxWidth="xl">

      <FilterDiv>
        <StyledPaper>
          <InnerDiv>
            <StyledForm
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit}
            >
              <StyledTextField
                id="filter-project"
                label="Project"
                value={project}
                select
                fullWidth
                onChange={handleProjectChange}
              >
                <MenuItem value="">( No Project )</MenuItem>
                {projects.map((project) => (
                  <MenuItem key={project.id} value={project.key_name}>
                    <ProjectName project={project} />
                  </MenuItem>
                ))}
              </StyledTextField>
            </StyledForm>
          </InnerDiv>
        </StyledPaper>
      </FilterDiv>

      <div>
        <StyledPaper>
          <InnerDiv>
            <RecordTable
              columns={columns}
              records={locations}
              onEditButtonClick={handleEditButtonClick}
              onDeleteButtonClick={handleDeleteButtonClick}
              tableFooter={tableFooter}
            />
          </InnerDiv>
        </StyledPaper>
      </div>

      <AddFab onClick={handleCreationDialogOpen} />

      <CreationDialog
        open={creationDialogOpen}
        onClose={handleCreationDialogClose}
        onCreate={handleLocationCreate}
      />

      {locationToDelete && (
        <DeletionDialog
          title="Deletion Confirmation"
          contentText={`Are you sure you want to delete location "${locationToDelete.path}"?`}
          onClose={handleDeletionDialogClose}
          onDelete={() => handleLocationDelete(locationToDelete)}
        />
      )}

    </StyledContainer>
  );
};

export default LocationPanel;
