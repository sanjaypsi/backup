import { useEffect, useState } from 'react';

import { queryLocations, queryParameters, queryValues } from './api';
import { Location, Parameter, Value } from './types';

export function useParameters(
  page: number,
  rowsPerPage: number,
) {
  const [parameters, setParameters] = useState<Parameter[]>([]);
  const [total, setTotal] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    (async () => {
      const res = await queryParameters(
        page,
        rowsPerPage,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setParameters(res.parameters);
        setTotal(res.total);
      }
    })();

    return () => controller.abort();
  }, [page, rowsPerPage]);

  return { parameters, total, setParameters, setTotal };
}

export function useAllParameters() {
  const [parameters, setParameters] = useState<Parameter[]>([]);
  const listParameter: Parameter[] = [];

  useEffect(() => {
    const controller = new AbortController();
    let page: number = 0;
    (async () => {
      while (true) {
        const res = await queryParameters(
          page,
          500,
          controller.signal,
        ).catch((err) => {
          if (err.name === 'AbortError') {
            return;
          }
          console.error(err);
        });
        if (res != null) {
          listParameter.push(...res.parameters);
          if (res.next === null) { break; }
          page++;
        }
      }
      setParameters(listParameter);
    })();
    return () => controller.abort();
  }, []);

  return { parameters };
}

export function useLocations(
  project: string,
  page: number,
  rowsPerPage: number,
) {
  const [locations, setLocations] = useState<Location[]>([]);
  const [total, setTotal] = useState(0);
  useEffect(() => {
    if (project === '') {
      if (locations.length !== 0) {
        setLocations([]);
        setTotal(0);
      }
      return;
    }

    const controller = new AbortController();

    (async () => {
      const res = await queryLocations(
        project,
        page,
        rowsPerPage,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setLocations(res.locations);
        setTotal(res.total);
      }
    })();

    return () => controller.abort();
  }, [project, page, rowsPerPage]);

  return { locations, total, setLocations, setTotal };
}

export function useValues(
  page: number,
  rowsPerPage: number,
  parameterKey: string,
  locationKey: string,
  studioKey: string,
  projectKey: string,
  valueKey: string,
) {
  const [values, setValues] = useState<Value[]>([]);
  const [total, setTotal] = useState(0);
  useEffect(() => {
    const controller = new AbortController();

    (async () => {
      const res = await queryValues(
        page,
        rowsPerPage,
        parameterKey,
        locationKey,
        studioKey,
        projectKey,
        valueKey,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setValues(res.values);
        setTotal(res.total)
      }
    })();

    return () => controller.abort();
  }, [page, rowsPerPage, parameterKey, locationKey, studioKey, projectKey, valueKey]);

  return { values, total, setValues, setTotal };
}
