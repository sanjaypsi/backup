import {
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Paper,
  TableCell,
  TextField,
} from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { TextFieldProps } from '@material-ui/core/TextField';
import { useSnackbar } from 'notistack';
import React, { useCallback, useMemo, useState } from 'react';

import { useProjects } from '../project/hooks';
import ProjectName from '../project/ProjectName';
import ActionCell from './ActionCell';
import AddFab from './AddFab';
import DeletionDialog from './DeletionDialog';
import LocationField from './Field/LocationField';
import ParameterField from './Field/ParameterField';
import ProjectField from './Field/ProjectField';
import StudioField from './Field/StudioField';
import ValueField from './Field/ValueField';
import RecordTable from './RecordTable';
import { createValue, deleteValue } from './api';
import { useValues } from './hooks';
import {
  Column,
  ColumnComponentProps,
  FilterProps,
  Parameter,
  Value,
  PageProps,
} from './types';
import SettingTableFooter from './SettingTableFooter';
import { TablePaginationProps } from '@material-ui/core/TablePagination';

class ValueData {
  readonly parameter: Parameter | null;
  readonly location: string;
  readonly value: string;
  readonly studio?: string;
  readonly project?: string;

  constructor(
    parameter: Parameter | null = null,
    location: string = '',
    value: string = '',
    studio?: string,
    project?: string,
  ) {
    this.parameter = parameter === undefined ? null : parameter;
    this.location = location;
    this.value = value;
    this.studio = studio;
    this.project = project;
  }

  withParameter(parameter: Parameter | null): ValueData {
    return new ValueData(parameter, this.location, this.value, this.studio, this.project);
  }

  withLocation(location: string): ValueData {
    return new ValueData(this.parameter, location, this.value, this.studio, this.project);
  }

  withValue(value: string): ValueData {
    return new ValueData(this.parameter, this.location, value, this.studio, this.project);
  }

  withStudio(studio?: string): ValueData {
    return new ValueData(this.parameter, this.location, this.value, studio, this.project);
  }

  withProject(project?: string): ValueData {
    return new ValueData(this.parameter, this.location, this.value, this.studio, project);
  }

  isValid(): boolean {
    if (this.parameter == null) {
      return false;
    }
    if (this.value === '') {
      return false;
    }
    return true;
  }
};

const StyledContainer = styled(Container)(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
});

const StyledDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'row',
}));

const StyledFilterDiv = styled('div')({
  minHeight: 70,
});

const StyledFilterForm = styled('form')(({ theme }) => ({
  '& .MuiTextField-root': {
    margin: theme.spacing(1),
    marginRight: 0,
  },
  '& .MuiTextField-root:last-child': {
    marginRight: theme.spacing(1),
  },
}));

const StyledTextField = styled(TextField)({
  maxWidth: 200,
  minWidth: 180,
});

const StyledFilterResetForm = styled('form')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  justifyContent: 'flex-end',
  marginTop: theme.spacing(1),
  marginRight: theme.spacing(1),
  marginBottom: theme.spacing(0.5),
}));

type CreationDialogProps = {
  open: boolean,
  onClose: () => void,
  onCreate: (value: Value) => void,
};

const CreationDialog: React.FC<CreationDialogProps> = ({ open, onClose, onCreate }) => {
  const [data, setData] = useState<ValueData>(new ValueData());
  const { enqueueSnackbar } = useSnackbar();

  const handleParameterChange = (value: Parameter | null) => {
    setData(data.withParameter(value));
  };

  const handleLocationChange = (value: string) => {
    setData(data.withLocation(value));
  };

  const handleValueChange = (value: string) => {
    setData(data.withValue(value));
  };

  const handleStudioChange = (value: string) => {
    setData(data.withStudio(value || undefined));
  };

  const handleProjectChange = (value: string) => {
    setData(data.withProject(value || undefined));
  };

  const handleCreate = async () => {
    if (data.parameter == null) {
      return;
    }

    let value: any = data.value;
    const { schema } = data.parameter;
    let isValid = false;

    switch (schema.type) {
      case 'boolean':
        value = data.value === 'true';
        isValid = true;
        break;

      case 'integer':
        value = Number(data.value) | 0;
        isValid = true;
        break;

      case 'number':
        value = Number(data.value);
        isValid = true;
        break;

      case 'array':
        let arrayType: any = null;
        if (typeof schema.items === 'object') {
          arrayType = schema.items.type;
        }
        value = data.value.split(',').map((s) => {
          s = s.trim();
          switch (arrayType) {
            case 'boolean':
              return s === 'true';
            case 'integer':
              return Number(s) | 0;
            case 'number':
              return Number(s);
          }
          return s;
        });
        isValid = true;
        break;

      case 'object':
        try {
          value = JSON.parse(value);
          isValid = true;
        } catch (err) {
          if (err instanceof Error) {
            enqueueSnackbar(err.message, { variant: 'error' })
            console.warn(err.message);
          }
          isValid = false;
        }
        break;
    }

    if (!isValid) {
      return;
    }

    try {
      const res = await createValue(
        data.parameter.key_name,
        data.location,
        value,
        data.studio,
        data.project,
      );
      if (res == null) {
        return;
      }

      const message = `A parameter value created: ${res.parameter}=${JSON.stringify(res.value)}`;
      enqueueSnackbar(message, { variant: 'success' });
      console.log(message);
      onCreate(res);
      onClose();
      setData(new ValueData());

    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
        console.warn(err.message);
      }
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      area-labelledby="creation-dialog-title"
    >
      <DialogTitle id="creation-dialog-title">New Value</DialogTitle>
      <DialogContent>
        <ParameterField value={data.parameter} onChange={handleParameterChange} />
        <LocationField value={data.location} onChange={handleLocationChange} />
        <ValueField
          value={data.value}
          onChange={handleValueChange}
          schema={data.parameter && data.parameter.schema}
        />
        <StudioField value={data.studio || ''} onChange={handleStudioChange} />
        <ProjectField value={data.project || ''} onChange={handleProjectChange} />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleCreate} disabled={!data.isValid()}>Create</Button>
      </DialogActions>
    </Dialog>
  );
};

const ValueCell: React.FC<ColumnComponentProps<Value>> = ({ value }) => {
  const text = useMemo(() => {
    if (typeof value.value === 'string') {
      return value.value;
    } else if (Array.isArray(value.value)) {
      return value.value.join(', ');
    } else {
      return JSON.stringify(value.value);
    }
  }, [value]);

  const align = useMemo(() => {
    switch (typeof value.value) {
      case 'boolean':
        return 'center';
      case 'number':
        return 'right';
      default:
        return undefined;
    }
  }, [value]);

  return <TableCell align={align}>{text}</TableCell>;
};

const ValuePanel: React.FC = () => {
  const { enqueueSnackbar } = useSnackbar();
  const { projects } = useProjects();
  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };
  const initFilterProps = {
    parameterKey: '',
    locationKey: '',
    studioKey: '',
    projectKey: '',
    valueKey: '',
  };
  const [pageProps, setPageProps] = useState<PageProps>(initPageProps);
  const [filterProps, setFilterProps] = useState<FilterProps>(initFilterProps);
  const { values, total, setValues, setTotal } = useValues(
    pageProps.page,
    pageProps.rowsPerPage,
    filterProps.parameterKey,
    filterProps.locationKey,
    filterProps.studioKey,
    filterProps.projectKey,
    filterProps.valueKey,
  );
  const [creationDialogOpen, setCreationDialogOpen] = useState(false);
  const [valueToModify, setValueToModify] = useState<Value | null>(null);
  const [valueToDelete, setValueToDelete] = useState<Value | null>(null);

  const columns = useMemo<Column<Value>[]>(() => [
    {
      id: 'id',
      label: 'ID',
      render: (value) => String(value.id),
      align: 'right',
    },
    {
      id: 'parameter',
      label: 'Parameter',
      render: (value) => value.parameter,
    },
    {
      id: 'location',
      label: 'Location',
      render: (value) => value.location,
    },
    {
      id: 'studio',
      label: 'Studio',
      render: (value) => value.studio || '-',
    },
    {
      id: 'project',
      label: 'Project',
      render: (value) => value.project || '-',
    },
    {
      id: 'value',
      label: 'Value',
      component: ValueCell,
    },
    {
      id: 'actions',
      label: 'Actions',
      component: ActionCell,
    },
  ], []);

  const handleCreationDialogOpen = useCallback(() => {
    setCreationDialogOpen(true);
  }, [setCreationDialogOpen]);

  const handleCreationDialogClose = () => {
    setCreationDialogOpen(false);
  };

  const handleValueCreate = (value: Value) => {
    setValues([...values, value]);
    setTotal(total + 1);
  };

  const handleModificationDialogClose = () => {
    setValueToModify(null);
  };

  const handleDeletionDialogClose = () => {
    setValueToDelete(null);
  };

  const handleValueModify = (value: Value) => {
    setValues(values.map((v) => (v.id === value.id) ? value : v));
  };

  const handleValueDelete = async (value: Value) => {
    try {
      await deleteValue(value.id);
      const message = `Value "${value.value}" deleted.`;
      enqueueSnackbar(message, { variant: 'success' });
      console.log(message);
      setValues(values.filter((v) => v.id !== value.id));
      const lastPageIndex = Math.ceil(total / pageProps.rowsPerPage) - 1;
      const lastPageRows = total % pageProps.rowsPerPage;
      if (pageProps.page === lastPageIndex && lastPageRows === 1) {
        setPageProps({
          ...pageProps,
          page: Math.max(0, pageProps.page - 1),
        });
      }
    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
        console.log(err.message);
      }
    }
  };

  const handleEditButtonClick = useCallback((value: Value) => {
    setValueToModify(value);
  }, [setValueToModify]);

  const handleDeleteButtonClick = useCallback((value: Value) => {
    setValueToDelete(value);
  }, [setValueToDelete]);

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  const handleFilterParameterKeyChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      parameterKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
    console.log('handleParameterKeyChange');
  };

  const handleFilterLocationKeyChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      locationKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleFilterStudioKeyChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      studioKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleFilterProjectKeyChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      projectKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleFilterValueKeyChange: TextFieldProps['onChange'] = event => {
    setFilterProps({
      ...filterProps,
      valueKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleFilterKeyPress: TextFieldProps['onKeyPress'] = event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      return false;
    }
  };

  const handleFilterResetClick = () => {
    setFilterProps({
      parameterKey: '',
      locationKey: '',
      studioKey: '',
      projectKey: '',
      valueKey: '',
    });
  };

  const tableFooter = <SettingTableFooter
    count={total}
    page={pageProps.page}
    rowsPerPage={pageProps.rowsPerPage}
    onChangePage={handlePageChange}
    onChangeRowsPerPage={handleRowsPerPageChange}
  />;

  return (
    <StyledContainer maxWidth="xl">

      <StyledFilterDiv>
        <StyledPaper>
          <StyledDiv>
            <StyledFilterForm>
              <StyledTextField
                id="filter-parameter"
                type="search"
                label="Parameter"
                value={filterProps.parameterKey}
                onChange={handleFilterParameterKeyChange}
                onKeyPress={handleFilterKeyPress}
              />
              <StyledTextField
                id="filter-location"
                type="search"
                label="Location"
                value={filterProps.locationKey}
                onChange={handleFilterLocationKeyChange}
                onKeyPress={handleFilterKeyPress}
              />
              <StyledTextField
                id="filter-studio"
                type="search"
                label="Studio"
                value={filterProps.studioKey}
                onChange={handleFilterStudioKeyChange}
                onKeyPress={handleFilterKeyPress}
              />
              <StyledTextField
                id="filter-project"
                label="Project"
                select
                value={filterProps.projectKey}
                onChange={handleFilterProjectKeyChange}
                onKeyPress={handleFilterKeyPress}
              >
                <MenuItem value="">( No Project )</MenuItem>
                {projects.map((project) => (
                  <MenuItem key={project.id} value={project.key_name}>
                    <ProjectName project={project} />
                  </MenuItem>
                ))}
              </StyledTextField>
              <StyledTextField
                id="filter-value"
                type="search"
                label="Value"
                value={filterProps.valueKey}
                onChange={handleFilterValueKeyChange}
                onKeyPress={handleFilterKeyPress}
              />
            </StyledFilterForm>
            <StyledFilterResetForm>
              <Button variant="outlined" onClick={handleFilterResetClick}>
                Reset
              </Button>
            </StyledFilterResetForm>
          </StyledDiv>
        </StyledPaper>
      </StyledFilterDiv>

      <div>
        <StyledPaper>
          <StyledDiv>
            <RecordTable
              columns={columns}
              records={values}
              onEditButtonClick={handleEditButtonClick}
              onDeleteButtonClick={handleDeleteButtonClick}
              tableFooter={tableFooter}
            />
          </StyledDiv>
        </StyledPaper>
      </div>

      <AddFab onClick={handleCreationDialogOpen} />

      <CreationDialog
        open={creationDialogOpen}
        onClose={handleCreationDialogClose}
        onCreate={handleValueCreate}
      />

      {
        valueToDelete && (
          <DeletionDialog
            title="Deletion Confirmation"
            contentText={`Are you sure you want to delete value "${valueToDelete.value}"?`}
            onClose={handleDeletionDialogClose}
            onDelete={() => handleValueDelete(valueToDelete)}
          />
        )
      }

    </StyledContainer>
  );
};

export default ValuePanel;
