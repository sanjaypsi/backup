import React, { ReactElement, useReducer } from 'react';
import { useSnackbar } from 'notistack';
import { Theme, TableCell } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import {
  Column,
  PipelineSettingSchema,
  PipelineSettingValue,
  SettingEntry,
  SettingGroup,
  SettingSection,
  PipelineSettingDefinition,
} from './types';
import ValueCell from './ValueCell';
import MTable from './MTable';
import TableEditField from './TableEditField';
import { getAuthHeader, setNewToken } from '../auth/util';

const SET_TARGET = 'SET_TARGET';
const UNSET_TARGET = 'UNSET_TARGET';
const SET_ERROR = 'SET_ERROR';
const SET_LOADING = 'SET_LOADING';
const SET_SECTIONS = 'SET_SECTIONS';
const SET_ENTRIES = 'SET_ENTRIES';
const SET_SCHEMA = 'SET_SCHEMA';
const SET_TARGET_SECTION = 'SET_TARGET_SECTION';
const SET_TARGET_ENTRY = 'SET_TARGET_ENTRY';
const SET_TARGET_VALUE = 'SET_TARGET_VALUE';

type State = {
  error: string,
  loading: boolean,
  target: PipelineSettingValue | null,
  key: PipelineSettingValue['key'],
  sections: SettingSection[],
  entries: SettingEntry[],
  schema: PipelineSettingSchema['schema'] | PipelineSettingDefinition['definition'] | null,
};

type Action = {
  type: typeof SET_TARGET,
  payload: {
    target: PipelineSettingValue | null,
  },
} | {
  type: typeof UNSET_TARGET,
  payload: {
    target: PipelineSettingValue,
  },
} | {
  type: typeof SET_ERROR,
  payload: {
    error: string,
  },
} | {
  type: typeof SET_LOADING,
  payload: {
    loading: boolean,
  },
} | {
  type: typeof SET_SECTIONS,
  payload: {
    sections: SettingSection[],
  },
} | {
  type: typeof SET_ENTRIES,
  payload: {
    entries: SettingEntry[],
  },
} | {
  type: typeof SET_SCHEMA,
  payload: {
    key: PipelineSettingValue['key'],
    schema: PipelineSettingSchema['schema'] | PipelineSettingDefinition['definition'],
  },
} | {
  type: typeof SET_TARGET_SECTION,
  payload: {
    section: SettingSection,
  },
} | {
  type: typeof SET_TARGET_ENTRY,
  payload: {
    entry: SettingEntry,
  },
} | {
  type: typeof SET_TARGET_VALUE,
  payload: {
    value: PipelineSettingValue['value'] | ((value: PipelineSettingValue['value']) => PipelineSettingValue['value']),
  },
};

const initialState: State = {
  error: '',
  loading: false,
  target: null,
  key: '',
  sections: [],
  entries: [],
  schema: null,
};

function reducer(state: State = initialState, action: Action): State {
  switch (action.type) {
    case SET_TARGET: {
      const { target } = action.payload;
      // console.log('set_target', target);
      return {
        ...state,
        error: '',
        loading: true,
        target,
        key: target != null ? target.key : '',
        schema: target != null && target.key !== state.key ? null : state.schema,
      };
    }
    case UNSET_TARGET: {
      const { target } = action.payload;
      if (state.target == null || state.target.id !== target.id) {
        return state;
      }
      return {
        ...state,
        target: null,
      };
    }
    case SET_ERROR: {
      // console.log('set_error');
      const { error } = action.payload;
      return {
        ...state,
        error,
        loading: false,
        target: null,
      };
    }
    case SET_LOADING: {
      // console.log('set_loading');
      const { loading } = action.payload;
      return {
        ...state,
        loading,
      };
    }
    case SET_SECTIONS: {
      const { sections } = action.payload;
      // console.log('set_sections', sections);
      return {
        ...state,
        sections,
      };
    }
    case SET_ENTRIES: {
      const { entries } = action.payload;
      // console.log('set_entries', entries);
      return {
        ...state,
        entries,
      };
    }
    case SET_SCHEMA: {
      const { key, schema } = action.payload;
      // console.log('set_schema', schema);
      if (key !== state.key) {
        return state;
      }
      return {
        ...state,
        schema,
      };
    }
    case SET_TARGET_SECTION: {
      const { section } = action.payload;
      // console.log(state.target, section);
      if (state.target == null) {
        return state;
      }
      return {
        ...state,
        target: {
          ...state.target,
          section,
        },
      };
    }
    case SET_TARGET_ENTRY: {
      const { entry } = action.payload;
      if (state.target == null) {
        return state;
      }
      return {
        ...state,
        target: {
          ...state.target,
          entry,
        },
      };
    }
    case SET_TARGET_VALUE: {
      const { value } = action.payload;
      if (state.target == null) {
        return state;
      }
      let newValue = typeof value === 'function' ? value(state.target.value) : value;
      return {
        ...state,
        target: {
          ...state.target,
          value: newValue,
        },
      };
    }
  }
}

const useStyles = makeStyles<Theme>(theme => ({
  cell: {
    width: 100,
  },
  valueCell: {
    width: 'auto',
  },
}));

type ValueTableContextProps = {
  settingGroup: SettingGroup | '',
  values: PipelineSettingValue[],
  onDeleteClick: (rowData: PipelineSettingValue) => void,
  onAcceptClick: (newData: PipelineSettingValue, oldData: PipelineSettingValue) => void,
  className?: string,
  tableFooter: ReactElement,
};

const ValueTableContext: React.FC<ValueTableContextProps> = ({
  settingGroup,
  values,
  onDeleteClick,
  onAcceptClick,
  className,
  tableFooter,
}) => {
  const classes = useStyles();
  // TODO: Safe dispatch
  // TODO: Switch to the redux state
  const [state, dispatch] = useReducer(reducer, initialState);
  const { enqueueSnackbar } = useSnackbar();

  const columns: Column<PipelineSettingValue>[] = [
    { title: 'Key', field: 'key' },
    {
      title: 'Section',
      field: 'section',
      isEditorReady: state.error == '',
      renderEditor: target => {
        return (
          <TableCell className={classes.cell}>
            <TableEditField
              schema={{
                type: 'string',
                enum: state.sections,
              }}
              value={target.section}
              onChange={section => {
                updateSchemaForKey(target);
                dispatch({ type: SET_TARGET_SECTION, payload: { section }});
              }}
            />
          </TableCell>
        );
      },
      className: classes.cell,
    },
    {
      title: 'Entry',
      field: 'entry',
      isEditorReady: state.error == '',
      renderEditor: target => {
        return (
          <TableCell className={classes.cell}>
            <TableEditField
              schema={{
                type: 'string',
                enum: target.section === ''
                  ? state.entries
                  : state.entries.reduce<string[]>((arr, entry) => {
                      const [section, name] = entry.split('/');
                      return section === target.section ? [...arr, name] : arr;
                    }, []),
              }}
              value={target.entry}
              onChange={entry => dispatch({ type: SET_TARGET_ENTRY, payload: { entry }})}
            />
          </TableCell>
        )
      },
      className: classes.cell,
    },
  ];

  if (settingGroup === 'environment') {
    columns.push(
      {
        title: 'Env Key',
        render: rowData => <ValueCell value={rowData.value.key} className={classes.cell} />,
        isEditorReady: state.error == '' && state.schema != null,
        renderEditor: target => {
          return (
            <TableCell className={classes.cell}>
              <TableEditField
                schema={state.schema.properties.key}
                value={target.value.key}
                onChange={key => dispatch({
                  type: SET_TARGET_VALUE,
                  payload: { value: (stateValue: PipelineSettingValue['value']) => ({ ...stateValue, key }) },
                })}
              />
            </TableCell>
          );
        },
      },
      {
        title: 'Usage',
        render: rowData => <ValueCell value={rowData.value.usage} className={classes.cell} />,
        isEditorReady: state.error == '' && state.schema != null,
        renderEditor: target => {
          return (
            <TableCell className={classes.cell}>
              <TableEditField
                schema={state.schema.properties.usage}
                value={target.value.usage}
                onChange={usage => dispatch({
                  type: SET_TARGET_VALUE,
                  payload: { value: (stateValue: PipelineSettingValue['value']) => ({ ...stateValue, usage }) },
                })}
              />
            </TableCell>
          );
        },
      },
      {
        title: 'Method',
        render: rowData => <ValueCell value={rowData.value.method} className={classes.cell} />,
        isEditorReady: state.error == '' && state.schema != null,
        renderEditor: target => {
          return (
            <TableCell className={classes.cell}>
              <TableEditField
                schema={state.schema.properties.method}
                value={target.value.method}
                onChange={method => dispatch({
                  type: SET_TARGET_VALUE,
                  payload: { value: (stateValue: PipelineSettingValue['value']) => ({ ...stateValue, method }) },
                })}
              />
            </TableCell>
          );
        },
      },
      {
        title: 'OS Name',
        render: rowData => <ValueCell value={rowData.value.osName} className={classes.cell} />,
        isEditorReady: state.error == '' && state.schema != null,
        renderEditor: target => {
          return (
            <TableCell className={classes.cell}>
              <TableEditField
                schema={state.schema.properties.osName}
                value={target.value.osName}
                onChange={osName => dispatch({
                  type: SET_TARGET_VALUE,
                  payload: { value: (stateValue: PipelineSettingValue['value']) => ({ ...stateValue, osName }) },
                })}
              />
            </TableCell>
          );
        },
      },
      {
        title: 'Sort Order',
        render: rowData => <ValueCell value={rowData.value.sortOrder} className={classes.cell} />,
        isEditorReady: state.error == '' && state.schema != null,
        renderEditor: target => {
          return (
            <TableCell className={classes.cell}>
              <TableEditField
                schema={state.schema.properties.sortOrder}
                value={target.value.sortOrder}
                onChange={sortOrder => dispatch({
                  type: SET_TARGET_VALUE,
                  payload: { value: (stateValue: PipelineSettingValue['value']) => ({ ...stateValue, sortOrder }) },
                })}
              />
            </TableCell>
          );
        },
      },
      {
        title: 'Env Value',
        render: rowData => <ValueCell value={rowData.value.value} className={classes.valueCell} />,
        isEditorReady: state.error == '' && state.schema != null,
        renderEditor: target => {
          return (
            <TableCell className={classes.valueCell}>
              <TableEditField
                schema={state.schema.properties.value}
                value={target.value.value}
                onChange={value => dispatch({
                  type: SET_TARGET_VALUE,
                  payload: { value: (stateValue: PipelineSettingValue['value']) => ({ ...stateValue, value }) },
                })}
              />
            </TableCell>
          );
        },
      },
    );
  } else {
    columns.push({
      title: 'Value',
      render: rowData => <ValueCell value={rowData.value} className={classes.valueCell} />,
      isEditorReady: state.target != null && state.error == '' && state.schema != null,
      renderEditor: target => {
        return (
          <TableCell className={classes.valueCell}>
            <TableEditField
              schema={state.schema}
              value={target.value}
              onChange={value => dispatch({ type: SET_TARGET_VALUE, payload: { value }})}
            />
          </TableCell>
        );
      },
      headerClassName: classes.valueCell,
      className: classes.valueCell,
    });
  }

  async function updateSchemaForKey(value: PipelineSettingValue) {
    // console.log('fetch schema for key');
    const headers = getAuthHeader();
    const section = value.group === 'config' ? value.section : '';
    const res = await fetch(
      `/api/setting/rc1/${value.group}/schemas?key=${value.key}&section=${section}`,
      {
        headers,
      }
    ).catch(e => { throw e });
    if (res.status == 401) {
      return null;
    }
    if (!res.ok) {
      throw new Error(`Failed to fetch schema for key: ${value.key}`);
    }
    const { schemas } = await res.json();
    if (!schemas.length) {
      throw new Error(`No schema found: key="${value.key}" section="${section}"`);
    }
    const schema: PipelineSettingSchema = schemas[0];

    const ref: string | undefined = schema.schema['$ref'];
    if (ref != null) {
      // If $ref definitions are found, fetch the appropriate definition
      const matched = /^#\/definitions\/(.+)$/.exec(ref);
      if (matched != null) {
        const name = matched[1];
        const res2 = await fetch(
          `/api/setting/rc1/${value.group}/definitions?key=${name}`,
          {
            headers,
          }
        ).catch(e => { throw e });
        if (res2.status == 401) {
          return null;
        }
        if (!res2.ok) {
          throw new Error(`Failed to fetch definition for key: ${name}`);
        }
        setNewToken(res);
        const { definitions } = await res2.json();
        if (!definitions) {
          throw new Error(`No definition found for key: ${name}`);
        }
        const definition: PipelineSettingDefinition = definitions[0];
        dispatch({ type: SET_SCHEMA, payload: { key: value.key,  schema: definition.definition }});
        return;
      }
    }

    dispatch({ type: SET_SCHEMA, payload: { key: value.key, schema: schema.schema }});
  };

  async function updateSections() {
    // console.log('fetch sections');
    const headers = getAuthHeader();
    const res = await fetch(
      `/api/setting/rc1/sections`,
      {
        headers,
      }
    ).catch(e => { throw e });
    if (res.status == 401) {
      return null;
    }
    if (!res.ok) {
      throw new Error('Failed to fetch sections.');
    }
    setNewToken(res);
    const { sections } = await res.json();
    dispatch({ type: SET_SECTIONS, payload: { sections }});
  };

  async function updateEntries() {
    // console.log('fetch entries');
    const headers = getAuthHeader();
    const res = await fetch(
      `/api/setting/rc1/entries`,
      {
        headers,
      }
    ).catch(e => { throw e });
    setNewToken(res);
    const { entries } = await res.json();
    dispatch({ type: SET_ENTRIES, payload: { entries }});
  };

  async function handleEditClick(value: PipelineSettingValue) {
    dispatch({ type: SET_TARGET, payload: { target: value }});

    try {
      await Promise.all([
        updateSchemaForKey(value),
        updateSections(),
        updateEntries(),
      ]).catch(e => { throw e });

      dispatch({ type: SET_LOADING, payload: { loading: false }});

    } catch (e) {
      dispatch({ type: SET_ERROR, payload: { error: String(e) }});
      enqueueSnackbar(String(e), { variant: 'error' });
      console.error(e);
    }
  }

  function handleRowUnmount(value: PipelineSettingValue) {
    dispatch({ type: UNSET_TARGET, payload: { target: value }});
  }

  function handleAcceptClick(newData: PipelineSettingValue, oldData: PipelineSettingValue) {
    dispatch({ type: SET_TARGET, payload: { target: null }});
    onAcceptClick(newData, oldData);
  }

  function handleCancelClick(value: PipelineSettingValue) {
    dispatch({ type: SET_TARGET, payload: { target: null }});
  }

  return (
    <MTable
      columns={columns}
      data={values}
      editingData={state.target}
      onEditClick={handleEditClick}
      onDeleteClick={onDeleteClick}
      onRowUnmount={handleRowUnmount}
      className={className}
      tableFooter={tableFooter}
      onAcceptClick={handleAcceptClick}
      onCancelClick={handleCancelClick}
    />
  );
};

export default ValueTableContext;
