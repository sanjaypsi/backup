import React from 'react';
import clsx from 'clsx';
import { TableCell, Theme, Table, TableRow, TableBody } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { blue, lightGreen, orange, pink } from '@material-ui/core/colors';

const useStyles = makeStyles<Theme>(theme => ({
  cell: {
    width: 100,
  },
  row: {
    '&:last-child > td': {
      borderBottom: 'none',
    },
  },
  keyCell: {
    whiteSpace: 'nowrap',
    '&::after': {
      content: "' :'",
    },
  },
  arrayValue: {
    color: pink[200],
  },
  booleanValue: {
    color: blue[200],
    textAlign: 'left',
  },
  numberValue: {
    color: lightGreen[200],
    textAlign: 'right',
  },
  stringValue: {
    color: orange[200],
  },
  objectValue: {
    padding: 0,
    '&:last-child': {
      paddingRight: 0,
    },
  },
}));

type ValueCellProps = {
  value: any,
  className?: string,
};

const ValueCell: React.FC<ValueCellProps> = ({
  value,
  className,
}) => {
  const classes = useStyles();

  if (Array.isArray(value)) {
    return (
      <TableCell className={clsx(classes.arrayValue, className)}>
        {value.map((item, i) => (
          <div key={i}>{String(item)}</div>
        ))}
      </TableCell>
    );
  }

  switch (typeof value) {
    case 'boolean':
      return (
        <TableCell className={clsx(classes.booleanValue, className)}>
          {String(value)}
        </TableCell>
      );
    case 'number':
      return (
        <TableCell className={clsx(classes.numberValue, className)}>
          {String(value)}
        </TableCell>
      );
    case 'string':
      return (
        <TableCell className={clsx(classes.stringValue, className)}>
          {value}
        </TableCell>
      );
    case 'object':
      return (
        <TableCell className={clsx(classes.objectValue, className)}>
          <Table>
            <TableBody>
              {Object.entries(value as object).map(([key, value]) => (
                <TableRow key={key} className={classes.row}>
                  <TableCell className={clsx(classes.cell, classes.keyCell)}>{key}</TableCell>
                  <ValueCell value={value} />
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableCell>
      );
  }

  return <TableCell className={className}>{value}</TableCell>;
};

export default ValueCell;
