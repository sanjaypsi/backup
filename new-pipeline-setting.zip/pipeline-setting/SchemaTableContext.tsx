import React, { ReactElement } from 'react';
import { Theme } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { PipelineSettingSchema, Column } from './types';
import ValueCell from './ValueCell';
import MTable from './MTable';

const useStyles = makeStyles<Theme>(theme => ({
  cell: {
    width: 100,
  },
  valueCell: {
    width: 'auto',
  },
}));

type SchemaTableContextProps = {
  settingGroup: string,
  schemas: PipelineSettingSchema[],
  onEditClick?: (rowData: PipelineSettingSchema) => void,
  onDeleteClick?: (rowData: PipelineSettingSchema) => void,
  className?: string,
  tableFooter: ReactElement,
};

const SchemaTableContext: React.FC<SchemaTableContextProps> = ({
  settingGroup,
  schemas,
  onEditClick,
  onDeleteClick,
  className,
  tableFooter,
}) => {
  const classes = useStyles();
  const isConfig = settingGroup === 'config';
  const isEnvironment = settingGroup === 'environment';

  const columns: Column<PipelineSettingSchema>[] = [{ title: 'Key', field: 'key' }];
  if (isConfig) {
    columns.push({ title: 'Section', field: 'section' });
  }
  if (isEnvironment) {
    columns.push({ title: 'Required', field: 'required' });
  }
  columns.push({
    title: 'Schema',
    render: rowData => <ValueCell value={rowData.schema} className={classes.valueCell} />,
    headerClassName: classes.valueCell,
  });

  return (
    <MTable
      columns={columns}
      data={schemas}
      onEditClick={onEditClick}
      onDeleteClick={onDeleteClick}
      className={className}
      tableFooter={tableFooter}
    />
  );
};

export default SchemaTableContext;
