import {
  PipelineSettingDefinition,
  PipelineSettingSchema,
  PipelineSettingValue,
  SettingStoreState,
  StateData,
  PipelineRecord,
} from "./types";
import {
  SettingActionTypes,
  SET_SETTING_DEFINITIONS,
  SET_SETTING_SCHEMAS,
  SET_SETTING_VALUES,
  SET_SETTING_SECTION,
  SET_SETTING_ENTRY,
  SET_SETTING_GROUPS,
  SET_SETTING_TYPES,
  SET_SETTING_GROUP,
  SET_SETTING_TYPE,
  SET_PAGE,
  SET_ROWS_PER_PAGE,
  SET_SEARCH_KEY,
  ADD_SETTING_VALUE,
  UPDATE_SETTING_VALUE,
  SET_EXACT_MATCH,
  DELETE_SETTING_RECORD,
} from "./actions";
import { getInitialTypeData, getStateData, hasSectionFilter } from "./utils";
import { Reducer } from "redux";

function getInitialGroupData() {
  return {
    definition: getInitialTypeData<PipelineSettingDefinition>(),
    schema: getInitialTypeData<PipelineSettingSchema>(),
    value: getInitialTypeData<PipelineSettingValue>(),
  };
}

export const initialSettingState: SettingStoreState = {
  config: getInitialGroupData(),
  environment: getInitialGroupData(),
  preference: getInitialGroupData(),
  settingGroups: [],
  settingTypes: [],
  settingGroup: '',
  settingType: '',
  settingSection: '',
  settingEntry: '',
  page: 0,
  rowsPerPage: 15,
  searchKey: '',
  exactMatch: false,
};

export const settingReducer: Reducer<SettingStoreState, SettingActionTypes> = (state = initialSettingState, action) => {
  switch (action.type) {
    case SET_SETTING_DEFINITIONS: {
      const { settingGroup, definitions, total, searchKey } = action.payload;
      return {
        ...state,
        [settingGroup]: {
          ...state[settingGroup],
          definition: {
            records: definitions,
            total,
            sections: [],
            entries: [],
          },
        },
        searchKey,
      };
    }
    case SET_SETTING_SCHEMAS: {
      const { settingGroup, sections, schemas, total, searchKey } = action.payload;
      const newSettingSection = sections.includes(state.settingSection) ? state.settingSection : '';
      return {
        ...state,
        [settingGroup]: {
          ...state[settingGroup],
          schema: {
            records: schemas,
            total,
            sections,
            entries: [],
          },
        },
        settingSection: newSettingSection,
        searchKey,
      };
    }
    case SET_SETTING_VALUES: {
      const { settingGroup, sections, entries, values, total, searchKey } = action.payload;
      const newSettingSection = sections.includes(state.settingSection) ? state.settingSection : '';
      const newSettingEntry = entries.includes(state.settingEntry) ? state.settingEntry : '';
      return {
        ...state,
        [settingGroup]: {
          ...state[settingGroup],
          value: {
            records: values,
            total,
            sections,
            entries,
          },
        },
        settingSection: newSettingSection,
        settingEntry: newSettingEntry,
        searchKey,
      };
    }
    case SET_SETTING_SECTION: {
      if (!state.settingGroup) {
        return state;
      }
      if (!state.settingType) {
        return state;
      }
      const { section, searchKey } = action.payload;
      const newSettingSection = getStateData(state).sections.includes(section) ? section : '';
      if (newSettingSection === state.settingSection) {
        return state;
      }
      return {
        ...state,
        [state.settingGroup]: {
          ...state[state.settingGroup],
          [state.settingType]: {
            ...state[state.settingGroup][state.settingType],
          },
        },
        settingSection: newSettingSection,
        settingEntry: '',
        searchKey,
        page: 0,
      };
    }
    case SET_SETTING_ENTRY: {
      if (!state.settingGroup) {
        return state;
      }
      if (!state.settingType) {
        return state;
      }
      const { entry, searchKey } = action.payload;
      const newSettingEntry = getStateData(state).entries.includes(entry) ? entry : '';
      if (newSettingEntry === state.settingEntry) {
        return state;
      }
      const newSettingSection = newSettingEntry ? newSettingEntry.split('/')[0] : state.settingSection;
      return {
        ...state,
        settingSection: newSettingSection,
        settingEntry: newSettingEntry,
        searchKey,
        page: 0,
      };
    }
    case SET_SETTING_GROUPS: {
      const { groups } = action.payload;
      const newSettingGroup = state.settingGroup && groups.includes(state.settingGroup) ? state.settingGroup : '';
      return {
        ...state,
        settingGroups: groups,
        settingGroup: newSettingGroup,
      };
    }
    case SET_SETTING_TYPES: {
      const { types } = action.payload;
      const newSettingType = state.settingType && types.includes(state.settingType) ? state.settingType : '';
      return {
        ...state,
        settingTypes: types,
        settingType: newSettingType,
      };
    }
    case SET_SETTING_GROUP: {
      const { group, searchKey } = action.payload;
      const newSettingGroup = group && state.settingGroups.includes(group) ? group : '';
      const newSettingSection = hasSectionFilter(newSettingGroup, state.settingType) ? state.settingSection : '';
      const newSettingEntry = newSettingSection !== '' ? state.settingEntry : '';
      return {
        ...state,
        settingGroup: newSettingGroup,
        settingSection: newSettingSection,
        settingEntry: newSettingEntry,
        searchKey,
        page: 0,
      };
    }
    case SET_SETTING_TYPE: {
      const { type, searchKey } = action.payload;
      const newSettingType = type && state.settingTypes.includes(type) ? type : '';
      const newSettingSection = hasSectionFilter(state.settingGroup, newSettingType) ? state.settingSection : '';
      const newSettingEntry = newSettingSection !== '' ? state.settingEntry : '';
      return {
        ...state,
        settingType: newSettingType,
        settingSection: newSettingSection,
        settingEntry: newSettingEntry,
        searchKey,
        page: 0,
      };
    }
    case SET_PAGE: {
      const { page, searchKey } = action.payload;
      const numPages = Math.ceil(getStateData(state).total / state.rowsPerPage);
      const newPage = page < numPages ? page : numPages;
      return {
        ...state,
        searchKey,
        page: newPage,
      };
    }
    case SET_ROWS_PER_PAGE: {
      const { rowsPerPage, searchKey } = action.payload;
      const newRowsPerPage = rowsPerPage > 0
        ? rowsPerPage < Infinity ? rowsPerPage : getStateData(state).total
        : 15;
      return {
        ...state,
        rowsPerPage: newRowsPerPage,
        searchKey,
        page: 0,
      };
    }
    case SET_SEARCH_KEY: {
      const { searchKey } = action.payload;
      return {
        ...state,
        searchKey,
        page: 0,
      };
    }
    case SET_EXACT_MATCH: {
      const { exactMatch, searchKey } = action.payload;
      return {
        ...state,
        exactMatch,
        searchKey,
        page: 0,
      };
    }
    case ADD_SETTING_VALUE: {
      const { settingGroup, key, section, entry, value } = action.payload;
      return {
        ...state,
        [settingGroup]: {
          ...state[settingGroup],
          value: {
            ...state[settingGroup].value,
            records: [
              ...state[settingGroup].value.records,
              {
                created_at_utc: '',
                created_by: '',
                entry,
                id: -1,
                key,
                modified_at_utc: '',
                modified_by: '',
                section,
                value,
              },
            ],
          },
        },
      };
    }
    case UPDATE_SETTING_VALUE: {
      const { settingGroup, id, section, entry, value } = action.payload;
      return {
        ...state,
        [settingGroup]: {
          ...state[settingGroup],
          value: {
            ...state[settingGroup].value,
            records: state[settingGroup].value.records.map(record => {
              if (record.id === id) {
                const { created_at_utc, created_by, id, key, modified_at_utc, modified_by } = record;
                return {
                  group: settingGroup,
                  key,
                  entry,
                  section,
                  value,
                  id,
                  created_at_utc,
                  created_by,
                  modified_at_utc,
                  modified_by,
                };
              }
              return record;
            }),
          },
        },
      };
    }
    case DELETE_SETTING_RECORD: {
      const { settingType, settingGroup, id } = action.payload;
      const stateData: StateData<PipelineRecord> = state[settingGroup][settingType];
      return {
        ...state,
        [settingGroup]: {
          ...state[settingGroup],
          [settingType]: {
            ...state[settingGroup][settingType],
            records: stateData.records.filter(record => record.id !== id),
          },
        },
      };
    }
    default:
      return state;
  }
};
