import { useCallback } from "react";
import { Dispatch } from "redux";
import { SettingStoreState } from "./types";
import { ActionTypes } from "../actions";
import { useMappedState, useDispatch } from "../store";

export function usePipelineSetting(): [SettingStoreState, Dispatch<ActionTypes>] {
  const state = useMappedState<SettingStoreState>(
    useCallback(_state => _state.setting, []),
  );
  const dispatch = useDispatch();
  return [state, dispatch];
}
