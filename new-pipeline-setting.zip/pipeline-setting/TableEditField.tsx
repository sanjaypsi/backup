import React from 'react';
import { Checkbox, TextField, Select, MenuItem, Theme } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles<Theme>(theme => ({
  textField: {
    display: 'flex',
    flexGrow: 1,
  },
}));

type TableEditFieldProps = {
  schema: any,
  value: any,
  onChange: (value: any) => void,
};

const TableEditField: React.FC<TableEditFieldProps> = ({
  schema,
  value,
  onChange,
}) => {
  const classes = useStyles();

  if (typeof schema !== 'object') {
    return <>{value || null}</>;
  }

  if (schema.type === 'boolean') {
    return (
      <Checkbox
        value={String(value)}
        checked={Boolean(value)}
        onChange={event => onChange(event.target.checked)}
      />
    );
  }

  if (schema.type === 'integer') {
    return (
      <TextField
        type="number"
        inputProps={{ step: 1 }}
        value={Number(value) | 0}
        onChange={event => onChange(Number(event.target.value) | 0)}
        className={classes.textField}
      />
    );
  }

  if (schema.type === 'number') {
    return (
      <TextField
        type="number"
        value={Number(value)}
        onChange={event => onChange(Number(event.target.value))}
        className={classes.textField}
      />
    );
  }

  if (schema.type === 'array') {
    // Currently only string array is supported.
    // TODO: Editable list UI
    return (
      <TextField
        value={(value as string[]).join(', ')}
        onChange={event => onChange(event.target.value.split(',').map(item => item.trim()))}
        className={classes.textField}
      />
    );
  }

  // string is a default type

  if (schema.enum != null) {
    const items = schema.enum as string[];
    return (
      <Select
        value={String(value)}
        onChange={event => onChange(event.target.value)}
      >
        {items.map((item, i) => (
          <MenuItem key={i} value={item}>{item}</MenuItem>
        ))}
      </Select>
    )
  }

  // TODO: Validate by JSON schema
  return (
    <TextField
      value={String(value)}
      onChange={event => onChange(event.target.value)}
      className={classes.textField}
    />
  );
};

export default TableEditField;
