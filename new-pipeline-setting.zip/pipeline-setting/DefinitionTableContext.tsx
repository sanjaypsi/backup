import React, { ReactElement } from 'react';
import { Theme } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { PipelineSettingDefinition, Column } from './types';
import ValueCell from './ValueCell';
import MTable from './MTable';

const useStyles = makeStyles<Theme>(theme => ({
  cell: {
    width: 100,
  },
  valueCell: {
    width: 'auto',
  },
}));

type DefinitionTableContextProps = {
  settingGroup: string,
  definitions: PipelineSettingDefinition[],
  onEditClick?: (rowData: PipelineSettingDefinition) => void,
  onDeleteClick?: (rowData: PipelineSettingDefinition) => void,
  className?: string,
  tableFooter: ReactElement,
};

const DefinitionTableContext: React.FC<DefinitionTableContextProps> = ({
  settingGroup,
  definitions,
  onEditClick,
  onDeleteClick,
  className,
  tableFooter,
}) => {
  const classes = useStyles();

  const columns: Column<PipelineSettingDefinition>[] = [
    { title: 'Key', field: 'key' },
  ];
  columns.push({
    title: 'Definition',
    render: rowData => <ValueCell value={rowData.definition} className={classes.valueCell} />,
    headerClassName: classes.valueCell,
  });

  return (
    <MTable
      columns={columns}
      data={definitions}
      onEditClick={onEditClick}
      onDeleteClick={onDeleteClick}
      className={className}
      tableFooter={tableFooter}
    />
  );
};

export default DefinitionTableContext;
