import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
} from '@material-ui/core';
import { DialogProps } from '@material-ui/core/Dialog';
import { ButtonProps } from '@material-ui/core/Button';

type Props = {
  open: boolean,
  onClose: DialogProps['onClose'],
  onCancelClick: ButtonProps['onClick'],
  onAcceptClick: ButtonProps['onClick'],
  title: string,
  description: string,
};

const DeleteConfirmationDialog: React.FC<Props> = ({
  open,
  onClose,
  onCancelClick,
  onAcceptClick,
  title,
  description,
}) => {
  return(
    <Dialog
      open={open}
      onClose={onClose}
      aria-labelledby="confirm-dialog-title"
      aria-describedby="confirm-dialog-description"
    >
      <DialogTitle id="confirm-dialog-title">{title}</DialogTitle>
      <DialogContent>
        <DialogContentText id="confirm-dialog-description">{description}</DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onCancelClick} color="secondary" autoFocus>Cancel</Button>
        <Button onClick={onAcceptClick} color="default">OK</Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteConfirmationDialog;
