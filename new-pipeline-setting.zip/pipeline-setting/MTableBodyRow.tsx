import React, { ReactElement, useEffect } from 'react';
import deepEqual from 'deep-equal';
import { TableRow, TableCell, Theme, IconButton, Tooltip } from '@material-ui/core';
import { IconButtonProps } from '@material-ui/core/IconButton';
import { makeStyles } from '@material-ui/styles';
import { Edit as EditIcon, Delete as DeleteIcon, Clear as ClearIcon, Done as DoneIcon } from '@material-ui/icons';
import { Column } from './types';

const useStyles = makeStyles<Theme>(theme => ({
  actionsCell: {
    width: 100,
  },
}));

interface MtableBodyRowProps<RowData extends { id: number }> {
  columns: Column<RowData>[];
  rowData: RowData;
  editingData?: RowData | null;
  onEditClick?: (rowData: RowData) => void;
  onDeleteClick?: (rowData: RowData) => void;
  onAcceptClick?: (newData: RowData, oldData: RowData) => void;
  onCancelClick?: (rowData: RowData) => void;
  onUnmount?: (rowData: RowData) => void;
}

const MTableBodyRow: <RowData extends { id: number }>(props: MtableBodyRowProps<RowData>) => ReactElement | null = ({
  columns,
  rowData,
  editingData,
  onEditClick,
  onDeleteClick,
  onAcceptClick,
  onCancelClick,
  onUnmount,
}) => {
  const classes = useStyles();

  useEffect(() => {
    return () => {
      if (onUnmount != null) {
        onUnmount(rowData);
      }
    };
  }, []);

  const handleEditButtonClick: IconButtonProps['onClick'] = event => {
    if (onEditClick != null) {
      onEditClick(rowData);
    }
  };

  const handleDeleteButtonClick: IconButtonProps['onClick'] = event => {
    if (onDeleteClick != null) {
      onDeleteClick(rowData);
    }
  };

  const handleAcceptButtonClick: IconButtonProps['onClick'] = event => {
    if (onAcceptClick != null && editingData != null) {
      onAcceptClick(editingData, rowData);
    }
  };

  const handleCancelButtonClick: IconButtonProps['onClick'] = event => {
    if (onCancelClick != null) {
      onCancelClick(rowData);
    }
  };

  return (
    <TableRow>
      {columns.map((column, i) => {
        if (editingData != null && editingData.id === rowData.id && column.renderEditor != null && column.isEditorReady !== false) {
          return (
            <React.Fragment key={`cell-${rowData.id}-${i}`}>
              {column.renderEditor(editingData)}
            </React.Fragment>
          )
        }

        if (column.render != null) {
          return (
            <React.Fragment key={`cell-${rowData.id}-${i}`}>
              {column.render(rowData)}
            </React.Fragment>
          );
        }

        return (
          <TableCell key={`cell-${rowData.id}-${i}`} className={column.className}>
            {column.field ? rowData[column.field] : ''}
          </TableCell>
        );
      })}
      <TableCell className={classes.actionsCell}>
        {editingData == null || rowData.id !== editingData.id ? (
          <>
            <Tooltip title="edit">
              <span>
                <IconButton
                  size="small"
                  onClick={handleEditButtonClick}
                  disabled={editingData != null && rowData.id !== editingData.id || onEditClick == null}
                >
                  <EditIcon />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title="delete">
              <span>
                <IconButton
                  size="small"
                  onClick={handleDeleteButtonClick}
                  disabled={editingData != null && rowData.id !== editingData.id}
                >
                  <DeleteIcon />
                </IconButton>
              </span>
            </Tooltip>
          </>
        ) : (
          <>
            <Tooltip title="accept">
              <span>
                <IconButton
                  size="small"
                  onClick={handleAcceptButtonClick}
                  disabled={deepEqual(editingData, rowData)}
                >
                  <DoneIcon />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title="cancel">
              <IconButton
                size="small"
                onClick={handleCancelButtonClick}
              >
                <ClearIcon />
              </IconButton>
            </Tooltip>
          </>
        )}
      </TableCell>
    </TableRow>
  );
};

export default MTableBodyRow;
