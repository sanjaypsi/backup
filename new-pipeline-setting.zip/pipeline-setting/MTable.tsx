import React, { ReactElement, useState } from 'react';
import {
  Table,
  TableBody,
  makeStyles,
  Theme,
  TableHead,
  TableRow,
  TableCell,
  TableSortLabel,
} from '@material-ui/core';
import { Column } from './types';
import DeleteConfirmationDialog from './DeleteConfirmationDialog';
import MTableBodyRow from './MTableBodyRow';
import clsx from 'clsx';

type Unpacked<T> = T extends (infer U)[] ? U : T;

const useStyles = makeStyles<Theme>(theme => ({
  cell: {
    width: 100,
  },
  actionsCell: {
    textAlign: 'center',
  },
}));

interface MTableProps<RowData extends { id: number }> {
  columns: Column<RowData>[];
  data: RowData[];
  editingData?: RowData | null;
  onEditClick?: (rowData: RowData) => void;
  onDeleteClick?: (rowData: RowData) => void;
  onRowUnmount?: (rowData: RowData) => void;
  className?: string;
  tableFooter?: ReactElement;
  onAcceptClick?: (newData: RowData, oldData: RowData) => void;
  onCancelClick?: (rowData: RowData) => void;
}

const MTable: <RowData extends { id: number }>(props: MTableProps<RowData>) => ReactElement | null = ({
  columns,
  data,
  editingData,
  onEditClick,
  onDeleteClick,
  onRowUnmount,
  className,
  tableFooter,
  onAcceptClick,
  onCancelClick,
}) => {
  const [item, setItem] = useState<Unpacked<typeof data> | null>(null);
  const classes = useStyles();

  function handleDialogClose() {
    setItem(null);
  }

  function handleAcceptClick() {
    if (onDeleteClick != null && item != null) {
      onDeleteClick(item);
    }
    handleDialogClose();
  }

  const handleDeleteClick: typeof onDeleteClick = rowData => {
    if (onDeleteClick != null) {
      setItem(rowData);
    }
  }

  return (
    <>
      <Table className={className}>
        <TableHead>
          <TableRow>
            {columns.map((column, i) => (
              <TableCell key={i} className={clsx(classes.cell, column.headerClassName)}>
                {column.title}
              </TableCell>
            ))}
            <TableCell
              key="key-actions-column"
              padding="checkbox"
              className={classes.actionsCell}
            >
              <TableSortLabel disabled>Actions</TableSortLabel>
            </TableCell>
          </TableRow>
        </TableHead>

        <TableBody className={className}>
          {data && data.map(rowData => (
            <MTableBodyRow
              columns={columns}
              rowData={rowData}
              editingData={editingData}
              onEditClick={onEditClick}
              onDeleteClick={handleDeleteClick}
              onUnmount={onRowUnmount}
              key={rowData.id}
              onAcceptClick={onAcceptClick}
              onCancelClick={onCancelClick}
            />
          ))}
        </TableBody>

        {tableFooter || null}
      </Table>

      <DeleteConfirmationDialog
        open={item != null}
        onClose={handleDialogClose}
        onCancelClick={handleDialogClose}
        onAcceptClick={handleAcceptClick}
        title="Confirm Delete Setting"
        description="Are you sure, you want to delete setting?"
      />
    </>
  );
};

export default MTable;
