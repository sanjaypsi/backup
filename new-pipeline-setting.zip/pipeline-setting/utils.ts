import { SettingGroup, PipelineRecord, SettingType, StateData, SettingStoreState } from "./types";

export function getInitialTypeData<T extends PipelineRecord>(): StateData<T> {
  return {
    records: [] as Array<T>,
    total: 0,
    sections: [],
    entries: [],
  };
}

export function hasSectionFilter(
  settingGroup: SettingGroup | '',
  settingType: SettingType | '',
): Boolean {
  return settingGroup === 'config' && settingType === 'schema' || settingType === 'value';
}

export function getStateData(state: SettingStoreState): StateData<PipelineRecord> {
  if (!state.settingGroup || !state.settingType) {
    return getInitialTypeData();
  }
  return state[state.settingGroup][state.settingType];
}
