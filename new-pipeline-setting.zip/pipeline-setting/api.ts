import { getAuthHeader, setNewToken } from "../auth/util";
import { SettingSection, SettingValue } from "./types";

export async function queryConfig(
  section: SettingSection,
  keyName: string,
  key: string,
  signal?: AbortSignal | null,
): Promise<any> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/pipelineSetting/config/${section}s/${keyName}/values/${key}`,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal
    },
  );
  if (res.status == 401) {
    return null;
  }
  if (!res.ok) {
    throw new Error(`Failed to fetch '${key}' of the ${section} '${keyName}'.`);
  }
  setNewToken(res);
  const json: SettingValue = await res.json();
  return json.value;
}

export async function queryPreference(
  common: string,
  studio: string,
  project: string,
  key: string,
  signal?: AbortSignal | null,
): Promise<any> {
  const headers = getAuthHeader();
  const res = await fetch(
    `/api/pipelineSetting/preference/composite/values/${encodeURIComponent(key)}`
    + `?common=${common}&studio=${studio}&project=${project}`,
    {
      method: 'GET',
      headers,
      mode: 'cors',
      signal
    },
  );
  if (res.status == 401) {
    return null;
  }
  if (!res.ok) {
    throw new Error(`Failed to fetch preference value with key '${key}'.`);
  }
  setNewToken(res);
  const json: SettingValue = await res.json();
  return json.value;
}
