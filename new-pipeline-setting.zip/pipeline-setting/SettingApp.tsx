import React from 'react';
import {
  Paper,
  Theme,
  Container,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  FormControlLabel,
  Checkbox,
  FormGroup,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { SelectProps } from '@material-ui/core/Select';
import { TextFieldProps } from '@material-ui/core/TextField';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import { useSnackbar } from 'notistack';
import {
  SettingGroup,
  SettingSection,
  SettingEntry,
  SettingType,
  PipelineSettingValue,
  PipelineRecord,
} from './types';
import {
  SET_SETTING_GROUP,
  SET_SETTING_TYPE,
  SET_SETTING_SECTION,
  SET_SETTING_ENTRY,
  SET_ROWS_PER_PAGE,
  SET_PAGE,
  SET_SEARCH_KEY,
  SET_EXACT_MATCH,
  ADD_SETTING_VALUE,
  UPDATE_SETTING_VALUE,
  DELETE_SETTING_RECORD,
} from './actions';
import { getStateData, hasSectionFilter } from './utils';
import { usePipelineSetting } from './hooks';
import SettingTableFooter from './SettingTableFooter';
import DefinitionTableContext from './DefinitionTableContext';
import SchemaTableContext from './SchemaTableContext';
import ValueTableContext from './ValueTableContext';
import { CheckboxProps } from '@material-ui/core/Checkbox';
import { getAuthHeader, setNewToken } from '../auth/util';

const useStyles = makeStyles<Theme>(theme => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
  },
  paper: {
    width: '100%',
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
  },
  formControl: {
    margin: theme.spacing(1),
    flexDirection: 'row',
    minWidth: 120,
  },
  select: {
    minWidth: 120,
  },
  settingTable: {
    width: '100%',
  },
}));

type Props = {
  searchKey: string,
  setSearchKey: React.Dispatch<React.SetStateAction<string>>,
};

const SettingApp: React.FC<Props> = ({
  searchKey,
  setSearchKey,
}) => {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const [state, dispatch] = usePipelineSetting();

  const handleGroupChange: SelectProps['onChange'] = event => {
    const newSettingGroup = event.target.value as SettingGroup | '';
    if (newSettingGroup === state.settingGroup) {
      return;
    }
    dispatch({ type: SET_SETTING_GROUP, payload: { group: newSettingGroup, searchKey }});
  };

  const handleTypeChange: SelectProps['onChange'] = event => {
    const newSettingType = event.target.value as SettingType | '';
    if (newSettingType === state.settingType) {
      return;
    }
    dispatch({ type: SET_SETTING_TYPE, payload: { type: newSettingType, searchKey }});
  };

  const handleSectionChange: SelectProps['onChange'] = event => {
    const newSettingSection = event.target.value as SettingSection;
    if (newSettingSection === state.settingSection) {
      return;
    }
    dispatch({ type: SET_SETTING_SECTION, payload: { section: newSettingSection, searchKey }});
  };

  const handleEntryChange: SelectProps['onChange'] = event => {
    const newSettingEntry = event.target.value as SettingEntry;
    if (newSettingEntry === state.settingEntry) {
      return;
    }
    dispatch({ type: SET_SETTING_ENTRY, payload: { entry: newSettingEntry, searchKey }});
  };

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    dispatch({ type: SET_ROWS_PER_PAGE, payload: { rowsPerPage: Number(event.target.value), searchKey }});
  }

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    dispatch({ type: SET_PAGE, payload: { page: newPage, searchKey }});
  };

  const handleSearchKeyChange: TextFieldProps['onChange'] = event => {
    setSearchKey(event.target.value);
  }

  const handleSearchKeyKeyPress: TextFieldProps['onKeyPress'] = event => {
    if (event.key === 'Enter') {
      dispatch({ type: SET_SEARCH_KEY, payload: { searchKey }});
    }
  }

  const handleExactMatchChange: CheckboxProps['onChange'] = event => {
    dispatch({
      type: SET_EXACT_MATCH,
      payload: { exactMatch: event.target.checked, searchKey },
    });
  }

  const handleSubmit: React.FormEventHandler = event => {
    event.preventDefault();
  }

  async function handleAddRow(newData: { key: string, section: SettingSection, entry: SettingEntry, value: any }) {
    if (state.settingGroup === '') {
      console.warn('Setting group not selected');
      return;
    }
    const headers = getAuthHeader();
    const { key, section, entry, value } = newData;
    const res = await fetch(
      `/api/setting/rc1/${state.settingGroup}/values`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...headers,
        },
        body: JSON.stringify({ key, section, entry, value }),
      }
    ).catch(e => { throw e });
    if (res.ok) {
      const { key, section, entry, value }: PipelineSettingValue = await res.json();
      dispatch({
        type: ADD_SETTING_VALUE,
        payload: { settingGroup: state.settingGroup, key, section, entry, value },
      });
      enqueueSnackbar(`Value ${key} created.`, { variant: 'success' });
      setNewToken(res);
      return;
    }
    enqueueSnackbar(`Failed to create value ${key}.`, { variant: 'error' });
  }

  async function handleUpdateRow(newData: PipelineSettingValue, oldData: PipelineSettingValue) {
    const headers = getAuthHeader();
    const { group, id, key, section, entry, value } = newData;

    try {
      dispatch({
        type: UPDATE_SETTING_VALUE,
        payload: { settingGroup: group, id, section, entry, value },
      });

      const res = await fetch(
        `/api/setting/rc1/${group}/values/${id}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            ...headers,
          },
          body: JSON.stringify({ section, entry, value }),
        }
      ).catch(e => { throw e });
      if (res.status == 401) {
        return null;
      }
      if (!res.ok) {
        let message = '';
        try {
          const err = await res.json();
          message = err.message;
        } catch (e) {}
        throw new Error(`${message} key=${key} id=${id} value=${JSON.stringify(value)}`);
      }
      setNewToken(res);
      enqueueSnackbar(`Value ${key} updated.`, { variant: 'success' });

    } catch (e) {
      console.error(e);
      const { section, entry, value } = oldData;
      dispatch({
        type: UPDATE_SETTING_VALUE,
        payload: { settingGroup: group, id, section, entry, value },
      });
      enqueueSnackbar(`Failed to update value: ${e}.`, { variant: 'error' });
    }
  }

  function handleDeleteRecord(settingType: SettingType) {
    return async function(rowData: PipelineRecord) {
      if (state.settingGroup === '') {
        console.warn('Setting group not selected.');
        return;
      }
      const headers = getAuthHeader();
      const { id, key } = rowData;
      const res = await fetch(
        `/api/setting/rc1/${state.settingGroup}/${state.settingType}s/${id}`,
        {
          method: 'DELETE',
          headers,
        },
      ).catch(e => { throw e });
      if (res.ok) {
        dispatch({
          type: DELETE_SETTING_RECORD,
          payload: { settingType: settingType, settingGroup: state.settingGroup, id },
        });
        enqueueSnackbar(`Setting deleted: key=${key} id=${id}`, { variant: 'success' });
        setNewToken(res);
        return;
      }
      enqueueSnackbar(`Failed to delete setting: key=${key} id=${id}`);
    };
  }

  function handleAcceptRecord(settingType: SettingType) {
    if (settingType === 'value') {
      return function(newData: PipelineSettingValue, oldData: PipelineSettingValue) {
        handleUpdateRow(newData, oldData);
      };
    }
    return function(newData: PipelineRecord, oldData: PipelineRecord) {
      //
    };
  }

  const tableFooter = <SettingTableFooter
    count={getStateData(state).total}
    page={state.page}
    rowsPerPage={state.rowsPerPage}
    onChangePage={handlePageChange}
    onChangeRowsPerPage={handleRowsPerPageChange}
  />;

  return (
    <Container
      maxWidth={state.settingGroup === 'environment' ? 'xl' : 'lg'}
      className={classes.root}
    >
      <Typography variant="h5">Pipeline Settings (rc1)</Typography>

      <form noValidate autoComplete="off" onSubmit={handleSubmit}>
        <FormGroup row>
          <FormControl className={classes.formControl}>
            <InputLabel htmlFor="setting-group">Group</InputLabel>
            <Select
              value={state.settingGroup}
              onChange={handleGroupChange}
              inputProps={{ name:'group', id: 'setting-group' }}
              className={classes.select}
            >
              <MenuItem value="">(None)</MenuItem>
              {state.settingGroups.map(name => (
                <MenuItem key={name} value={name}>{name}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl className={classes.formControl}>
            <InputLabel htmlFor="setting-type">Type</InputLabel>
            <Select
              value={state.settingType}
              onChange={handleTypeChange}
              inputProps={{ name:'type', id: 'setting-type'}}
              className={classes.select}
            >
              <MenuItem value="">(None)</MenuItem>
              {state.settingTypes.map(name => (
                <MenuItem key={name} value={name}>{name}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </FormGroup>

        {state.settingGroup ? <FormGroup row>
          {hasSectionFilter(state.settingGroup, state.settingType)
            ? <FormControl className={classes.formControl}>
                <InputLabel htmlFor="setting-section">Section</InputLabel>
                <Select
                  value={state.settingSection}
                  onChange={handleSectionChange}
                  inputProps={{ name:'section', id: 'setting-section'}}
                  className={classes.select}
                >
                  <MenuItem value="">(None)</MenuItem>
                  {getStateData(state).sections.map(section => (
                    <MenuItem key={section} value={section}>{section}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            : null}

          {state.settingType === 'value'
            ? <FormControl className={classes.formControl}>
                <InputLabel htmlFor="setting-entry">Entry</InputLabel>
                <Select
                  value={state.settingEntry}
                  onChange={handleEntryChange}
                  inputProps={{ name:'entry', id: 'setting-entry'}}
                  className={classes.select}
                >
                  <MenuItem value="">(None)</MenuItem>
                  {getStateData(state).entries.filter(entry => {
                    const section = entry.split('/')[0];
                    return state.settingSection === '' || section === state.settingSection;
                  }).map(entryTag => {
                    const entry = state.settingSection === '' ? entryTag : entryTag.split('/')[1];
                    return <MenuItem key={entryTag} value={entryTag}>{entry}</MenuItem>;
                  })}
                </Select>
              </FormControl>
            : null}

          {state.settingType !== ''
            ? (<>
                <FormControl className={classes.formControl}>
                  <TextField
                    id="key-prefix"
                    type="search"
                    label="Search Key"
                    value={searchKey}
                    onChange={handleSearchKeyChange}
                    onKeyPress={handleSearchKeyKeyPress}
                  />
                </FormControl>
                <FormControlLabel
                  control={
                    <Checkbox checked={state.exactMatch} onChange={handleExactMatchChange} />
                  }
                  label="Exact Match"
                />
              </>)
            : null}
        </FormGroup> : null}
      </form>

      <Paper className={classes.paper}>
        {state.settingType === 'definition'
          ? <DefinitionTableContext
            settingGroup={state.settingGroup}
            definitions={state.settingGroup ? state[state.settingGroup].definition.records : []}
            onDeleteClick={handleDeleteRecord('definition')}
            tableFooter={tableFooter}
            className={classes.settingTable}
          />
          : state.settingType === 'schema'
            ? <SchemaTableContext
              settingGroup={state.settingGroup}
              schemas={state.settingGroup ? state[state.settingGroup].schema.records : []}
              onDeleteClick={handleDeleteRecord('schema')}
              tableFooter={tableFooter}
              className={classes.settingTable}
            />
            : state.settingType === 'value'
              ? <ValueTableContext
                settingGroup={state.settingGroup}
                values={state.settingGroup ? state[state.settingGroup].value.records : []}
                tableFooter={tableFooter}
                onDeleteClick={handleDeleteRecord('value')}
                onAcceptClick={handleAcceptRecord('value')}
                className={classes.settingTable}
            />
              : null
          }
      </Paper>
    </Container>
  );
};

export default SettingApp;
