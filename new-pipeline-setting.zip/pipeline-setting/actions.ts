import {
  SettingGroup,
  SettingType,
  SettingSection,
  SettingEntry,
  PipelineSettingDefinition,
  PipelineSettingSchema,
  PipelineSettingValue,
} from "./types";

export const SET_SETTING_DEFINITIONS = 'SET_SETTING_DEFINITIONS';
export const SET_SETTING_SCHEMAS = 'SET_SETTING_SCHEMAS';
export const SET_SETTING_VALUES = 'SET_SETTING_VALUES';
export const SET_SETTING_SECTION = 'SET_SETTING_SECTION';
export const SET_SETTING_ENTRY = 'SET_SETTING_ENTRY';
export const SET_SETTING_GROUPS = 'SET_SETTING_GROUPS';
export const SET_SETTING_TYPES = 'SET_SETTING_TYPES';
export const SET_SETTING_GROUP = 'SET_SETTING_GROUP';
export const SET_SETTING_TYPE = 'SET_SETTING_TYPE';
export const SET_PAGE = 'SET_PAGE';
export const SET_ROWS_PER_PAGE = 'SET_ROWS_PER_PAGE';
export const SET_SEARCH_KEY = 'SET_SEARCH_KEY';
export const SET_EXACT_MATCH = 'SET_EXACT_MATCH';
export const ADD_SETTING_VALUE = 'ADD_SETTING_VALUE';
export const UPDATE_SETTING_VALUE = 'UPDATE_SETTING_VALUE';
export const DELETE_SETTING_RECORD = 'DELETE_SETTING_RECORD';

export type SettingActionTypes = {
  type: typeof SET_SETTING_DEFINITIONS,
  payload: {
    settingGroup: SettingGroup,
    definitions: PipelineSettingDefinition[],
    total: number,
    searchKey: string,
  },
} | {
  type: typeof SET_SETTING_SCHEMAS,
  payload: {
    settingGroup: SettingGroup,
    sections: SettingSection[],
    schemas: PipelineSettingSchema[],
    total: number,
    searchKey: string,
  },
} | {
  type: typeof SET_SETTING_VALUES,
  payload: {
    settingGroup: SettingGroup,
    sections: SettingSection[],
    entries: SettingEntry[],
    values: PipelineSettingValue[],
    total: number,
    searchKey: string,
  },
} | {
  type: typeof SET_SETTING_SECTION,
  payload: {
    section: SettingSection,
    searchKey: string,
  },
} | {
  type: typeof SET_SETTING_ENTRY,
  payload: {
    entry: SettingEntry,
    searchKey: string,
  },
} | {
  type: typeof SET_SETTING_GROUPS,
  payload: {
    groups: SettingGroup[],
  },
} | {
  type: typeof SET_SETTING_TYPES,
  payload: {
    types: SettingType[],
  },
} | {
  type: typeof SET_SETTING_GROUP,
  payload: {
    group: SettingGroup | '',
    searchKey: string,
  },
} | {
  type: typeof SET_SETTING_TYPE,
  payload: {
    type: SettingType | '',
    searchKey: string,
  },
} | {
  type: typeof SET_PAGE,
  payload: {
    page: number,
    searchKey: string,
  },
} | {
  type: typeof SET_ROWS_PER_PAGE,
  payload: {
    rowsPerPage: number,
    searchKey: string,
  },
} | {
  type: typeof SET_SEARCH_KEY,
  payload: {
    searchKey: string,
  },
} | {
  type: typeof SET_EXACT_MATCH,
  payload: {
    exactMatch: boolean,
    searchKey: string,
  },
} | {
  type: typeof ADD_SETTING_VALUE,
  payload: {
    settingGroup: SettingGroup,
    key: string,
    section: SettingSection,
    entry: SettingEntry,
    value: any,
  },
} | {
  type: typeof UPDATE_SETTING_VALUE,
  payload: {
    settingGroup: SettingGroup,
    id: number,
    section: SettingSection,
    entry: SettingEntry,
    value: any,
  },
} | {
  type: typeof DELETE_SETTING_RECORD,
  payload: {
    settingType: SettingType,
    settingGroup: SettingGroup,
    id: number,
  },
};
