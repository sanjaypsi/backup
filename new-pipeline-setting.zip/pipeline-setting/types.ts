import { ReactNode } from "react";

export type SettingGroup = 'config' | 'environment' | 'preference';
export type SettingType = 'definition' | 'schema' | 'value';
// export type SettingSection = 'common' | 'studio' | 'project';
export type SettingSection = string;
export type SettingEntry = string;

export type PipelineSettingDefinition = Readonly<{
  group: SettingGroup,
  key: string,
  definition: any,
  id: number,
  created_at_utc: string,
  created_by: string,
  modified_at_utc: string,
  modified_by: string,
}>;

export type PipelineSettingSchema = Readonly<{
  group: SettingGroup,
  section: string,
  key: string,
  schema: any,
  required: boolean,
  id: number,
  created_at_utc: string,
  created_by: string,
  modified_at_utc: string,
  modified_by: string,
}>;

export type PipelineSettingValue = Readonly<{
  group: SettingGroup,
  key: string,
  value: any,
  section: string,
  entry: string,
  id: number,
  created_at_utc: string,
  created_by: string,
  modified_at_utc: string,
  modified_by: string,
}>;

export type SettingValue = Readonly<{
  id: number,
  group: SettingGroup,
  section: string,
  entry: string,
  key: string,
  value: any,
  created_by: string | null,
  created_at_utc: string | null,
  modified_by: string | null,
  modified_at_utc: string | null,
}>;

export type PipelineRecord = PipelineSettingDefinition | PipelineSettingSchema | PipelineSettingValue;

export type StateData<T extends PipelineRecord> = {
  records: Array<T>,
  total: number,
  sections: SettingSection[],
  entries: SettingEntry[],
};

export type SettingStoreState = {
  [C in SettingGroup]: {
    definition: StateData<PipelineSettingDefinition>,
    schema: StateData<PipelineSettingSchema>,
    value: StateData<PipelineSettingValue>,
  };
} & {
  settingGroups: SettingGroup[],
  settingTypes: SettingType[],
  settingGroup: SettingGroup | '',
  settingType: SettingType | '',
  settingSection: SettingSection,
  settingEntry: SettingEntry,
  page: number,
  rowsPerPage: number,
  searchKey: string,
  exactMatch: boolean,
};

export interface Column<RowData extends object> {
  title?: string;
  field?: keyof RowData;
  render?: (rowData: RowData) => ReactNode;
  isEditorReady?: boolean;
  renderEditor?: (rowData: RowData) => any;
  headerClassName?: string;
  className?: string;
}
