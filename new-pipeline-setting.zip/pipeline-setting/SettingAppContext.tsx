import React, { useEffect, useState } from 'react';
import SettingApp from './SettingApp';
import { usePipelineSetting } from './hooks';
import {
  SET_SETTING_GROUPS,
  SET_SETTING_TYPES,
  SET_SETTING_DEFINITIONS,
  SET_SETTING_SCHEMAS,
  SET_SETTING_VALUES,
} from './actions';
import { SettingSection } from './types';
import { getAuthHeader, setNewToken } from '../auth/util';

type Props = {};

const SettingAppContext: React.FC<Props> = () => {
  const [state, dispatch] = usePipelineSetting();
  const [searchKey, setSearchKey] = useState<string>('');
  let mounted = true;

  useEffect(() => {
    (async () => {
      const headers = getAuthHeader();
      const res = await fetch(
        '/api/setting/rc1/groups',
        {
          headers,
        }
      ).catch(e => {
        throw e;
      });
      if (res.ok) {
        setNewToken(res);
        const data = await res.json();
        if (mounted) {
          const { groups } = data;
          dispatch({ type: SET_SETTING_GROUPS, payload: { groups }});
        }
      }
    })();

    (async () => {
      const headers = getAuthHeader();
      const res = await fetch(
        '/api/setting/rc1/types',
        {
          headers,
        }
      ).catch(e => {
        throw e;
      });
      if (res.ok) {
        setNewToken(res);
        const data = await res.json();
        if (mounted) {
          const { types } = data;
          dispatch({ type: SET_SETTING_TYPES, payload: { types }});
        }
      }
    })();

    return () => {
      mounted = false;
    }
  }, []);

  useEffect(() => {
    (async () => {
      if (state.settingGroup === '' || state.settingType === '') {
        return;
      }
      const headers = getAuthHeader();
      const params = new URLSearchParams();
      if (state.settingSection) {
        params.set('section', state.settingSection);
      }
      if (state.settingEntry) {
        params.set('entry', state.settingEntry.split('/')[1]);
      }
      if (state.searchKey) {
        params.set(state.exactMatch ? 'key' : 'search_key', state.searchKey);
      }
      params.set('per_page', String(state.rowsPerPage));
      if (state.page !== 0) {
        params.set('page', String(state.page + 1));
      }
      console.log(`/api/setting/rc1/${state.settingGroup}/${state.settingType}s?${params}`);
      const res = await fetch(
        `/api/setting/rc1/${state.settingGroup}/${state.settingType}s?${params}`,
        {
          headers,
        }
      ).catch(e => {
        throw e;
      });

      if (res.status == 401) {
        return;
      }
      if (res.ok) {
        setNewToken(res);
        const data = await res.json();
        if (mounted) {
          switch (state.settingType) {
            case 'definition': {
              const { definitions, total } = data;
              dispatch({
                type: SET_SETTING_DEFINITIONS,
                payload: { settingGroup: state.settingGroup, definitions, total, searchKey },
              });
              break;
            }
            case 'schema': {
              const { schemas, section_tags: sections, total } = data;
              dispatch({
                type: SET_SETTING_SCHEMAS,
                payload: { settingGroup: state.settingGroup, schemas, sections, total, searchKey },
              });
              break;
            }
            case 'value': {
              const { values, entry_tags: entries, total } = data;
              const sections: SettingSection[] = [];
              for (const entry of entries) {
                const section: SettingSection = entry.split('/')[0];
                if (!sections.includes(section)) {
                  sections.push(section);
                }
              }
              dispatch({
                type: SET_SETTING_VALUES,
                payload: { settingGroup: state.settingGroup, values, sections, entries, total, searchKey },
              });
              break;
            }
          }
        }
      }
    })();
    return () => {
      mounted = false;
    }
  }, [
    state.settingGroup,
    state.settingType,
    state.settingSection,
    state.settingEntry,
    state.searchKey,
    state.exactMatch,
    state.rowsPerPage,
    state.page,
  ]);

  return (
    <SettingApp searchKey={searchKey} setSearchKey={setSearchKey} />
  );
};

export default SettingAppContext;
