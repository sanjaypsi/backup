import { Box, Table, TableBody, TableCell, TableHead, TableRow, TableSortLabel } from '@material-ui/core';
import { ArrowDropDown } from '@material-ui/icons';
import React, { ReactElement } from 'react';

import { Column, Order, Record, SortProps } from './types';

type RecordTableHeadProps<T extends Record> = {
  columns: Column<T>[],
  onRequestSort: (event: React.MouseEvent<unknown>, property: string) => void,
  order: Order,
  orderBy: string,
};

type RecordTableHeadType = <T extends Record>(
  props: RecordTableHeadProps<T>,
) => React.ReactElement | null;

const RecordTableHead = React.memo<RecordTableHeadType>(({
  columns,
  onRequestSort,
  order,
  orderBy,
}) => {
  const createSortHandler =
    (property: string) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };
  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => (
          column.id == 'id' || column.id == 'key'
          ? <TableCell
            key={column.id}
            sortDirection={orderBy === column.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === column.id}
              direction={orderBy === column.id ? order : 'asc'}
              onClick={createSortHandler(column.id)}
              IconComponent={ArrowDropDown}
            >
              {column.label}
            </TableSortLabel>
          </TableCell>
          : <TableCell key={column.id}>{column.label}</TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}) as RecordTableHeadType;

type RecordTableRowProps<T extends Record> = {
  columns: Column<T>[],
  record: T,
  onEditButtonClick: (record: T) => void,
  onDeleteButtonClick: (record: T) => void,
};

type RecordTableRowType = <T extends Record>(
  props: RecordTableRowProps<T>,
) => React.ReactElement | null;

const RecordTableRow = React.memo<RecordTableRowType>(({
  columns,
  record,
  onEditButtonClick,
  onDeleteButtonClick,
}) => {
  return (
    <TableRow>
      {columns.map((column) => {
        if (typeof column.component === 'function') {
          return (
            <column.component
              key={column.id}
              value={record}
              onEditButtonClick={onEditButtonClick}
              onDeleteButtonClick={onDeleteButtonClick}
            />
          );
        }
        return (
          <TableCell key={column.id} align={column.align}>
            {typeof column.render === 'function' && column.render(record)}
          </TableCell>
        );
      })}
    </TableRow>
  );
}) as RecordTableRowType;

type RecordTableProps<T extends Record> = {
  columns: Column<T>[],
  records: T[],
  onEditButtonClick: (record: T) => void,
  onDeleteButtonClick: (record: T) => void,
  tableFooter?: ReactElement | null,
  sortProps: SortProps,
  setSortProps: React.Dispatch<React.SetStateAction<SortProps>>,
};

const RecordTable: <T extends Record>(
  props: RecordTableProps<T>,
) => React.ReactElement | null = ({
  columns,
  records,
  onEditButtonClick,
  onDeleteButtonClick,
  sortProps,
  setSortProps,
  tableFooter,
}) => {
  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: string,
  ) => {
    const isAsc = sortProps.orderBy === property && sortProps.order === 'asc';
    setSortProps({
      order: isAsc ? 'desc' : 'asc',
      orderBy: property,
    });
  };

  return (
    <Table size="small" stickyHeader>
      <RecordTableHead
        columns={columns}
        order={sortProps.order}
        orderBy={sortProps.orderBy}
        onRequestSort={handleRequestSort}
      />
      <TableBody>
        {records.map((record) => (
          <RecordTableRow
            key={record.id}
            columns={columns}
            record={record}
            onEditButtonClick={onEditButtonClick}
            onDeleteButtonClick={onDeleteButtonClick}
          />
        ))}
      </TableBody>
      {tableFooter || null}
    </Table>
  );
};

export default RecordTable;
