import { useEffect, useState } from 'react';
import { queryProperties, queryValues } from './api';
import { GROUP, Order, Property, Value } from './types';

export function useProperties(
  group: string,
  section: string,
  page: number,
  rowsPerPage: number,
  order: Order,
  orderBy: string,
  searchKey: string,
) {
  const [properties, setProperties] = useState<Property[]>([]);
  const [total, setTotal] = useState(0);
  useEffect(() => {
    if (group === GROUP.Config && section === '') {
      if (properties.length !== 0) {
        setProperties([]);
        setTotal(0);
      }
      return;
    }

    const controller = new AbortController();

    (async () => {
      const res = await queryProperties(
        group,
        section,
        page,
        rowsPerPage,
        order,
        orderBy,
        searchKey,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setProperties(res.properties);
        setTotal(res.total);
      }
    })();

    return () => controller.abort();
  }, [group, section, page, rowsPerPage, searchKey, order, orderBy]);


  return { properties, total, setProperties, setTotal };
}

export function useValues(
  group: string,
  section: string,
  entry: string,
  page: number,
  rowsPerPage: number,
  order: Order,
  orderBy: string,
  searchKey: string,
) {
  const [values, setValues] = useState<Value[]>([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    if (entry === '') {
      if (values.length !== 0) {
        setValues([]);
        setTotal(0);
      }
      return;
    }

    const controller = new AbortController();

    (async () => {
      const res = await queryValues(
        group,
        section,
        entry,
        page,
        rowsPerPage,
        order,
        orderBy,
        searchKey,
        controller.signal,
      ).catch((err) => {
        if (err.name === 'AbortError') {
          return;
        }
        console.error(err);
      });
      if (res != null) {
        setValues(res.values);
        setTotal(res.total);
      }
    })();

    return () => controller.abort();
  }, [group, section, entry, page, rowsPerPage, searchKey, order, orderBy]);

  return { values, total, setValues, setTotal };
}
