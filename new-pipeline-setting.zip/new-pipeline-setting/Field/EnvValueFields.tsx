import {
  MenuItem,
  TextField
} from '@material-ui/core';
import React from 'react';
import { EnvValueType } from '../types';

type ValueFieldProps = {
  envValue: EnvValueType,
  onChange: (envValue: EnvValueType) => void,
};

const EnvValueFields: React.FC<ValueFieldProps> = ({ envValue, onChange }) => {
  const handleEnvKeyChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = {
      ...envValue,
      key: event.target.value,
    };
    onChange(newValue);
  };
  const handleUsageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = {
      ...envValue,
      usage: event.target.value,
    };
    onChange(newValue);
  };
  const handleMethodChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = {
      ...envValue,
      method: event.target.value,
    };
    onChange(newValue);
  };
  const handleOSNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = {
      ...envValue,
      osName: event.target.value,
    };
    onChange(newValue);
  };
  const handleSortOrderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const sortOrder = Number(event.target.value);
    const newValue = {
      ...envValue,
      sortOrder,
    };
    onChange(newValue);
  };
  const handleValueChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = {
      ...envValue,
      value: event.target.value,
    };
    onChange(newValue);
  };

  return (
    <>
      <TextField
        id="env-create-key"
        label="Environment Key"
        value={envValue.key}
        onChange={handleEnvKeyChange}
        fullWidth
        required
      />
      <TextField
        id="env-create-usage"
        label="Usage"
        value={envValue.usage}
        onChange={handleUsageChange}
        fullWidth
      />
      <TextField
        id="env-create-method"
        label="Method"
        value={envValue.method}
        onChange={handleMethodChange}
        select
        fullWidth
        required
      >
        <MenuItem value="set">set</MenuItem>
        <MenuItem value="append">append</MenuItem>
        <MenuItem value="prepend">prepend</MenuItem>
        <MenuItem value="remove">remove</MenuItem>
      </TextField>
      <TextField
        id="env-create-osname"
        label="OS Name"
        value={envValue.osName}
        onChange={handleOSNameChange}
        select
        fullWidth
        required
      >
        <MenuItem value="com">com</MenuItem>
        <MenuItem value="win">win</MenuItem>
        <MenuItem value="mac">mac</MenuItem>
        <MenuItem value="lnx">lnx</MenuItem>
      </TextField>
      <TextField
        id="env-create-sortorder"
        label="Sort Order"
        value={envValue.sortOrder}
        onChange={handleSortOrderChange}
        type="number"
        fullWidth
        required
      />
      <TextField
        id="env-create-value"
        label="Value"
        value={envValue.value}
        onChange={handleValueChange}
        fullWidth
        required
      />
    </>
  );
};

export default EnvValueFields;
