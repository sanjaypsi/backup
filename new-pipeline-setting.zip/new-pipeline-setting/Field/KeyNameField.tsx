import { TextField } from '@material-ui/core';
import React from 'react';

type KeyNameFieldProps = {
  value: string,
  disabled?: boolean,
  onChange?: (value: string) => void,
}

const KeyNameField: React.FC<KeyNameFieldProps> = ({ value, disabled = false, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange && onChange(event.target.value);
  };

  return (
    <TextField
      required
      disabled={disabled}
      value={value}
      onChange={handleChange}
      margin="dense"
      id="dialog-key-name"
      label="Key Name"
      inputProps={{ readOnly: onChange == null }}
      fullWidth
    />
  );
};

export default KeyNameField;
