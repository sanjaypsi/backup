import {
  Button,
  FormControl,
  FormControlLabel,
  FormLabel,
  IconButton,
  Radio,
  RadioGroup,
  styled,
  TextField
} from '@material-ui/core';
import { AddCircleOutline, RemoveCircleOutline } from '@material-ui/icons';
import React, { useEffect, useState } from 'react';
import { JsonSchema } from '../types';

type ValueFieldProps = {
  value: any,
  onChange: (value: string) => void,
  schema: { [k: string]: any } | null,
};

const StyledArrayDiv = styled('div')(({ theme }) => ({
  overflow: 'auto',
  maxHeight: 300,
}));

const StyledIconButton = styled(IconButton)(({ theme }) => ({
  verticalAlign: 'bottom',
}));

const StyledArrayField = styled(TextField)({
  minWidth: 200,
})

type ArrayValueFieldProps = {
  value: string | string[],
  onChange: (value: string) => void,
  onClick: () => void,
  label: string,
  defaultValue: string[],
}

const ArrayValueField: React.FC<ArrayValueFieldProps> = ({
  value,
  onChange,
  onClick,
  label,
  defaultValue,
}) => {
  const [items, setItems] = useState<string[]>(
    typeof value === 'string' ? value.split(',') : value
  );

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const i = event.currentTarget.getAttribute('data-text-id') as string;
    const target = Number(i);
    const copied = items.slice();
    copied[target] = event.target.value;
    let newItems: string[] = [];
    for (const c of copied) {
      newItems = [...newItems, ...c.split(',').map(c => c.trim())];
    }
    setItems(newItems);
    onChange(newItems.join(','));
  };

  const handleAddClick = (event:  React.MouseEvent<HTMLElement, MouseEvent>) => {
    const i = event.currentTarget.getAttribute('data-add-id') as string;
    const target = Number(i) + 1;
    const front = items.slice(0, target);
    front.push('');
    if (target === items.length) {
      setItems(front);
      return;
    }
    const back = items.slice(target, items.length);
    const concatarray = front.concat(back);
    setItems(concatarray);
    onChange(concatarray.join(','));
  };

  const handleRemoveClick = (event:  React.MouseEvent<HTMLElement, MouseEvent>) => {
    const i = event.currentTarget.getAttribute('data-remove-id') as string;
    const id = Number(i);
    const removed = items.filter((_, i) => i !== id);
    setItems(removed);
    onChange(removed.join(','));
  };

  const handleCopyClick = (event:  React.MouseEvent<HTMLElement, MouseEvent>) => {
    setItems(defaultValue);
    onClick();
  };

  return (
    <StyledArrayDiv>
      {items.map((array, i) => (
        <div key={'div-' + i}>
          <StyledArrayField
            key={'text-' + i}
            id={'schema-value-array-' + i}
            label={label + ' item' + (i + 1)}
            value={array}
            onChange={handleChange}
            inputProps={{'data-text-id': i}}
            required
          />
          <StyledIconButton
            key={'add-' + i}
            aria-label="add"
            data-add-id={i}
            onClick={handleAddClick}
          >
            <AddCircleOutline key={'add-icon-' + i}/>
          </StyledIconButton>
          {items.length > 1
            ? <StyledIconButton
              key={'remove-' + i}
              aria-label="remove"
              data-remove-id={i}
              onClick={handleRemoveClick}
            >
              <RemoveCircleOutline key={'remove-icon-' + i} />
            </StyledIconButton>
            : null
          }
        </div>
      ))}
      <Button onClick={handleCopyClick} variant="text">Copy from default</Button>
    </StyledArrayDiv>
  );
};

const ValueField: React.FC<ValueFieldProps> = ({ value, onChange, schema }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };
  const label = "Value";
  const jsonSchema = schema ? new JsonSchema(schema) : new JsonSchema();
  const handleClick = () => {
    onChange(jsonSchema.getDefault());
  }

  return (
    <div>
      {jsonSchema && jsonSchema.getType() == 'string'
        ? <>
          <TextField
            id="schema-value-string"
            label={label}
            value={value}
            onChange={handleChange}
            fullWidth
            required
          />
          <Button onClick={handleClick} variant="text">Copy from default</Button>
        </>
        : null
      }
      {jsonSchema && jsonSchema.getType() == 'boolean'
        ? <FormControl required>
          <FormLabel id="schema-value-boolean-group-label">{label}</FormLabel>
          <RadioGroup
            row
            aria-labelledby="schema-value-boolean-group-label"
            name="schema-value-boolean-group"
            value={typeof value === 'boolean' ? value.toString() : value}
            onChange={handleChange}
          >
            <FormControlLabel
              value="true"
              control={<Radio />}
              label="true"
            />
            <FormControlLabel
              value="false"
              control={<Radio />}
              label="false"
            />
          </RadioGroup>
        </FormControl>
        : null
      }
      {jsonSchema && (jsonSchema.getType() == 'number' || jsonSchema.getType() == 'integer')
        ? <>
          <TextField
            id="schema-default-number"
            label={label}
            value={value}
            onChange={handleChange}
            fullWidth
            type="number"
            required
          />
          <Button onClick={handleClick} variant="text">Copy from default</Button>
        </>
        : null
      }
      {jsonSchema && jsonSchema.getType() == 'array'
        ? <ArrayValueField
          value={value || ''}
          onChange={onChange}
          onClick={handleClick}
          label={label}
          defaultValue={jsonSchema.getDefault()}
        />
        : null
      }
    </div>
  );
};

export default ValueField;
