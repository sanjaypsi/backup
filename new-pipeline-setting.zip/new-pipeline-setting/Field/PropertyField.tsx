import { MenuItem, TextField } from '@material-ui/core';
import React, { useMemo } from 'react';

import { useProperties } from '../hooks';
import { Property } from '../types';

type PropertyFieldProps = {
  value: Property | null,
  group: string,
  section: string,
  onChange: (value: Property | null) => void,
};

const PropertyField: React.FC<PropertyFieldProps> = ({ value, group, section, onChange }) => {
  const { properties } = useProperties(group, section, 0, 0, 'asc', 'id', '');

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const property = properties.find((p) => p.key === event.target.value);
    onChange(property || null);
  };

  const property = useMemo((): Property | undefined => {
    if (value == null) {
      return;
    }
    return properties.find((p) => p.key === value.key);
  }, [value, properties]);

  return (
    <TextField
      required
      value={property != null ? property.key : ''}
      onChange={handleChange}
      margin="dense"
      id="dialog-property"
      label="Key"
      select
      fullWidth
    >
      {properties.sort().map((property) => (
        <MenuItem key={property.id} value={property.key}>{property.key}</MenuItem>
      ))}
    </TextField>
  );
};

export default PropertyField;
