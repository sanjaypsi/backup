import { Checkbox, FormControlLabel, styled } from "@material-ui/core";
import React from 'react';

const StyledFormControlLabel = styled(FormControlLabel)({
  marginTop: 16,
  marginBottom: -6,
});

type RequiredCheckboxProps = {
  value: boolean,
  disabled?: boolean,
  onChange: () => void,
};

const RequiredCheckbox: React.FC<RequiredCheckboxProps> = ({ value, disabled=false, onChange }) => {
  const handleChange = () => {
    onChange();
  };

  return (
    <StyledFormControlLabel
      control={(
        <Checkbox
          checked={value}
          onChange={handleChange}
          color="primary"
        />
      )}
      label="Required"
      disabled={disabled}
    />
  );
};

export default RequiredCheckbox;
