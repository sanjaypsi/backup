import {
  FormControl,
  FormControlLabel,
  FormLabel,
  IconButton,
  MenuItem,
  Radio,
  RadioGroup,
  TextField
} from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { AddCircleOutline, RemoveCircleOutline } from '@material-ui/icons';
import React, { useEffect, useState } from 'react';
import { JsonSchema } from '../types';

const StyledDiv = styled('div')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'row',
  gap: `${theme.spacing(2)}px`,
  '& > *': {
    flexGrow: 1,
  },
}));

const StyledTextField = styled(TextField)({
  '& textarea': {
    fontFamily: 'monospace',
  },
})

const StyledCreateForm = styled('form')(({
  flexGrow: 1,
  display: 'flex',
  '& .MuiTextField-root': {
    marginRight: 10,
  },
}));

const StyledTypeField = styled(TextField)({
  minWidth: 200,
})

const StyledArrayDiv = styled('div')(({ theme }) => ({
  overflow: 'auto',
  maxHeight: 300,
}));

const StyledIconButton = styled(IconButton)(({ theme }) => ({
  verticalAlign: 'bottom',
}));

const StyledArrayField = styled(TextField)({
  minWidth: 200,
})

type TypeFieldProps = {
  schema: JsonSchema,
  disabled: boolean,
  onChange: (value: string) => void,
};

const TypeField: React.FC<TypeFieldProps> = ({ schema, disabled, onChange }) => {
  const type = schema.getType();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <StyledTypeField
      id="schema-type"
      label="Type"
      value={type || ''}
      onChange={handleChange}
      select
      required
      disabled={disabled}
    >
      <MenuItem value="">&nbsp;</MenuItem>
      {JsonSchema.SCHEMA_TYPES.map((schemaType) => (
        <MenuItem key={schemaType} value={schemaType}>{schemaType}</MenuItem>
      ))}
      {type === JsonSchema.UNKNOWN_TYPE && (
        <MenuItem value={JsonSchema.UNKNOWN_TYPE}>( unknown )</MenuItem>
      )}
    </StyledTypeField>
  );
};

type MinMaxFieldProps = {
  idSuffix?: string,
  labelSuffix?: string,
  minimumValue?: number,
  onMinimumChange: (value?: number) => void,
  maximumValue?: number,
  onMaximumChange: (value?: number) => void,
  disabled: boolean,
};

const MinMaxField: React.FC<MinMaxFieldProps> = ({
  idSuffix,
  labelSuffix,
  minimumValue,
  onMinimumChange,
  maximumValue,
  onMaximumChange,
  disabled,
}) => {
  const handleMinimumChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    onMinimumChange(value === '' ? undefined : Number(value));
  };

  const handleMaximumChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    onMaximumChange(value === '' ? undefined : Number(value));
  };

  return (
    <StyledDiv>
      <TextField
        id={idSuffix == null ? 'schema-minimum' : `schema-minimum-${idSuffix}`}
        label={labelSuffix == null ? 'Minimum' : `Minimum ${labelSuffix}`}
        value={minimumValue == null ? '' : minimumValue}
        onChange={handleMinimumChange}
        type="number"
        disabled={disabled}
      />
      <TextField
        id={idSuffix == null ? 'schema-maximum' : `schema-maximum-${idSuffix}`}
        label={labelSuffix == null ? 'Maximum' : `Maximum ${labelSuffix}`}
        value={maximumValue == null ? '' : maximumValue}
        onChange={handleMaximumChange}
        type="number"
        disabled={disabled}
      />
    </StyledDiv>
  );
};

type PatternFieldProps = {
  schema: JsonSchema,
  disabled: boolean,
  onChange: (value: string) => void,
};

const PatternField: React.FC<PatternFieldProps> = ({ schema, disabled, onChange }) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  const message: string = (() => {
    try {
      schema.validatePattern();
      return '';
    } catch (err) {
      if (err instanceof Error) {
        return err.message;
      }
      return String(err);
    }
  })();

  return (
    <TextField
      id="schema-pattern"
      label="Pattern"
      value={schema.getPattern() || ''}
      onChange={handleChange}
      error={message !== ''}
      helperText={message}
      fullWidth
      disabled={disabled}
    />
  );
};

type SchemaTextFieldProps = {
  schema: JsonSchema,
  disabled: boolean,
  onChange: (value: string) => void,
};

const SchemaTextField: React.FC<SchemaTextFieldProps> = ({ schema, disabled, onChange }) => {
  const message: string = (() => {
    if (schema.toString() === '') {
      return '';
    }
    try {
      schema.validate();
      return '';
    } catch (err) {
      if (err instanceof Error) {
        return err.message;
      }
      return String(err);
    }
  })();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };

  return (
    <StyledTextField
      required
      value={schema.toString()}
      onChange={handleChange}
      error={message !== ''}
      helperText={message}
      margin="dense"
      id="schema-text"
      label="Schema"
      multiline
      rows={6}
      fullWidth
      disabled={disabled}
    />
  );
};

type DefaultArrayProps = {
  value: string | string[],
  onChange: (value: string) => void,
  label: string,
  disabled: boolean,
};

const ArrayDefaultField: React.FC<DefaultArrayProps> = ({ value, onChange, label, disabled }) => {
  const [items, setItems] = useState<string[]>(
    typeof value === 'string' ? value.split(',') : value
  );

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const id = event.target.id;
    const i = id.charAt(id.length - 1);
    const target = Number(i);
    const copied = items.slice();
    copied[target] = event.target.value;
    let newItems: string[] = [];
    for (const c of copied) {
      newItems = [...newItems, ...c.split(',').map(c => c.trim())];
    }
    setItems(newItems);
    onChange(newItems.join(','));
  };

  const handleAddClick = (event:  React.MouseEvent<HTMLElement, MouseEvent>) => {
    const i = event.currentTarget.getAttribute('data-add-id') as string;
    const target = Number(i) + 1;
    const front = items.slice(0, target);
    front.push('');
    if (target === items.length) {
      setItems(front);
      return;
    }
    const back = items.slice(target, items.length);
    const concatarray = front.concat(back);
    setItems(concatarray);
    onChange(concatarray.join(','));
  };

  const handleRemoveClick = (event:  React.MouseEvent<HTMLElement, MouseEvent>) => {
    const i = event.currentTarget.getAttribute('data-remove-id') as string;
    const id = Number(i);
    const removed = items.filter((_, i) => i !== id);
    setItems(removed);
    onChange(removed.join(','));
  };

  return (
    <StyledArrayDiv>
      {items.map((array, i) => (
        <div key={'div-' + i}>
          <StyledArrayField
            key={'text-' + i}
            id={'schema-default-array-' + i}
            label={label + ' item' + (i + 1)}
            value={array}
            onChange={handleChange}
            data-text-id={i}
            disabled={disabled}
          />
          <StyledIconButton
            key={'add-' + i}
            aria-label="add"
            data-add-id={i}
            onClick={handleAddClick}
            disabled={disabled}
          >
            <AddCircleOutline key={'add-icon-' + i}/>
          </StyledIconButton>
          {items.length > 1
            ? <StyledIconButton
              key={'remove-' + i}
              aria-label="remove"
              data-remove-id={i}
              onClick={handleRemoveClick}
              disabled={disabled}
            >
              <RemoveCircleOutline key={'remove-icon-' + i} />
            </StyledIconButton>
            : null
          }
        </div>
      ))}
    </StyledArrayDiv>
  );
};

type DefaultFieldProps = {
  schema: JsonSchema,
  disabled: boolean,
  onChange: (value: string) => void,
};

const DefaultField: React.FC<DefaultFieldProps> = ({ schema, disabled, onChange }) => {
  const label = "Default(" + schema.getType() + ")";
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.value);
  };
  const handleRadioButtonChange = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    const value = (event.target as HTMLButtonElement).value;
    if (schema.getDefault() === value) {
      onChange('');
    } else {
      onChange(value);
    }
  };

  const message: string = (() => {
    try {
      schema.validatePattern();
      return '';
    } catch (err) {
      if (err instanceof Error) {
        return err.message;
      }
      return String(err);
    }
  })();

  return (
    <>
      {schema.getType() == 'string'
        ? <TextField
          id="schema-default-string"
          label={label}
          value={schema.getDefault()}
          onChange={handleChange}
          error={message !== ''}
          helperText={message}
          fullWidth
          disabled={disabled}
        />
        : null
      }
      {schema.getType() == 'boolean'
        ? <FormControl disabled={disabled}>
          <FormLabel id="schema-default-boolean-group-label">{label}</FormLabel>
          <RadioGroup
            row
            aria-labelledby="schema-default-boolean-group-label"
            name="schema-default-boolean-group"
            value={schema.getDefault() || ''}
          >
            <FormControlLabel
              value="true"
              control={<Radio onClick={handleRadioButtonChange} />}
              label="true"
            />
            <FormControlLabel
              value="false"
              control={<Radio onClick={handleRadioButtonChange} />}
              label="false"
            />
          </RadioGroup>
        </FormControl>
        : null
      }
      {schema.getType() == 'number' || schema.getType() == 'integer'
        ? <TextField
          id="schema-default-number"
          label={label}
          value={schema.getDefault()}
          onChange={handleChange}
          error={message !== ''}
          helperText={message}
          fullWidth
          disabled={disabled}
          type="number"
        />
        : null
      }
      {schema.getType() == 'array'
        ? <ArrayDefaultField
          value={schema.getDefault() || ''}
          onChange={onChange}
          label={label}
          disabled={disabled}
        />
        : null
      }
    </>
  );
};

type SchemaEditProps = {
  schema: JsonSchema,
  disableOptions?: DisableOptions,
  onSchemaChange: (schema: JsonSchema) => void,
};

type DisableOptions = Readonly<{
  type?: boolean,
  minmax?: boolean,
  pattern?: boolean,
  schema?: boolean,
  default?: boolean,
  required?: boolean,
}>;

const SchemaFields: React.FC<SchemaEditProps> = ({
  schema,
  disableOptions = {},
  onSchemaChange
}) => {
  const handleTypeChange = (value: string) => {
    switch (value) {
      case JsonSchema.UNKNOWN_TYPE:
        return;
      case '':
        onSchemaChange(new JsonSchema());
        return;
      case 'array':
        onSchemaChange(schema.withType(value).withDefault(''));
      default:
        onSchemaChange(schema.withType(value));
    }
  };

  const handleMinimumChange = (value?: number) => {
    onSchemaChange(schema.withMinimum(value));
  };

  const handleMaximumChange = (value?: number) => {
    onSchemaChange(schema.withMaximum(value));
  };

  const handlePatternChange = (value: string) => {
    onSchemaChange(schema.withPattern(value));
  };

  const handleDefaultChange = (value: string) => {
    onSchemaChange(schema.withDefault(value));
  };

  const handleSchemaChange = (value: string) => {
    onSchemaChange(new JsonSchema(value));
  };

  const shouldShowJsonSchemaField = (): boolean => {
    if (schema.toString() === '') {
      return false;
    }
    switch (schema.getType()) {
      case JsonSchema.UNKNOWN_TYPE:
      case undefined:
        return true;
    }
    return false;
  };

  return (
    <>
      <StyledCreateForm>
        <TypeField
          schema={schema}
          onChange={handleTypeChange}
          disabled={disableOptions.type != null || false}
        />
      </StyledCreateForm>
      {(schema.getType() === 'integer' || schema.getType() === 'number') &&
        <MinMaxField
          minimumValue={schema.getMinimum()}
          onMinimumChange={handleMinimumChange}
          maximumValue={schema.getMaximum()}
          onMaximumChange={handleMaximumChange}
          disabled={disableOptions.minmax != null || false}
        />
      }
      {(schema.getType() === 'string' || schema.getType() === 'array') &&
        <PatternField
          schema={schema}
          onChange={handlePatternChange}
          disabled={disableOptions.pattern != null || false}
        />
      }
      {shouldShowJsonSchemaField() &&
        <SchemaTextField
          schema={schema}
          onChange={handleSchemaChange}
          disabled={disableOptions.schema != null || false}
        />
      }
      {schema.getType() &&
        <DefaultField
          schema={schema}
          onChange={handleDefaultChange}
          disabled={disableOptions.default != null || false}
        />
      }
    </>
  );
};

export default SchemaFields;
