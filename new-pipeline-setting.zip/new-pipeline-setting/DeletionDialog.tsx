import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@material-ui/core';
import React from 'react';

type DeletionDialogProps = {
  title: string,
  contentText: string,
  onClose: () => void,
  onDelete: () => void,
};

const DeletionDialog: React.FC<DeletionDialogProps> = ({
  title,
  contentText,
  onClose,
  onDelete,
}) => {
  const handleDelete = () => {
    onDelete();
    onClose();
  };

  return (
    <Dialog
      open
      onClose={onClose}
      area-labelledby="deletion-dialog-title"
    >
      <DialogTitle id="deletion-dialog-title">{title}</DialogTitle>
      <DialogContent>
        <DialogContentText>{contentText}</DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button color="secondary" onClick={handleDelete}>Delete</Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeletionDialog;
