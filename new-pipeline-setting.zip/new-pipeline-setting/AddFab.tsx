import { Fab } from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { Add } from '@material-ui/icons';
import React from 'react';

const StyledFab = styled(Fab)(({ theme }) => ({
  position: 'absolute',
  bottom: theme.spacing(2),
  right: theme.spacing(2),
}));

type AddFabProps = {
  onClick: () => void,
};

const AddFab = React.memo<AddFabProps>(({ onClick }) => {
  return (
    <StyledFab
      color="primary"
      size="medium"
      aria-label="add"
      onClick={onClick}
    >
      <Add />
    </StyledFab>
  );
});

export default AddFab;
