import { TableCellProps } from "@material-ui/core/TableCell";

export type SettingGroup = 'config' | 'environment' | 'preference';
export type SettingSection = string;

export type SettingValue = Readonly<{
  id: number,
  group: SettingGroup,
  section: string,
  entry: string,
  key: string,
  value: any,
  created_by: string | null,
  created_at_utc: string | null,
  modified_by: string | null,
  modified_at_utc: string | null,
}>;

export type Record = Readonly<{
  id: number,
  created_by: string,
  created_at_utc: string,
  modified_by: string,
  modified_at_utc: string,
}>;

export type Property = Readonly<{
  key: string,
  schema: { [k: string]: any },
  required: boolean,
}> & Record;

export type Value = Readonly<{
  entry: string,
  key: string,
  value: any,
}> & Record;

export type ColumnComponentProps<T extends Record> = {
  value: T,
  onEditButtonClick: (value: T) => void,
  onDeleteButtonClick: (value: T) => void,
};

export type Column<T extends Record> = {
  id: string,
  label: string,
  render?: (value: T) => React.ReactNode,
  component?: (props: ColumnComponentProps<T>) => React.ReactElement | null,
  align?: TableCellProps['align'],
};

export type Order = 'asc' | 'desc';

export type SettingFilter = Readonly<{
  group: string,
  section: string,
  entry: string,
}>;

export type PageProps = Readonly<{
  page: number,
  rowsPerPage: number,
}>;

export type SearchProps = Readonly<{
  searchKey: string,
}>;

export type SortProps = Readonly<{
  order: Order,
  orderBy: string,
}>;

export const GROUP = {
  Config: 'config',
  Preference: 'preference',
  Environment:'environment',
} as const;

export const SECTION = {
  Common: 'common',
  Studio: 'studio',
  Project: 'project',
} as const;

// Reference: https://json-schema.org/understanding-json-schema/
export class JsonSchema {
  static readonly SCHEMA_TYPES = [
    'boolean',
    'integer',
    'number',
    'string',
    'array',
  ] as const;

  static readonly UNKNOWN_TYPE = 'unknown' as const;

  private readonly _value: string;

  constructor(value?: string | { [k: string]: any }) {
    if (value == null) {
      this._value = '';
    } else if (typeof value === 'string') {
      this._value = value;
    } else {
      this._value = JSON.stringify(value, null, 2);
    }
  }

  getType(): typeof JsonSchema.SCHEMA_TYPES[number] | typeof JsonSchema.UNKNOWN_TYPE | undefined {
    try {
      const obj = this.toObject();
      if (typeof obj !== 'object' || obj.type == null) {
        return;
      }
      if (!JsonSchema.SCHEMA_TYPES.includes(obj.type)) {
        return JsonSchema.UNKNOWN_TYPE;
      }
      return obj.type;
    } catch (err) {}
  }

  getMinimum(): number | undefined {
    try {
      return this.toObject().minimum;
    } catch (err) {}
  }

  getMaximum(): number | undefined {
    try {
      return this.toObject().maximum;
    } catch (err) {}
  }

  getPattern(): string | undefined {
    try {
      switch (this.getType()) {
        case 'array':
          return this.toObject().items.pattern;
        default:
          return this.toObject().pattern;
      }
    } catch (err) {}
  }

  getDefault(): any | undefined {
    try {
      switch (this.getType()) {
        case 'boolean':
          return this.toObject().default.toString();
        default:
          return this.toObject().default;
      }
    } catch (err) {}
  }

  validate(): void {
    this.toObject();
    this.validateType();
    switch (this.getType()) {
      case 'string':
        this.validatePattern();
        break;
    }
  }

  validateType(): void {
    const type = this.getType();
    if (type == null) {
      throw new Error('"type" is required.');
    }
    if (type === JsonSchema.UNKNOWN_TYPE) {
      throw new Error(`Unknown type.`);
    }
    if (!(JsonSchema.SCHEMA_TYPES as readonly string[]).includes(type)) {
      throw new Error(`Invalid type "${type}"`);
    }
  }

  validatePattern(): void {
    const pattern = this.getPattern();
    if (pattern != null) {
      new RegExp(pattern);
    }
  }

  toString(): string {
    return this._value;
  }

  toObject(): any {
    return JSON.parse(this._value);
  }

  withType(type: string): JsonSchema {
    if (!(JsonSchema.SCHEMA_TYPES as readonly string[]).includes(type)) {
      throw new Error(`Invalid schema type "${type}".`);
    }

    let obj: { [k: string ]: any } = {};
    try {
      obj = this.toObject();
      if (typeof obj !== 'object') {
        obj = {};
      }
    } catch (err) {}

    if (obj.type === type) {
      return this;
    }

    switch (type) {

      case 'boolean':
        obj = {
          type,
          default: obj.default,
          required: obj.required,
        };
        break;

      case 'integer':
        obj = {
          type,
          minimum: (typeof obj.minimum === 'number') ? obj.minimum | 0 : undefined,
          maximum: (typeof obj.maximum === 'number') ? obj.maximum | 0 : undefined,
          default: obj.default,
          required: obj.required,
        };
        break;

      case 'number':
        obj = {
          type,
          minimum: obj.minimum,
          maximum: obj.maximum,
          default: obj.default,
          required: obj.required,
        };
        break;

      case 'string':
        obj = {
          type,
          pattern: obj.pattern,
          default: obj.default,
          required: obj.required,
        };
        break;

      case 'array':
        obj = {
          type,
          items: obj.items ? obj.items : { type: 'string' },
          default: obj.default,
          required: obj.required,
        };
        break;
    }

    return new JsonSchema(obj);
  }

  withMinimum(value?: number | null): JsonSchema {
    const obj = this.toObject();
    obj.minimum = (value != null && obj.type === 'integer') ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withMaximum(value?: number | null): JsonSchema {
    const obj = this.toObject();
    obj.maximum = (value != null && obj.type === 'integer') ? (value | 0) : value;
    return new JsonSchema(obj);
  }

  withPattern(value: string | null): JsonSchema {
    const obj = this.toObject();
    const pattern = (value !== '') ? value : undefined;
    switch (this.getType()) {
      case 'array':
        obj.items.pattern = pattern;
        break;
      default:
        obj.pattern = pattern;
    }
    return new JsonSchema(obj);
  }

  withDefault(value: string | null): JsonSchema {
    const obj = this.toObject();
    obj.default = (value !== '') ? value : undefined;
    return new JsonSchema(obj);
  }

  isModifiedFrom(oldSchema: JsonSchema): boolean {
    return JSON.stringify(this) != JSON.stringify(oldSchema);
  }

  parse(): JsonSchema {
    const obj = this.toObject();
    if (obj.default == null || typeof obj.default !== 'string') {
      return this;
    }
    switch (this.getType()) {
      case 'boolean':
        const b = obj.default.toLowerCase();
        obj.default = (b == 'true' || b == 'false') ? JSON.parse(b) : obj.default;
        break;

      case 'integer':
      try {
        obj.default = !isNaN(Number(obj.default)) ? parseInt(obj.default) : obj.default;
      } catch (err) {}
        break;

      case 'number':
      try {
        obj.default = !isNaN(Number(obj.default)) ? parseFloat(obj.default) : obj.default;
      } catch (err) {}
        break;

      case 'array':
        obj.default = obj.default.split(',').map((s: string) => {
          return s.trim();
        });
        break;
    }
    return new JsonSchema(obj);
  }
};

export type EnvValueType = Readonly<{
  key: string;
  usage?: string;
  method: string;
  osName: string;
  sortOrder: number;
  value: string;
}>;

export const isEnvValueType = (arg: any): arg is EnvValueType => {
    return arg
      && arg.key !== undefined
      && arg.method !== undefined
      && arg.osName !== undefined
      && arg.sortOrder !== undefined
      && arg.value !== undefined;
};

export type ConfPrefValueType = string | boolean | number | string[];

export const isConfPrefValueType = (arg: any): arg is ConfPrefValueType => {
  const argType = typeof arg;
  if (['string', 'boolean', 'number'].includes(argType)) {
    return true;
  }
  if (Array.isArray(arg) && arg.every(e => typeof e === 'string')) {
    return true;
  }
  return false;
};

export class EnvironmentValue {
  readonly params: EnvValueType;

  constructor(
    params: EnvValueType = {
      key: '',
      method: '',
      osName: '',
      sortOrder: 0,
      value: '',
    }
  ) {
    this.params = params;
  }

  withKey(key: string): EnvironmentValue {
    return new EnvironmentValue({
      ...this.params,
      key: key,
    });
  }

  withUsage(usage: string): EnvironmentValue {
    return new EnvironmentValue({
      ...this.params,
      usage: usage,
    });
  }

  withMethod(method: string): EnvironmentValue {
    return new EnvironmentValue({
      ...this.params,
      method: method,
    });
  }

  withOSName(osName: string): EnvironmentValue {
    return new EnvironmentValue({
      ...this.params,
      osName: osName,
    });
  }

  withSortOrder(sortOrder: number): EnvironmentValue {
    return new EnvironmentValue({
      ...this.params,
      sortOrder: sortOrder,
    });
  }

  withValue(value: string): EnvironmentValue {
    return new EnvironmentValue({
      ...this.params,
      value: value,
    });
  }

  isValid(): boolean {
    if (this.params.key && this.params.method && this.params.osName && this.params.value) {
      return true;
    }
    return false;
  }

  isEquals(target: EnvironmentValue): boolean {
    return JSON.stringify(target.params) === JSON.stringify(this.params);
  }
};
