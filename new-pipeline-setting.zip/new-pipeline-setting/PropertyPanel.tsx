import {
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  MenuItem,
  Paper,
  TextField,
} from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { useSnackbar } from 'notistack';
import React, { useCallback, useEffect, useMemo, useState } from 'react';

import ActionCell from './ActionCell';
import AddFab from './AddFab';
import DeletionDialog from './DeletionDialog';
import KeyNameField from './Field/KeyNameField';
import SchemaFields from './Field/SchemaFields';
import RecordTable from './RecordTable';
import { createProperty, deleteProperty, updateProperty } from './api';
import { useProperties } from './hooks';
import { Column, JsonSchema, Property, PageProps, GROUP, SECTION, SettingFilter, SearchProps, Order, SortProps} from './types';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import SettingTableFooter from './SettingTableFooter';
import { TextFieldProps } from '@material-ui/core/TextField';
import RequiredCheckbox from './Field/RequiredCheckbox';

class PropertyData {
  readonly keyName: string;
  readonly group: string;
  readonly section: string;
  readonly schema: JsonSchema;
  readonly required: boolean;

  constructor(
    keyName: string = '',
    group: string = '',
    section: string = '',
    schema: JsonSchema | null = null,
    required: boolean = false,
  ) {
    this.keyName = keyName;
    this.group = group;
    this.section = section;
    this.schema = schema || new JsonSchema();
    this.required = required;
  }

  withKeyName(keyName: string): PropertyData {
    return new PropertyData(keyName, this.group, this.section, this.schema, this.required);
  }

  withGroup(group: string): PropertyData {
    return new PropertyData(this.keyName, group, this.section, this.schema, this.required);
  }

  withSection(section: string): PropertyData {
    return new PropertyData(this.keyName, this.group, section, this.schema, this.required);
  }

  withSchema(schema: JsonSchema): PropertyData {
    return new PropertyData(this.keyName, this.group, this.section, schema, this.required);
  }

  withRequired(required: boolean): PropertyData {
    return new PropertyData(this.keyName, this.group, this.section, this.schema, required);
  }

  isValid(): boolean {
    if (this.keyName == '') {
      return false;
    }
    if (this.group == '') {
      return false;
    }
    if (this.group == GROUP.Environment) {
      return true;
    }
    if (this.group == GROUP.Config && this.section == '') {
      return false;
    }
    if (this.schema == null) {
      return false;
    }
    try {
      this.schema.validate();
    } catch (err) {
      return false;
    }
    return true;
  }
}

const StyledContainer = styled(Container)(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
});

const StyledContentDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'row',
}));

const StyledTableDiv = styled('div')(({
  paddingBottom: 8,
}));

const StyledSelectForm = styled('form')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  '& .MuiTextField-root': {
    margin: theme.spacing(1),
    marginRight: 0,
  },
  '& .MuiTextField-root:last-child': {
    marginRight: theme.spacing(1),
  },
}));

const StyledSearchForm = styled('form')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  justifyContent: 'flex-end',
  '& .MuiTextField-root:last-child': {
    marginRight: theme.spacing(1),
  },
}));

const StyledCreateForm = styled('form')(({
  flexGrow: 1,
  display: 'flex',
  '& .MuiTextField-root': {
    marginRight: 10,
  },
}));

const StyledTextField = styled(TextField)({
  maxWidth: 200,
});

const StyledSearchField = styled(TextField)({
  maxWidth: 500,
  minWidth: 400,
});

const StyledDialogContent = styled(DialogContent)({
  width: 600,
});

const StyledFilterDiv = styled('div')({
  minHeight: 70,
});

const StyledErrorPaper = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.error.dark,
  padding: theme.spacing(1),
  color: theme.palette.text.primary,
}));

type CreationDialogProps = {
  open: boolean,
  onClose: () => void,
  onCreate: (property: Property) => void,
  group: string,
  section: string,
};

const CreationDialog: React.FC<CreationDialogProps> = ({
  open,
  onClose,
  onCreate,
  group,
  section,
}) => {
  const [data, setData] = useState<PropertyData>(new PropertyData());
  const [errorMessage, setErrorMessage] = useState('');
  const { enqueueSnackbar } = useSnackbar();

  const handleKeyNameChange = (value: string) => {
    setData(data.withKeyName(value));
  };

  const handleGroupChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setData(data.withGroup(event.target.value));
  };

  const handleSectionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setData(data.withSection(event.target.value));
  };

  const handleSchemaChange = (value: JsonSchema) => {
    setData(data.withSchema(value));
  };

  const handleRequiredChange = () => {
    setData(data.withRequired(!data.required));
  };

  const handleDialogClose = () => {
    onClose();
    setErrorMessage('');
  };

  const handleCreate = async () => {
    try {
      const newSchema = data.group !== GROUP.Environment ? data.schema.parse().toObject() : {};
      const res = await createProperty(
        data.keyName,
        newSchema,
        data.required,
        data.group,
        data.section,
      );

      if (res == null) {
        return;
      }
      const message = `Property "${data.keyName}" created.`
      enqueueSnackbar(message, { variant: 'success' });
      onCreate(res);
      handleDialogClose();
      setData(new PropertyData('', data.group, data.section, null));

    } catch (err) {
      if (err instanceof Error) {
        setErrorMessage(err.message);
        console.log(err.message);
      }
    }
  };

  useEffect(() => {
    setData(data.withSection(section));
  }, [section]);

  useEffect(() => {
    setData(data.withGroup(group));
  }, [group]);

  useEffect(() => {
    setData((data) => {
      return new PropertyData(data.keyName, group, section, data.schema);
    });
  }, []);

  return (
    <Dialog
      open={open}
      onClose={handleDialogClose}
      area-labelledby="creation-dialog-title"
    >
      <DialogTitle id="creation-dialog-title">New Property</DialogTitle>
      <StyledDialogContent>
        <StyledCreateForm>
          <StyledTextField
            id="create-group"
            label="Group"
            select
            fullWidth
            value={data.group}
            onChange={handleGroupChange}
          >
            <MenuItem value={GROUP.Config}>{GROUP.Config}</MenuItem>
            <MenuItem value={GROUP.Preference}>{GROUP.Preference}</MenuItem>
            <MenuItem value={GROUP.Environment}>{GROUP.Environment}</MenuItem>
          </StyledTextField>
          <StyledTextField
            id="filter-section"
            label="Section"
            select
            fullWidth
            value={data.section}
            onChange={handleSectionChange}
            disabled={data.group != GROUP.Config}
          >
            <MenuItem value={SECTION.Common}>{SECTION.Common}</MenuItem>
            <MenuItem value={SECTION.Studio}>{SECTION.Studio}</MenuItem>
            <MenuItem value={SECTION.Project}>{SECTION.Project}</MenuItem>
          </StyledTextField>
        </StyledCreateForm>
        <KeyNameField value={data.keyName} onChange={handleKeyNameChange} />
        {data.group && data.group !== GROUP.Environment &&
          <>
            <RequiredCheckbox value={data.required} onChange={handleRequiredChange} />
            <SchemaFields schema={data.schema} onSchemaChange={handleSchemaChange} />
          </>
        }

        {errorMessage &&
          <StyledErrorPaper >{errorMessage}</StyledErrorPaper>
        }
      </StyledDialogContent>
      <DialogActions>
        <Button onClick={handleDialogClose}>Cancel</Button>
        <Button onClick={handleCreate} disabled={!data.isValid()}>Create</Button>
      </DialogActions>
    </Dialog>
  );
};

type ModificationDialogProps = {
  property: Property,
  group: string,
  section: string,
  onClose: () => void,
  onModify: (property: Property) => void,
};

const ModificationDialog: React.FC<ModificationDialogProps> = ({
  property,
  group,
  section,
  onClose,
  onModify,
}) => {
  const [data, setData] = useState<PropertyData>(new PropertyData());
  const [errorMessage, setErrorMessage] = useState('');
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    setData(new PropertyData(
      property.key,
      group,
      section,
      new JsonSchema(property.schema),
      property.required,
    ));
  }, [property]);

  const handleSchemaChange = (value: JsonSchema) => {
    setData(data.withSchema(value));
  };

  const handleRequiredChange = () => {
    setData(data.withRequired(!data.required));
  };

  const handleDialogClose = () => {
    onClose();
    setErrorMessage('');
  };

  const handleModify = async () => {
    try {
      const oldSchema = new JsonSchema(property.schema);
      if (!data.schema.isModifiedFrom(oldSchema) && property.required == data.required) {
        return;
      }
      const updateSchema = data.schema.parse().toObject();
      const res = await updateProperty(
        data.keyName,
        updateSchema,
        data.required,
        group,
        section,
      );
      if (res == null) {
        return;
      }
      const message = `Property "${data.keyName}" modified.`
      enqueueSnackbar(message, { variant: 'success' });
      onModify(res);
      handleDialogClose();
      setData(new PropertyData());
    } catch (err) {
      if (err instanceof Error) {
        setErrorMessage(err.message);
      }
    }
  };

  return (
    <Dialog
      open
      onClose={onClose}
      area-labelledby="modification-dialog-title"
    >
      <DialogTitle id="modification-dialog-title">Modify Property</DialogTitle>
      <StyledDialogContent>
        <KeyNameField value={data.keyName} disabled />
        {data.group !== GROUP.Environment &&
          <>
            <RequiredCheckbox value={data.required} onChange={handleRequiredChange} />
            <SchemaFields
              schema={data.schema}
              onSchemaChange={handleSchemaChange}
              disableOptions={{ type: true }}
            />
          </>
        }
        {errorMessage &&
          <StyledErrorPaper >{errorMessage}</StyledErrorPaper>
        }
      </StyledDialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          onClick={handleModify}
          disabled={data.group === GROUP.Environment || !data.isValid()}
        >
          Modify
        </Button>
      </DialogActions>
    </Dialog>
  );
};

type PropertyPanelProps = {
  settingFilter: SettingFilter,
  setSettingFilter: React.Dispatch<React.SetStateAction<SettingFilter>>,
};

const PropertyPanel: React.FC<PropertyPanelProps> = ({
  settingFilter,
  setSettingFilter,
}) => {
  const { enqueueSnackbar } = useSnackbar();
  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };
  const initSearchProps = {
    searchKey: '',
  };
  const initSortProps: { order: Order, orderBy: string, } = {
    order: 'asc',
    orderBy: 'id',
  };
  const [pageProps, setPageProps] = useState<PageProps>(initPageProps);
  const [searchProps, setSearchProps] = useState<SearchProps>(initSearchProps);
  const [sortProps, setSortProps] = useState<SortProps>(initSortProps);
  const { properties, total, setProperties, setTotal } = useProperties(
    settingFilter.group,
    settingFilter.section,
    pageProps.page,
    pageProps.rowsPerPage,
    sortProps.order,
    sortProps.orderBy,
    searchProps.searchKey,
  );
  const [creationDialogOpen, setCreationDialogOpen] = useState(false);
  const [propertyToModify, setPropertyToModify] = useState<Property | null>(null);
  const [propertyToDelete, setPropertyToDelete] = useState<Property | null>(null);

  const columns = useMemo<Column<Property>[]>(() => [
    {
      id: 'id',
      label: 'ID',
      render: (property) => String(property.id),
      align: 'right',
    },
    {
      id: 'key',
      label: 'Key',
      render: (property) => property.key,
    },
    {
      id: 'type',
      label: 'Type',
      render: (property) => {
        const { schema } = property;
        if (schema.type === 'array') {
          if (typeof schema.items === 'object' && schema.items.type != null) {
            return `Array<${schema.items.type}>`;
          }
          return 'Array';
        }
        return schema.type;
      },
    },
    {
      id: 'actions',
      label: 'Actions',
      component: ActionCell,
    },
  ], []);

  const handleCreationDialogOpen = useCallback(() => {
    setCreationDialogOpen(true);
  }, [setCreationDialogOpen]);

  const handleCreationDialogClose = () => {
    setCreationDialogOpen(false);
  };

  const handlePropertyCreate = (property: Property) => {
    setProperties([...properties, property]);
    setTotal(total + 1);
  };

  const handleModificationDialogClose = () => {
    setPropertyToModify(null);
  };

  const handleDeletionDialogClose = () => {
    setPropertyToDelete(null);
  };

  const handlePropertyModify = (property: Property) => {
    setProperties(properties.map((p) => (p.id === property.id) ? property : p));
  };

  const handlePropertyDelete = async (property: Property) => {
    const controller = new AbortController();
    try {
      await deleteProperty(
        property.key,
        settingFilter.group,
        settingFilter.section,
        controller.signal
      );
      const message = `Property "${property.key}" deleted.`
      enqueueSnackbar(message, { variant: 'success' });
      setProperties(properties.filter((p) => p.id !== property.id));
      const lastPageIndex = Math.ceil(total / pageProps.rowsPerPage) - 1;
      const lastPageRows = total % pageProps.rowsPerPage;
      if (pageProps.page === lastPageIndex && lastPageRows === 1) {
        setPageProps({
          ...pageProps,
          page: Math.max(0, pageProps.page - 1),
        });
      }
      setTotal(total - 1);
    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
      }
      console.log(err);
    } finally {
      controller.abort();
    }
  };

  const handleEditButtonClick = useCallback((property: Property) => {
    setPropertyToModify(property);
  }, [setPropertyToModify]);

  const handleDeleteButtonClick = useCallback((property: Property) => {
    setPropertyToDelete(property);
  }, [setPropertyToDelete]);

  const handleGroupChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setSettingFilter({
      ...settingFilter,
      group:  event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleSectionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setSettingFilter({
      ...settingFilter,
      section: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  const handleSearchKeyChange: TextFieldProps['onChange'] = event => {
    setSearchProps({
      ...searchProps,
      searchKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleSearchKeyKeyPress: TextFieldProps['onKeyPress'] = event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      // TODO send an API request only when hitting the enter key
      return false;
    }
  };

  const tableFooter = <SettingTableFooter
    count={total}
    page={pageProps.page}
    rowsPerPage={pageProps.rowsPerPage}
    onChangePage={handlePageChange}
    onChangeRowsPerPage={handleRowsPerPageChange}
  />;

  return (
    <StyledContainer maxWidth="xl">

      <StyledFilterDiv>
        <StyledPaper>
          <StyledContentDiv>
            <StyledSelectForm
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit}
            >
              <StyledTextField
                id="filter-group"
                label="Group"
                select
                fullWidth
                value={settingFilter.group}
                onChange={handleGroupChange}
              >
                <MenuItem value={GROUP.Config}>{GROUP.Config}</MenuItem>
                <MenuItem value={GROUP.Preference}>{GROUP.Preference}</MenuItem>
                <MenuItem value={GROUP.Environment}>{GROUP.Environment}</MenuItem>
              </StyledTextField>
              <StyledTextField
                id="filter-section"
                label="Section"
                select
                fullWidth
                value={settingFilter.section}
                onChange={handleSectionChange}
                disabled={settingFilter.group != GROUP.Config}
              >
                <MenuItem value={SECTION.Common}>{SECTION.Common}</MenuItem>
                <MenuItem value={SECTION.Studio}>{SECTION.Studio}</MenuItem>
                <MenuItem value={SECTION.Project}>{SECTION.Project}</MenuItem>
              </StyledTextField>
            </StyledSelectForm>
            <StyledSearchForm>
              <StyledSearchField
                id="key-prefix"
                type="search"
                label="Search Key"
                value={searchProps.searchKey}
                onChange={handleSearchKeyChange}
                onKeyPress={handleSearchKeyKeyPress}
              />
            </StyledSearchForm>
            </StyledContentDiv>
        </StyledPaper>
      </StyledFilterDiv>

      <StyledTableDiv>
        <StyledPaper>
          <StyledContentDiv>
          <RecordTable
            columns={columns}
            records={properties}
            onEditButtonClick={handleEditButtonClick}
            onDeleteButtonClick={handleDeleteButtonClick}
            tableFooter={tableFooter}
            sortProps={sortProps}
            setSortProps={setSortProps}
          />
          </StyledContentDiv>
        </StyledPaper>
      </StyledTableDiv>
      <AddFab onClick={handleCreationDialogOpen} />
      <CreationDialog
        open={creationDialogOpen}
        onClose={handleCreationDialogClose}
        onCreate={handlePropertyCreate}
        group={settingFilter.group}
        section={settingFilter.section}
      />

      {propertyToModify && (
        <ModificationDialog
          property={propertyToModify}
          onClose={handleModificationDialogClose}
          onModify={handlePropertyModify}
          group={settingFilter.group}
          section={settingFilter.section}
        />
      )}

      {propertyToDelete && (
        <DeletionDialog
          title="Deletion Confirmation"
          contentText={
            `Are you sure you want to delete property "${propertyToDelete.key}"?`
          }
          onClose={handleDeletionDialogClose}
          onDelete={() => handlePropertyDelete(propertyToDelete)}
        />
      )}
    </StyledContainer>
  );
};

export default PropertyPanel;
