import { Container, Tabs, Toolbar } from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import React, { useEffect, useMemo, useState } from 'react';
import { Redirect, Route, RouteComponentProps, Switch, useRouteMatch } from 'react-router';

import LinkTab from '../LinkTab';
import PropertyPanel from './PropertyPanel';
import { SettingFilter } from './types';
import ValuePanel from './ValuePanel';

const StyledContainer = styled(Container)({
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
});

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  backgroundColor: theme.palette.primary.dark,
  color: 'white',
  padding: 0,
}));

const StyledDiv = styled('div')({
  flexGrow: 1,
  display: 'flex',
  overflow: 'hidden',
});

type PipelineSettingTypes = 'property' | 'value';

type PipelineSettingPanelProps = {
  location: RouteComponentProps['location'],
};

const PipelineSettingPanel: React.FC<PipelineSettingPanelProps> = ({ location }) => {
  const [value, setValue] = useState<PipelineSettingTypes>('property');
  const initFilter = {
    group: '',
    section: '',
    entry: '',
  };
  const [settingFilter, setSettingFilter] = useState<SettingFilter>(initFilter);
  const { path, url } = useRouteMatch();

  const re = useMemo(() => {
    return new RegExp(`^${url.replace('/', '\\/')}\/([a-zA-Z0-9]+)`);
  }, [url]);

  useEffect(() => {
    const matched = re.exec(location.pathname);
    if (matched != null) {
      switch (matched[1]) {
        case 'property':
        case 'value':
          setValue(matched[1]);
          break;
      }
    }
  }, [location, re]);

  const handleChange = (event: React.ChangeEvent<{}>, newValue: any) => {
    setValue(newValue);
  };

  return (
    <StyledContainer maxWidth="xl">
      <StyledToolbar>
        <Tabs value={value} onChange={handleChange}>
          <LinkTab
            to={`${url}/property${location.search}`}
            label="Property"
            value="property"
          />
          <LinkTab
            to={`${url}/value${location.search}`}
            label="Value"
            value="value"
          />
        </Tabs>
      </StyledToolbar>

      <StyledDiv>
        <Switch>
          <Redirect
            from={path}
            exact
            to={`${path}/property${location.search}`}
          />
          <Route
            path={`${path}/property`}
            render={() =>
              <PropertyPanel
                settingFilter={settingFilter}
                setSettingFilter={setSettingFilter}
              />
            }
          />
          <Route
            path={`${path}/value`}
            render={() =>
              <ValuePanel
                settingFilter={settingFilter}
                setSettingFilter={setSettingFilter}
              />
            }
          />
        </Switch>
      </StyledDiv>
    </StyledContainer>
  );
};

export default PipelineSettingPanel;
