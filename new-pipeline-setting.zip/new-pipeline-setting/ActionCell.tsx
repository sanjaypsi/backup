import { IconButton, TableCell } from '@material-ui/core';
import { Delete, Edit } from '@material-ui/icons';
import React from 'react';

import { ColumnComponentProps, Record } from './types';

const ActionCell: <T extends Record>(
  props: ColumnComponentProps<T>,
) => React.ReactElement | null = ({
  value,
  onEditButtonClick,
  onDeleteButtonClick,
}) => {
  const handleEditButtonClick = () => {
    onEditButtonClick(value);
  };

  const handleDeleteButtonClick = () => {
    onDeleteButtonClick(value);
  };

  return (
    <TableCell align="center">
      <IconButton area-label="edit" onClick={handleEditButtonClick}>
        <Edit fontSize="small" />
      </IconButton>
      <IconButton area-label="delete" onClick={handleDeleteButtonClick}>
        <Delete fontSize="small" />
      </IconButton>
    </TableCell>
  );
};

export default ActionCell;
