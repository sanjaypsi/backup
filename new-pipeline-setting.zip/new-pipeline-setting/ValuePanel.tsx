import {
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  List,
  ListItem,
  MenuItem,
  Paper,
  TableCell,
  TextField,
} from '@material-ui/core';
import { makeStyles, styled } from '@material-ui/core/styles';
import { useSnackbar } from 'notistack';
import React, { useCallback, useEffect, useMemo, useState } from 'react';

import ActionCell from './ActionCell';
import AddFab from './AddFab';
import DeletionDialog from './DeletionDialog';
import RecordTable from './RecordTable';
import { createValue, deleteValue, updateValue } from './api';
import { useProperties, useValues } from './hooks';
import {
  Column,
  ColumnComponentProps,
  Property,
  Value,
  GROUP,
  SECTION,
  PageProps,
  SettingFilter,
  SearchProps,
  JsonSchema,
  Order,
  SortProps,
  EnvironmentValue,
  ConfPrefValueType,
  EnvValueType,
  isEnvValueType,
  isConfPrefValueType
} from './types';
import { useProjects } from '../project/hooks';
import SettingTableFooter from './SettingTableFooter';
import { TablePaginationProps } from '@material-ui/core/TablePagination';
import { Project } from '../project/types';
import ValueField from './Field/ValueField';
import { useStudios } from '../studio/hooks';
import { Studio } from '../studio/types';
import { TextFieldProps } from '@material-ui/core/TextField';
import KeyNameField from './Field/KeyNameField';
import SchemaFields from './Field/SchemaFields';
import RequiredCheckbox from './Field/RequiredCheckbox';
import { SearchRounded } from '@material-ui/icons';
import EnvValueFields from './Field/EnvValueFields';

class ValueData {
  readonly section: string;
  readonly group: string;
  readonly entry: string;
  readonly property: Property | null;
  readonly key: string;
  readonly value: ConfPrefValueType | EnvValueType | null;

  constructor(
    group: string = '',
    section: string = '',
    entry: string = '',
    property: Property | null = null,
    key: string = '',
    value: ConfPrefValueType | EnvValueType | null = null,
  ) {
    this.property = property;
    this.group = group;
    this.section = section;
    this.entry = entry;
    this.key = key;
    this.value = value;
  }

  withGroup(group: string): ValueData {
    return new ValueData(
      group,
      this.section,
      this.entry,
      this.property,
      this.key,
      this.value,
    );
  }

  withSection(section: string): ValueData {
    return new ValueData(
      this.group,
      section,
      this.entry,
      this.property,
      this.key,
      this.value,
    );
  }

  withEntry(entry: string): ValueData {
    return new ValueData(
      this.group,
      this.section,
      entry,
      this.property,
      this.key,
      this.value,
    );
  }

  withProperty(property: Property | null): ValueData {
    return new ValueData(
      this.group,
      this.section,
      this.entry,
      property,
      this.key,
      this.value,
    );
  }

  withKey(key: string): ValueData {
    return new ValueData(
      this.group,
      this.section,
      this.entry,
      this.property,
      key,
      this.value,
    );
  }

  withValue(value: ConfPrefValueType | EnvValueType): ValueData {
    return new ValueData(
      this.group,
      this.section,
      this.entry,
      this.property,
      this.key,
      value,
    );
  }

  isValidCreation(): boolean {
    if (this.group === '') {
      return false;
    }
    if (this.section === '') {
      return false;
    }
    if (this.entry === '') {
      return false;
    }
    if (this.value == null) {
      return false;
    }
    if (isEnvValueType(this.value)) {
      const newEnv = new EnvironmentValue(this.value);
      if (!newEnv.isValid()) {
        return false;
      }
    }
    if (!this.key) {
      return false;
    }
    return true;
  }

  isValidModification(oldValue: ConfPrefValueType | EnvValueType): boolean {
    if (this.group === '') {
      return false;
    }
    if (this.section === '') {
      return false;
    }
    if (this.entry === '') {
      return false;
    }
    if (this.key === '') {
      return false;
    }
    if (this.value == null) {
      return false;
    }
    if (isConfPrefValueType(this.value)) {
      const parsedValue = this.parseValue();
      if (parsedValue == null || JSON.stringify(parsedValue) === JSON.stringify(oldValue)) {
        return false;
      }
    } else if (isEnvValueType(this.value)) {
      const newEnv = new EnvironmentValue(this.value);
      if (!newEnv.isValid()) {
        return false;
      }
      const oldEnv = new EnvironmentValue(oldValue as EnvValueType);
      if (newEnv.isEquals(oldEnv)) {
        return false;
      }
    }
    return true;
  }

  parseValue(): ConfPrefValueType | EnvValueType | null {
    if (isEnvValueType(this.value)) {
      return this.value;
    }
    if (!this.property || this.value == null) {
      return null;
    }
    const schema = new JsonSchema(this.property.schema);
    try {
      const strValue = this.value as string;
      switch (schema.getType()) {
      case 'boolean':
        const boolStr = strValue.toLowerCase();
        return (boolStr === 'true' || boolStr === 'false') ? JSON.parse(boolStr) : null;
      case 'integer':
        return parseInt(strValue);
      case 'number':
        return parseFloat(strValue);
      case 'string':
        return strValue;
      case 'array':
        switch (typeof strValue) {
        case 'string':
          return strValue.split(',').map((s: string) => {
            return s.trim();
          });
        default:
          return null;
        }
      default:
        return null;
      }
    } catch (err) {
      console.log(err);
      return null;
    }
  }
};

const useStyles = makeStyles(theme => ({
  dialogPaper: {
    overflow: 'visible',
  },
}));

const StyledContainer = styled(Container)(({ theme }) => ({
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
  padding: 0,
  '& > *': {
    display: 'flex',
    overflow: 'hidden',
    padding: theme.spacing(1),
    paddingBottom: 0,
  },
  '& > *:last-child': {
    paddingBottom: theme.spacing(1),
  },
}));

const StyledPaper = styled(Paper)({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'auto',
});

const StyledDiv = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'row',
}));

const StyledSquareDiv = styled('div')(({ theme }) => ({
  margin: 'auto',
}));

const StyledSelectForm = styled('form')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  '& .MuiTextField-root': {
    margin: theme.spacing(1),
    marginRight: 0,
  },
  '& .MuiTextField-root:last-child': {
    marginRight: theme.spacing(1),
  },
}));

const StyledSearchForm = styled('form')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  justifyContent: 'flex-end',
  '& .MuiTextField-root:last-child': {
    marginRight: theme.spacing(1),
  },
}));

const StyledCreateForm = styled('form')(() => ({
  flexGrow: 1,
  display: 'flex',
  justifyContent: 'space-between',
  '& .MuiTextField-root': {
    marginRight: 10,
  },
}));

const StyledTextField = styled(TextField)({
  maxWidth: 200,
  minWidth: 180,
});

const StyledSearchField = styled(TextField)({
  maxWidth: 500,
  minWidth: 400,
});

const StyledKeyField = styled(TextField)({
  width: '100%',
  minWidth: 180,
});

const StyledKeyList = styled(List)(({ theme }) => ({
  position: 'absolute',
  zIndex: 999,
  backgroundColor: theme.palette.primary.light,
}));

const StyledListItem = styled(ListItem)(({ theme }) => ({
  backgroundColor: theme.palette.primary.dark,
}));


const StyledDialogContent = styled(DialogContent)({
  width: 600,
});

const StyledFilterDiv = styled('div')({
  minHeight: 70,
});

const StyledErrorPaper = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.error.dark,
  padding: theme.spacing(1),
  color: theme.palette.text.primary,
}));

type CreationDialogProps = {
  open: boolean,
  onClose: () => void,
  onCreate: (value: Value, group: string, section: string, entry: string) => void,
  group: string,
  section: string,
  entry: string,
  projects: Project[],
  studios: Studio[],
};

const CreationDialog: React.FC<CreationDialogProps> = ({
  open,
  onClose,
  onCreate,
  group,
  section,
  entry,
  projects,
  studios,
}) => {
  const [data, setData] = useState<ValueData>(new ValueData(group, section, entry));
  const [searchKey, setSearchKey] = useState<string>('');
  const [showsSuggestion, setShowsSuggestion] = useState<boolean>(false);
  const { properties, setProperties } = useProperties(
    data.group,
    data.section,
    0,
    10,
    'asc',
    'id',
    searchKey,
  );
  const [errorMessage, setErrorMessage] = useState('');
  const { enqueueSnackbar } = useSnackbar();
  const classes = useStyles();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setData(data.withKey(event.target.value));
    setShowsSuggestion(false);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case 'Enter':
      case 'Tab':
        event.preventDefault();
        if (!data.group || !data.section || !data.entry) {
          setErrorMessage('Select Group/Section/Entry');
          return;
        }
        setErrorMessage('');
        if (searchKey === data.key) {
          setShowsSuggestion(true);
        }
        setSearchKey(data.key ? data.key : '');
    }
  };

  const handleSearchClick = (event: React.MouseEvent<HTMLElement, MouseEvent>) => {
    event.preventDefault();
    if (!data.group || !data.section || !data.entry) {
          setErrorMessage('Select Group/Section/Entry');
          return;
        }
        setErrorMessage('');
    if (searchKey === data.key) {
      setShowsSuggestion(true);
    }
    setSearchKey(data.key ? data.key : '');
  };

  const handleKeyClick = (event: React.MouseEvent<HTMLInputElement>) => {
    setData(data.withKey(event.currentTarget.id));
    setShowsSuggestion(false);
  };

  const handleGroupChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setData(data.withGroup(event.target.value));
  };

  const handleSectionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setData(data.withSection(event.target.value));
  };

  const handleEntryChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setData(data.withEntry(event.target.value));
  };

  const handleValueChange = (value: ConfPrefValueType | EnvValueType) => {
    setData(data.withValue(value));
  };

  const handleDialogClose = () => {
    onClose();
    setErrorMessage('');
  };

  const handleCreate = async () => {
    try {
      if (!data.property || !data.key) {
        setErrorMessage('Key does not exist');
        return;
      }
      const value = data.parseValue();
      if (!value) {
        setErrorMessage('Invalid value conversion');
        return;
      }
      const res = await createValue(
        data.key,
        value,
        data.group,
        data.section,
        data.entry,
      );
      if (res == null) {
        return;
      }
      const message = `Value of "${data.key}" created.`;
      enqueueSnackbar(message, { variant: 'success' });
      onCreate(res, data.group, data.section, data.entry);
      handleDialogClose();
      setData(new ValueData(data.group, data.section, data.entry));
    } catch (err) {
      if (err instanceof Error) {
        setErrorMessage(err.message);
        console.log(err.message);
      }
    }
  };

  useEffect(() => {
    if (data.group === GROUP.Environment) {
      setData(data.withGroup(group).withValue(new EnvironmentValue().params));
    } else {
      setData(data.withGroup(group).withValue(''));
    }
  }, [group]);

  useEffect(() => {
    setData(data.withSection(section));
  }, [section]);

  useEffect(() => {
    setData(data.withEntry(entry));
  }, [entry]);

  useEffect(() => {
    if (searchKey) {
      setShowsSuggestion(true);
    }
  }, [properties]);

  useEffect(() => {
    if (showsSuggestion) {
      return;
    }
    const property = properties.find((p) => p.key === data.key);
    let newData = data.withProperty(property || null);
    if (data.group === GROUP.Environment) {
      newData = newData.withValue(new EnvironmentValue().params);
    } else {
      newData = newData.withValue('');
    }
    setData(newData);
  }, [properties, data.key, showsSuggestion]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      area-labelledby="creation-dialog-title"
      PaperProps={{ className: classes.dialogPaper }}
    >
      <DialogTitle id="creation-dialog-title">New Value</DialogTitle>
      <DialogContent>
        <StyledCreateForm>
          <StyledTextField
            id="create-group"
            label="Group"
            select
            fullWidth
            value={data.group}
            onChange={handleGroupChange}
          >
            <MenuItem value={GROUP.Config}>{GROUP.Config}</MenuItem>
            <MenuItem value={GROUP.Preference}>{GROUP.Preference}</MenuItem>
            <MenuItem value={GROUP.Environment}>{GROUP.Environment}</MenuItem>
          </StyledTextField>
          <StyledTextField
            id="create-section"
            label="Section"
            select
            fullWidth
            value={data.section}
            onChange={handleSectionChange}
          >
            <MenuItem value={SECTION.Common}>{SECTION.Common}</MenuItem>
            <MenuItem value={SECTION.Studio}>{SECTION.Studio}</MenuItem>
            <MenuItem value={SECTION.Project}>{SECTION.Project}</MenuItem>
          </StyledTextField>
          <StyledTextField
            id="create-entry"
            label="Entry"
            select
            fullWidth
            value={data.entry}
            onChange={handleEntryChange}
          >
            {data.section == SECTION.Common &&
              <MenuItem value="default">default</MenuItem>
            }
            {data.section == SECTION.Studio
              ? studios.length > 0
                ? studios.map((studio) => (
                  <MenuItem key={studio.id} value={studio.key_name}>
                    {studio.key_name}
                  </MenuItem>
                ))
                : <MenuItem disabled>(No Studio)</MenuItem>
              : null
            }
            {data.section == SECTION.Project
              ? projects.length > 0
                ? projects.map((project) => (
                  <MenuItem key={project.id} value={project.key_name}>
                    {project.key_name}
                  </MenuItem>
                ))
                : <MenuItem disabled>(No Project)</MenuItem>
              : null
            }
          </StyledTextField>
        </StyledCreateForm>
        <StyledSearchForm>
          <StyledKeyField
            label="Key"
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            value={data.key}
            required
          />
          <StyledSquareDiv>
            <IconButton color="inherit" onClick={handleSearchClick} >
              <SearchRounded />
            </IconButton>
          </StyledSquareDiv>
        </StyledSearchForm>
        {showsSuggestion
          ? <StyledKeyList>
            {properties.map(prop => {
              if (prop.key === data.key) {
                return (
                  <StyledListItem
                    button
                    id={prop.key}
                    key={prop.key}
                    onClick={handleKeyClick}
                  >
                    {prop.key} (exactly matched)
                  </StyledListItem>
                );
              }
            })}
            {properties.slice(0, 10).map(prop => (
              <StyledListItem
                button
                id={prop.key}
                key={prop.key}
                onClick={handleKeyClick}
              >
                {prop.key}
              </StyledListItem>
            ))}
          </StyledKeyList>
          : null
        }
        {data.property && data.property.schema
          ? data.group !== GROUP.Environment
            ? <>
              <RequiredCheckbox
                disabled
                value={data.property && data.property.required}
                onChange={() => {}}
              />
              <SchemaFields
                schema={data.property && new JsonSchema(data.property.schema)}
                onSchemaChange={() => {}}
                disableOptions={{
                  type: true,
                  minmax: true,
                  pattern: true,
                  default: true,
                  required: true,
                }}
              />
              <ValueField
                value={data.value}
                onChange={handleValueChange}
                schema={data.property && data.property.schema}
              />
            </>
            : <EnvValueFields
              envValue={data.value as EnvValueType}
              onChange={handleValueChange}
            />
          : null
        }
        {errorMessage &&
          <StyledErrorPaper >{errorMessage}</StyledErrorPaper>
        }
      </DialogContent>
      <DialogActions>
        <Button onClick={handleDialogClose}>Cancel</Button>
        <Button onClick={handleCreate} disabled={!data.isValidCreation()}>Create</Button>
      </DialogActions>
    </Dialog>
  );
};

type ModificationDialogProps = {
  value: Value,
  group: string,
  section: string,
  entry: string,
  onClose: () => void,
  onModify: (value: Value) => void,
  property: Property | null,
};

const ModificationDialog: React.FC<ModificationDialogProps> = ({
  value,
  group,
  section,
  entry,
  onClose,
  onModify,
  property,
}) => {
  const [data, setData] = useState<ValueData>(new ValueData(
    group,
    section,
    entry,
    property,
    value.key,
    value.value,
  ));
  const [errorMessage, setErrorMessage] = useState('');
  const { enqueueSnackbar } = useSnackbar();
  useEffect(() => {
    setData(new ValueData(
      group,
      section,
      entry,
      property,
      value.key,
      value.value,
    ));
  }, [property]);

  const handleModify = async () => {
    try {
      const updateKey = group === GROUP.Environment ? String(value.id) : value.key;
      const newValue = data.parseValue();
      console.log(newValue);
      if (!newValue) {
        return;
      }
      const res = await updateValue(
        updateKey,
        newValue,
        group,
        section,
        entry,
      );
      if (res == null) {
        return;
      }
      const message = `Value "${data.value}" is modified to "${value}".`;
      enqueueSnackbar(message, { variant: 'success' });
      onModify(res);
      onClose();
      setData(new ValueData());
    } catch (err) {
      if (err instanceof Error) {
        setErrorMessage(err.message);
      }
    }
  };

  const handleValueChange = (value: ConfPrefValueType | EnvValueType) => {
    setData(data.withValue(value));
  };

  const handleDialogClose = () => {
    onClose();
    setErrorMessage('');
  };

  return (
    <Dialog
      open
      onClose={onClose}
      area-labelledby="modification-dialog-title"
    >
      <DialogTitle id="modification-dialog-title">Modify Value</DialogTitle>
      <StyledDialogContent>
        <KeyNameField value={data.key} disabled/>
        {property && data.group !== GROUP.Environment &&
          <>
            <RequiredCheckbox disabled value={property.required} onChange={() => {}}/>
            <SchemaFields
              schema={new JsonSchema(property.schema)}
              onSchemaChange={() => {}}
              disableOptions={{
                type: true,
                minmax: true,
                pattern: true,
                default: true,
                required: true,
              }}
            />
          </>
        }
        {data.group === GROUP.Environment
          ? <EnvValueFields
            envValue={data.value as EnvValueType}
            onChange={handleValueChange}
          />
          : property && property.schema && <ValueField
            value={data.value}
            onChange={handleValueChange}
            schema={property && property.schema}
          />
        }
        {errorMessage &&
          <StyledErrorPaper >{errorMessage}</StyledErrorPaper>
        }
      </StyledDialogContent>
      <DialogActions>
        <Button onClick={handleDialogClose}>Cancel</Button>
        <Button onClick={handleModify} disabled={!data.isValidModification(value.value)}>
          Modify
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const ValueCell: React.FC<ColumnComponentProps<Value>> = ({ value }) => {
  const text = useMemo(() => {
    if (typeof value.value === 'string') {
      return value.value;
    } else if (Array.isArray(value.value)) {
      return value.value.join(', ');
    } else {
      return JSON.stringify(value.value);
    }
  }, [value]);

  const align = useMemo(() => {
    switch (typeof value.value) {
      case 'boolean':
        return 'center';
      case 'number':
        return 'right';
      default:
        return undefined;
    }
  }, [value]);

  return <TableCell align={align}>{text}</TableCell>;
};

type ValuePanelProps = {
  settingFilter: SettingFilter,
  setSettingFilter: React.Dispatch<React.SetStateAction<SettingFilter>>,
};

const ValuePanel: React.FC<ValuePanelProps> = ({
  settingFilter,
  setSettingFilter,
}) => {
  const { enqueueSnackbar } = useSnackbar();
  const initPageProps = {
    page: 0,
    rowsPerPage: 15,
  };
  const initSearchProps = {
    searchKey: '',
  };
  const initSortProps: { order: Order, orderBy: string, } = {
    order: 'asc',
    orderBy: 'id',
  };
  const [pageProps, setPageProps] = useState<PageProps>(initPageProps);
  const [searchProps, setSearchProps] = useState<SearchProps>(initSearchProps);
  const [sortProps, setSortProps] = useState<SortProps>(initSortProps);
  const { values, total, setValues, setTotal } = useValues(
    settingFilter.group,
    settingFilter.section,
    settingFilter.entry,
    pageProps.page,
    pageProps.rowsPerPage,
    sortProps.order,
    sortProps.orderBy,
    searchProps.searchKey,
  );
  const { projects } = useProjects();
  const { studios } = useStudios();
  const { properties } = useProperties(
    settingFilter.group,
    settingFilter.section,
    0,
    0,
    'asc',
    'id',
    '',
  );
  const [creationDialogOpen, setCreationDialogOpen] = useState(false);
  const [valueToModify, setValueToModify] = useState<Value | null>(null);
  const [valueToDelete, setValueToDelete] = useState<Value | null>(null);

  const columns = useMemo<Column<Value>[]>(() => [
    {
      id: 'id',
      label: 'ID',
      render: (value) => String(value.id),
      align: 'right',
    },
    {
      id: 'key',
      label: 'Key',
      render: (value) => value.key,
    },
    {
      id: 'value',
      label: 'Value',
      component: ValueCell,
    },
    {
      id: 'actions',
      label: 'Actions',
      component: ActionCell,
    },
  ], []);

  const envColumns = useMemo<Column<Value>[]>(() => [
    {
      id: 'id',
      label: 'ID',
      render: (value) => String(value.id),
      align: 'right',
    },
    {
      id: 'prop_key',
      label: 'Property',
      render: (value) => value.key,
    },
    {
      id: 'env_key',
      label: 'key',
      render: (value) => value.value.key,
    },
    {
      id: 'usage',
      label: 'Usage',
      render: (value) => value.value.usage,
    },
    {
      id: 'method',
      label: 'Method',
      render: (value) => value.value.method,
    },
    {
      id: 'os',
      label: 'OS Name',
      render: (value) => value.value.osName,
    },
    {
      id: 'sort',
      label: 'Sort Order',
      render: (value) => value.value.sortOrder,
    },
    {
      id: 'value',
      label: 'Value',
      render: (value) => value.value.value,
    },
    {
      id: 'actions',
      label: 'Actions',
      component: ActionCell,
    },
  ], []);

  const handleCreationDialogOpen = useCallback(() => {
    setCreationDialogOpen(true);
  }, [setCreationDialogOpen]);

  const handleCreationDialogClose = () => {
    setCreationDialogOpen(false);
  };

  const handleValueCreate = (value: Value, group: string, section: string, entry: string) => {
    setValues([...values, value]);
    setTotal(total + 1);
    setSettingFilter({
      group,
      section,
      entry,
    });
  };

  const handleModificationDialogClose = () => {
    setValueToModify(null);
  };

  const handleDeletionDialogClose = () => {
    setValueToDelete(null);
  };

  const handleValueModify = (value: Value) => {
    setValues(values.map((v) => (v.id === value.id) ? value : v));
  };

  const handleValueDelete = async (value: Value) => {
    try {
      const deleteKey = settingFilter.group === GROUP.Environment ? String(value.id) : value.key;
      await deleteValue(deleteKey, settingFilter.group, settingFilter.section, settingFilter.entry);
      const message = `Value of "${value.key}" deleted.`;
      enqueueSnackbar(message, { variant: 'success' });
      setValues(values.filter((v) => v.id !== value.id));
      const lastPageIndex = Math.ceil(total / pageProps.rowsPerPage) - 1;
      const lastPageRows = total % pageProps.rowsPerPage;
      if (pageProps.page === lastPageIndex && lastPageRows === 1) {
        setPageProps({
          ...pageProps,
          page: Math.max(0, pageProps.page - 1),
        });
      }
      setTotal(total - 1);

    } catch (err) {
      if (err instanceof Error) {
        enqueueSnackbar(err.message, { variant: 'error' });
        console.log(err.message);
      }
    }
  };

  const handleEditButtonClick = useCallback((value: Value) => {
    setValueToModify(value);
  }, [setValueToModify]);

  const handleDeleteButtonClick = useCallback((value: Value) => {
    setValueToDelete(value);
  }, [setValueToDelete]);

  const handleGroupChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setSettingFilter({
      ...settingFilter,
      group: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleSectionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setSettingFilter({
      ...settingFilter,
      section: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleEntryChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    setSettingFilter({
      ...settingFilter,
      entry: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  const handleRowsPerPageChange: TablePaginationProps['onChangeRowsPerPage'] = event => {
    setPageProps({
      page: 0,
      rowsPerPage: parseInt(event.target.value),
    });
  };

  const handlePageChange: TablePaginationProps['onChangePage'] = (event, newPage) => {
    setPageProps({
      ...pageProps,
      page: newPage,
    });
  };

  const handleSearchKeyChange: TextFieldProps['onChange'] = event => {
    setSearchProps({
      ...searchProps,
      searchKey: event.target.value,
    });
    setPageProps({ ...pageProps, page: 0 });
  };

  const handleSearchKeyKeyPress: TextFieldProps['onKeyPress'] = event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      // TODO send an API request only when hitting the enter key
      return false;
    }
  };

  const tableFooter = <SettingTableFooter
    count={total}
    page={pageProps.page}
    rowsPerPage={pageProps.rowsPerPage}
    onChangePage={handlePageChange}
    onChangeRowsPerPage={handleRowsPerPageChange}
  />;

  return (
    <StyledContainer maxWidth="xl">
      <StyledFilterDiv>
        <StyledPaper>
          <StyledDiv>
            <StyledSelectForm
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit}
            >
              <StyledTextField
                id="filter-group"
                label="Group"
                select
                fullWidth
                value={settingFilter.group}
                onChange={handleGroupChange}
              >
                <MenuItem value={GROUP.Config}>{GROUP.Config}</MenuItem>
                <MenuItem value={GROUP.Preference}>{GROUP.Preference}</MenuItem>
                <MenuItem value={GROUP.Environment}>{GROUP.Environment}</MenuItem>
              </StyledTextField>
              <StyledTextField
                id="filter-section"
                label="Section"
                select
                fullWidth
                value={settingFilter.section}
                onChange={handleSectionChange}
                disabled={settingFilter.group == ''}
              >
                <MenuItem value={SECTION.Common}>{SECTION.Common}</MenuItem>
                <MenuItem value={SECTION.Studio}>{SECTION.Studio}</MenuItem>
                <MenuItem value={SECTION.Project}>{SECTION.Project}</MenuItem>
              </StyledTextField>
              <StyledTextField
                id="filter-entry"
                label="Entry"
                select
                fullWidth
                value={settingFilter.entry}
                onChange={handleEntryChange}
                disabled={settingFilter.section == ''}
              >
                {settingFilter.section == SECTION.Common &&
                  <MenuItem value="default">default</MenuItem>
                }
                {settingFilter.section == SECTION.Studio
                  ? studios.length > 0
                    ? studios.map((studio) => (
                      <MenuItem key={studio.id} value={studio.key_name}>
                        {studio.key_name}
                      </MenuItem>
                    ))
                    : <MenuItem disabled>(No Studio)</MenuItem>
                  : null
                }
                {settingFilter.section == SECTION.Project
                  ? projects.length > 0
                    ? projects.map((project) => (
                      <MenuItem key={project.id} value={project.key_name}>
                        {project.key_name}
                      </MenuItem>
                    ))
                    : <MenuItem disabled>(No Project)</MenuItem>
                  : null
                }
              </StyledTextField>
            </StyledSelectForm>
            <StyledSearchForm>
              <StyledSearchField
                id="key-prefix"
                type="search"
                label="Search Key"
                value={searchProps.searchKey}
                onChange={handleSearchKeyChange}
                onKeyPress={handleSearchKeyKeyPress}
              />
            </StyledSearchForm>
          </StyledDiv>
        </StyledPaper>
      </StyledFilterDiv>

      <div>
        <StyledPaper>
          <StyledDiv>
            <RecordTable
              columns={settingFilter.group == GROUP.Environment ? envColumns : columns}
              records={values}
              onEditButtonClick={handleEditButtonClick}
              onDeleteButtonClick={handleDeleteButtonClick}
              tableFooter={tableFooter}
              sortProps={sortProps}
              setSortProps={setSortProps}
            />
          </StyledDiv>
        </StyledPaper>
      </div>
      <AddFab onClick={handleCreationDialogOpen} />
      <CreationDialog
        open={creationDialogOpen}
        onClose={handleCreationDialogClose}
        onCreate={handleValueCreate}
        group={settingFilter.group}
        section={settingFilter.section}
        entry={settingFilter.entry}
        projects={projects}
        studios={studios}
      />

      {valueToModify && (
        <ModificationDialog
          value={valueToModify}
          group={settingFilter.group}
          section={settingFilter.section}
          entry={settingFilter.entry}
          onClose={handleModificationDialogClose}
          onModify={handleValueModify}
          property={properties.find((p) => p.key === valueToModify.key) || null}
        />
      )}

      {valueToDelete && (
        <DeletionDialog
          title="Deletion Confirmation"
          contentText={`Are you sure you want to delete value "${valueToDelete.value}"?`}
          onClose={handleDeletionDialogClose}
          onDelete={() => handleValueDelete(valueToDelete)}
        />
      )}

    </StyledContainer>
  );
};

export default ValuePanel;
